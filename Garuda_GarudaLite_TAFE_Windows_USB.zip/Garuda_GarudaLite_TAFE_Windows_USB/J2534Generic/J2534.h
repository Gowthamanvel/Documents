/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J2534.h
 Description			: This is the main header file for J2534
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

  File		 Date			Author						Description
  Version
_____________________________________________________________________________
 
  1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
*****************************************************************************/

#ifndef _J2534_H_
#define _J2534_H_


#define  __declspec(dllexport)

// J2534 API Document Version String.
#define J2534_APIDOC_VERSION TEXT("04.04")


//User defined macros
#define PASSTHRU_MSG_DATA_SIZE		4128
#define J2534_TX_MSG_BUFFER_SIZE	4096
#define J2534_RX_MSG_BUFFER_SIZE	4096


// Connect Flag Bits
#define J2534_CONNECT_FLAGBIT_CAN29BIT	0x00000100 // Bit 8
#define J2534_CONNECT_FLAGBIT_NOCHKSUM	0x00000200 // Bit 9
#define J2534_CONNECT_FLAGBIT_CANBOTH	0x00000800 // Bit 11
#define J2534_CONNECT_FLAGBIT_KONLY		0x00001000 // Bit 12

// Tx Flag Bits
#define	J2534_TX_FLAGBIT_CAN29BIT		0x00000100 // Bit 8

// Rx Flag Bits
#define	J2534_RX_FLAGBIT_MSGTYPE		0x00000001 // Bit 0
#define	J2534_RX_FLAGBIT_CAN29BIT		0x00000100 // Bit 0



#define J2534_TX_MSG_SIZE	sizeof(PASSTHRU_MSG)
#define J2534_RX_MSG_SIZE	sizeof(PASSTHRU_MSG)


//Tx and Rx Flags definition used with PASSTHRU Message structure

#define TX_MSG_TYPE				(1<<0) /*Bit 0:- Receive Indication/Transmit Loopback
												 0 = received 
												 i.e. this message was transmitted on 
												 the bus by another node,
												 1 = transmitted 
												 i.e. this is the  echo of the message
												 transmitted by the PassThru device 
												 (received only if loopback is turned on)*/

#define START_OF_MESSAGE	    (1<<1) /*Bit 1:- Indicates the reception of the first
												 byte of an ISO9141 or ISO14230
												 message or first frame of an ISO15765 
												 multi-frame message 
												 0 = Not a start of message indication
												 1 = First byte or frame received*/

#define RX_BREAK				(1<<2) /*Bit 2:- Break indication received SAE J2610 and 
												 SAE J1850 VPW only
												 0 = No break received
												 1 = Break received*/


#define ISO15765_TX_DONE        (1<<3) /*Bit 3:- ISO15765 TxDone indication- CANID and 
												 extended address, if Present, shall be 
												 included in the Message structure
												 0= No TxDone
												 1= TxDone*/

#define ISO15765_PADDING_ERROR	(1<<4) /*Bit 4:- For ProtocolID ISO 15765 a CAN
												 frame was received with less than 8
												 data bytes.
												 0 = No Error
												 1 = Padding Error*/

#define ISO15765_ADDR_TYPE	    (1<<7) /*Bit 7:- ISO 15765-2 Addressing Method 
												 0= no extended address,
												 1= extended address is first
												 byte after the CAN ID */

#define CAN_29BIT_ID   			(1<<8) /*Bit 8:- CAN ID type for CAN And ISO15765
												 0 = 11-bit, 1 = 29-bit*/

#define ISO15765_FRAME_PAD		(1<<6)
/*Jayasheela-Added range for the buadrate (5-500000)*/
#define DATA_RATE_MIN			0x5
#define DATA_RATE_MAX			0x7A120

//added for data log
#define J2534REGISTRY_KEY_PATH          "Software\\PassThruSupport.04.04"
#define J2534REGISTRY_COMPANY		"Dearborn Electronics India Pvt Ltd. - Garuda"
#define J2534REGISTRY_MAX_STRING_LENGTH     1024
// J2534 Message Structure
typedef struct
{
	unsigned long ulProtocolID;
	unsigned long ulRxStatus;
	unsigned long ulTxFlags;
	unsigned long ulTimeStamp;
	unsigned long ulDataSize;
	unsigned long ulExtraDataIndex;
	unsigned char ucData[PASSTHRU_MSG_DATA_SIZE];
}
PASSTHRU_MSG; 

/* Ravi : Changed SW_ISO15765_PS from 0x87 to 0x8007 and 
	SW_CAN_PS from 0x88 to 0x8008 as per J2534 Part II */
//J2534 Protocol definitions
typedef enum
{
	J1850VPW			= 0x01,					// J1850VPW Protocol
	J1850PWM			= 0x02,					// J1850PWM Protocol
	ISO9141				= 0x03,					// ISO9141 Protocol
	ISO14230			= 0x04,					// ISO14230 Protocol
	CAN					= 0x05,					// CAN Protocol
	ISO15765			= 0x06,					// ISO15765 Protocol	
	SCI_A_ENGINE		= 0x07,					// J2610(Configuration A for engine) 
	SCI_A_TRANS			= 0x08,					// J2610(Configuration A for transmission) 
	SCI_B_ENGINE		= 0x09,					// J2610(Configuration B for engine) 
	SCI_B_TRANS			= 0x0A,					// J2610(Configuration B for transmission) 
	SW_ISO15765_PS		= 0x87,				// Single Wire CAN ISO 15765 as per J2534 -2
	SW_CAN_PS			= 0x88,				// Single Wire CAN Raw CAN as per J2534 -2
	CCD					= 0xC2,				// CCD as per J2534 - 2
	CAN_CH1				= 0x90,				//CAN 2 channel for SDK- DLL communication
	ISO15765_CH1		= 0x94,				//CAN 2 channel for SDK- DLL communication
	J1939_PS			= 0x100,
	J1939_CH1			= 0xC6,
	J1939_CH2			= 0xC7,
	
	//**** NOTE TO J2534 IMPLEMENTER **** 
	//		 ALWAYS ADD NEW PROTOCOL
	//		 BEFORE J2534_PROTOCOL_NUM
	//		 SO THAT THIS VALUE AUTOMATICALLY
	//		 GETS UPDATED WHEN A NEW PROTOCOL
	//		 IS ADDED.
	J2534_PROTOCOL_NUM
}
J2534_PROTOCOL;

// Ioctl ID Command Values
typedef enum
{
	
	GET_CONFIG                          = 0x01,
	SET_CONFIG							= 0x02,
	READ_VBATT							= 0x03,
	FIVE_BAUD_INIT						= 0x04,
	FAST_INIT							= 0x05,
	SET_PIN_USE							= 0x06,
	CLEAR_TX_BUFFER						= 0x07,
	CLEAR_RX_BUFFER						= 0x08,
	CLEAR_PERIODIC_MSGS					= 0x09,
	CLEAR_MSG_FILTERS					= 0x0A,
	CLEAR_FUNCT_MSG_LOOKUP_TABLE		= 0x0B,
	ADD_TO_FUNCT_MSG_LOOKUP_TABLE		= 0x0C,
	DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE	= 0x0D,
	READ_PROG_VOLTAGE					= 0x0E,
	SW_CAN_HS							= 0x80,
	SW_CAN_NS							= 0x87,
	PROTECT_J1939_ADDR					= 0x00008009,
} 
J2534IOCTLID;

// Ioctl Parameter ID Values
typedef enum 
{
	DATA_RATE			= 0x01,
    //Unused			= 0x02,		Reserved for SAE,
	LOOPBACK			= 0x03,		// 0 (OFF) 1 (ON)
	NODE_ADDRESS		= 0x04,		//Range 0x00-0xFF
	NETWORK_LINE		= 0x05,		//0 (BUS_NORMAL) 1 (BUS_PLUS) 2 (BUS_MINUS)
	P1_MIN				= 0x06,      
	P1_MAX				= 0x07,		
	P2_MIN				= 0x08, 
	P2_MAX				= 0x09,
	P3_MIN				= 0x0A,   
	P3_MAX			    = 0x0B,		
	P4_MIN				= 0x0C, 
	P4_MAX				= 0x0D,
	W1					= 0x0E,
	W2					= 0x0F, 
	W3					= 0x10,
	W4					= 0x11, 
	W5					= 0x12,
	TIDLE				= 0x13,
	TINIL				= 0x14,
	TWUP				= 0x15,
	PARITY				= 0x16,		//0 (NO_PARITY) 1 (ODD_PARITY) 2 (EVEN_PARITY)
									//0 For a protocol ID of ISO9141 or ISO14230 only.
	BIT_SAMPLE_POINT	= 0x17,
	SYNC_JUMP_WIDTH		= 0x18,
	W0					= 0x19, 
	T1_MAX				= 0x1A,
	T2_MAX				= 0x1B,
	T4_MAX				= 0x1C,
	T5_MAX				= 0x1D,
	ISO15765_BS			= 0x1E,
	ISO15765_STMIN		= 0x1F,
	DATA_BITS			= 0x20,
	FIVE_BAUD_MOD		= 0x21,
	BS_TX				= 0x22,
	STMIN_TX			= 0x23,
	T3_MAX				= 0x24,
	ISO15765_WFT_MAX	= 0x25,
	CAN_MIXED_FORMAT	= 0x80,
	J1962_PINS			= 0x81,
	SWCAN_HS_DATA_RATE	= 0x90,
	SWCAN_SPEEDCHANGE_ENABLE = 0x91,
	SWCAN_RES_SWITCH    = 0x92,	
	J1939_T1			= 0x0000803F,
	J1939_T2			= 0x00008040,
	J1939_T3			= 0x00008041,
	J1939_T4			= 0x00008042,
	J1939_BRDCST_MIN_DELAY	= 0x00008043,
}
J2534_IOCTLPARAMID;

// J2534 Error codes
typedef enum
{
	J2534_STATUS_NOERROR		    = 0,	// Function call successful.
	J2534_ERR_NOT_SUPPORTED,			// Function not supported.
	J2534_ERR_INVALID_CHANNEL_ID,		// Invalid ChannelID value.
	J2534_ERR_INVALID_PROTOCOL_ID,		// Invalid ProtocolID value.
	J2534_ERR_NULLPARAMETER,			// NULL pointer supplied where a valid 
										// pointer
										// is required.
	J2534_ERR_INVALID_IOCTL_VALUE,		// Invalid value for Ioctl parameter 
	J2534_ERR_INVALID_FLAGS,			// Invalid flag values.
	J2534_ERR_FAILED,					// Undefined error, use 
										// PassThruGetLastError for description
										// of error.
	J2534_ERR_INVALID_DEVICE_ID,		// Device not connected to PC 										
	J2534_ERR_TIMEOUT,					// Timeout. No message available to 
										// read or 
										// could not read the specified no. of 
										// msgs.
	J2534_ERR_INVALID_MSG,				// Invalid message structure pointed 
										// to by pMsg.
	J2534_ERR_INVALID_TIME_INTERVAL,	// Invalid TimeInterval value.
	J2534_ERR_EXCEEDED_LIMIT,			// ALL periodic message IDs have been 
										// used.
	J2534_ERR_INVALID_MSG_ID,			// Invalid MsgID value.
	J2534_ERR_DEVICE_IN_USE,			// Device already open and/or in use
	J2534_ERR_INVALID_IOCTL_ID,			// Invalid IoctlID value.
	J2534_ERR_BUFFER_EMPTY,				// Protocol message buffer empty.
	J2534_ERR_BUFFER_FULL,				// Protocol message buffer full.
	J2534_ERR_BUFFER_OVERFLOW,			// Protocol message buffer overflow.
	J2534_ERR_PIN_INVALID,				// Invalid pin number.
	J2534_ERR_CHANNEL_IN_USE,			// Channel already in use.
	J2534_ERR_MSG_PROTOCOL_ID,			// Protocol type does not match the
										// protocol associated with the 
										// Channel ID
	J2534_ERR_INVALID_FILTER_ID,		// Invalid MsgID value
	J2534_ERR_NO_FLOW_CONTROL,			// An attempt was made to send a message
										// on an ISO15765 ChannelID before a flow
										// control filter was established.	
	J2534_ERR_NOT_UNIQUE,				// A CAN ID in PatternMsg or FlowControlMsg
										// matches either ID in an existing Flow Control 
										// Filter
    J2534_ERR_INVALID_BAUDRATE,			// Desired baud rate cannot be achieved within 
										// tolerances			
	J2534_ERR_DEVICE_NOT_CONNECTED	= 0x20,// Device not connected
	J2534_ERR_ADDRESS_NOT_CLAIMED			= 0x00010000, //Address not claimed for J1939
} 
J2534ERROR;

//Filter Configuiration
typedef enum
{
	J2534_FILTER_NONE,         
	J2534_FILTER_PASS, 	
	J2534_FILTER_BLOCK,
	J2534_FILTER_FLOW_CONTROL 
} 
J2534_FILTER;


// SCONFIG Structure
typedef struct
{
	J2534_IOCTLPARAMID Parameter;	// name of parameter
	unsigned long ulValue;			// value of the parameter
}
SCONFIG;

// SCONFIG_LIST Structure
typedef struct
{
	unsigned long ulNumOfParams;	// number of SCONFIG elements
	SCONFIG *pConfigPtr;			// array of SCONFIG
}
SCONFIG_LIST;

// SBYTE_ARRAY Structure
typedef struct
{
	unsigned long ulNumOfBytes;		// number of bytes in the array
	unsigned char *pucBytePtr;		// array of bytes
}
SBYTE_ARRAY;


//Declaration of Exported functions to the user application
extern "C" J2534ERROR  WINAPI PassThruOpen(void *pName,
										   unsigned long *pulDeviceID);

extern "C" J2534ERROR  WINAPI PassThruClose(unsigned long ulDeviceID);

extern "C" J2534ERROR  WINAPI PassThruConnect(unsigned long ulDeviceID,
											  J2534_PROTOCOL enumProtocolID,
											  unsigned long ulFlags,
											  unsigned long ulBaudRate,
											  unsigned long *pulChannelID);

extern "C" J2534ERROR  WINAPI PassThruDisconnect(unsigned long ulChannelID);

extern "C" J2534ERROR  WINAPI PassThruReadMsgs(unsigned long ulChannelID,
											   PASSTHRU_MSG  *pMsg,
											   unsigned long *pulNumMsgs,
											   unsigned long ulTimeout);

extern "C" J2534ERROR  WINAPI PassThruWriteMsgs(unsigned long ulChannelID,
											    PASSTHRU_MSG	   *pMsg,
											    unsigned long *pulNumMsgs,
											    unsigned long ulTimeout);

extern "C" J2534ERROR  WINAPI PassThruStartPeriodicMsg(unsigned long ulChannelID, 
													   PASSTHRU_MSG *pMsgJ2534, 
													   unsigned long *pulMsgID, 
													   unsigned long ulTimeInterval);
extern "C" J2534ERROR  WINAPI PassThruUpdatePeriodicMsg(unsigned long ulChannelID, 
													   PASSTHRU_MSG *pMsgJ2534, 
													   unsigned long ulMsgID, 
													   unsigned long ulTimeInterval);

extern "C" J2534ERROR  WINAPI PassThruStopPeriodicMsg(unsigned long ulChannelID,
													  unsigned long ulMsgID);

extern "C" J2534ERROR  WINAPI PassThruStartMsgFilter(unsigned long	ulChannelID,
													 J2534_FILTER	enumFilterType,
													 PASSTHRU_MSG	*pstrucJ2534Mask,
													 PASSTHRU_MSG	*pstrucJ2534Pattern,
													 PASSTHRU_MSG	*pstrucJ2534FlowControl,
													 unsigned long *pulFilterID);

extern "C" J2534ERROR  WINAPI PassThruStopMsgFilter(unsigned long ulChannelID,
													unsigned long ulFilterID);

extern "C" J2534ERROR  WINAPI PassThruSetProgrammingVoltage(unsigned long ulDeviceID,
															unsigned long ulPin,
														    unsigned long ulVoltage);

extern "C" J2534ERROR  WINAPI PassThruReadVersion(unsigned long	ulDeviceID,
												  char *pFirmwareVersion,
												  char *pDllVersion,
												  char *pApiVersion);

extern "C" J2534ERROR  WINAPI PassThruGetLastError(char *pErrorDescription);

extern "C" J2534ERROR  WINAPI PassThruIoctl(unsigned long ulChannelID,
											J2534IOCTLID enumIoctlID,
											void *pInput,
											void *pOutput);


#ifdef GARUDA_TOOL
	extern "C" J2534ERROR  WINAPI LoggingStatus(unsigned long ulDeviceID,unsigned long bLogFlag,SYSTEMTIME *Time);
#endif
	void IsDebugLogEnable();
	void SetPathForLog();
#endif

