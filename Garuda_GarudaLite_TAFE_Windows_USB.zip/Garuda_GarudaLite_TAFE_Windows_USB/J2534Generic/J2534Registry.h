/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J2534Registry.h
 Description			: interface for the CJ2534Registry class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 29, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#if !defined(AFX_J2534REGISTRY_H__D6F4DEA2_DBCE_4DDA_BAEC_55ABA3E051CA__INCLUDED_)
#define AFX_J2534REGISTRY_H__D6F4DEA2_DBCE_4DDA_BAEC_55ABA3E051CA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/*Directive for switching between Garuda and Innova DLL configuration*/
#define GARUDA_TOOL 

//Macros
#define J2534REGISTRY_MAX_STRING_LENGTH		1024
#define J2534REGISTRY_MINI_STRING_LENGTH	128

#ifdef GARUDA_TOOL
//Garuda OEM TOOL Registry Settings.
#define J2534REGISTRY_KEY_PATH			"Software\\PassThruSupport.04.04"
#define J2534REGISTRY_DEVICE_ID			"DeviceId"
#define J2534REGISTRY_NAME				"Name"
#define J2534REGISTRY_COMPANY_NAME		"Dearborn Electronics India Pvt Ltd."
#define J2534REGISTRY_DEVICES			"Devices"
#define J2534REGISTRY_DOUBLE_BACKSLASH	"\\"
#define J2534REGISTRY_HYPHEN_SPACE		" - "
#define J2534REGISTRY_5000OEM_TOOL		"Garuda"
#define J2534REGISTRY_VENDOR			"Vendor"
#define J2534REGISTRY_NAME				"Name"
#define J2534REGISTRY_PROTOCOLSSUPPORT	"ProtocolsSupported"
#define J2534REGISTRY_CONFIGAPP			"ConfigApplication"
#define J2534REGISTRY_FUNCLIB			"FunctionLibrary"
#define J2534REGISTRY_APIVERSION		"APIVersion"
#define J2534REGISTRY_PRODUCTVERSION	"ProductVersion"
#define J2534REGISTRY_LOGGING			"Logging"
#define J2534REGISTRY_LOGGINGDIRECTORY	"LoggingDirectory"
#define J2534REGISTRY_CAN				"CAN"
#define J2534REGISTRY_ISO15765			"ISO15765"
#define J2534REGISTRY_J1850PWM			"J1850PWM"
#define J2534REGISTRY_J1850VPW			"J1850VPW"
#define J2534REGISTRY_ISO9141			"ISO9141"
#define J2534REGISTRY_ISO14230			"ISO14230"
#define J2534REGISTRY_SCI_A_ENGINE		"SCI_A_ENGINE"
#define J2534REGISTRY_SCI_A_TRANS		"SCI_A_TRANS"
#define J2534REGISTRY_SCI_B_ENGINE		"SCI_B_ENGINE"
#define J2534REGISTRY_SCI_B_TRANS		"SCI_B_TRANS"
#define J2534REGISTRY_SWCAN_ISO15765_PS	"SWCAN_ISO15765_PS"
#define J2534REGISTRY_SWCAN_PS			"SWCAN_PS"
#define J2534REGISTRY_CCD				"CCD"

#else
//Innova OEM TOOL Registry Settings.
#define J2534REGISTRY_KEY_PATH			"Software\\PassThruSupport.04.04"
#define J2534REGISTRY_DEVICE_ID			"DeviceId"
#define J2534REGISTRY_NAME				"Name"
#define J2534REGISTRY_COMPANY_NAME		"Innova Electronics Corporation"
#define J2534REGISTRY_DOUBLE_BACKSLASH	"\\"
#define J2534REGISTRY_HYPHEN_SPACE		" - "
#define J2534REGISTRY_5000OEM_TOOL		"Innova - 5000 TOOL"
#define J2534REGISTRY_VENDOR			"Vendor"
#define J2534REGISTRY_PROTOCOLSSUPPORT	"ProtocolsSupported"
#define J2534REGISTRY_CONFIGAPP			"ConfigApplication"
#define J2534REGISTRY_FUNCLIB			"FunctionLibrary"
#define J2534REGISTRY_APIVERSION		"APIVersion"
#define J2534REGISTRY_PRODUCTVERSION	"ProductVersion"
#define J2534REGISTRY_LOGGING			"Logging"
#define J2534REGISTRY_LOGGINGDIRECTORY	"LoggingDirectory"
#define J2534REGISTRY_CAN				"CAN"
#define J2534REGISTRY_ISO15765			"ISO15765"
#define J2534REGISTRY_J1850PWM			"J1850PWM"
#define J2534REGISTRY_J1850VPW			"J1850VPW"
#define J2534REGISTRY_ISO9141			"ISO9141"
#define J2534REGISTRY_ISO14230			"ISO14230"
#define J2534REGISTRY_SCI_A_ENGINE		"SCI_A_ENGINE"
#define J2534REGISTRY_SCI_A_TRANS		"SCI_A_TRANS"
#define J2534REGISTRY_SCI_B_ENGINE		"SCI_B_ENGINE"
#define J2534REGISTRY_SCI_B_TRANS		"SCI_B_TRANS"
#define J2534REGISTRY_SWCAN_ISO15765_PS	"SW_ISO15765_PS"
#define J2534REGISTRY_SWCAN_PS			"SW_CAN_PS"
#define J2534REGISTRY_CCD				"CCD"

#endif



typedef enum
{
	J2534REGISTRY_DEVICE_INNOVA_OEMTOOL = 0x01,
	J2534REGISTRY_INVALID_DEVICE
}
J2534REGISTRY_DEVICE_TYPE;

typedef enum
{
	J2534REGISTRY_ERR_SUCCESS = 0x00,
	J2534REGISTRY_ERR_DEVICE_NOT_FOUND,
	J2534REGISTRY_ERR_NULL_PARAMETER,
	J2534REGISTRY_ERR_INSUFFICIENT_WRITING_PRIVILEGE,
	J2534REGISTRY_ERR_NO_DATA_KEY_VALUE
}
J2534REGISTRY_ERROR_TYPE;

typedef struct 
{
	char chCommPort[J2534REGISTRY_MAX_STRING_LENGTH];
}
J2534REGISTRY_CONFIG_INNOVA_OEMTOOL;

typedef union
{
	J2534REGISTRY_CONFIG_INNOVA_OEMTOOL stJ2534RegConfigOEMTool;
}
J2534REGISTRY_DEVICE;

typedef struct 
{
	DWORD	dwDeviceId;
	char	chVendor[J2534REGISTRY_MAX_STRING_LENGTH];
	char	chName[J2534REGISTRY_MAX_STRING_LENGTH];
	char	chProtocolSupported[J2534REGISTRY_MAX_STRING_LENGTH];
	DWORD	dwCAN;
	DWORD	dwISO15765;
	DWORD	dwJ1850PWM;
	DWORD	dwJ1850VPW;
	DWORD	dwISO9141;
	DWORD	dwISO14230;
	DWORD	dwSCIAEng;
	DWORD	dwSCIATrans;
	DWORD	dwSCIBEng;
	DWORD	dwSCIBTrans;
	DWORD	dwSWISO15765PS;
	DWORD	dwSWCANPS;
	DWORD	dwCCD;
	char	chConfigApplication[J2534REGISTRY_MAX_STRING_LENGTH];
	char	chFunctionLibrary[J2534REGISTRY_MAX_STRING_LENGTH];
	char	chAPIVersion[J2534REGISTRY_MAX_STRING_LENGTH];	
	char	chProductVersion[J2534REGISTRY_MAX_STRING_LENGTH];	
	DWORD	dwLogging;
	char	chLoggingDirectory[J2534REGISTRY_MAX_STRING_LENGTH];
						
	J2534REGISTRY_DEVICE_TYPE	enJ2534RegistryDeviceType; 
	J2534REGISTRY_DEVICE		unJ2534RegistryDevice;
	
} J2534REGISTRY_CONFIGURATION;



class CJ2534Registry  
{
public:
	public:
		CJ2534Registry();
		~CJ2534Registry();
		//Operations
		J2534REGISTRY_ERROR_TYPE GetRegistry(
			J2534REGISTRY_CONFIGURATION* pstJ2534RegistryConfig);
		J2534REGISTRY_ERROR_TYPE WriteToRegistry(
			J2534REGISTRY_CONFIGURATION* pstJ2534RegistryConfig);
	private:
		//Operations
		BOOL FindJ2534Entry(HKEY **phTempkey,
			char chJ2534DeviceName[J2534REGISTRY_MAX_STRING_LENGTH]);
		void CreateWriteKeyValues(HKEY *thiskey,
			J2534REGISTRY_CONFIGURATION stJ2534RegistryConfig);
};

#endif // !defined(AFX_J2534REGISTRY_H__D6F4DEA2_DBCE_4DDA_BAEC_55ABA3E051CA__INCLUDED_)
