// J2534Generic.h : main header file for the J2534GENERIC DLL
//

#if !defined(AFX_J2534GENERIC_H__1F6C5E34_431D_49B5_AF11_4A043BD62F02__INCLUDED_)
#define AFX_J2534GENERIC_H__1F6C5E34_431D_49B5_AF11_4A043BD62F02__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "J2534Registry.h"


#define J2534MAIN_ERROR_TEXT_SIZE		80


/////////////////////////////////////////////////////////////////////////////
// CJ2534GenericApp
// See J2534Generic.cpp for the implementation of this class
//

class CJ2534GenericApp : public CWinApp
{
public:
	CJ2534GenericApp();
	~CJ2534GenericApp();
	
	//Variable Declaration
	BOOL							m_bRegistryRead;
	J2534REGISTRY_CONFIGURATION		m_J2534Registry;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJ2534GenericApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CJ2534GenericApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_J2534GENERIC_H__1F6C5E34_431D_49B5_AF11_4A043BD62F02__INCLUDED_)
