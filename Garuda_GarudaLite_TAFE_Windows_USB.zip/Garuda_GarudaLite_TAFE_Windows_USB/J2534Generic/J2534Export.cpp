/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J2534Export.cpp
 Description			: This is the main header file for J2534
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				:
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 29, 2008	Chakravarthy				Initial Version


_______________________________________________________________________________
******************************************************************************/

#include "StdAfx.h"
#include "J2534Generic.h"
#include "J2534.h"

#include "winbase.h"
#include <Setupapi.h>
#define BUFF_LEN 20
#include <string>
#include <chrono>
#include <thread>
#pragma comment (lib, "Setupapi.lib")
HANDLE								hSerCom;
BOOL GetComPort(TCHAR* pszComePort, const WCHAR* vid, const WCHAR* pid);
bool LoadGarudaDevice();
bool UnLoadGarudaDevice();
bool IsGarudaLiteDevicePlugged();

int Init_FunctionPointers();
HINSTANCE hModule;

/*Exported Function Pointers*/
typedef long (CALLBACK* PTOPEN)(void*, unsigned long*);
typedef long (CALLBACK* PTCLOSE)(unsigned long);
typedef long (CALLBACK* PTCONNECT)(unsigned long, unsigned long, unsigned long,
	unsigned long, unsigned long*);
typedef long (CALLBACK* PTDISCONNECT)(unsigned long);
typedef long (CALLBACK* PTREADMSGS)(unsigned long, void*, unsigned long*, unsigned long);
typedef long (CALLBACK* PTWRITEMSGS)(unsigned long, void*, unsigned long*, unsigned long);
typedef long (CALLBACK* PTSTARTPERIODICMSG)(unsigned long, void*, unsigned long*,
	unsigned long);
typedef long (CALLBACK* PTUPDATEPERIODICMSG)(unsigned long, void*, unsigned long , unsigned long);
typedef long (CALLBACK* PTSTOPPERIODICMSG)(unsigned long, unsigned long);
typedef long (CALLBACK* PTSTARTMSGFILTER)(unsigned long, unsigned long, void*, void*, void*,
	unsigned long*);
typedef long (CALLBACK* PTSTOPMSGFILTER)(unsigned long, unsigned long);
typedef long (CALLBACK* PTSETPROGRAMMINGVOLTAGE)(unsigned long, unsigned long, unsigned long);
typedef long (CALLBACK* PTREADVERSION)(unsigned long, char*, char*, char*);
typedef long (CALLBACK* PTGETLASTERROR)(char*);
typedef long (CALLBACK* PTIOCTL)(unsigned long, unsigned long, void*, void*);
typedef long (CALLBACK* PTLOADFIRMWARE)(void);
typedef long (CALLBACK* PTRECOVERFIRMWARE)(void);
typedef long (CALLBACK* PTREADIPSETUP)(char*, char*, char*, char*, char*);
typedef long (CALLBACK* PTWRITEIPSETUP)(char*, char*, char*, char*, char*);
typedef long (CALLBACK* PTREADPCSETUP)(char*, char*);
typedef long (CALLBACK* LOGGINGSTATUS)(unsigned long, unsigned long, SYSTEMTIME*);

PTOPEN	__PassThruOpen = NULL;
PTCLOSE	__PassThruClose = NULL;
PTCONNECT __PassThruConnect = NULL;
PTDISCONNECT __PassThruDisconnect = NULL;
PTREADMSGS __PassThruReadMsgs = NULL;
PTWRITEMSGS __PassThruWriteMsgs = NULL;
PTSTARTPERIODICMSG __PassThruStartPeriodicMsg = NULL;
PTUPDATEPERIODICMSG __PassThruUpdatePeriodicMsg = NULL;
PTSTOPPERIODICMSG __PassThruStopPeriodicMsg = NULL;
PTSTARTMSGFILTER __PassThruStartMsgFilter = NULL;
PTSTOPMSGFILTER __PassThruStopMsgFilter = NULL;
PTSETPROGRAMMINGVOLTAGE __PassThruSetProgrammingVoltage = NULL;
PTREADVERSION __PassThruReadVersion = NULL;
PTGETLASTERROR __PassThruGetLastError = NULL;
PTIOCTL __PassThruIoctl = NULL;
PTLOADFIRMWARE __PassThruLoadFirmware = NULL;
PTRECOVERFIRMWARE __PassThruRecoverFirmware = NULL;
PTREADIPSETUP __PassThruReadIPSetup = NULL;
PTWRITEIPSETUP __PassThruWriteIPSetup = NULL;
PTREADPCSETUP __PassThruReadPCSetup = NULL;
LOGGINGSTATUS __LoggingStatus = NULL;

HINSTANCE __hModule = NULL;

/*-----------------------------------------------------------------------------
	Function Name	: PassThruOpen()
	Input Params	: None

	Output Params	: None

	Return			: Returns an Error Status.
	Description		: This function opens connection to a device.
					  This is a very first function that a user must call
					  before using any other exported functions.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR WINAPI PassThruOpen(void* pName,
	unsigned long* pulDeviceID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	bool error;
	if (!LoadGarudaDevice())
		return J2534_ERR_DEVICE_NOT_CONNECTED;

	if (__PassThruOpen != NULL)
	{
		error = __PassThruOpen(pName, pulDeviceID);
		if(error == J2534_STATUS_NOERROR)
			return J2534_STATUS_NOERROR;
	}

	return J2534_ERR_DEVICE_NOT_CONNECTED;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruClose()
	Input Params	: None

	Output Params	: None

	Return			: Returns an Error Status.
	Description		: This function closes connection to a device.
					  This is the very last function that a user must call
					  before the application exits.
---------------------------------------------------------------------------*/
extern "C" J2534ERROR WINAPI PassThruClose(unsigned long ulDeviceID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruClose != NULL)
	{
		__PassThruClose(ulDeviceID);
		UnLoadGarudaDevice();
	}

	return J2534_STATUS_NOERROR;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruConnect()
	Input Params	: ulChannelNum - Used for multiple ch. of same protocol.
					  (This parameter is taken off of the specification.
					  Therefore, on the header file, this value is
					  hardcoded to 1.)
					  enumProtocolID - ProtocolID of Protocol to be connected.
					  ulTxMsgBuffSize - Transmit Msg. Buffer Size.
					  ulRxMsgBuffSize - Receive Msg. Buffer Size (size of
										circular buffer.
					  (This buffer size parameters are taken off of the
					  specification.
					  Therefore, on the header file, this value is
					  hardcoded to 4096.)
					  ulFlags - Flags used for connection, normally set to zero.

	Output Params	: pulChannelID - Channel ID created by this dll. This is
									 returned to user for all future reference.

	Return			: Returns an Error Status.
	Description		: This is an exported API to connect to a device.
					  This is a very first function that a user must call
					  before using any other exported functions.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruConnect(unsigned long ulDeviceID,
	J2534_PROTOCOL enumProtocolID,
	unsigned long ulFlags,
	unsigned long ulBaudRate,
	unsigned long* pulChannelID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruConnect != NULL)
		__PassThruConnect(ulDeviceID, enumProtocolID, ulFlags, ulBaudRate, pulChannelID);
	return J2534_STATUS_NOERROR;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruDisconnect()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
	Output Params	:
	Return			: Returns an Error Status.
	Description		: This is an exported API to disconnect the device.
------------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruDisconnect(unsigned long ulChannelID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	if (__PassThruDisconnect != NULL)
		__PassThruDisconnect(ulChannelID);

	return J2534_STATUS_NOERROR;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruReadMsgs()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pulNumMsgs - Number of msgs requested by user to be read.
					  ulTimeout - The timeout value to read msgs.

	Output Params	: pstrucJ2534Msg - Address of location where the data read
									   should be placed.
					  pulNumMsgs - Number of msgs actually read.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  function of that class to read messages.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruReadMsgs(unsigned long ulChannelID,
	PASSTHRU_MSG * pstrucJ2534Msg,
	unsigned long* pulNumMsgs,
	unsigned long ulTimeout)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruReadMsgs != NULL)
		__PassThruReadMsgs(ulChannelID, pstrucJ2534Msg, pulNumMsgs, ulTimeout);

	return J2534_STATUS_NOERROR;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruWriteMsgs()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pulNumMsgs - Number of msgs requested by user to write.
					  ulTimeout - The timeout value to write msgs.
					  pstrucJ2534Msg - Address of location where the data is
									   that should be placed on the bus.
	Output Params	:

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  function of that class to write messages.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruWriteMsgs(unsigned long ulChannelID,
	PASSTHRU_MSG * pstrucJ2534Msg,
	unsigned long* pulNumMsgs,
	unsigned long ulTimeout)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruWriteMsgs != NULL)
		__PassThruWriteMsgs(ulChannelID, pstrucJ2534Msg, pulNumMsgs, ulTimeout);
	return J2534_STATUS_NOERROR;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruStartPeriodicMsg()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pstrucJ2534Msg - Address of location where the msg. is
									   that needs to be started periodically.

					  ulTimeInterval - The time between msgs to be sent out.

	Output Params	: pulMsgID - MsgID created by this DLL for this msg. for
								 all future references to this msg.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  virtual function of that class to start a periodic
					  message.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStartPeriodicMsg(unsigned long ulChannelID,
	PASSTHRU_MSG * pMsgJ2534,
	unsigned long* pulMsgID,
	unsigned long ulTimeInterval)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruStartPeriodicMsg != NULL)
		__PassThruStartPeriodicMsg(ulChannelID, pMsgJ2534, pulMsgID, ulTimeInterval);

	return J2534_STATUS_NOERROR;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruUpdatePeriodicMsg()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pstrucJ2534Msg - Address of location where the msg. is
									   that needs to be started periodically.

					  ulTimeInterval - The time between msgs to be sent out.

	Output Params	: pulMsgID - MsgID created by this DLL for this msg. for
								 all future references to this msg.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  virtual function of that class to start a periodic
					  message.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruUpdatePeriodicMsg(unsigned long ulChannelID,
	PASSTHRU_MSG * pMsgJ2534,
	unsigned long ulMsgID,
	unsigned long ulTimeInterval)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruUpdatePeriodicMsg != NULL)
		__PassThruUpdatePeriodicMsg(ulChannelID, pMsgJ2534, ulMsgID , ulTimeInterval);

	return J2534_STATUS_NOERROR;
}


/*-----------------------------------------------------------------------------
	Function Name	: PassThruStopPeriodicMsg()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  ulMsgID - MsgID for a msg. that was started before.
	Output Params	:
	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  virtual function of that class to stop a periodic
					  message.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStopPeriodicMsg(unsigned long ulChannelID,
	unsigned long ulMsgID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState())
		if (__PassThruStopPeriodicMsg != NULL)
			__PassThruStopPeriodicMsg(ulChannelID, ulMsgID);

	return J2534_STATUS_NOERROR;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruStartMsgFilter()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  enumFilterType - Filter Type PASS_FILTER or BLOCK_FILTER.

					  pstrucJ2534Mask - The mask to be used to filter msg.
					  pstrucJ2534Pattern - Pattern that the msg. should match
										   with after applying mask.

	Output Params	: pulMsgID - MsgID created by this DLL for this filter for
								 all future references to this msg.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  virtual function of that class to start filtering
					  messages with the given filter.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStartMsgFilter(unsigned long	ulChannelID,
	J2534_FILTER	enumFilterType,
	PASSTHRU_MSG * pstrucJ2534Mask,
	PASSTHRU_MSG * pstrucJ2534Pattern,
	PASSTHRU_MSG * pstrucJ2534FlowControl,
	unsigned long* pulFilterID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if (__PassThruStartMsgFilter != NULL)
		__PassThruStartMsgFilter(ulChannelID, enumFilterType, pstrucJ2534Mask, pstrucJ2534Pattern, pstrucJ2534FlowControl, pulFilterID);

	return J2534_STATUS_NOERROR;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruStopMsgFilter()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  ulMsgID - MsgID of a Filter msg. that was started before.
	Output Params	:
	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol
					  Object and uses the pointer to call the corressponding
					  virtual function of that class to stop filtering
					  messages for the given MsgID.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStopMsgFilter(unsigned long ulChannelID,
	unsigned long ulFilterID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruStopMsgFilter != NULL)
		__PassThruStopMsgFilter(ulChannelID, ulFilterID);

	return J2534_STATUS_NOERROR;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruSetProgrammingVoltage()
	Input Params	: ulPin - The pin on which the programming voltage will be
							  set.
					  ulVoltage - The voltage (in milli-volts) to be set.
	Output Params	:
	Return			: Returns an Error Status.
	Description		: This function sets a programming voltage on a specific
					  pin.
-----------------------------------------------------------------------------*/

extern "C" J2534ERROR  WINAPI PassThruSetProgrammingVoltage(unsigned long ulDeviceID,
	unsigned long ulPin,
	unsigned long ulVoltage)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruSetProgrammingVoltage != NULL)
		__PassThruSetProgrammingVoltage(ulDeviceID, ulPin, ulVoltage);

	return J2534_STATUS_NOERROR;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruReadVersion()
	Input Params	: pDllVersion - Pointer to DLL version string.
					  pApiVersion - Pointer to API version string.
	Output Params	:
	Return			: Returns Dll & Api Version Numbers.
	Description		: This function gets the Dll Version Number and Api Version
					  Number.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruReadVersion(unsigned long ulDeviceID,
	char* pchFirmwareVersion,
	char* pchDllVersion,
	char* pchApiVersion)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruReadVersion != NULL)
		__PassThruReadVersion(ulDeviceID, pchFirmwareVersion, pchDllVersion, pchApiVersion);

	return J2534_STATUS_NOERROR;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruGetLastError()
	Input Params	: ulErrorID - ID that identifies the type of error.
						(Out of specification)
					  pErrorDescription - Pointer to error description string.
	Output Params	:
	Return			: Returns an Error Description.
	Description		: This function gets an Error ID and matches it to an error
					  string.
-----------------------------------------------------------------------------*/

extern "C" J2534ERROR  WINAPI PassThruGetLastError(char* pchErrorDescription)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruGetLastError != NULL)
		__PassThruGetLastError(pchErrorDescription);

	return J2534_STATUS_NOERROR;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruIoctl()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  ulIoctlID - IoctlID that identifies the Ioctl call.
	Output Params	:
	Return			: Returns an Error Status.
	Description		: This function is used to read and write all the protocol
					  hardware and software configuration parameters for a
					  given ulIoctlID.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruIoctl(unsigned long ulChannelID,
	J2534IOCTLID enumIoctlID,
	void* pInput,
	void* pOutput)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__PassThruIoctl != NULL)
		__PassThruIoctl(ulChannelID, enumIoctlID, pInput, pOutput);

	return J2534_STATUS_NOERROR;
}


#ifdef GARUDA_TOOL
/*-----------------------------------------------------------------------------
	Function Name	: LoggingStatus()
	Input Params	: pDllVersion - Pointer to DLL version string.
					  pApiVersion - Pointer to API version string.
	Output Params	:
	Return			: Returns Dll & Api Version Numbers.
	Description		: This function gets the Dll Version Number and Api Version
					  Number.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI LoggingStatus(unsigned long ulDeviceID, unsigned long bLogFlag,
	SYSTEMTIME * Time)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	if (__LoggingStatus != NULL)
		__LoggingStatus(ulDeviceID, bLogFlag, Time);

	return J2534_STATUS_NOERROR;
}
#endif

bool LoadGarudaDevice()
{
	std::string garudaLiteDLLName = "C:\\Windows\\system32\\GarudaLite.dll";
	std::string garuda2DLLName = "C:\\Windows\\system32\\GarudaII.dll";
	bool bGarudLitePlugged = IsGarudaLiteDevicePlugged();
	std::string garudaDLLName = "";

	if (bGarudLitePlugged)
		garudaDLLName = garudaLiteDLLName;
	else
		garudaDLLName = garuda2DLLName;

	//Load Garuda dll
	hModule = LoadLibrary(garudaDLLName.c_str());
	if (hModule == NULL)
		return false;

	if (Init_FunctionPointers() != 0)
		return false;

	return true;
}

bool UnLoadGarudaDevice()
{
	if (__hModule != NULL)
	{
		FreeLibrary(__hModule);
	}

	//Set J2534 Ptr to NULL
	__PassThruOpen = NULL;
	__PassThruClose = NULL;
	__PassThruConnect = NULL;
	__PassThruDisconnect = NULL;
	__PassThruReadMsgs = NULL;
	__PassThruWriteMsgs = NULL;
	__PassThruStartPeriodicMsg = NULL;
	__PassThruStopPeriodicMsg = NULL;
	__PassThruStartMsgFilter = NULL;
	__PassThruStopMsgFilter = NULL;
	__PassThruSetProgrammingVoltage = NULL;
	__PassThruReadVersion = NULL;
	__PassThruGetLastError = NULL;
	__PassThruIoctl = NULL;
	__PassThruLoadFirmware = NULL;
	__PassThruRecoverFirmware = NULL;
	__PassThruReadIPSetup = NULL;
	__PassThruWriteIPSetup = NULL;
	__PassThruReadPCSetup = NULL;
	__LoggingStatus = NULL;

	return true;
}

bool IsGarudaLiteDevicePlugged()
{
	TCHAR pszPortName[BUFF_LEN] = { 0 };
	int selection = 0;
	
	bool devicePlugged = false;

	//Checking VID:03EB and PID:5745 available on COM Port
	//Read Port No. 
	if (GetComPort(pszPortName, L"03EB", L"5745"))
	{
		//Open COM Port
		hSerCom = CreateFile(pszPortName,          // for COM1�COM9 only
			GENERIC_READ | GENERIC_WRITE, //Read/Write
			0,               // No Sharing
			NULL,            // No Security
			OPEN_EXISTING,   // Open existing port only
			0,               // Non Overlapped I/O
			NULL);

		if (hSerCom != INVALID_HANDLE_VALUE)
		{
			devicePlugged = true;
			CloseHandle(hSerCom);
		}
	}

	return devicePlugged;
}

BOOL GetComPort(TCHAR* pszComePort, const WCHAR* vid, const WCHAR* pid)
{
	HDEVINFO DeviceInfoSet;
	DWORD DeviceIndex = 0;
	SP_DEVINFO_DATA DeviceInfoData;
	PCSTR DevEnum = "USB";
	WCHAR ExpectedDeviceId[80] = { 0 }; //Store hardware id
	BYTE szBuffer[1024] = { 0 };
	DEVPROPTYPE ulPropertyType;
	DWORD dwSize = 0;
	DWORD Error = 0;
	//create device hardware id
	wcscpy_s(ExpectedDeviceId, L"vid_");
	wcscat_s(ExpectedDeviceId, _T(vid));
	wcscat_s(ExpectedDeviceId, L"&pid_");
	wcscat_s(ExpectedDeviceId, pid);
	//SetupDiGetClassDevs returns a handle to a device information set
	DeviceInfoSet = SetupDiGetClassDevs(
		NULL,
		DevEnum,
		NULL,
		DIGCF_ALLCLASSES | DIGCF_PRESENT);
	if (DeviceInfoSet == INVALID_HANDLE_VALUE)
		return -1;
	//Fills a block of memory with zeros
	ZeroMemory(&DeviceInfoData, sizeof(SP_DEVINFO_DATA));
	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
	//Receive information about an enumerated device
	while (SetupDiEnumDeviceInfo(
		DeviceInfoSet,
		DeviceIndex,
		&DeviceInfoData))
	{
		DeviceIndex++;
		//Retrieves a specified Plug and Play device property
		if (SetupDiGetDeviceRegistryProperty(DeviceInfoSet, &DeviceInfoData, SPDRP_HARDWAREID,
			&ulPropertyType, (BYTE*)szBuffer,
			sizeof(szBuffer),   // The size, in bytes
			&dwSize))
		{
			HKEY hDeviceRegistryKey;
			//Get the key
			hDeviceRegistryKey = SetupDiOpenDevRegKey(DeviceInfoSet, &DeviceInfoData, DICS_FLAG_GLOBAL, 0, DIREG_DEV, KEY_READ);
			if (hDeviceRegistryKey == INVALID_HANDLE_VALUE)
			{
				Error = GetLastError();
				break; //Not able to open registry
			}
			else
			{
				// Read in the name of the port
				char pszPortName[BUFF_LEN];
				DWORD dwSize = sizeof(pszPortName);
				DWORD dwType = 0;
				if ((RegQueryValueEx(hDeviceRegistryKey, "PortName", NULL, &dwType, (LPBYTE)pszPortName, &dwSize) == ERROR_SUCCESS) && (dwType == REG_SZ))
				{
					// Check if it really is a com port
					if (_tcsnicmp(pszPortName, _T("COM"), 3) == 0)
					{
						int nPortNr = _ttoi(pszPortName + 3);
						if (nPortNr != 0)
						{
							_tcscpy_s(pszComePort, BUFF_LEN, pszPortName);
						}
					}
				}
				// Close the key now that we are finished with it
				RegCloseKey(hDeviceRegistryKey);

			}
		}
	}
	if (DeviceInfoSet)
	{
		SetupDiDestroyDeviceInfoList(DeviceInfoSet);
	}
}

int Init_FunctionPointers()
{
	if ((__PassThruOpen = (PTOPEN)GetProcAddress(hModule, "PassThruOpen")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruClose = (PTCLOSE)GetProcAddress(hModule, "PassThruClose")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruConnect = (PTCONNECT)GetProcAddress(hModule, "PassThruConnect")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruDisconnect = (PTDISCONNECT)GetProcAddress(hModule,
		"PassThruDisconnect")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruReadMsgs = (PTREADMSGS)GetProcAddress(hModule, "PassThruReadMsgs")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruWriteMsgs = (PTWRITEMSGS)GetProcAddress(hModule, "PassThruWriteMsgs")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruStartPeriodicMsg = (PTSTARTPERIODICMSG)GetProcAddress(hModule,
		"PassThruStartPeriodicMsg")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruUpdatePeriodicMsg = (PTUPDATEPERIODICMSG)GetProcAddress(hModule,
		"PassThruUpdatePeriodicMsg")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruStopPeriodicMsg = (PTSTOPPERIODICMSG)GetProcAddress(hModule,
		"PassThruStopPeriodicMsg")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruStartMsgFilter = (PTSTARTMSGFILTER)GetProcAddress(hModule,
		"PassThruStartMsgFilter")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruStopMsgFilter = (PTSTOPMSGFILTER)GetProcAddress(hModule,
		"PassThruStopMsgFilter")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruSetProgrammingVoltage = (PTSETPROGRAMMINGVOLTAGE)GetProcAddress(hModule,
		"PassThruSetProgrammingVoltage")) == NULL)
	{
		return(FALSE);
	}
	if ((__PassThruReadVersion = (PTREADVERSION)GetProcAddress(hModule, "PassThruReadVersion"))
		== NULL)
	{
		return(FALSE);
	}
	if ((__PassThruGetLastError = (PTGETLASTERROR)GetProcAddress(hModule, "PassThruGetLastError"))
		== NULL)
	{
		return(FALSE);
	}
	if ((__PassThruIoctl = (PTIOCTL)GetProcAddress(hModule, "PassThruIoctl")) == NULL)
	{
		return(FALSE);
	}
	if ((__LoggingStatus = (LOGGINGSTATUS)GetProcAddress(hModule, "LoggingStatus")) == NULL)
	{
		return(FALSE);
	}
	return 0;
}