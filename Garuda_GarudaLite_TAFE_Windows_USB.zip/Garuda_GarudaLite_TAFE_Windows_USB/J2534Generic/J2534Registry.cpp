/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J2534Registry.cpp
 Description			: implementation of the CJ2534Registry class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 29, 2008	Chakravarthy				Initial Version
*******************************************************************************/


#include "stdafx.h"
#include "J2534Generic.h"
#include "J2534Registry.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CJ2534Registry::CJ2534Registry()
{

}

CJ2534Registry::~CJ2534Registry()
{

}

//-----------------------------------------------------------------------------
//	Function Name	: FindJ2534Entry()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: This is a function to find the J2534 device entry in
//					  the registry.
//-----------------------------------------------------------------------------
BOOL CJ2534Registry::FindJ2534Entry(HKEY **phTempkey,char chJ2534DeviceName[J2534REGISTRY_MAX_STRING_LENGTH])
{
	long			lSuccess;
	char			chTempstr[J2534REGISTRY_MAX_STRING_LENGTH]; 
	DWORD			dwDatasize;  	
	unsigned char	ucValueread[J2534REGISTRY_MAX_STRING_LENGTH];
	DWORD			dwDword, dwString; 
	char			chValueset[J2534REGISTRY_MAX_STRING_LENGTH];
	HKEY			hMainkey;
	HKEY			hTempkey;			// handle for key
//	HKEY			*phTempkey;
	int				i, iHighdevice, iHighvendor;

	dwDword = REG_DWORD, dwString = REG_SZ;
	i=0, iHighdevice=1, iHighvendor=1;
	hTempkey = NULL;
//	phTempkey = NULL;

	strcpy(chTempstr, J2534REGISTRY_KEY_PATH);
	lSuccess = RegOpenKeyEx(HKEY_LOCAL_MACHINE, chTempstr, 
			0, KEY_READ, &hMainkey);

	if(lSuccess==ERROR_SUCCESS) 
	{
		i=0;
		dwDatasize=1024;
		lSuccess = RegEnumKey(hMainkey, i, chTempstr, dwDatasize);
		if(lSuccess!=ERROR_SUCCESS)
		{
			RegCloseKey(hMainkey);
			return FALSE;
		}
		if(chTempstr[strlen(chTempstr)-1]-'0'==iHighvendor)
			iHighvendor++;
		lSuccess = RegOpenKeyEx(hMainkey, chTempstr, 
				0, KEY_READ, &hTempkey);
		while(lSuccess==ERROR_SUCCESS)
		{
			dwDatasize = sizeof(ucValueread);
			lSuccess = RegQueryValueEx(hTempkey, J2534REGISTRY_NAME, NULL, 
				&dwString, ucValueread, &dwDatasize);
		
			if(lSuccess==ERROR_SUCCESS)
			{
				sprintf(chValueset, "%s", ucValueread);
				if(!strcmp(chValueset, chJ2534DeviceName))
				{
					dwDatasize = sizeof(ucValueread);
					lSuccess = RegQueryValueEx(hTempkey, J2534REGISTRY_VENDOR, NULL, 
												&dwString, ucValueread, &dwDatasize);
		
					if(lSuccess==ERROR_SUCCESS)
					{
						sprintf(chValueset, "%s", ucValueread);
						if(!strcmp(chValueset, J2534REGISTRY_COMPANY_NAME))
						{
							*phTempkey = &hTempkey;
							break;
						}
					}
				}
			}

			RegCloseKey(hTempkey);
			hTempkey = NULL;
			i++;
			dwDatasize=1024;
			lSuccess = RegEnumKey(hMainkey, i, chTempstr, dwDatasize);
			if(lSuccess!=ERROR_SUCCESS)
			{
				break;
			}
			if(chTempstr[strlen(chTempstr)-1]-'0'==iHighvendor)
				iHighvendor++;
			lSuccess = RegOpenKeyEx(hMainkey, chTempstr, 
					0, KEY_READ, &hTempkey);
		}
	}
	RegCloseKey(hMainkey);
	return TRUE;
}

//-----------------------------------------------------------------------------
//	Function Name	: GetRegistry()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: This is a function to record Gryphon registry information.
//-----------------------------------------------------------------------------
J2534REGISTRY_ERROR_TYPE CJ2534Registry::GetRegistry(
						J2534REGISTRY_CONFIGURATION* pstJ2534RegistryConfig)
{
	HKEY			*phKey;							// handle for key
	BOOL			bSuccess;
	long			lSuccess;
	unsigned char	ucValueread[J2534REGISTRY_MAX_STRING_LENGTH];
	DWORD			dwValueread[J2534REGISTRY_MAX_STRING_LENGTH];
	DWORD			dwDword, dwString;				
	DWORD			dwDatasize;	
	CString			cszIP;
//	HKEY			*phTempkey = NULL;

	dwDword = REG_DWORD, dwString = REG_SZ;
	dwDatasize = sizeof(ucValueread);
	phKey = NULL;

	if (pstJ2534RegistryConfig == NULL)
	{
		return(J2534REGISTRY_ERR_NULL_PARAMETER);
	}

	if (pstJ2534RegistryConfig->enJ2534RegistryDeviceType == 
		J2534REGISTRY_DEVICE_INNOVA_OEMTOOL)
	{
		bSuccess = FindJ2534Entry(&phKey, J2534REGISTRY_5000OEM_TOOL);
	}
	
	if(phKey==NULL || bSuccess == FALSE)
	{
		return(J2534REGISTRY_ERR_DEVICE_NOT_FOUND);
	}

	// DeviceId
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_DEVICE_ID, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwDeviceId = dwValueread[0];

	// Vendor
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_VENDOR, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chVendor, "%s", ucValueread);

	// Name
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_NAME, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chName, "%s", ucValueread);

	// ProtocolsSupported
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_PROTOCOLSSUPPORT, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chProtocolSupported, "%s", ucValueread);

	// ConfigApplication
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_CONFIGAPP, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chConfigApplication, "%s", ucValueread);

	// LoggingDirectory
/*	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_LOGGINGDIRECTORY, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chLoggingDirectory, "%s", ucValueread);*/

	// FunctionLibrary
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_FUNCLIB, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chFunctionLibrary, "%s", ucValueread);

	// APIVersion //RMR1
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_APIVERSION, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chAPIVersion, "%s", ucValueread);

	// ProductVersion //RMR1
	dwDatasize = sizeof(ucValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_PRODUCTVERSION, NULL, &dwString, 
		ucValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	sprintf(pstJ2534RegistryConfig->chProductVersion, "%s", ucValueread);

	// CAN
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_CAN, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwCAN = dwValueread[0];

	// ISO15765
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_ISO15765, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwISO15765 = dwValueread[0];

	// J1850PWM
/*	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_J1850PWM, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwJ1850PWM = dwValueread[0];*/

	// J1850VPW
/*	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_J1850VPW, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwJ1850VPW = dwValueread[0];*/

		// ISO14230
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_ISO14230, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwISO14230 = dwValueread[0];

#ifndef GARUDA_TOOL
	// ISO9141
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_ISO9141, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwISO9141 = dwValueread[0];

	// SCI_A_ENGINE
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_SCI_A_ENGINE, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwSCIAEng = dwValueread[0];

	// SCI_A_TRANS
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_SCI_A_TRANS, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwSCIATrans = dwValueread[0];

	// SCI_B_ENGINE
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_SCI_B_ENGINE, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwSCIBEng = dwValueread[0];

	// SCI_B_TRANS
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_SCI_B_TRANS, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwSCIBTrans = dwValueread[0];

	// SWCAN_ISO15765_PS
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_SWCAN_ISO15765_PS, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwSWISO15765PS = dwValueread[0];

	// SWCAN_PS
	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_SWCAN_PS, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwSWCANPS = dwValueread[0];
#endif
	// CCD
/*	dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_CCD, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwCCD = dwValueread[0];*/

	// Logging
	/*dwDatasize = sizeof(dwValueread);
	lSuccess = RegQueryValueEx(*phKey, J2534REGISTRY_LOGGING, NULL, &dwDword, 
		(unsigned char *)dwValueread, &dwDatasize);
	if (lSuccess!=ERROR_SUCCESS)
	{
		RegCloseKey(*phKey);
		return(J2534REGISTRY_ERR_NO_DATA_KEY_VALUE);
	}
	pstJ2534RegistryConfig->dwLogging = dwValueread[0];*/
	RegCloseKey(*phKey);

	return(J2534REGISTRY_ERR_SUCCESS);
}

//-----------------------------------------------------------------------------
//	Function Name	: WriteToRegistry()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: This is a function to write registry information.
//-----------------------------------------------------------------------------
J2534REGISTRY_ERROR_TYPE CJ2534Registry::WriteToRegistry(
						J2534REGISTRY_CONFIGURATION* pstJ2534RegistryConfig)
{
	long			lSuccess;
	char			chTempstr[J2534REGISTRY_MINI_STRING_LENGTH];
	DWORD			dwSzdata;  
	unsigned char	ucValueread[J2534REGISTRY_MINI_STRING_LENGTH];	// read in String value
	DWORD			dwDword, dwString; 
	char			chValueset[J2534REGISTRY_MINI_STRING_LENGTH];	// used to set String values
	HKEY			hMainkey, hTempkey;
	int				i, iHighdevice, iHighvendor;

	dwDword = REG_DWORD; 
	dwString = REG_SZ; 
	i=0;
	iHighdevice=1; 
	iHighvendor=1;

	if (pstJ2534RegistryConfig == NULL)
	{
		return(J2534REGISTRY_ERR_NULL_PARAMETER);
	}

	strcpy(chTempstr, J2534REGISTRY_KEY_PATH);
	lSuccess = RegOpenKeyEx(HKEY_LOCAL_MACHINE, chTempstr, 
			0, KEY_ALL_ACCESS, &hMainkey);

	if(lSuccess==ERROR_SUCCESS)
	{
		i=0;
		dwSzdata=J2534REGISTRY_MINI_STRING_LENGTH;
		lSuccess = RegEnumKey(hMainkey, i, chTempstr, dwSzdata);
		if(lSuccess!=ERROR_SUCCESS)
		{
			strcpy(chTempstr, pstJ2534RegistryConfig->chVendor);
			strcat(chTempstr, J2534REGISTRY_HYPHEN_SPACE);
			strcat(chTempstr, pstJ2534RegistryConfig->chName);
			RegCreateKey(hMainkey, chTempstr, &hTempkey);
			CreateWriteKeyValues(&hTempkey, *pstJ2534RegistryConfig);
			RegCloseKey(hMainkey);
			RegCloseKey(hTempkey);
			return (J2534REGISTRY_ERR_SUCCESS);
		}
		lSuccess = RegOpenKeyEx(hMainkey, chTempstr, 
				0, KEY_ALL_ACCESS, &hTempkey);
		while(lSuccess==ERROR_SUCCESS)
		{
			dwSzdata = sizeof(ucValueread);
			lSuccess = RegQueryValueEx(hTempkey, J2534REGISTRY_NAME, NULL, 
				&dwString, ucValueread, &dwSzdata);
		
			if(lSuccess==ERROR_SUCCESS)
			{
				sprintf(chValueset, "%s", ucValueread);
				if(!strcmp(chValueset, pstJ2534RegistryConfig->chName))
				{
					dwSzdata = sizeof(ucValueread);
					lSuccess = RegQueryValueEx(hTempkey, J2534REGISTRY_VENDOR, 
						NULL, &dwString, ucValueread, &dwSzdata);
				
					if(lSuccess==ERROR_SUCCESS)
					{
						sprintf(chValueset, "%s", ucValueread);
						if(!strcmp(chValueset, pstJ2534RegistryConfig->chVendor))
						{
							CreateWriteKeyValues(&hTempkey, *pstJ2534RegistryConfig);
							RegCloseKey(hMainkey);
							RegCloseKey(hTempkey);
							break;
						}
					}
				}
			}
			i++;
			dwSzdata=J2534REGISTRY_MINI_STRING_LENGTH;
			lSuccess = RegEnumKey(hMainkey, i, chTempstr, dwSzdata);
			if(lSuccess!=ERROR_SUCCESS)
			{
				strcpy(chTempstr, pstJ2534RegistryConfig->chVendor);
				strcat(chTempstr, J2534REGISTRY_HYPHEN_SPACE);
				strcat(chTempstr, pstJ2534RegistryConfig->chName);
				RegCreateKey(hMainkey, chTempstr, &hTempkey);
				CreateWriteKeyValues(&hTempkey, *pstJ2534RegistryConfig);
				RegCloseKey(hMainkey);
				RegCloseKey(hTempkey);
				break;
			}
			lSuccess = RegOpenKeyEx(hMainkey, chTempstr, 
					0, KEY_ALL_ACCESS, &hTempkey);
		}
	}
	else
	{
		strcpy(chTempstr, J2534REGISTRY_KEY_PATH);
		strcat(chTempstr, J2534REGISTRY_DOUBLE_BACKSLASH);
		strcat(chTempstr, pstJ2534RegistryConfig->chVendor);
		strcat(chTempstr, J2534REGISTRY_HYPHEN_SPACE);
		strcat(chTempstr, pstJ2534RegistryConfig->chName);
		lSuccess = RegCreateKeyEx(HKEY_LOCAL_MACHINE, chTempstr, 0,0,0,
			KEY_ALL_ACCESS, 0, &hTempkey, 0);

		if (lSuccess != ERROR_SUCCESS)
		{
			return (J2534REGISTRY_ERR_INSUFFICIENT_WRITING_PRIVILEGE);
		}

		CreateWriteKeyValues(&hTempkey, *pstJ2534RegistryConfig);
		RegCloseKey(hTempkey);
	}

	return (J2534REGISTRY_ERR_SUCCESS);
}

void CJ2534Registry::CreateWriteKeyValues(HKEY *phThiskey,
								J2534REGISTRY_CONFIGURATION stJ2534RegistryConfig)
{
	char	chTempstr[J2534REGISTRY_MINI_STRING_LENGTH];
	DWORD	dwDatasize, dwWorddata;
	CString cszString;

	strcpy(chTempstr, stJ2534RegistryConfig.chConfigApplication);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_CONFIGAPP, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwDeviceId;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_DEVICE_ID, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	strcpy(chTempstr, stJ2534RegistryConfig.chFunctionLibrary);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_FUNCLIB, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	strcpy(chTempstr, stJ2534RegistryConfig.chVendor);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_VENDOR, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	strcpy(chTempstr, stJ2534RegistryConfig.chName);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_NAME, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);
	strcpy(chTempstr, stJ2534RegistryConfig.chLoggingDirectory);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_LOGGINGDIRECTORY, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwCAN;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_CAN, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwISO15765;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_ISO15765, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwJ1850PWM;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_J1850PWM, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwJ1850VPW;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_J1850VPW, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwISO9141;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_ISO9141, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwISO14230;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_ISO14230, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwSCIAEng;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_SCI_A_ENGINE, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwSCIATrans;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_SCI_A_TRANS, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwSCIBEng;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_SCI_B_ENGINE, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwSCIBTrans;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_SCI_B_TRANS, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwSWISO15765PS;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_SWCAN_ISO15765_PS, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwSWCANPS;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_SWCAN_PS, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwCCD;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_CCD, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);

	strcpy(chTempstr, stJ2534RegistryConfig.chProtocolSupported);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_PROTOCOLSSUPPORT, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	strcpy(chTempstr, stJ2534RegistryConfig.chAPIVersion);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_APIVERSION, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	strcpy(chTempstr, stJ2534RegistryConfig.chProductVersion);
	dwDatasize=strlen(chTempstr)+1;
	RegSetValueEx(*phThiskey, J2534REGISTRY_PRODUCTVERSION, 0, REG_SZ, 
		(unsigned char*)chTempstr, dwDatasize);

	dwWorddata=stJ2534RegistryConfig.dwLogging;
	dwDatasize=4;
	RegSetValueEx(*phThiskey, J2534REGISTRY_LOGGING, 0, REG_DWORD, 
		(unsigned char*)&dwWorddata, dwDatasize);
}
