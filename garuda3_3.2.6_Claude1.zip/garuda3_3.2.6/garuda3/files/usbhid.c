﻿/**
 *	@file usbhid.c
 *
 *	Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include	<unistd.h>
#include	<glib.h>

#include	"g3d.h"
#include	"usbhid.h"
#include	"hfcp.h"
#include	"data_logger.h"

#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>


#define USB_PKT_SIZE       (512)

static USBHIDContext_t usbhidctx;

ssize_t usbhid_read(void *buf, size_t count)
{
	ssize_t ret;

	if (usbhidctx.hidfd < 0)
		return -1;

	if (buf == NULL || count <= 0) {
		DBG("Invalid parameters!");
		return -2;
	}

	for (;;) {
		ret = read(usbhidctx.hidfd, buf, count);

		if (ret > 0)
			return ret;

		if (ret == 0) {
			usbhid_reinit();
			return ret;
		}

		DBG("Read error: %s\n", strerror(errno));

		switch (errno) {
		case EINTR:
			continue;
		case EAGAIN:
			ERR("USBHID device is in NON-BLOCKING mode!");
			/* Fall through */
		case EBADF:
		case EINVAL:
		case EIO:
		default:
			usbhid_reinit();
			return -1;
		}
	}
}

static ssize_t _usbhid_write(int wfd, const void *buf, size_t count)
{
	ssize_t ret;
	ssize_t wrote;

	wrote = 0;

	const uint8_t *p = buf;

	for (;;) {
		ret = write(wfd, p, count);

		if (ret >= 0) {
			wrote += ret;

			if ((size_t)ret < count) {
				p += ret;
				count -= ret;
				continue;
			}

			return wrote;
		}

		DBG("Write error: %s\n", strerror(errno));

		switch (errno) {
		case EINTR:
			continue;
		case EAGAIN:
			ERR("USBHID device is in NON-BLOCKING mode!");
			/* Fall through */
		case EBADF:
		case EINVAL:
		case EIO:
		default:
			usbhid_reinit();
			return -1;
		}
	}
}

/*
 * NOTE: the HID gadget uses a fixed 512-byte report, so each packet is always
 * written as USB_PKT_SIZE bytes regardless of `count`.  Every caller therefore
 * has to hand in a buffer of at least USB_PKT_SIZE bytes (they currently all
 * do: a 512-byte malloc, the 1024-byte usbhid rx buffer, or net_if's 512-byte
 * rxbuf).  Passing a smaller object here reads past its end.
 */
ssize_t usbhid_write(const void *buf, size_t count)
{
	int i, npkts, bytes;
	ssize_t ret;
	uint8_t *pkt;

	if (usbhidctx.hidfd < 0)
		return -1;

	bytes = 0;
	pkt = (uint8_t *)buf;
	npkts = (count + USB_PKT_SIZE - 1) / USB_PKT_SIZE;  /* Number of USB_PKT_SIZE byte USB frames */

	for (i = 0; i < npkts; i++) {
		/* Dump USB_PKT_SIZE, not `count`: for i > 0 the old call read
		 * `count` bytes starting at an offset and ran off the end.
		 */
		hexdump("USB-WR", &pkt[i*USB_PKT_SIZE], USB_PKT_SIZE, 1);
		ret = _usbhid_write(usbhidctx.hidfd, &pkt[i*USB_PKT_SIZE],
				USB_PKT_SIZE);
		if (ret < 0) {
			ERR("_usbhid_write failed %zu bytes\n", count);
			break;
		}
		bytes += USB_PKT_SIZE;
	}

	return bytes;
}

static gboolean usbhid_data_handler(GIOChannel *channel,
		GIOCondition cond, gpointer data)
{
	USBHIDContext_t *ctx = (USBHIDContext_t *)data;
	int len;

	/* TODO: Validate usbhidctx.state */

	switch (cond) {
	case G_IO_IN:
		/* Read from USB */
		memset(ctx->buf, 0, sizeof(ctx->buf));
		
		/* read 64 bytes */
		len = usbhid_read(&ctx->buf[0], USB_PKT_SIZE);
		if (len != USB_PKT_SIZE) {
			ERR("USB Read failed!");
			break;
		}
		if (len) {
			hexdump("USB-RD", ctx->buf, len, 1);
			handle_hfcp_rx(ctx->buf, len);
		}
		break;
	case G_IO_OUT:
	case G_IO_PRI:
	case G_IO_ERR:
	case G_IO_HUP:
	case G_IO_NVAL:
		return FALSE;
	}

	return TRUE;
}

static gboolean usbhid_timer_handler(gpointer data)
{
	int fd;
	USBHIDContext_t *ctx = (USBHIDContext_t *)data;
	GIOChannel *channel;

	if (G3dCtx.Terminate) {
		ctx->timersource = 0;
		return G_SOURCE_REMOVE;
	}

	/* If not opened - open the usbhid device */
	if (ctx->hidfd < 0)
		ctx->hidfd = open(ctx->hiddevname, O_RDWR);

	fd = ctx->hidfd;
	if (fd < 0) {
		DBG("Garuda3 not connected to host! Will retry later...(%s)\n",
				ctx->hiddevname);
		ctx->state = USBHID_DISCONNECTED;
		return G_SOURCE_CONTINUE;
	}

	channel = g_io_channel_unix_new(fd);
	if (!channel) {
		ERR("Failed to create g_io_channel for USBHID!\n");
		/* Just drop the fd and let this timer try again; calling
		 * usbhid_deinit() here would tear down the very GSource we are
		 * running in and then return G_SOURCE_CONTINUE for it.
		 */
		close(fd);
		ctx->hidfd = -1;
		ctx->state = USBHID_DISCONNECTED;
		return G_SOURCE_CONTINUE;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);

	ctx->watch_source = g_io_add_watch(channel, ctx->cond,
				usbhid_data_handler, ctx);

	g_io_channel_unref(channel);

	ctx->state = USBHID_CONNECTED;

	//INFO("Garuda3 HID connection established! Stopping timer...\n");
	/* Once the HID is connected then remove the timer and restart	*/
	/* it when HID connect loss is detected.			*/
	/* Clear the id too, otherwise usbhid_deinit() later calls	*/
	/* g_source_remove() on a source GLib has already destroyed.	*/
	ctx->timersource = 0;
	return G_SOURCE_REMOVE;
}

int usbhid_init(void)
{
	/**
	 * TODO: check if this can be replaced by udev monitoring of
	 * the gadget driver getting triggered.
	 * https://www.collabora.com/news-and-blog/blog/2019/02/18/modern-usb-gadget-on-linux-and-how-to-integrate-it-with-systemd-part-1/
	 */
	guint timersource;

	usbhidctx.hidfd = -1;
	usbhidctx.state = USBHID_DISCONNECTED;
	usbhidctx.cond = G_IO_PRI | G_IO_IN;
	usbhidctx.hiddevname = CfgInfo[CFG_USBHID_IF].value;
	timersource = g_timeout_add_seconds(USBHID_MONITOR_PERIOD,
			usbhid_timer_handler, &usbhidctx);

	/* timersource is a guint, so the old `timersource < 0` could never be
	 * true.  g_timeout_add_seconds() signals failure by returning 0.
	 */
	if (timersource == 0) {
		ERR("Failed to create USBHID timer source!");
		return -1;
	}

	usbhidctx.timersource = timersource;

	HFCP_setApplicationMode(GARUDA_IN_USB_MODE);

	return 0;
}

int usbhid_reinit(void)
{
	usbhid_deinit();
	return usbhid_init();
}

void usbhid_deinit(void)
{
	/*
	 * This used to close() the fd and nothing else.  usbhid_reinit() calls
	 * deinit followed by init, and init unconditionally installs a new
	 * 1-second GSource - so every USB read/write error (which is what calls
	 * reinit) orphaned the previous I/O watch and stacked another monitor
	 * timer.  A few hours of USB flapping accumulated thousands of live
	 * sources all polling a closed descriptor.
	 */
	if (usbhidctx.watch_source) {
		g_source_remove(usbhidctx.watch_source);
		usbhidctx.watch_source = 0;
	}

	if (usbhidctx.timersource) {
		g_source_remove(usbhidctx.timersource);
		usbhidctx.timersource = 0;
	}

	if (usbhidctx.hidfd >= 0) {
		close(usbhidctx.hidfd);
		usbhidctx.hidfd = -1;
	}

	usbhidctx.state = USBHID_DISCONNECTED;
}
