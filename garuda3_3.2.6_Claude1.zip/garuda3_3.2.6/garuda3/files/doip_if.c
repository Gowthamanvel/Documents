/**
 *  @file doip_if.c
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 *
 *  This file provides the interface APIs that are invoked by the HFCP / other
 *  applications using DoIP client
 */

#include "doip_if.h"
#include "g3d.h"
#include "hfcp.h"
#include "net.h"
#include "j2534_periodic.h"
char server_ip_addr[IPV4_STR_ADDR_LEN];

static int doip_cli_destroy_server(doip_conn_table_t *conn);

int doip_cli_cmd_start_session(doip_cli_cmd_start_session_t *psession)
{
	(void) doip_cli_set_logical_address(psession->logical_addr);

	return STATUS_NOERROR;
}

/*
 * This function receives the server information like VIN, logical addr, EID,
 * GID IP address and returns a 'handle' which is used to identify the server.
 *
 * Everytime this function is called a 'server node' is created and added to
 * the connection-list
 */
int doip_cli_add_server(doip_cli_cmd_add_doip_server_t *sinfo)
{
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head();
	doip_conn_table_t *connlist;
	int ret;

	DBG("In %s", __func__);

	connlist = (doip_conn_table_t *) malloc(sizeof(doip_conn_table_t));
	if (connlist == NULL) {
		DBG("malloc failed - add_server");
		return ERR_BUFFER_FULL;
	}
	memcpy(&connlist->sinfo, &sinfo->sinfo, sizeof(sinfo->sinfo));
	strncpy(connlist->ipaddr, sinfo->ipaddr, IPV4_STR_ADDR_LEN);
	connlist->ipaddr[IPV4_STR_ADDR_LEN-1] = '\0';
	connlist->nodelist = NULL;

	DBG("After connlist...");
	ret = validate_ip(sinfo->ipaddr);
	if(ret != 1){
		/* This used to do `*head_connlist = NULL;` - throwing away (and
		 * leaking) every DoIP server already registered just because
		 * this one request carried a malformed IP string.  It also
		 * leaked the connlist allocated above.
		 */
		ERR("Validate IP failed");
		free(connlist);
		return ERR_FAILED;
	}

	DBG("Aftr validation ip address...");
	connlist->next = NULL;
	if (*head_connlist == NULL) {
		*head_connlist = connlist;
	} else {
		doip_conn_table_t *tmp = *head_connlist;

		while (tmp->next != NULL){
			tmp = tmp->next;
		}
		tmp->next = connlist;
	}
	DBG("After connlist...");
	/*
	 * Initiate TCP connection with the DoIP server
	 * Change the connection status
	 */
	ret = doip_cli_start_tcp_connection(connlist);
	if (ret < 0) {
		DBG("Failed to connect to %s", connlist->ipaddr);
		/* TODO: Retry the connection */
		/* Unlink and free, otherwise the list keeps a node whose TCP
		 * connection was never established and whose memory is never
		 * reclaimed.
		 */
		doip_cli_destroy_server(connlist);
		return ERR_FAILED;
	}
	else
	{
		led_set(LED_LINK_LED, LED_ON);
	}
	/* TCP connection is established */
	connlist->conn_state = DOIP_CONN_STATE_ACTIVE;
	ret = doip_cli_send_routing_act_req(connlist, doip_cli_get_logical_address());

	if (ret < 0) {
		DBG("Failed to send %s", connlist->ipaddr);
		/* TODO: Retry the connection */
		doip_cli_destroy_server(connlist);
		return ERR_FAILED;
	}

	return STATUS_NOERROR;
}

doip_conn_table_t *doip_cli_ipaddr_to_conn_table(char *ip)
{
	struct in_addr sin_addr;
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head(), *conn;
	char *ipaddr;

	sin_addr.s_addr = inet_addr(ip);

	conn = *head_connlist;
	/* Identify the DoIP server */

	if (conn == NULL) {
		DBG("No servers found with IP %s\n", ip);
		return NULL;
	}

	while (conn) {
		ipaddr = conn->ipaddr;
		if (sin_addr.s_addr == inet_addr(ipaddr)) {
			DBG("Found the server with %s", ipaddr);
			break;
		}
		conn = conn->next;
	}

	if (conn == NULL) {
		DBG("No servers found with IP %s\n", ip);
		return NULL;
	}
	return conn;
}

int doip_cli_del_server(doip_cli_cmd_del_doip_server_t *sdel)
{
	doip_conn_table_t *conn;

	/* %s, not %p - sdel->ipaddr is the address string itself */
	memcpy(server_ip_addr, sdel->ipaddr, sizeof(server_ip_addr));
	server_ip_addr[sizeof(server_ip_addr) - 1] = '\0';

	conn = doip_cli_ipaddr_to_conn_table(sdel->ipaddr);
	if (conn == NULL) {
		ERR("No server with %s is added", server_ip_addr);
		return ERR_FAILED;
	}

	DBG("At the end of doip_cli_del_server...");

	return doip_cli_destroy_server(conn);
}

/*
 * For a given IP address, add the list of DoIP node
 *
 */
/*
 * Both of these open-coded the same server lookup that
 * doip_cli_ipaddr_to_conn_table() already performs (~20 duplicated lines each),
 * and differed only in which per-node helper they called.
 */
int doip_cli_add_node(doip_cli_cmd_add_node_t *en)
{
	doip_conn_table_t *conn;
	uint16_t cnt;
	int ret;

	conn = doip_cli_ipaddr_to_conn_table(en->ipaddr);
	if (conn == NULL) {
		DBG("No servers found with IP %s\n", en->ipaddr);
		return ERR_FAILED;
	}

	/* Add the node to the server */
	for (cnt = 0; cnt < en->node_cnt; cnt++) {
		ret = doip_cli_add_node_tolist(conn, en->laddr[cnt]);
		if (ret < 0) {
			DBG("Cannot add laddr %d to node %s", en->laddr[cnt], conn->ipaddr);
			break;
		}
	}
	return STATUS_NOERROR;
}

int doip_cli_del_node(doip_cli_cmd_del_node_t *en)
{
	doip_conn_table_t *conn;
	uint16_t cnt;
	int ret;

	conn = doip_cli_ipaddr_to_conn_table(en->ipaddr);
	if (conn == NULL) {
		DBG("No servers found with IP %s\n", en->ipaddr);
		return ERR_FAILED;
	}

	/* Delete the nodes from the list */
	for (cnt = 0; cnt < en->node_cnt; cnt++) {
		ret = doip_cli_remove_node_fromlist(conn, en->laddr[cnt]);
		if (ret < 0) {
			DBG("Cannot remove laddr %d to node %s", en->laddr[cnt], conn->ipaddr);
			break;
		}
	}
	return STATUS_NOERROR;
}

/*
 * Transmit Diagnostic message to DoIP server
 */
int doip_cli_cmd_send_diag_msg(doip_cli_cmd_diag_msg_t *dmsg)
{
	doip_conn_table_t *conn;
	int ret;
	char ipaddr[IPV4_STR_ADDR_LEN];

	memcpy(ipaddr, dmsg->ipaddr, sizeof(ipaddr));
	ipaddr[IPV4_STR_ADDR_LEN-1] = 0;

	conn = doip_cli_ipaddr_to_conn_table(ipaddr);
	if (conn == NULL) {
		DBG("No server with %s is added", ipaddr);
		return ERR_FAILED;
	}

	ret = doip_cli_send_diag_msg(conn, dmsg->dst_laddr, dmsg->seqNum,
					dmsg->lastpkt, dmsg->msg_len, dmsg->diag_data);
	if (ret < 0) {
		DBG("DiagMsg send failed");
		return ERR_FAILED;
	}
	return STATUS_NOERROR;
}

/*
 * Transmit Diagnostic message to DoIP server
 */
int doip_cli_cmd_send_periodic_msg(doip_cli_cmd_periodic_msg_t *dmsg)
{       
       
	PERIODIC_MSG j2534_periodic_msg;
	uint8_t periodic_msg_cmd = 0;
	uint8_t fl_status_U8 = STATUS_NOERROR;

	periodic_msg_cmd = dmsg->periodic_command;
        j2534_periodic_msg.protocol_id = DOIP_PROTOCOL_ID ;     /* buffer[0]; */

                j2534_periodic_msg.periodicity = dmsg->periodicity;

		j2534_periodic_msg.prmsg_id = dmsg->msgid ;

		memcpy(j2534_periodic_msg.u.doip_periodic_send_data.ipaddr, dmsg->ipaddr, IPV4_STR_ADDR_LEN);

		j2534_periodic_msg.u.doip_periodic_send_data.seqNum = dmsg->seqNum;

		j2534_periodic_msg.u.doip_periodic_send_data.lastpkt = dmsg->lastpkt;

		j2534_periodic_msg.u.doip_periodic_send_data.dst_laddr = dmsg->dst_laddr;

                if ((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN) || (periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID)) {
                        uint32_t len = dmsg->msg_len;

                        /*
                         * diag_data is 255 bytes and msg_len is an unvalidated
                         * uint32_t from the host.  The copy loop below used a
                         * uint8_t counter, so any msg_len > 255 both overran
                         * diag_data[] by one byte and then looped forever
                         * because the counter wrapped back to 0.
                         */
                        if (len > sizeof(j2534_periodic_msg.u.doip_periodic_send_data.diag_data)) {
                                ERR("DoIP periodic msg_len %u exceeds %zu-byte buffer - truncating",
                                        len,
                                        sizeof(j2534_periodic_msg.u.doip_periodic_send_data.diag_data));
                                len = sizeof(j2534_periodic_msg.u.doip_periodic_send_data.diag_data);
                        }

                        j2534_periodic_msg.u.doip_periodic_send_data.msg_len = len;
                        memcpy(j2534_periodic_msg.u.doip_periodic_send_data.diag_data,
                                dmsg->diag_data, len);
                } else {
                        j2534_periodic_msg.u.doip_periodic_send_data.msg_len = 0;
                }

                if (PERIODIC_SUCCESS == PERIODIC_task_msg_cmd(&j2534_periodic_msg, periodic_msg_cmd)) {
                        fl_status_U8 = STATUS_NOERROR;
			dmsg->msgid = j2534_periodic_msg.prmsg_id;
                } else {
                        fl_status_U8 = ERR_FAILED;
                }

	return fl_status_U8; 
} 

int doip_ioctl_handling(doip_ioctl_handle_t *en)
{
	/* TODO: unimplemented - no DoIP IOCTL is acted on yet. */
	(void)en;
	return STATUS_NOERROR;
}

int doip_client_details(doip_client_details_t *dclient)
{
	int ret;
        char ipaddr[IPV4_STR_ADDR_LEN];
        char subnetaddr[IPV4_STR_ADDR_LEN];
        char Gwaddr[IPV4_STR_ADDR_LEN];
        uint16_t logicaladdr;

	memcpy(ipaddr, dclient->ipaddr, sizeof(ipaddr));
	ipaddr[IPV4_STR_ADDR_LEN-1] = 0;
	memcpy(subnetaddr, dclient->subnetaddr, sizeof(subnetaddr));
	subnetaddr[IPV4_STR_ADDR_LEN-1] =0;
	memcpy(Gwaddr, dclient->Gwaddr, sizeof(Gwaddr));
	Gwaddr[IPV4_STR_ADDR_LEN-1] = 0;
	logicaladdr = dclient->logical_addr;

	/* Validate the local copies, and do NOT wipe the server list on a bad
	 * address: `*head_connlist = NULL` discarded (and leaked) every DoIP
	 * server already registered.
	 */
	if (validate_ip(ipaddr) != 1) {
		ERR("Invalid client IP address (subnet=%s gw=%s laddr=0x%x)",
				subnetaddr, Gwaddr, logicaladdr);
		return ERR_FAILED;
	}

	if (validate_ip(Gwaddr) != 1) {
		ERR("Invalid gateway address (ip=%s subnet=%s laddr=0x%x)",
				ipaddr, subnetaddr, logicaladdr);
		return ERR_FAILED;
	}

	/* ipaddr/subnetaddr/Gwaddr are arrays, so the old
	 * `if (ipaddr == NULL || ...)` could never be true (-Waddress).
	 */
/*
#define	IFACE_DOWN	0
#define	IFACE_UP	1

	set_if_state("eth0", IFACE_DOWN);
	set_if_state("eth0", IFACE_UP);
*/
	ret = net_set_ip_addr("eth0", ipaddr, subnetaddr);
	if (ret < 0) {
		ERR("Set ip address failed");
		return ERR_FAILED;
	}


	ret = net_set_gw_addr(ipaddr, Gwaddr); 
	if (ret < 0) {
		ERR("Set Gateway address failed");
		return ERR_FAILED;
	}

	return STATUS_NOERROR;
}
/*
 * Unlink a connection table entry, tear down its TCP connection and free it.
 *
 * doip_cli_del_server() and doip_cli_delete_server() were byte-for-byte copies
 * of this (~35 lines each), so a fix in one never reached the other.  The
 * unlink walk also assumed `conn` was always reachable from the head: if it was
 * not, `while (tmp->next != conn) tmp = tmp->next;` ran off the end of the list
 * and dereferenced NULL.
 */
static int doip_cli_destroy_server(doip_conn_table_t *conn)
{
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head();
	doip_conn_table_t *tmp;
	int ret;

	if (conn == NULL)
		return ERR_FAILED;

	ret = doip_cli_stop_tcp_connection(conn);
	DBG("Returned from doip_cli_stop_tcp_connection with ret=%d!", ret);
	if (ret < 0) {
		ERR("Failed to stop TCP connection for %s\n", conn->ipaddr);
		/* fall-through */
	} else {
		led_set(LED_LINK_LED, LED_OFF);
	}

	/* Free the node list. connlist */
	doip_cli_remove_all_nodes(conn);

	/* Remove the 'connection table' from doip_clist */
	tmp = *head_connlist;
	if (tmp == conn) {
		*head_connlist = conn->next;
	} else {
		while (tmp != NULL && tmp->next != conn)
			tmp = tmp->next;

		if (tmp != NULL)
			tmp->next = conn->next;
	}

	free(conn);

	return STATUS_NOERROR;
}

void doip_cli_delete_server(void)
{
	doip_conn_table_t *conn;

	conn = doip_cli_ipaddr_to_conn_table(server_ip_addr);
	if (conn == NULL) {
		ERR("No server with %s is added", server_ip_addr);
		return;		/* was `return ERR_FAILED;` in a void function */
	}

	(void)doip_cli_destroy_server(conn);

	DBG("At the end of doip_cli_delete_server...");
}
/*
 * TODO: Need a mechanism to send Async events to the application
 * Eg. Veh-annon-resp results
 */
