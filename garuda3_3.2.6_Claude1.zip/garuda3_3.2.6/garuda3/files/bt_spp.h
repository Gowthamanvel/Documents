﻿#ifndef BT_SPP_H
#define BT_SPP_H

#include <stddef.h>
#include <stdint.h>
#include <dbus/dbus.h>

typedef void (*data_callback_t)(const char *data, int len);

/* NOTE: a `static GMainLoop *glib_main_loop = NULL;` definition used to live
 * here.  A static object defined in a header gives every translation unit that
 * includes it its own private, unused copy (and an -Wunused-variable warning).
 * Nothing referenced it, so it has been removed.
 */

struct bt_spp_ctx {
	int fd;
	GIOChannel *channel;
	guint watch_id;
	void (*rx_cb)(const char *data, int len);
};

int bt_spp_init(void);
void bt_spp_deinit(void);

/* Write data to the connected SPP device */
ssize_t bt_spp_write(const void *data, size_t len);

/* checks if connection exists */
uint8_t bt_spp_is_connected(void);

int bt_init(void);
int bt_deinit(void);

#endif
