﻿
/**
 *	@file can.h
 *
 *	Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _CAN_H_
#define _CAN_H_

#include <linux/can.h>
#include <netinet/in.h>

#include "hfcp.h"

//#define CAN_0   "can0"                // Specify the CAN0 interface name
//#define CAN_1   "can1"                //CAN1 interface name
#define NEW_BAUDRATE  500000
#define CAN_BAUDRATE1  1
#define CAN_SJW1       2
#define CAN_SAMPLING_POINT1 3
#define QUEUE_NAME "/can_queue"
#define MAX_MSG_SIZE 250
#define MAX_MSG_COUNT 10
#define CAN1_TX_QUEUE 1
#define CAN2_TX_QUEUE 2
#define CAN1_RX_QUEUE 3
#define CAN2_RX_QUEUE 4
#define CAN0_TX_Queue_SIZE   600	//500 Changed to 64 to support 1Mbps 4096 bytes data transfer
#define CAN0_RX_Queue_SIZE   800
#define CAN1_TX_Queue_SIZE   600	//500 Changed to 64 to support 1Mbps 4096 bytes data transfer
#define CAN1_RX_Queue_SIZE   800

/******************************************************************************
 *               E X P O R T E D   D E F I N I T I O N S
 ******************************************************************************/
#define RX_ONLY_STD_MSG         0x01
#define RX_ONLY_EXT_MSG         0x02
#define RX_BOTH_STD_EXT_MSG     0x03
#define BAUDRATE_100K           100000
#define BAUDRATE_125K           125000
#define BAUDRATE_250K           250000
#define BAUDRATE_500K           500000
#define BAUDRATE_800K           800000
#define BAUDRATE_1000K          1000000

#define CAN_FIXED_PACKET_LENGTH		6	/*< (2 (Rx Flags) + 4 (Timestamp) ) */
#define DATALOG_FIXED_PACKET_LENGTH     7	/*< (2 (Rx Flags) + 5 (Timestamp) ) */
#define CAN_PACKET_COPY_LENGTH		4	/*<  4 (Timestamp) */
#define DATALOG_PACKET_COPY_LENGTH      5	/*<  5 (Timestamp) */
#define MAX_CAN_FRAMES			3	/*< Maximum no of CAN Frames in to be framed/ sent to HFCP */
#define MODE				0x40	/*< Mode 01 for MultiFrames functionality */
#define MAX_CAN_FRAME_SIZE		19
#define MAX_DATALOG_FRAME_SIZE		20	/*< ( 1 (Message Length) + 2 (Rx Flags) + 5 (Timestamp) + 4 (Msg ID) + 8 ( Data ) */
#define MAX_USB_BUFFER_SIZE		512

#define CAN_INTERFACE			"can0"

typedef struct {
	uint8_t dlc;		/* DLC */
	uint8_t ide;		/* IDE : STD = 0, EXT = 1 */
	uint8_t rtr;		/* RTR : Data = 0, Remote = 1 */
	uint32_t msg_id;	/* Message Identifier */
	uint8_t data[8];	/* Message data */
} PACKED CAN_TX_Msg_t;

typedef struct {
	uint16_t msgLen;	/* Total Length Including Header(Msg ID) */
	uint32_t rxFlags;	/* IDE : STD or  EXT */
	uint32_t timeStamp;	/* Timestamp */
	uint32_t msgId;		/* Message Identifier */
	uint8_t data[8];	/* Message data */
} PACKED CAN_Rx_Msg_t;

/*
 * typedef enum {
 *	MID_FAIL,
 *	MID_PASS
 * } Mid_API_Status_t;
 */

typedef enum {
	CAN_BAUDRATE,
	CAN_SJW,
	CAN_SAMPLING_POINT
} CAN_Config_t;

typedef enum {
	CAN_CH1 = 0,
	CAN_CH2 = 1,
	CANFD_CH1 = 2,
	CANFD_CH2 = 3,

	CAN_CH_MAX,
} CAN_CH_TypeDef;

/* Added the Debug Messages, which will be sent on USB Packets */
typedef struct {
	uint32_t CAN_Mid_Tx_Send;
	uint32_t CAN_Mid_Tx_Fail;
	uint32_t CAN_Tx_Complete;
	uint32_t CAN_Tx_Queue_Fail;
	uint32_t CAN_Rx_Count;
	uint8_t CAN_Tx_Progress;
	uint8_t CAN_Last_Tx_Data;
	uint8_t reserved_1;
	uint8_t reserved_2;
} PACKED Garuda_Debug_Info;

struct mode2_queue {
	uint8_t chan_num;
	uint32_t stmin;
	union {
		struct can_frame CAN;
		struct canfd_frame CANFD;
	}frame;
};

typedef struct mode2_queue mode2_queue_t;

struct mode2_msg_buf {
	long mtype;
	struct mode2_queue m2_data;
};

typedef struct mode2_msg_buf mode2_msg_buf_t;

uint8_t CAN_Mid_Init(char *can, uint32_t p_baudrate);
uint8_t CAN_Mid_Disable(uint8_t p_channel);
uint8_t CAN_Mid_Enable(uint8_t p_channel, uint8_t p_connection_flag_U8);

/** TODO: Undefined function - remove if not required */

/** Mid_API_Status_t CAN_Mid_txData(CAN_CH_TypeDef, CAN_TX_Msg_t *, uint8_t); */



int getCAN1TXStatus(void);
Mid_API_Status_t CAN_Mid_Transmit(CAN_CH_TypeDef channel,
				  struct can_frame *frame);
Mid_API_Status_t CAN_FD_Mid_Transmit(CAN_CH_TypeDef channel,
				     struct canfd_frame *frame);


//int LowLevel_CAN_get_loopback_status(uint8_t p_channel_no_U8);
//int CAN_Mid_get_current_baudrate(uint8_t chid);
//int LowLevel_CAN_enable_loopback(uint8_t p_channel_no_U8);
//int LowLevel_CAN_disable_loopback(uint8_t p_channel_no_U8);
//int CAN_Mid_set_baudrate(int baudrate, uint8_t chid);

//int LowLevel_CAN_get_current_sampling_mode(int channel);

uint32_t swap_uint32(uint32_t val);
uint32_t can_rx_handler(int channel, uint8_t *buf, int len);

int mode2_create_process(void);

#endif /* _CAN_H_ */

