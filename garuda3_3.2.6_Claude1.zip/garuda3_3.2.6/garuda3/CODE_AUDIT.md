# Garuda-3 (g3d) — Code Audit and Cleanup Report

**Subject:** `garuda3` 3.2.6 — Linux diagnostic daemon for SAMA5D2 (CAN, CAN-FD, KWP/ISO-9141, DoIP)
**Scope:** Full static review of the 19 C modules / 21 headers (~14,400 lines), the Yocto recipe and both Makefiles
**Status:** Stage 1 cleanup applied; Stage 2 items listed for the team

> This report and the accompanying code changes were produced with AI assistance.
> **Nothing here has been compiled or run on target.** Please build, review the diff,
> and run your HIL regression before promoting any of it.

---

## 1. Executive summary

The daemon is functional but carries a significant amount of accumulated risk. The
review found **38 defects**, of which the most consequential fall into four groups:

| Group | Count | Why it matters |
|---|---|---|
| **Memory safety on host-controlled input** | 8 | Length fields taken straight off USB/Wi-Fi/Bluetooth drive `memcpy()` into fixed buffers. A malformed or hostile host frame can smash the stack, overrun a global, or leak heap contents back to the host. |
| **Undefined behaviour the compiler already knew about** | 11 | `void` functions doing `return -1`, non-`void` functions falling off the end, GLib callbacks with no `return` at all, `uint8_t` holding a `-1` error code. These are all `-Wall` diagnostics that were never acted on. |
| **Resource leaks in long-running paths** | 7 | Every ISO-TP frame, every USB re-init, every Bluetooth reconnect and every CAN command leaked memory or a GLib source. On a device that runs for days this is cumulative. |
| **Silent functional faults** | 12 | CAN-FD data-rate requests reprogrammed the arbitration rate; periodic messages whose period was not a multiple of 10 ms never transmitted; `-d`/`-D` command-line flags aborted with a usage message; the Wi-Fi listener ignored a failed `bind()`. |

Separately, the source tree shipped **13.0 MB of editor swap files, Visual Studio
caches, `tags` and `cscope.out` against 0.6 MB of actual source** — a 23:1 ratio of
build/editor litter to code.

**Stage 1 (applied):** 13.0 MB of litter removed, build files hardened, and **26 defects
fixed** — every memory-safety finding, every leak, and every compiler-diagnosable
defect. All edits are local and mechanical; no protocol logic or state machine was
restructured.

**Stage 2 (not applied, listed in §5):** duplicated subsystems, dead code, debug-logging
throughput cost, and input validation at the protocol boundary. These need design
decisions and bench testing.

---

## 2. Immediate next step

```bash
make -f Makefile.ubuntu clean && make -f Makefile.ubuntu 2>&1 | tee build.log
```

The x86 Makefile was stale (it listed a `gpio.c` that does not exist and omitted five
modules that do) and has been corrected, so this path now builds the same source set as
the Yocto recipe. Please send the warnings — several fixes assume struct layouts I could
only read, not verify.

Then the target build:

```bash
bitbake garuda3
```

---

## 3. Stage 1 — housekeeping and build hygiene (applied)

### 3.1 Tree cleanup

Removed 13.0 MB / 26 files that should never have been committed:

- `.vs/` — Visual Studio browse database, two 4 MB precompiled headers, `.wsuo`, `slnx.sqlite` (10.8 MB)
- 15 Vim swap files — `.hfcp.c.swf` … `.swp`, `.can.c.sw*`, `.doip_cli.c.swm`, `.net_if.c.swp` (1.3 MB)
- `tags` (189 KB) and `cscope.out` (884 KB) — regenerable

Added **`.gitignore`** covering build output, editor state and navigation databases so
this does not recur. `make tags` and `make cscope` targets were added to regenerate the
indices on demand.

### 3.2 `Makefile`

- **Header dependency tracking** (`-MMD -MP`). Previously there were no header
  dependencies at all: `hfcp.h` is included by 12 of the 19 translation units, so editing
  a packed struct there and running an incremental build linked stale objects against the
  old layout. This is the single highest-value build change in the report.
- Explicit `%.o` rule (was relying on make's implicit rule), `.PHONY`, `tags`/`cscope`
  targets, and `clean` now removes the `.d` files.

### 3.3 `Makefile.ubuntu`

This file was unbuildable. It listed `gpio.c` (does not exist) and omitted
`gpio_App.c`, `kwp_if.c`, `periodic_if.c`, `bt_spp.c` and `doip_if.c`. Corrected to match
the Yocto source list, added the dbus pkg-config flags that the link needs, and dropped
`-Werror` (the tree is not warning-clean yet — see §5.1).

### 3.4 `garuda3.bb`

- `file://scripts/run_wifi.sh` was listed twice in `SRC_URI`.
- `DEBUG` is now a single switch:

  ```
  G3_DEBUG ?= "1"     # default unchanged; set to "0" for production/perf images
  ```

- Added the four warning flags that catch the defect classes actually present:
  `-Wreturn-type -Wimplicit-function-declaration -Wuninitialized -Wsign-compare`.

---

## 4. Stage 1 — defects fixed

### 4.1 Memory safety on host-controlled input — **critical**

These are all reachable from a frame arriving over USB HID, the Wi-Fi socket or the
Bluetooth SPP channel. None of the length fields were validated.

| # | Location | Defect |
|---|---|---|
| 1 | `hfcp.c` — CAN and CAN-FD send paths, 8 call sites | `memcpy(&data_buffer[data_idx], src, len)` with **both** the destination offset and the length taken from the host's `Totallen`/`currlen`. `data_buffer` is 4096 bytes; nothing bounded either value. Now routed through `hfcp_copy_segment()`, which clamps against the real buffer size and logs the drop. |
| 2 | `hfcp.c` — `Start_msg_filter`, `Start_FD_msg_filter`, KWP filter (3 sites) | `for (i = 0; i < plv->len; i++) fl_filter_config.maskMsg[i] = plv->buf[i];` — `maskMsg`/`patternMsg` are 12 bytes, `plv->len` is an unvalidated host `uint8_t`. **A `len` of 255 wrote 243 bytes past a stack object.** Now `hfcp_copy_filter_field()`. |
| 3 | `hfcp.c` — periodic message handlers (2 sites) | Same pattern into `proto_msg.data[12]`. Now `hfcp_copy_periodic_data()`. |
| 4 | `hfcp.c:Firmware_Update_command()` | `Firmware->length` is a host `uint16_t`; `Firmware->buffer` is 512 bytes. Two unbounded `memcpy()`s walked past the end of `buffer_t`. Now rejects any packet claiming more than the buffer holds. |
| 5 | `can.c:can_rx_handler()` / `hfcp.h` | `canBufInfo[].address` was `HFCP_MAX_IN_SINGLE_FRAME` (64) bytes, sized when `CAN_MSG_DATA_SIZE` was 8. Raising it to 64 for CAN-FD grew `can_msg_resp_hdr_t` to **232 bytes** without growing the buffer, so a CAN-FD payload overran into the adjacent channel's entry. Buffer resized to `HFCP_CAN_RESP_BUF_SIZE` (512) and locked down with two `_Static_assert`s. |
| 6 | `bt_spp.c:spp_rx_data_callback()` | `memcpy(recvbuf + 256, data, len)` — `recvbuf` is 512 bytes, `len` is up to 1023 from the RFCOMM read. **767-byte overflow of a static buffer.** Now bounded. |
| 7 | `bt_spp.c:spp_rfcomm_io_handler()` | Read `sizeof(buf)` then wrote `buf[bytes_read] = '\0'` — one past the end of a 1024-byte stack array on a full read. Now reads `sizeof(buf) - 1`. |
| 8 | `doip_if.c` / `periodic_if.c` (3 sites) | DoIP periodic payload copied with a `uint8_t` loop counter against a `uint32_t` host `msg_len` into `diag_data[255]`. A `msg_len` above 255 wrote one byte past the array **and then looped forever** as the counter wrapped. Now clamped `memcpy()`. |

Additionally, `kwp_if.c:App_InitData()` allocated ~19 bytes but handed the pointer to
`host_write()`, which always transmits a full 512-byte HID report — **reading ~490 bytes
of adjacent heap and sending it to the diagnostic host.** Now allocates and zeroes a full
report (and frees it — see §4.3).

### 4.2 Undefined behaviour / compiler diagnostics

| Location | Defect |
|---|---|
| `hfcp.c` ×6 | `return -1;` inside `void` functions (`process_CAN_command`, `process_CAN_FD_command`, both IOCTL handlers). Each also leaked the 512-byte `pbuf`. Converted to `goto out`. |
| `hfcp.c:process_Setup_command()` | `return EXIT_FAILURE;` in a `void` function — and it returned without answering the host at all. Now sends `ERR_FAILED` and returns. |
| `hfcp.c:process_Setup_command()` | `pResp` was only assigned in three of the case arms but written through in two others — **a store through an uninitialised pointer.** Now assigned once up front. |
| `hfcp.c:isotp_rx_callback()` | A `gboolean` GLib callback **with no `return` statement**. GLib decided whether to keep the CAN ISO-TP receive watch alive from whatever was in the return register. |
| `hfcp.c:bitrate_config_check()`, `get_bitrate_config()` | Both fall off the end for an unrecognised protocol id. The first drives `isotp_close_all_sockets()`. |
| `hfcp.c` CAN-FD send | `uint8_t fd` and `uint8_t ret`. `isotp_canfd_get_socket()` returns `-1` → `255`, so `if (fd < 0)` never fired and the code wrote to descriptor 255; a failed `write()` was reported to the host as success. Now `int` / `ssize_t`. |
| `kwp_if.c:KWP_uart_rx_callback()` | Two bare `return;` in a `gboolean` callback, on the K-line receive path. Also leaked the `GError`. |
| `can.c:can_rx_handler()` | Bare `return;` in a `uint32_t` function. |
| `can.c:can_rx_handler()` | `chan` and `protoid` used uninitialised when no protocol is enabled for the interface. Now drops the frame. |
| `gpio_App.c` ×2 | `T_gpio_PIN_config()` / `T_gpio_PIN_set()` declared `void`, both `return -1`. Changed to `int` (header updated), and `T_gpio_PIN_config()` no longer continues after a failed `open()`. |
| `periodic_if.c:periodic_handle_DOIP()`, `doip_if.c:doip_cli_delete_server()` | `return ERR_FAILED;` in `void` functions. |
| `hfcp.c` ×3 | `memset(pbuf, 0, sizeof(USB_PKT_SIZE))` — `sizeof(int)` is **4**, not 512. The remaining 508 bytes of heap garbage went to the host in every response. Replaced with `calloc()`. |
| `hfcp.c` | `ReadBatteryVoltage()` called with no prototype in scope (implicit declaration) **and** handed a `uint32_t *` where it takes a `uint16_t *`. Prototype added to `hfcp.h`; caller's type corrected. |
| `hfcp.c`, `bt_spp.c`, `doip_if.c`, `kwp_if.c`, `periodic_if.c` | K&R `()` parameter lists under `-Wstrict-prototypes` → `(void)`. |
| `bt_spp.h` | `static GMainLoop *glib_main_loop = NULL;` **defined in a header** — a private unused copy in every including TU. Removed. |
| `ioctl_common.h` | Include guard typo: `#ifndef IOCTL_COMMON_H` / `#define IOCTL_COMMO**M**_H`. The guard never worked. |
| `g3d.h` | `char *p = CSZ_logpriority[...]` discards `const`. |
| `net.c` | `#define NO_OF_INTERFACES (sizeof(x)/sizeof(x[0])` — **unbalanced parenthesis**. Unused, removed. |

### 4.3 Resource leaks

| Location | Leak |
|---|---|
| `hfcp.c:isotp_rx_callback()` | `malloc(sizeof(can_bulk_msg_resp_hdr_t))` never freed on the success path — **~534 bytes leaked per ISO-TP frame received.** (The CAN-FD twin already freed it correctly.) |
| `hfcp.c` ×6 | `pbuf` leaked on every early `return -1` (see §4.2). |
| `kwp_if.c:App_InitData()` | Allocation never freed — leaked on every 5-baud / fast init. |
| `usbhid.c:usbhid_deinit()` | Closed the fd and nothing else. `usbhid_reinit()` is called from every read/write error path and re-adds a 1-second `GSource` each time, orphaning the previous I/O watch. **Hours of USB flapping accumulated thousands of live sources polling a closed descriptor.** Now removes both sources. |
| `net_if.c` | Every client reconnect leaked a `GIOChannel` watch and a `GSocketConnection` ref, and the stale watch kept firing on a closed fd. |
| `bt_spp.c` | Same on every Bluetooth reconnect. Factored into `spp_close_channel()`, which the three disconnect paths now share. |
| `doip_if.c:doip_cli_add_server()` | The `connlist` node leaked on all three error returns. |

### 4.4 Silent functional faults

| Location | Fault |
|---|---|
| `can_nl_if.c:can_if_setdbitrate()` | Called `can_nl_set_bittiming()` (sets `IFLA_CAN_BITTIMING`, the **arbitration** rate) instead of `can_set_dbittiming()` (`IFLA_CAN_DATA_BITTIMING`). **Every CAN-FD data-rate request reprogrammed the wrong phase**, and the correct function was dead code. |
| `can_nl_if.c:send_nl_request()` | `phdr = (struct nlmsghdr *)(phdr + NLMSG_ALIGN(phdr->nlmsg_len))` — pointer arithmetic on a struct pointer, advancing **16× too far**, then decrementing the remaining length using a value read from that out-of-bounds pointer. Replaced with `NLMSG_OK`/`NLMSG_NEXT`. |
| `periodic_if.c:PERIODIC_task_handler()` | `local_periodicity` is `uint16_t`; the handler did `-= 10` then `if (... <= 0)`. For any period that is **not an exact multiple of 10 ms** the subtraction underflowed to ~65530, was caught by the overrun guard, reset to the period, and the message **never transmitted at all**. The "send the first one immediately" path (`c_TX_IMMEDIATE_CNT == 1`) never worked either. Now saturates at 0. |
| `g3d.c:process_command_line()` | `getopt` string was `"C:b"`. `-b` takes the bitrate but had no `:` (so `atol(optarg)` read a stale/NULL pointer), and `-d`/`-D` were documented in the usage text but **absent from the string**, so both fell to `default:` and aborted. Now `"C:b:dD"`. |
| `g3d.c:signals_init()` | Returns `guint` but returned `-1` on failure — `0xffffffff`, which sails past the caller's `if (!SignalSource)`. Now returns 0. |
| `net_if.c:net_if_init_server()` | `if (ret && err != NULL)` — only reported an error when the call had **succeeded**. A failed bind to port 9000 was silently ignored and the Wi-Fi/CDC transport came up dead. |
| `net_if.c:net_if_write()` | `if (err \|\| bytes_written != count) { ... err->message ... }` — **NULL dereference** on every short write, because a short write leaves `err == NULL`. |
| `net.c:net_event_handler()` | On any `recvmsg` errno other than `EINTR`/`EAGAIN` (e.g. `ENOBUFS`, which netlink does produce), control fell through and **spun forever**, wedging the GLib main loop. |
| `net.c:net_get_addr_status()` | Required `IFF_DORMANT` to be *set* to report an interface as healthy. A working interface is not dormant, so this returned 0 unconditionally. |
| `net.c:validate_ip()` | Ran `strtok()` **directly on the caller's buffer**, replacing every `.` with `\0`. `doip_if.c` passes the host-supplied address field in, so after validation the string was truncated to its first octet for every subsequent use. Now works on a local copy via `strtok_r()`. |
| `doip_if.c` ×3 | On a malformed IP the code did `*head_connlist = NULL` — **discarding and leaking every DoIP server already registered** because one request was bad. |
| `doip_if.c:doip_cli_del_server()` | `while (tmp->next != conn) tmp = tmp->next;` dereferences NULL if `conn` is not reachable from the head; and when `conn` *was* the head it set the head to NULL, **dropping the entire rest of the list**. |
| `hfcp.c:host_write()` | The Bluetooth branch had `hexdump()` **after** `return` — dead code, so BT traffic was never traced. |
| `can_if.c:can_if_init_chan()` | `memset(&gstrCANInitInfo[ch], ...)` ran **before** the bounds check, and the check used `>` instead of `>=`. |
| `can_if.c:CAN_Mid_set_datarate()` | Passed an **uninitialised stack buffer** as the interface name (both assignment branches were commented out). |
| `can_if.c:can_if_deinit_chan()` | `g_io_channel_shutdown(NULL, ...)` on any channel never brought up — which is all of them, since `can_if_init()` no longer opens them. |
| `can_if.c:can_if_open()` | Error path did a bare `close(canfd)`, closing an uninitialised value when `socket()` failed and leaking `*fd` when the second socket failed. |
| `can_if.c:can_if_reinit()` | `uint32_t ret; if (ret < 0)` — never true. |
| `usbhid.c:usbhid_init()` | `guint timersource; if (timersource < 0)` — never true. `g_timeout_add_seconds()` signals failure with 0. |
| `usbhid.c`, `can_if.c` | `hexdump()` called with the already-advanced buffer/offset after a partial write, printing the wrong region (and reading past the end for packets after the first). |
| `bt_spp.c:bt_register_spp_profile()` | Returned 0 even when BlueZ rejected the profile, so `bt_spp_init()` reported success and no SPP channel would ever open. |
| `bt_spp.c:bt_spp_is_connected()` | Dereferenced `spp_ctx` before `bt_spp_init()` had allocated it; and `fd > 0` under-reports (fd 0 is valid). |
| `bt_spp.c:bt_spp_init()` | `malloc()` without initialising `->channel` / `->watch_id`, both of which `bt_spp_deinit()` and the I/O handler read. Now `calloc()`. |
| `hfcp.c:ReadBatteryVoltage()` | Both `fscanf()` return values ignored — a short or malformed sysfs read left `scale`/`adc_raw` as uninitialised stack data and reported a garbage battery voltage to the host. |
| `hfcp.c:FileToDelete()` | `system("rm /tmp/...")` replaced with `unlink()` — no shell, no fork, no `PATH` lookup. |
| `data_logger.c:DEBUG_deinit()` | `fflush(NULL_pointer)` when `DEBUG_init()`'s `fopen` had failed. |
| `led.c:led_set()` | No lower bound on the index. |
| `net.c:net_set_gw_addr()` | `rt.rt_dev = "eth0"` assigns a string literal to `char *`. |
| `net.c:net_init()` | Ignored `net_init_ctrl_interface()`'s return, and installed the event callbacks **after** arming the netlink watch — the first `RTM_NEWLINK` could call through a NULL `link_status` pointer. |

### 4.5 Duplication removed

- `doip_if.c`: `doip_cli_del_server()` and `doip_cli_delete_server()` were byte-for-byte
  copies (~35 lines each) — a fix in one never reached the other. Both now call a shared
  `doip_cli_destroy_server()`.
- `doip_if.c`: `doip_cli_add_node()` / `doip_cli_del_node()` each open-coded the same
  server lookup that `doip_cli_ipaddr_to_conn_table()` already performs (~20 lines each).
- `bt_spp.c`: three identical disconnect teardowns → `spp_close_channel()`.
- `hfcp.c`: eight copies of the reassembly `memcpy` → `hfcp_copy_segment()`; five copies
  of the filter-field copy → `hfcp_copy_filter_field()`.
- `USB_PKT_SIZE` was defined in three places and only reachable when `CONFIG_USBHID` was
  set; now also defined (guarded) in `hfcp.h`, which every module includes.

---

## 5. Stage 2 — recommended, not applied

These need a design decision, a bench, or both.

### 5.1 Validate the protocol boundary (highest remaining risk)

`handle_hfcp_rx(uint8_t *buf, int length)` **ignores `length` entirely**. It casts `buf`
to `hfcpReq_t *`, reads `proto_id`, and dispatches. Every handler then reads union members
without checking that the frame is long enough to contain them. Stage 1 bounded the
*copies*; it did not bound the *reads*.

Recommendation: add a per-command minimum-length table and reject short frames at the top
of `handle_hfcp_rx()` before dispatch. This is the one change that would turn the whole
class of input-handling bugs from "exploitable" into "rejected".

### 5.2 Debug logging throughput cost

`-DDEBUG` is on in the shipped recipe, which builds **~430 `DBG()` sites and ~80 direct
`printf()` calls**. Worse, `hexdump()` emits **one `printf()` per byte** and is called on
every USB read, every USB write and every CAN frame — ~512 `printf()` calls per 512-byte
transfer. On a SAMA5D2 driving CAN-FD at 1 Mbit/s with bulk ISO-TP transfers this is very
likely the dominant throughput limiter.

Stage 1 made this a one-line switch (`G3_DEBUG = "0"`). Suggested measurement: time a
large ISO-TP block transfer with `G3_DEBUG=1` vs `G3_DEBUG=0`. If the delta is large,
consider also rewriting `hexdump()` to build a line buffer and emit one `fputs()` per 16
bytes, so that debug builds stay usable.

Note also that in `-D` (syslog) mode `daemon(0, 0)` closes stdout, so all 80 direct
`printf()` calls write to a closed descriptor — they cost syscalls and produce nothing.
Those should be converted to `DBG()`/`ERR()`. `doip_cli.c` has 30 of them.

### 5.3 Two parallel periodic-message engines

`j2534_periodic.c` (806 lines) and `periodic_if.c` (459 lines) implement the same
`startnew` / `stop` / `suspend` / `update` state machine over near-identical tables, and
they **disagree**: `j2534_periodic.c` decrements by 1 and tests `== 0`; `periodic_if.c`
decremented by 10 and tested `<= 0` (the bug fixed in §4.4). Only `periodic_if.c` handles
DoIP; only `j2534_periodic.c` has the BCM path. Recommend consolidating on one.

### 5.4 Is the raw-socket CAN RX path still live?

`can_if_init()` no longer opens the CAN channels (the loop is commented out), and the
`CAN_Mid_Init()` calls in `hfcp.c` that would reach `can_if_init_chan()` are largely
commented out too. The ISO-TP socket path added in `hfcp.c` appears to have superseded it.
If so, `can_rx_handler()`, `can_if_data_handler()` and the `canBufInfo` assembly logic in
`can.c` (~250 lines) are dead and should be deleted rather than maintained. **Please
confirm before removing** — I could not establish this from the source alone.

### 5.5 `mode2_tx_process()` — `select()` used as a sleep

`can.c:mode2_tx_process()` does `FD_SET(1, &readfds); select(1, &readfds, ...)`. With
`nfds == 1` only descriptor 0 is watched, so descriptor 1 is outside the set and the call
always times out — it is a `sleep()` with extra steps. Worse, the STmin delay is then
applied by re-calling `select()` with the **same `timeval`**, which Linux has already
decremented to zero, so the inter-frame delay never happens. Replace with
`clock_nanosleep()`.

This whole function runs in a `fork()`ed child that never exits and inherits the parent's
GLib state; it is worth reconsidering as a thread or a timerfd in the main loop.

### 5.6 Dead code and unreachable configuration

- **`app_iso14230.c` / `app_iso14230.h` cannot compile.** `app_iso14230.h` includes
  `iso14230.h`, which does not exist in the tree. It is correctly absent from both
  Makefiles but still listed in `SRC_URI`, so it is copied to `WORKDIR` on every build.
  Delete both files, or restore the missing header.
- **`CONFIG_GPIO` and `CONFIG_BT` can never be enabled** — `g3d.h` includes `gpio.h` and
  `bt.h`, neither of which exists. `CONFIG_GPIO` is already commented out in the recipe;
  `CONFIG_BT` is dead (Bluetooth is built under `CONFIG_BTH` instead). `g3d.c` calls
  `bt_init()`/`bt_deinit()` twice, once under each. Remove the `CONFIG_BT` arms.
- `can_if.c` and `net.c` contain several large `#if 0` blocks (the old `can_if_open()`,
  `can_if_fd_write()`, `#ifdef WANTED`). These are history; git holds history.

### 5.7 `host_write()` size handling

The Wi-Fi branch calls `net_if_write(buf, HFCP_PKT_SIZE)`, ignoring the caller's `count`;
the USB branch rounds up to a whole 512-byte HID report. Both therefore require every
caller to pass a buffer of at least 512 bytes. That holds today, but it is an undocumented
invariant enforced by nothing. Either make `host_write()` copy into a report-sized bounce
buffer, or assert on it.

### 5.8 Global state in `hfcp.c`

`hfcp.c` carries roughly 60 file-scope mutable globals (`CAN_active`, `CAN_or_ISO`,
`stored_CANID`, `data_idx`, `sequenceNum`, …) shared across the CAN, CAN-FD and KWP
handlers, plus `static` locals that persist reassembly state between frames. The CAN and
CAN-FD send paths share `data_buffer`, `data_idx` and `tx_flag`, so interleaved CAN and
CAN-FD traffic on the two channels can corrupt each other's reassembly. Recommend a
per-channel context struct. This is a real latent bug, but it is a refactor, not a patch.

### 5.9 Minor

- `g3d.c:get_g3_board_info()` loops `for (i = FIRST_BINFO_MTD; ; i++)` with no upper
  bound, relying on `open()` failing to terminate.
- `g3d.c` — the `G3_board_info_valid` assignment reads as inverted relative to its comment.
- `struct G3dContext.Platform` is declared `gboolean` but holds a 0–3 platform index.
- `net_if.c` uses `g_io_channel_read`/`g_io_channel_write`, deprecated since GLib 2.2 in
  favour of the `_chars` variants.
- `j2534_filter.c:J2534_ExclusiveFilter()`/`J2534_InclusiveFilter()` are near-identical and
  both stop at the first unused slot rather than scanning the whole table.
- `can_nl_if.c`: `can_nl_set_bittiming()` and `can_set_dbittiming()` are ~70 identical
  lines differing only in one `rta_type`.
- `gpio_App.h` uses `guint` without including a GLib header; it works only because every
  includer pulls in `g3d.h` first.

---

## 6. Verification checklist

Stage 1 changed behaviour in ways your regression suite should confirm:

1. **CAN-FD data rate** — `can_if_setdbitrate()` now programs the data phase. Verify with
   a scope or `ip -d link show can0` that both arbitration and data rates are as requested.
2. **Periodic messages** — previously only periods that were exact multiples of 10 ms
   transmitted. Test 5 ms, 25 ms, 100 ms; confirm the first message now goes out immediately.
3. **Command line** — `g3d -d` and `g3d -D` now daemonize instead of printing usage;
   `-b 500000` now parses.
4. **Wi-Fi transport** — a failed bind to port 9000 is now reported at startup.
5. **Network link LED** — `net_get_addr_status()` now returns 1 for a healthy interface.
6. **DoIP** — adding a server with a malformed IP no longer wipes previously added servers;
   the address string is no longer mangled by validation.
7. **Oversized frames** — a filter/periodic/segment length beyond the buffer is now
   truncated with an `ERR()` rather than overflowing. Confirm your host tooling never
   legitimately sends one; if it does, the limits in §4.1 need raising, not the clamp removing.
8. **Long-run soak** — with the leaks closed, RSS should now be flat. Run a 24 h CAN-FD
   soak with periodic USB disconnect/reconnect and watch `/proc/<pid>/status`.
