// GarudaReflashDlg.h : header file
//

#if !defined(AFX_INNOVAREFLASHDLG_H__6F6EAB2A_F43B_4A79_A512_517695C56FB1__INCLUDED_)
#define AFX_INNOVAREFLASHDLG_H__6F6EAB2A_F43B_4A79_A512_517695C56FB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <wtypes.h>	// MFC type defines
#include <initguid.h>
#include "winuser.h"
#include "usb.h"
extern "C" 
{
	#include "hidsdi.h"
	#include <setupapi.h>
	#include <dbt.h>
}
#include <iostream>

typedef unsigned char UCHAR; // Saving space with typedef

#define INPUTREPORTMAX				256  // Defines the maximum number of bytes in input report
#define OUTPUTREPORTMAX				256 // Maximum number of bytes in output report
#define MAX_FILE_NAME_LENGHT		4096
#define BUFFER_SIZE					256
#define FIRMWARE_BYTES_LENGTH		2

/*error codes*/
#define STATUS_NOERROR				0x00
#define STATUS_INVALID_RESPONSE		0x01
#define STATUS_UNKNOWNERROR			0x02
#define STATUS_WRITE_FAILED			0x04


//Header for Bootloader data 
#define BOOTLOADER_BYTE				0xEA

//To send  bootloader mode command after detecting device in normal mode.
#define COMMAND_BYTE1				0xEE	
#define COMMAND_BYTE2				0xAA
#define COMMAND_BYTE3				0x55

//To send checksum info command after changing to bootloader mode.
#define CHECKSUM_BYTE1				0xA5
#define CHECKSUM_BYTE2				0xAA
#define CHECKSUM_BYTE3				0x55

#define START_NORMALMODE			0xAA


#define READFILE_TRIES			    5
#define WRITEFILE_TRIES				5

#define INFPATH						"C:\\windows\\DE_L_C.inf"
#define VALIDLABELUSERSTRING		"@DELabelConFig@DEB1@06022009@DELabeler"
#define DELIMETER					"#"



#define BL_VID_1X						0x0471 
#define BL_PID_1X						0x5742

#define NM_VID_1X						0x0471 
#define NM_PID_1X						0x5741

#define BL_VID_2X						0x03EB 
#define BL_PID_2X						0x5744

#define NM_VID_2X						0x03EB 
#define NM_PID_2X						0x5743


#define	DBGU_CIDR_MASK				~0x000F001F		// Remove version and SRAMSIZ (bug DBGU_CIDR S128 et S256 rev C)
#define PROG_FMR					 0x00480100		// EFC FMR configuration for 48MHz 
#define FLASH_CMD_REG 				 0xFFFFFF64	
#define BOOTLOADER_CMD				 0x5A00020B
#define BOOTLOADER_ENTRY			 0x0100000
#define BOOTLOADER_NVM		         0x00300100

//uncomment whichever is required
//#define GARUDA_BULK
#define GARUDA_HID
#ifdef GARUDA_TOOL
	#define VID							0x0471
	#define PID							0x5741
#else
	#define VID							0x1720 // Vendor id of the innova device
	#define PID							0x120 // Product id of the innova device
#endif
#define EP_IN  0x82
#define EP_OUT 0x02
#define MAX_PROTOCOL_NUM			255
/////////////////////////////////////////////////////////////////////////////
// CGarudaReflashDlg dialog

class CGarudaReflashDlg : public CDialog
{
// Construction
public:
	CGarudaReflashDlg(CWnd* pParent = NULL);	// standard constructor
	~CGarudaReflashDlg();
	char chFileName[MAX_FILE_NAME_LENGHT];
	CMenu *m_pMenu,*submenu;
	HWND  m_hWndProgress;
	CWnd* pwnd ;// Pointer to main window
	BOOL NormalMode;
	BOOL BootLoaderMode ;
	BOOL FlashThreadActive;
	BOOL HidAttached;					// Used by member functions to make sure device enumerated


	unsigned char *buffer;



	void  RemoveCodeFromFile(unsigned char *, DWORD *);
	BOOL bReadFlashStatus(int);
	BOOL bSendNMCommandToDevice();
	BOOL constructPacket(unsigned char *,unsigned char*,unsigned int,unsigned char,unsigned int);
	BOOL constructExtraPacket(unsigned char *,unsigned char*,unsigned int,unsigned char,unsigned int);
	BOOL WriteOutputReport(unsigned char*ucReport,DWORD dwLength);
	BOOL WriteOutputReport_Bulkmode(unsigned char*ucReport,DWORD dwLength);
	BOOL  ReadInputReport();
	BOOL  ReadInputReport_Bulkmode();
	BOOL bOpenHidDevice();
	BOOL bOpenDevice();
	BOOL EnableBootLoader();
	usb_dev_handle* open_dev(void);
	
	UCHAR								InputReport[INPUTREPORTMAX];
	UCHAR								OutputReport[OUTPUTREPORTMAX];
	//For Garuda Bulk Implementation

	usb_dev_handle *dev;



protected:
	//Sends enable bootloader command to device
	void ParseFirmWareFile();
	// Open the HID Device based on VID and PID
	//Reads the newest report from the device

	//Get Output Report size
	int GetOutputReportSize(void); 
	int GetInputReportSize(void);
	int GetFeatureReportByteLength(void);
	//Writes the newest report from the device based on report number
	void CloseHandles();
	BOOL GetDeviceDetected() {return (HidAttached);}
	void DisplayInputReport();
	void PrepareForOverlappedTransfer();
	BOOL ValidateFile(unsigned char *);
	BOOL ValidateLabelUser();
	// gets the device capabilites and puts it in Capabilities
	void GetDeviceCapabilities(void);
	/*Device change detection*/
	LRESULT Main_OnDeviceChange(WPARAM wParam, LPARAM lParam);
	void RegisterForDeviceNotifications();

private:
	// private properties
	HANDLE HidDevHandle;				// Handle for HID Device
	HANDLE ReadHandle;						
	HANDLE WriteHandle;	
	GUID HidGuid;						// holds GUID of device
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
	OVERLAPPED HIDOverlapped;
	DWORD dwError;
	ULONG Length;
	LPOVERLAPPED lpOverLap;
	DWORD NumberOfBytesRead;
	ULONG Required;
	HIDP_CAPS Capabilities;				// holds enumeration info
	HANDLE								hEventObject;
	unsigned char						uchFirmWareVersion[FIRMWARE_BYTES_LENGTH];
	unsigned short						usFirmwareVersion;

	HWND hStatus;

	unsigned long m_ulPID;
	unsigned long m_ulVID;


public:

// Dialog Data
	//{{AFX_DATA(CGarudaReflashDlg)
	enum { IDD = IDD_GARUDAREFLASH_DIALOG };
	CStatic	m_ctrlDwnStatus;
	CProgressCtrl	m_ctrlProgress;
	CEdit	m_ctrlFrmFile;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGarudaReflashDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	// Generated message map functions
	//{{AFX_MSG(CGarudaReflashDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonAutoDetect();
	afx_msg void OnSelfwmFile();
	afx_msg void OnReflash();
	afx_msg void OnUserManual();
	afx_msg void OnClose();
	afx_msg void OnButtonBl();
	afx_msg void OnLabel();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INNOVAREFLASHDLG_H__6F6EAB2A_F43B_4A79_A512_517695C56FB1__INCLUDED_)
