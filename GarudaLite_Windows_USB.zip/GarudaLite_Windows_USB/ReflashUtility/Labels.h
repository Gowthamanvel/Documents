#if !defined(AFX_LABELS_H__F84532F3_4EE7_405A_9D60_801906883EA0__INCLUDED_)
#define AFX_LABELS_H__F84532F3_4EE7_405A_9D60_801906883EA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Labels.h : header file
//

#define MAX_FILE_NAME_LENGHT		4096
#define FIRMWARE_BYTES_LENGTH		2
#define STATIC_ENTRYPOINT			13
#define STATIC_PASSCODE_1X				"DEB1"
#define STATIC_PASSCODE_2X				"DEB2"
#define USER_AUTHENTICATION			"del"

/////////////////////////////////////////////////////////////////////////////
// CLabels dialog

class CLabels : public CDialog
{
// Construction
public:
	BOOL ValidateData(CString,CString,CString);
	CLabels(CWnd* pParent = NULL);   // standard constructor
	char chFileName[MAX_FILE_NAME_LENGHT];
	unsigned long ulSize ;
	FILE* pFile;
	BOOL Fileselected;




// Dialog Data
	//{{AFX_DATA(CLabels)
	enum { IDD = IDD_DELABELER_DIALOG };
	CComboBox	m_cmbctrlHWSeries;
	CEdit	m_statusDisplay;
	CEdit	m_ctrlFrmFile;
	CString	m_enc;
	CString	m_pswd;
	CString	m_ep;
	CString	m_authenticate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLabels)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLabels)
	afx_msg void OnEncode();
	virtual void OnCancel();
	afx_msg void OnButtonSelectFile();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	unsigned char						uchFirmWareVersion[FIRMWARE_BYTES_LENGTH];
	unsigned char						*ucBuffer;
	CWnd* pwnd ;// Pointer to main window

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LABELS_H__F84532F3_4EE7_405A_9D60_801906883EA0__INCLUDED_)
