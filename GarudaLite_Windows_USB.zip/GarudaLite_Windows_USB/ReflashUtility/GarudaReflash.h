// GarudaReflash.h : main header file for the GARUDAREFLASH application
//

#if !defined(AFX_INNOVAREFLASH_H__D2CE9797_AA5E_46BE_98EC_58388DC7955E__INCLUDED_)
#define AFX_INNOVAREFLASH_H__D2CE9797_AA5E_46BE_98EC_58388DC7955E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGarudaReflashApp:
// See GarudaReflash.cpp for the implementation of this class
//

class CGarudaReflashApp : public CWinApp
{
public:
	CGarudaReflashApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGarudaReflashApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGarudaReflashApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INNOVAREFLASH_H__D2CE9797_AA5E_46BE_98EC_58388DC7955E__INCLUDED_)
