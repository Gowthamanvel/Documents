// Labels.cpp : implementation file
//

#include "stdafx.h"
#include "Garudareflash.h"
#include "Labels.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLabels dialog


CLabels::CLabels(CWnd* pParent /*=NULL*/)
	: CDialog(CLabels::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLabels)
	m_enc = _T("1");
	m_pswd = _T("0000");
	m_ep = _T("00");
	m_authenticate = _T("");
	//}}AFX_DATA_INIT
	Fileselected = FALSE;
}


void CLabels::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLabels)
	DDX_Control(pDX, IDC_COMBO_HW, m_cmbctrlHWSeries);
	DDX_Control(pDX, IDC_EDIT_STATUS, m_statusDisplay);
	DDX_Control(pDX, IDC_EDIT_FL, m_ctrlFrmFile);
	DDX_CBString(pDX, IDC_COMBO_ENC, m_enc);
	DDV_MaxChars(pDX, m_enc, 3);
	DDX_Text(pDX, IDC_EDIT_CODE, m_pswd);
	DDV_MaxChars(pDX, m_pswd, 4);
	DDX_Text(pDX, IDC_EDIT_EP, m_ep);
	DDV_MaxChars(pDX, m_ep, 2);
	DDX_Text(pDX, IDC_EDIT_CHECK, m_authenticate);
	DDV_MaxChars(pDX, m_authenticate, 3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLabels, CDialog)
	//{{AFX_MSG_MAP(CLabels)
	ON_BN_CLICKED(IDOK, OnEncode)
	ON_BN_CLICKED(IDC_BUTTON_SF, OnButtonSelectFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLabels message handlers

void CLabels::OnEncode() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	pwnd = AfxGetMainWnd(); // Pointer to main window
	m_statusDisplay.SetWindowText("");

	if(m_authenticate != USER_AUTHENTICATION)
	{
		m_statusDisplay.SetWindowText("Invalid check value. You are not authorized to use this application");
		return;
	}
	if(Fileselected == FALSE)
	{
		m_statusDisplay.SetWindowText("Firmware file not selected. Please select valid .bin file.");
		return;
	}
	CString l_ep;
	CString l_code;
	CString l_enc;
	unsigned int l_ep_int = 0;
	BOOL status = FALSE;

	unsigned long i,j,k = 0;
	unsigned char pswdc[5] = {0};
	unsigned char* MainBuffer;
//	unsigned char testbuf[5000];
	MainBuffer = (unsigned char*)malloc(ulSize + 5); 


	l_ep = m_ep;
	l_code = m_pswd;
	l_enc = m_enc;
	status = ValidateData(l_ep,l_code,l_enc);
	if(!status)
	{
		AfxMessageBox("Please enter valid data");
			return;
	}
//	l_ep_int = atoi(l_ep);

	//Static appointment of hardcoded data to variables
	l_ep_int = STATIC_ENTRYPOINT;

	if(m_cmbctrlHWSeries.GetCurSel() == 0)
	{
		l_code = STATIC_PASSCODE_1X;
	}
	else if(m_cmbctrlHWSeries.GetCurSel() == 1)
	{
		l_code = STATIC_PASSCODE_2X;
	}
	else
	{
		AfxMessageBox("Invalid Hw Type");
			return;
	}
	
//	l_code.Format("%s",pswdc);

	pswdc[0] = l_code[0];
	pswdc[1] = l_code[1];
	pswdc[2] = l_code[2];
	pswdc[3] = l_code[3];


	for(i = 0,j = 0;i<l_ep_int;i++,j++)
		MainBuffer[i]  = ucBuffer[i];
	for(k = 0;k<4;k++)
		MainBuffer[i++] =  pswdc[k];
	for(;i<(ulSize+4) ;i++,j++)
		MainBuffer[i] = ucBuffer[j];

/*	fseek (pFile , 0 , SEEK_SET);

	/*for(i=0;i<(ulSize+4);i++)
		fprintf( pFile, "%c", MainBuffer[i] );*/


	/////////////////////////////
	char BASED_CODE szFilt[50];
	FILE *pFile_S;
	i = 0;
	while(chFileName[i] != NULL)
	{
		if(	chFileName[i] == '.')
			break;
		chFileName[i] = chFileName[i];
		i++;
	}
	chFileName[i] = '\0';
	strcat(chFileName,".debf");

	strcpy(szFilt, "Configuration Files (*.debf)|*.debf||");
	CFileDialog dlgSave(FALSE,"bin",chFileName,OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY ,szFilt);
	dlgSave.m_ofn.lpstrTitle = "Save Configuration Files";

	switch(dlgSave.DoModal())
	{
	case IDOK:
	
	//	m_ctrlFrmFile.GetWindowText(dlgSave.GetPathName());
	//	strcpy(chFileName,dlgSave.GetFileName());
		strcpy(chFileName,dlgSave.GetPathName());
		pFile_S = fopen(chFileName, "w+b");
		if(pFile_S != NULL)
		{
		for(i=0;i<(ulSize+4);i++)
			fprintf( pFile_S, "%c", MainBuffer[i] );
		///Authenticate file here Authenticate()
		pwnd = AfxGetMainWnd(); // Pointer to main window
		m_ctrlFrmFile.SetWindowText(dlgSave.GetPathName());
		fclose(pFile_S);
		}
		break;
	default:
		break;
	}
	///////////////////////////
	m_statusDisplay.SetWindowText("Successfully Encoded !");


	free(MainBuffer);	
}

void CLabels::OnCancel() 
{
	// TODO: Add extra cleanup here
	if(	Fileselected == TRUE)
		free(ucBuffer);


	CDialog::OnCancel();
}

void CLabels::OnButtonSelectFile() 
{
	// TODO: Add your control notification handler code here
	char BASED_CODE szFilt[50];
	int success;
	m_statusDisplay.SetWindowText("");
	strcpy(szFilt, "Configuration Files (*.bin)|*.bin||");
	CFileDialog dlg1(TRUE,"bin","*.bin",OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY ,szFilt);
	dlg1.m_ofn.lpstrTitle = "Open Configuration Files";
	switch(dlg1.DoModal())
	{
	case IDOK:
		ulSize = 0;
		if(Fileselected == TRUE)
		{
			free(ucBuffer);
		}
		Fileselected = TRUE;
		m_ctrlFrmFile.SetWindowText("");
		strcpy(chFileName,dlg1.GetFileName());
		success = SetFileAttributes(chFileName,FILE_ATTRIBUTE_NORMAL);
		pFile = fopen(chFileName, "r+b");
		if(pFile == NULL)
		{
				m_statusDisplay.SetWindowText("Cannot open File. Please check file attributes");
				return;
		}
		fseek (pFile , 0 , SEEK_END);
		ulSize = ftell (pFile);
		rewind (pFile);
	//	fread(uchFirmWareVersion, sizeof( unsigned char), FIRMWARE_BYTES_LENGTH, pFile);
		ucBuffer = (unsigned char*)malloc(ulSize ); 
		fread(ucBuffer, sizeof( unsigned char), ulSize , pFile);
		///Authenticate file here Authenticate()
		pwnd = AfxGetMainWnd(); // Pointer to main window
		m_ctrlFrmFile.SetWindowText(dlg1.GetPathName());
		m_statusDisplay.SetWindowText("File selected !");
		fclose(pFile);

		break;
	default:
		m_statusDisplay.SetWindowText("File selection aborted !");
		break;
	}
	
}

BOOL CLabels::ValidateData(CString l_ep ,CString l_code,CString l_enc)
{
	if(l_ep == "" || l_code == "")
		return FALSE;

	return TRUE;
}

BOOL CLabels::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if(m_cmbctrlHWSeries.GetCount()>0)
	{
		m_cmbctrlHWSeries.SetCurSel(0);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
