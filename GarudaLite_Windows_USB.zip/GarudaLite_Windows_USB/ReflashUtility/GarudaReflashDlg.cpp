/*****************************************************************************************
Project : Garuda SHop Software 5000 OEM TOOL   
Version : 1.0
Date    : 20/01/08
Author  : Charavarthy

Purpose: USB communications with a HID-class device and Device Firmware Upgadation using
		 CDC (Communication device class)

Description: 
	Finds an attached HID-class device that matches a specified Vendor ID and Product ID.
	Retrieves the HID's capabilities.
	Sends a report to the HID and receives a report from the HID.
	Supports Input, Output, and Feature reports. 
	The API function ReadFile retrieves Input reports from the HID driver's buffer. 
	Non-overlapped ReadFile is a blocking call. 
	If a report isn't available, the function waits.
	With overlapped I/O, the call to ReadFile returns immediately. 
	The application then calls 
	WaitForSingleObject, which returns when either the data has arrived or 
	the specified timeout has elapsed.
	This application has been tested on Windows XP,Windows VISTA.

***********************Modification History************************************************
File					Author				Change sescription
Vesrion										
-------------------------------------------------------------------------------------------
1.0						Chakravarthy		Initial Version

*******************************************************************************************/

#include "stdafx.h"
#include "math.h"
#include "GarudaReflash.h"
#include "GarudaReflashDlg.h"
#include "Labels.h"
#include <io.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGarudaReflashDlg dialog

CGarudaReflashDlg::CGarudaReflashDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGarudaReflashDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGarudaReflashDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	ZeroMemory(chFileName,MAX_FILE_NAME_LENGHT);
	HidDevHandle = NULL;
	ReadHandle = NULL;						
	WriteHandle = NULL;
	hEventObject = NULL;

	HidAttached = FALSE;
	FlashThreadActive = FALSE;
	BootLoaderMode = FALSE;
	NormalMode = FALSE;
	ZeroMemory(uchFirmWareVersion,FIRMWARE_BYTES_LENGTH);
	usFirmwareVersion = 0;
	pwnd = AfxGetMainWnd(); // Pointer to main window

	dev = NULL;
}
CGarudaReflashDlg::~CGarudaReflashDlg()
{
	/*Close the handles once the application is clsed completed*/
	CloseHandles();
}

void CGarudaReflashDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGarudaReflashDlg)
	DDX_Control(pDX, IDC_FS, m_ctrlDwnStatus);
	DDX_Control(pDX, IDC_PROGRESS1, m_ctrlProgress);
	DDX_Control(pDX, IDC_EDIT1, m_ctrlFrmFile);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGarudaReflashDlg, CDialog)
	//{{AFX_MSG_MAP(CGarudaReflashDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnButtonAutoDetect)
	ON_BN_CLICKED(IDSELFWM, OnSelfwmFile)
	ON_BN_CLICKED(IDREFLASH, OnReflash)
	ON_COMMAND(IDD_USER_MANUAL, OnUserManual)
	ON_BN_CLICKED(IDCANCEL, OnClose)
	ON_BN_CLICKED(IDC_BUTTON_BL, OnButtonBl)
	ON_COMMAND(ID_LABEL, OnLabel)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_DEVICECHANGE, Main_OnDeviceChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGarudaReflashDlg message handlers

BOOL CGarudaReflashDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	memset(OutputReport,0,OUTPUTREPORTMAX);
	memset(InputReport,0,INPUTREPORTMAX);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGarudaReflashDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGarudaReflashDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGarudaReflashDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CGarudaReflashDlg::OnButtonAutoDetect() 
{
	BOOL Hidstatus = FALSE;
    pwnd = AfxGetMainWnd(); // Pointer to main window
	pwnd->SetDlgItemText(IDC_KBSEC,"Detecting..");
	HidAttached = FALSE;
///////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////

	if(!bOpenHidDevice())
	{
		pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
		pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not connected. Please verify.");
	}
	else
	{
		if(BootLoaderMode == TRUE)
		{
				pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in BootLoader Mode.");
				//Send checksum command
				GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
			
			//	flash_Status = bReadFlashStatus();
		}
		else
			if(NormalMode == TRUE)
			{
			
				pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Normal Mode.");
				GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
///////////////////////////////////////////////////////////////////////////////////////////////
	//Following code is inactive, Can be activated if user wants to switch mode on autoDetec - Nikhilesh
//////////////////////////////////////////////////////////////////////////////////////////////
				//Send Change Bootloader command
/*				if(IDYES    != AfxMessageBox("Click Yes to default in BootLoader mode.\nClick No to cancel.",MB_YESNO|MB_ICONQUESTION))
					return;
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Normal Mode.\nInitializing BooLoader Mode");

				EnableBootLoader();
				//Sufficient delay for driver loading and enumeration
				Sleep(6000);
				// Detect device again
				Hidstatus = bOpenHidDevice();
				if(Hidstatus == TRUE && BootLoaderMode == TRUE)
				{
					pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
					pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in BootLoader Mode.");
					GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
					GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
					
				}
				else
				{
					pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
					pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not connected or still active in Normal Mode. Please verify.");
				
				}
				//Send checksum command
			//	flash_Status = bReadFlashStatus();*/
///////////////////////////////////////////////////////////////////////////////////////////////
	//Till Here	- Nikhilesh
//////////////////////////////////////////////////////////////////////////////////////////////
			}
	}
	return;
}	

BOOL CGarudaReflashDlg::ValidateLabelUser()//Nikhil added
{
	BOOL success;
	char dataBuf[50];
	char tokens[] = DELIMETER;
	char *token;
	FILE *tempFile;
	success = SetFileAttributes(INFPATH,FILE_ATTRIBUTE_NORMAL);
	if((tempFile = fopen(INFPATH,"r"))!= NULL)
	{
		fscanf(tempFile,"%s",dataBuf); 
		token = strtok( dataBuf, tokens );
		fclose(tempFile);
		if(strcmp(token,VALIDLABELUSERSTRING))
			return FALSE;
		else
			return TRUE;
	}
	return FALSE;
}

char LicenseString[5] = {0};

BOOL CGarudaReflashDlg:: ValidateFile(unsigned char* buffer)
{	
	unsigned int i,j = 0;
	memset(LicenseString,0,sizeof(LicenseString));
	for(i = STATIC_ENTRYPOINT;i<STATIC_ENTRYPOINT +4;i++)
		LicenseString[j++] = buffer[i];

	LicenseString[j] = '\0';
	if((strcmp(LicenseString,STATIC_PASSCODE_1X)) && (strcmp(LicenseString,STATIC_PASSCODE_2X)))
		return FALSE;
	else
		return TRUE;

}
void CGarudaReflashDlg::OnSelfwmFile() 
{
	char BASED_CODE szFilt[50];
	unsigned char						*ucBuffer;
	int success = 0;
	FILE* pFile;
	BOOL pass = FALSE;
	pwnd = AfxGetMainWnd(); // Pointer to main window

	strcpy(szFilt, "Configuration Files (*.bin)|*.bin||");
	CFileDialog dlg1(TRUE,"debf","*.debf",OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY ,szFilt);
	dlg1.m_ofn.lpstrTitle = "Open Configuration Files";
	unsigned long ulSize = 0;
	switch(dlg1.DoModal())
	{
	case IDOK:
		m_ctrlFrmFile.SetWindowText("");
		strcpy(chFileName,dlg1.GetFileName());
		success = SetFileAttributes(chFileName,FILE_ATTRIBUTE_NORMAL);//test
		pFile = fopen(chFileName, "r+b");
		if(pFile == NULL)
		{
			pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
			pwnd->SetDlgItemText(IDC_FS,"Cannot open File.");
			return;
		}
		fseek (pFile , 0 , SEEK_END);
		ulSize = ftell (pFile);
		rewind (pFile);
	//	fread(uchFirmWareVersion, sizeof( unsigned char), FIRMWARE_BYTES_LENGTH, pFile);
		ucBuffer = (unsigned char*)malloc(ulSize ); 
		fread(ucBuffer, sizeof( unsigned char), ulSize , pFile);
		///Authenticate file here Authenticate()
		if(!ValidateFile(ucBuffer))
		{
			pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
			pwnd->SetDlgItemText(IDC_FS,"Invalid File.");
		}
		else
		{
			m_ctrlFrmFile.SetWindowText(dlg1.GetPathName());
			pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
			pwnd->SetDlgItemText(IDC_FS,"File Selected.");
			GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
			m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

		}
		free(ucBuffer);
		fclose(pFile);

		break;
	default:
		break;
	}
}

BOOL CGarudaReflashDlg::constructPacket(unsigned char * buffer,unsigned char* ucData,unsigned int packetlength,unsigned char segmentno ,unsigned int packetno)
{
//MSB first
	unsigned char index = 0;
	int buff_index = 0;
	unsigned char test[70];
	int databytes = 0;
	if(packetlength == 24)
		databytes = 24;
	if(packetlength == 256)
		databytes = 58;
	ucData[index++] = BOOTLOADER_BYTE;
	ucData[index++] = unsigned char(packetlength) ;
	ucData[index++] = unsigned char(packetlength >> 8);
	ucData[index++] = segmentno;
	ucData[index++] = unsigned char(packetno) ;
	ucData[index++] = unsigned char(packetno >> 8);
	for(int a =0;a<databytes;a++)
	{
		buff_index = (segmentno-1)* 58 + (packetno-1)* 256 + a;
		ucData[index++] = buffer[buff_index];
		test[a] = buffer[buff_index];
	}

	return TRUE;
}

BOOL CGarudaReflashDlg::constructExtraPacket(unsigned char * chBuffer,unsigned char* ucData,unsigned int packetlength,unsigned char segmentno ,unsigned int packetno)
{
//LSB first
	unsigned char index = 0;
	int chBuffer_index = 0;
	unsigned char test[70];
	int databytes = 0;
	if(packetlength == 24)
		databytes = 24;
	else
		databytes = 58;
	ucData[index++] = BOOTLOADER_BYTE;
	ucData[index++] = unsigned char(packetlength) ;
	ucData[index++] = unsigned char(packetlength >> 8);
	ucData[index++] = segmentno;
	ucData[index++] = unsigned char(packetno) ;
	ucData[index++] = unsigned char(packetno >> 8);
	for(int a =0;a<databytes;a++)
	{
		chBuffer_index = (segmentno-1)* 58 + a;
		ucData[index++] = chBuffer[chBuffer_index];
		test[a] = chBuffer[chBuffer_index];
	}

	return TRUE;
}
void CGarudaReflashDlg:: RemoveCodeFromFile(unsigned char *buffer, DWORD * dwSize)
{
	int i = 0;
	for(i = 0;i<STATIC_ENTRYPOINT;i++)
		buffer[i] = buffer[i];
	for(;i<(*dwSize-4);i++)
		buffer[i] = buffer[i+4];
	*dwSize = *dwSize - 4;
}


UINT FlashData(LPVOID lpvoid)
{

	CString KBin,KBsec,Perc,FileSize; // String variables
	int pos = 0;
	float buflength = 0.00;
	unsigned char chBuffer[256];
	unsigned char ucData[64] = {'0'};
	char extrapacket = 0;
	unsigned int extrapacket_size = 0;
	int nperc,kbrecv; // Percentage of progress,kbs received
	double secs,kbsec; // Seconds, kb/sec
	int bufferlength_int = 0;
	BOOL pass = 0;
	BOOL flash_Status = FALSE;
	unsigned char segmentNO = 0;
	unsigned int packetNO = 0;
	HANDLE hFile = {NULL};
	DWORD dwSize, bytes_read;
	int buffer_index = 0;
	int m = 0;
	int nFileSize = 0;
	int delayCount = 0;
	BOOL Hidstatus = FALSE;


	
	CGarudaReflashDlg *pFlash = (CGarudaReflashDlg*)lpvoid;

	/****************************************************************/
	if(!pFlash->BootLoaderMode)
	{
		pFlash->EnableBootLoader();
		pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Progressing !");
		pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is entering in BootLoader Mode.");
		//Sufficient delay for driver loading and enumeration
		Hidstatus = FALSE;
		pFlash->HidAttached = FALSE;
		for(delayCount = 0; delayCount<10;delayCount++)
		{
			pFlash->pwnd->SetDlgItemText(IDC_FS," ");
			Sleep(1000);
			pFlash->pwnd->SetDlgItemText(IDC_FS,"Initializing, please wait...");
			Sleep(1000);
			Hidstatus = pFlash->bOpenHidDevice();
			if(Hidstatus == TRUE && pFlash->BootLoaderMode == TRUE)
			{
				pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
				pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in BootLoader Mode.");
				break;
			}
		}
		if(Hidstatus == TRUE && pFlash->NormalMode == TRUE)
		{
			pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
			pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Normal Mode.Please Verify");
			pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
			pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
			pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
			pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

			return 0;
				
		}
		else
			if(Hidstatus == FALSE)
			{
				pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
				pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not connected or still active in Normal Mode. Please reset device and verify.");
				pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
				pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
				pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
				pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

				return 0;
			}
		
	}
	/***************************************/


	memset(&chBuffer,0,sizeof(BUFFER_SIZE));


		COleDateTime dlStart = COleDateTime::GetCurrentTime();

		pFlash->m_ctrlDwnStatus.SetWindowText("Flashing Started...");

		
		// MANDATORY: Program EFC_FMR register  Assume Target is at 48MHz


	
		// Open the file and get ready to read it.
		// Don't be confused by the CreateFile() function,
		// we're only opening an existing file.
		hFile = CreateFile(pFlash->chFileName, GENERIC_READ, 
						   FILE_SHARE_READ | FILE_SHARE_WRITE,
						   NULL, OPEN_EXISTING,
						   FILE_FLAG_SEQUENTIAL_SCAN, NULL);
		
		if(hFile == INVALID_HANDLE_VALUE)
		{
			AfxMessageBox("Failed to open the file!");
			pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
			pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
			pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
			return 0;
		}
	
	
	// Get the file size so we know how long to make our buffer.
		dwSize = GetFileSize(hFile, NULL);
		nFileSize = ceil(dwSize / 1024.0);
		FileSize.Format("%d",nFileSize); // Format file size in kb into string
		// Create a CString buffer of the proper length
		// and fill it with spaces.
		pFlash->FlashThreadActive = TRUE;
		pFlash->buffer = (unsigned char *)malloc(dwSize);
		// Read the file into the buffer
		ReadFile(hFile, pFlash->buffer, dwSize, &bytes_read, NULL);
		pFlash->RemoveCodeFromFile(pFlash->buffer,&dwSize);
		// We're done with the file handle so close it.
		buflength = dwSize/256.0;
		if(buflength - floor(buflength) != 0)
		{
			extrapacket = 1;
			extrapacket_size = dwSize%256;
		}

		bufferlength_int = floor(buflength);
		flash_Status = pFlash->bReadFlashStatus(int(ceil(buflength)));
		
		CloseHandle(hFile);
		pFlash->m_ctrlProgress.SetPos(0); 
		pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"0kb/sec");
		pFlash->m_ctrlProgress.SetRange32(0,dwSize);

	
	
		for( packetNO=1;packetNO<=bufferlength_int;packetNO++)
		{
			pos = pos + BUFFER_SIZE; // Set new progress position value
			pFlash->m_ctrlProgress.SetPos(pos);
			//read 256 bytes from buffer
			memset(&chBuffer[0],0,256);
			for(m = 0;m<256;m++)
				chBuffer[m] = pFlash->buffer[buffer_index++];
			for( segmentNO = 1;segmentNO<6; segmentNO++)
			{
				memset(&ucData[0],0,64);
				if( segmentNO == 5)
					pass = pFlash->constructPacket(pFlash->buffer,ucData,24,segmentNO,packetNO);
				else
					pass = pFlash->constructPacket(pFlash->buffer,ucData,256,segmentNO,packetNO);
					
				//send data
				if(pFlash->WriteOutputReport(&ucData[0],64))
				{
					if(segmentNO == 5)
					{
						if(pFlash->ReadInputReport())
						{
							if(pFlash->InputReport[1] == BOOTLOADER_BYTE && pFlash->InputReport[4] == STATUS_NOERROR )
							{
								TRACE("###Success### %x\n",packetNO);
							}
							else
							{
								pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
								pFlash->pwnd->SetDlgItemText(IDC_FS,"Error in Communication with Garuda TOOL. Flashing aborted");
								pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
								pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
								pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
								pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	


								return 0;
							}
						}
						else
						{
							pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
							pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not responding to Flashing Commands !");
							pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
							pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
							pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
							pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

							return 0;
						}
					}
		
				}
				else
				{
					pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
					pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not responding to Flashing Commands !");
					pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
					pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
					pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
					pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	
					pFlash->m_ctrlFrmFile.SetWindowText("");
					return 0;
				}
			}
		

		// Calculate total seconds between start of download up until now
			COleDateTimeSpan dlElapsed = COleDateTime::GetCurrentTime() - dlStart;
			// Get seconds between starting time and current time
			secs = dlElapsed.GetTotalSeconds();
			// User info calculations -
			nperc = pos * 100 / dwSize; // Calculate percentage
			kbrecv = pos / 1024; // Get received KB
			kbsec = kbrecv / secs; // Get KB download per second
			Perc.Format("%d",nperc); // Format percent into string
			KBin.Format("%d",kbrecv); // Format read KB into string
			KBsec.Format("%0.1f",kbsec); // Format KB/sec into string
			//Update GUI with above information
			pFlash->pwnd->SetDlgItemText(IDC_KBSEC,KBsec + "kb/sec"); 
			pFlash->pwnd->SetDlgItemText(IDC_PERCENT,Perc + "%");
			pFlash->pwnd->SetDlgItemText(IDC_FS,"Flashing in progress : " + KBin + "kb/" + FileSize + "kb");
		}
	

		if(extrapacket == 1)
		{
			pos = pos+ extrapacket_size;
			pFlash->m_ctrlProgress.SetPos(pos);
			memset(&chBuffer[0],0,256);
			for(m = 0;m<extrapacket_size;m++)
				chBuffer[m] = pFlash->buffer[buffer_index++];
			for(segmentNO = 1;segmentNO<6; segmentNO++)
			{
				memset(&ucData[0],0,64);
				if( segmentNO == 5)
					pass = pFlash->constructExtraPacket(chBuffer,ucData,24,segmentNO,packetNO);
				else
					pass = pFlash->constructExtraPacket(chBuffer,ucData,extrapacket_size,segmentNO,packetNO);

				//send data
				if(pFlash->WriteOutputReport(&ucData[0],64))
				{
					if(segmentNO == 5)
					{
						if(pFlash->ReadInputReport())
						{
							if(pFlash->InputReport[1] == BOOTLOADER_BYTE && pFlash->InputReport[4] == STATUS_NOERROR)
							{
								TRACE("###Success### %x\n",packetNO);
							}
							else
							{
								pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
								pFlash->pwnd->SetDlgItemText(IDC_FS,"Error in Communication with Garuda TOOL. Flashing aborted");
								pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
								pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
								pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
								pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

								return 0;
							}
						}
						else
						{
							pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
							pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not responding to Flashing Commands !");
							pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
							pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
							pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
							pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

							return 0;
						}

					}
				}
				else
				{
					pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
					pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not responding to Flashing Commands !");
					pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
					pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
					pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
					pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	

					pFlash->m_ctrlFrmFile.SetWindowText("");
					return 0;
				}
				
				
			}
				// Calculate total seconds between start of download up until now
			COleDateTimeSpan dlElapsed = COleDateTime::GetCurrentTime() - dlStart;
			// Get seconds between starting time and current time
			secs = dlElapsed.GetTotalSeconds();
			// User info calculations -
			nperc = pos * 100 / dwSize; // Calculate percentage
			kbrecv = ceil(pos / 1024.0); // Get received KB
			kbsec = kbrecv / secs; // Get KB download per second
			Perc.Format("%d",nperc); // Format percent into string
			KBin.Format("%d",kbrecv); // Format read KB into string
			KBsec.Format("%0.1f",kbsec); // Format KB/sec into string
			//Update GUI with above information
			pFlash->pwnd->SetDlgItemText(IDC_KBSEC,KBsec + "kb/sec"); 
			pFlash->pwnd->SetDlgItemText(IDC_PERCENT,Perc + "%");
			pFlash->pwnd->SetDlgItemText(IDC_FS,"Flashing in progress : " + KBin + "kb/" + FileSize + "kb");
		}
		
		// Free Allocated memory
		free(pFlash->buffer);
		pFlash->FlashThreadActive = FALSE;
		Sleep(2000);
		pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
		pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is programmed successfully.\nInitializing in Normal Mode !");
		pass = pFlash->bSendNMCommandToDevice();
		for( delayCount = 0; delayCount<10;delayCount++)
		{
			Hidstatus = FALSE;
			pFlash->HidAttached = FALSE;

			pFlash->pwnd->SetDlgItemText(IDC_FS," ");
			Sleep(1000);
			pFlash->pwnd->SetDlgItemText(IDC_FS,"Reseting Garuda TOOL, please wait...");
			Sleep(1000);
			//Hidstatus = pFlash->bOpenHidDevice();
			Hidstatus = pFlash->bOpenDevice();
			if(Hidstatus == TRUE && pFlash->NormalMode == TRUE)
			{
				pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Success !");

				#ifdef GARUDA_BULK 
				pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Bulk Mode.Flashing Successful");
				#endif

				#ifdef GARUDA_HID
				pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Normal Mode.Flashing Successful");
				#endif

				break;
			}
		}
		if(Hidstatus == TRUE && pFlash->BootLoaderMode == TRUE)
		{
			pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
			pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in BootLoader Mode.Please Verify.");
		}
		else
			if(Hidstatus == FALSE)
			{
				pFlash->pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
				pFlash->pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not connected. Please verify.");
			}

	pFlash->GetDlgItem(IDOK)->EnableWindow(TRUE);
	pFlash->GetDlgItem(IDSELFWM)->EnableWindow(TRUE);
	pFlash->GetDlgItem(IDREFLASH)->EnableWindow(TRUE);
	pFlash->m_pMenu->EnableMenuItem(ID_LABEL,MF_ENABLED );	


	return 1;
}
	
void CGarudaReflashDlg::OnReflash() 
{
	pwnd = AfxGetMainWnd(); // Pointer to main window
	pwnd->SetDlgItemText(IDC_KBSEC,"Detecting..");
	HidAttached = FALSE;

	m_ulPID = 0x00;
	m_ulVID = 0x00;

///////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
	if(m_ctrlFrmFile.GetWindowTextLength()==0)
	{
		pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
		pwnd->SetDlgItemText(IDC_FS,"Firmware file not selected. Please click Select Firmware File button and select the firmware file.");
		return;
	}
	if(!bOpenHidDevice())
	//if(!bOpenDevice())
	{
		if(!bOpenHidDevice())
		{
			pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
			pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is not connected. Please verify.");
			return;
		}
		else
		{		
			if(BootLoaderMode == TRUE)
			{
					pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
					pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in BootLoader Mode.");
				
			}
			else
			if(NormalMode == TRUE)
			{
				pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Normal Mode.");
			}
			GetDlgItem(IDOK)->EnableWindow(FALSE);
			GetDlgItem(IDSELFWM)->EnableWindow(FALSE);
			GetDlgItem(IDREFLASH)->EnableWindow(FALSE);
			m_pMenu->EnableMenuItem(ID_LABEL,MF_GRAYED );
			Invalidate(TRUE);
			AfxBeginThread(FlashData, this);
		}
	}
	else
	{

		//Checking for Firmware and Hardware Versions are compatible or not
		if  (((m_ulVID == NM_VID_1X) &&	(strcmp(LicenseString,STATIC_PASSCODE_1X) == 0)) ||
			((m_ulVID == NM_VID_2X) &&	(strcmp(LicenseString,STATIC_PASSCODE_2X) == 0)))
		{
			//Valid Configuration
		}
		else
		{
			pwnd->SetDlgItemText(IDC_FS,"Firmware File not supported.");

			if(strcmp(LicenseString,STATIC_PASSCODE_1X) == 0)
			{
				AfxMessageBox("Error: Firmware Update doesn't support 2x H/W Series.");
			}
			
			else 
			{
				AfxMessageBox("Error: Firmware Update doesn't support 1x H/WSeries.");
			}

			return;
		}
	
		if(BootLoaderMode == TRUE)
		{
				pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in BootLoader Mode.");
			
		}
		else
			if(NormalMode == TRUE)
			{
				pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
#ifdef GARUDA_BULK 
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in bulk Normal Mode.");
#endif
				
#ifdef GARUDA_HID
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is detected in Normal Mode.");
#endif				
			}
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDSELFWM)->EnableWindow(FALSE);
		GetDlgItem(IDREFLASH)->EnableWindow(FALSE);
		m_pMenu->EnableMenuItem(ID_LABEL,MF_GRAYED );
		Invalidate(TRUE);
		AfxBeginThread(FlashData, this);
	}	
}

void CGarudaReflashDlg::OnUserManual() 
{
	char chWindowsDir[128];
	ZeroMemory(chWindowsDir,128);
	GetWindowsDirectory(chWindowsDir,128);
	strcat(chWindowsDir,"\\GarudaReflash.pdf");
}

void CGarudaReflashDlg::OnClose() 
{
	CDialog::OnCancel();
}

/************************************************************************************
*
*	Function: bOpenHidDevice
*	Purpose: tries to open a HID device based on VID and PID
*	Parameters: vid - HID device's vendor ID
*				pid - HID device's product ID
			
*	Returns: TRUE, if device is found
*			 FALSE, if device is not found
*
*************************************************************************************/
BOOL CGarudaReflashDlg::bOpenHidDevice()
{
	static GUID HidGuid;						/* HID Globally Unique ID: windows supplies us with this value */
	HDEVINFO HidDevInfo;						/* handle to structure containing all attached HID Device information */
	SP_DEVICE_INTERFACE_DATA devInfoData;		/* Information structure for HID devices */
	BOOLEAN Result;								/* result of getting next device information structure */
	DWORD Index;								/* index of HidDevInfo array entry */
	DWORD DataSize;								/* size of the DeviceInterfaceDetail structure */		
	BOOLEAN GotRequiredSize;					/* 1-shot got device info data structure size flag */
	DWORD RequiredSize;							/* size of device info data structure */
	BOOLEAN DIDResult;							/* get device info data result */
	HIDD_ATTRIBUTES HIDAttrib;					/* HID device attributes */
	
	detailData = NULL;

	BootLoaderMode = NormalMode = FALSE; 

	/* 1) Get the HID Globally Unique ID from the OS */
	HidD_GetHidGuid(&HidGuid);

	/* 2) Get an array of structures containing information about
	all attached and enumerated HIDs */
	HidDevInfo = SetupDiGetClassDevs(	&HidGuid, 
										NULL, 
										NULL, 
										DIGCF_PRESENT | DIGCF_INTERFACEDEVICE);


	/* 3) Step through the attached device list 1 by 1 and examine
	each of the attached devices.  When there are no more entries in
	the array of structures, the function will return FALSE. */

	Index = 0;									/* init to first index of array */
	devInfoData.cbSize = sizeof(devInfoData);	/* set to the size of the structure
												that will contain the device info data */

	do 
	{
		/* initialize variables */
		GotRequiredSize = FALSE;
		/* Get information about the HID device with the 'Index' array entry */
		Result = SetupDiEnumDeviceInterfaces(	HidDevInfo, 
												0, 
												&HidGuid, 
												Index, 
												&devInfoData);
		
		/* If we run into this condition, then there are no more entries
		to examine, we might as well return FALSE at point */
		if(Result == FALSE)
		{
			/* free the memory allocated for DetailData */
			if(detailData != NULL)
				free(detailData);
			
			/* free HID device info list resources */
			SetupDiDestroyDeviceInfoList(HidDevInfo);
			
			return HidAttached;
		}
		
		if(GotRequiredSize == FALSE)
		{
		/*3) Get the size of the DEVICE_INTERFACE_DETAIL_DATA
		structure.  The first call will return an error condition, 
			but we'll get the size of the strucure */
			DIDResult = SetupDiGetDeviceInterfaceDetail(	HidDevInfo,
				&devInfoData,
				NULL,
				0,
				&DataSize,
				NULL);
			GotRequiredSize = TRUE;
			
			/* allocate memory for the HidDevInfo structure */
			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(DataSize);
			
			/* set the size parameter of the structure */
			detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
		}
		
		
		/* 4) Now call the function with the correct size parameter.  This 
		function will return data from one of the array members that 
		Step #2 pointed to.  This way we can start to identify the
		attributes of particular HID devices.  */
		DIDResult = SetupDiGetDeviceInterfaceDetail(HidDevInfo,
													&devInfoData,
													detailData,
													DataSize,
													&RequiredSize,
													NULL);
		
		
		/* 5) Open a file handle to the device.Make sure the attibutes specify 
			overlapped transactions or the IN transaction may block the input thread.*/
		HidDevHandle=CreateFile(detailData->DevicePath, 
								GENERIC_WRITE, 
								FILE_SHARE_READ|FILE_SHARE_WRITE, 
								(LPSECURITY_ATTRIBUTES)NULL,
								OPEN_EXISTING, 
								0, 
 								NULL);
		 
		
		/* 6) Get the Device VID & PID to see if it's the device we want */
		if(HidDevHandle != INVALID_HANDLE_VALUE)
		{
			HIDAttrib.Size = sizeof(HIDAttrib);
			HidD_GetAttributes(	HidDevHandle, &HIDAttrib);

			if(((HIDAttrib.VendorID == BL_VID_1X  && HIDAttrib.ProductID == BL_PID_1X)) ||
			   ((HIDAttrib.VendorID == BL_VID_2X  && HIDAttrib.ProductID == BL_PID_2X)))
			{
				BootLoaderMode = TRUE;
			}
			if(((HIDAttrib.VendorID == NM_VID_1X  && HIDAttrib.ProductID == NM_PID_1X)) ||
				((HIDAttrib.VendorID == NM_VID_2X  && HIDAttrib.ProductID == NM_PID_2X)))
				NormalMode = TRUE;
			
			if((NormalMode == TRUE || BootLoaderMode == TRUE ))
			{
				m_ulPID = HIDAttrib.ProductID;
				m_ulVID = HIDAttrib.VendorID;

				usFirmwareVersion = HIDAttrib.VersionNumber;
				HidAttached = TRUE;
				GetDeviceCapabilities();
				/* Get a handle for writing Output reports.*/
				WriteHandle=CreateFile (detailData->DevicePath, 
										GENERIC_WRITE, 
										FILE_SHARE_READ|FILE_SHARE_WRITE, 
										(LPSECURITY_ATTRIBUTES)NULL,
										OPEN_EXISTING, 
										0, 
										NULL);
				
								
				/* Prepare to read reports using Overlapped I/O.*/
				PrepareForOverlappedTransfer();
				
				/* free the memory allocated for DetailData */
				if(detailData != NULL)
				{
					free(detailData);
					detailData = NULL;
				}
				
				/* free HID device info list resources */
				SetupDiDestroyDeviceInfoList(HidDevInfo);
				return HidAttached;	/* found HID device */
			}
			else
			{
				if(detailData != NULL)
				{
					free(detailData);
					detailData = NULL;
				}
			}
			
			/* 7) Close the Device Handle because we didn't find the device
			with the correct VID and PID */
			CloseHandle(HidDevHandle);

		}
		else
		{
			if(detailData != NULL)
				{
					free(detailData);
					detailData = NULL;
				}
		}
		
		Index++;	/* increment the array index to search the next entry */
		
	} while(Result == TRUE);

	/* free the memory allocated for DetailData */
	if(detailData != NULL)
	{
		free(detailData);
		detailData = NULL;
	}

	/* free HID device info list resources */
	SetupDiDestroyDeviceInfoList(HidDevInfo);
	return HidAttached;
}


#ifdef GARUDA_BULK
usb_dev_handle* CGarudaReflashDlg::open_dev(void)
{
  struct usb_bus *bus;
  struct usb_device *dev;

  for(bus = usb_get_busses(); bus; bus = bus->next) 
    {
      for(dev = bus->devices; dev; dev = dev->next) 
        {
		  NormalMode = TRUE;
          if(dev->descriptor.idVendor == 0x0471
             && dev->descriptor.idProduct == 0x5741)
            {
				//NormalMode = TRUE;
                return usb_open(dev);
            }
		  else if(dev->descriptor.idVendor == 0x0471
             && dev->descriptor.idProduct == 0x5742)
		  {
				//BootLoaderMode = TRUE;
				return usb_open(dev);
		  }
          /*if(dev->descriptor.idVendor == 0x0471
             && dev->descriptor.idProduct == 0x5741)
            {
              return usb_open(dev);
            }*/
        }
    }
  return NULL;
}
#endif

/************************************************************************************
*
*	Function: bOpenDevice
*	Purpose: tries to open a HID and bulk device based on VID and PID
*	Parameters: vid - HID device's vendor ID
*				pid - HID device's product ID
			
*	Returns: TRUE, if device is found
*			 FALSE, if device is not found
*
*************************************************************************************/
BOOL CGarudaReflashDlg::bOpenDevice()
{
#ifdef GARUDA_HID
	static GUID HidGuid;						/* HID Globally Unique ID: windows supplies us with this value */
	HDEVINFO HidDevInfo;						/* handle to structure containing all attached HID Device information */
	SP_DEVICE_INTERFACE_DATA devInfoData;		/* Information structure for HID devices */
	BOOLEAN Result;								/* result of getting next device information structure */
	DWORD Index;								/* index of HidDevInfo array entry */
	DWORD DataSize;								/* size of the DeviceInterfaceDetail structure */		
	BOOLEAN GotRequiredSize;					/* 1-shot got device info data structure size flag */
	DWORD RequiredSize;							/* size of device info data structure */
	BOOLEAN DIDResult;							/* get device info data result */
	HIDD_ATTRIBUTES HIDAttrib;					/* HID device attributes */
	
	detailData = NULL;

	BootLoaderMode = NormalMode = FALSE; 

	/* 1) Get the HID Globally Unique ID from the OS */
	HidD_GetHidGuid(&HidGuid);

	/* 2) Get an array of structures containing information about
	all attached and enumerated HIDs */
	HidDevInfo = SetupDiGetClassDevs(	&HidGuid, 
										NULL, 
										NULL, 
										DIGCF_PRESENT | DIGCF_INTERFACEDEVICE);


	/* 3) Step through the attached device list 1 by 1 and examine
	each of the attached devices.  When there are no more entries in
	the array of structures, the function will return FALSE. */

	Index = 0;									/* init to first index of array */
	devInfoData.cbSize = sizeof(devInfoData);	/* set to the size of the structure
												that will contain the device info data */

	do 
	{
		/* initialize variables */
		GotRequiredSize = FALSE;
		/* Get information about the HID device with the 'Index' array entry */
		Result = SetupDiEnumDeviceInterfaces(	HidDevInfo, 
												0, 
												&HidGuid, 
												Index, 
												&devInfoData);
		
		/* If we run into this condition, then there are no more entries
		to examine, we might as well return FALSE at point */
		if(Result == FALSE)
		{
			/* free the memory allocated for DetailData */
			if(detailData != NULL)
				free(detailData);
			
			/* free HID device info list resources */
			SetupDiDestroyDeviceInfoList(HidDevInfo);
			
			return HidAttached;
		}
		
		if(GotRequiredSize == FALSE)
		{
		/*3) Get the size of the DEVICE_INTERFACE_DETAIL_DATA
		structure.  The first call will return an error condition, 
			but we'll get the size of the strucure */
			DIDResult = SetupDiGetDeviceInterfaceDetail(	HidDevInfo,
				&devInfoData,
				NULL,
				0,
				&DataSize,
				NULL);
			GotRequiredSize = TRUE;
			
			/* allocate memory for the HidDevInfo structure */
			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(DataSize);
			
			/* set the size parameter of the structure */
			detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
		}
		
		
		/* 4) Now call the function with the correct size parameter.  This 
		function will return data from one of the array members that 
		Step #2 pointed to.  This way we can start to identify the
		attributes of particular HID devices.  */
		DIDResult = SetupDiGetDeviceInterfaceDetail(HidDevInfo,
													&devInfoData,
													detailData,
													DataSize,
													&RequiredSize,
													NULL);
		
		
		/* 5) Open a file handle to the device.Make sure the attibutes specify 
			overlapped transactions or the IN transaction may block the input thread.*/
		HidDevHandle=CreateFile(detailData->DevicePath, 
								GENERIC_WRITE, 
								FILE_SHARE_READ|FILE_SHARE_WRITE, 
								(LPSECURITY_ATTRIBUTES)NULL,
								OPEN_EXISTING, 
								0, 
 								NULL);
		 
		
		/* 6) Get the Device VID & PID to see if it's the device we want */
		if(HidDevHandle != INVALID_HANDLE_VALUE)
		{
			HIDAttrib.Size = sizeof(HIDAttrib);
			HidD_GetAttributes(	HidDevHandle, &HIDAttrib);


			if(((HIDAttrib.VendorID == BL_VID_1X  && HIDAttrib.ProductID == BL_PID_1X)) ||
				((HIDAttrib.VendorID == BL_VID_2X  && HIDAttrib.ProductID == BL_PID_2X)))

				BootLoaderMode = TRUE;
			if(((HIDAttrib.VendorID == NM_VID_1X  && HIDAttrib.ProductID == NM_PID_1X)) ||
				((HIDAttrib.VendorID == NM_VID_2X  && HIDAttrib.ProductID == NM_PID_2X)))
				NormalMode = TRUE;
			
			if((NormalMode == TRUE || BootLoaderMode == TRUE ))
			{	
				usFirmwareVersion = HIDAttrib.VersionNumber;
				HidAttached = TRUE;
				GetDeviceCapabilities();
				/* Get a handle for writing Output reports.*/
				WriteHandle=CreateFile (detailData->DevicePath, 
										GENERIC_WRITE, 
										FILE_SHARE_READ|FILE_SHARE_WRITE, 
										(LPSECURITY_ATTRIBUTES)NULL,
										OPEN_EXISTING, 
										0, 
										NULL);
				
								
				/* Prepare to read reports using Overlapped I/O.*/
				PrepareForOverlappedTransfer();
				
				/* free the memory allocated for DetailData */
				if(detailData != NULL)
				{
					free(detailData);
					detailData = NULL;
				}
				
				/* free HID device info list resources */
				SetupDiDestroyDeviceInfoList(HidDevInfo);
				return HidAttached;	/* found HID device */
			}
			else
			{
				if(detailData != NULL)
				{
					free(detailData);
					detailData = NULL;
				}
			}
			
			/* 7) Close the Device Handle because we didn't find the device
			with the correct VID and PID */
			CloseHandle(HidDevHandle);

		}
		else
		{
			if(detailData != NULL)
				{
					free(detailData);
					detailData = NULL;
				}
		}
		
		Index++;	/* increment the array index to search the next entry */
		
	} while(Result == TRUE);

	/* free the memory allocated for DetailData */
	if(detailData != NULL)
	{
		free(detailData);
		detailData = NULL;
	}

	/* free HID device info list resources */
	SetupDiDestroyDeviceInfoList(HidDevInfo);
#endif
#ifdef GARUDA_BULK
	BootLoaderMode = NormalMode = FALSE; 
	usb_init(); /* initialize the library */
	usb_find_busses(); /* find all busses */
	usb_find_devices(); /* find all connected devices */
	
	
	if(!(dev = open_dev()))
    {		
		HidAttached = FALSE;
		return HidAttached;
    }
	
	if(usb_set_configuration(dev, 1) < 0)
    {
		usb_close(dev);
		HidAttached = FALSE;
		return HidAttached;
    }
	
	if(usb_claim_interface(dev, 0) < 0)
    {		
		usb_close(dev);
		HidAttached = FALSE;
		return HidAttached;
    }

	HidAttached = TRUE;

#endif
	return HidAttached;
}

/************************************************************************************
*	Function: GetDeviceCapabilities
*	Purpose: Gets the devices specific capabilites
*	Parameters: Void
*	Returns: Void 
*************************************************************************************/
void CGarudaReflashDlg::GetDeviceCapabilities(void)
{
	//Get the Capabilities structure for the device.
	PHIDP_PREPARSED_DATA	PreparsedData;

	/*
	API function: HidD_GetPreparsedData
	Returns: a pointer to a buffer containing the information about the device's 
	capabilities.
	Requires: A handle returned by CreateFile.
	There's no need to access the buffer directly,
	but HidP_GetCaps and other API functions require a pointer to the buffer.
	*/

	HidD_GetPreparsedData (HidDevHandle, &PreparsedData);

	/*
	API function: HidP_GetCaps
	Learn the device's capabilities.
	For standard devices such as joysticks, you can find out the specific
	capabilities of the device.
	For a custom device, the software will probably know what the device is
	capable of,and the call only verifies the information.
	Requires: the pointer to the buffer returned by HidD_GetPreparsedData.
	Returns: a Capabilities structure containing the information.
	*/
	
	HidP_GetCaps (PreparsedData, &Capabilities);

	//No need for PreparsedData any more, so free the memory it's using.
	HidD_FreePreparsedData(PreparsedData);
}

/************************************************************************************
*	Function: GetInputReportSize 
*	Purpose:  Returns the info from capablities
*	Parameters: Void
*	Returns: Input Report size for device	 
*************************************************************************************/

int CGarudaReflashDlg::GetInputReportSize(void)
{
	return(Capabilities.InputReportByteLength);
}
/************************************************************************************
*	Function: GetOutputReportSize 
*	Purpose:  Returns the info from capablities
*	Parameters: Void
*	Returns: Input Report size for device	 
*************************************************************************************/

int CGarudaReflashDlg::GetOutputReportSize(void)
{
	return(Capabilities.OutputReportByteLength);
}
/************************************************************************************
*	Function: GetFeatureReportByteLength 
*	Purpose:  Returns the info from capablities
*	Parameters: Void
*	Returns: Feature Report size for device	 
*************************************************************************************/

int CGarudaReflashDlg::GetFeatureReportByteLength(void)
{
	return(Capabilities.FeatureReportByteLength);
}

/************************************************************************************
*	Function: ReadReport 
*	Purpose:  returns a report
*	Parameters: 
*	Returns																			
*************************************************************************************/
BOOL CGarudaReflashDlg::ReadInputReport_Bulkmode()
{
	// Retrieve an Input report from the device.
	Sleep(500);
	BOOL ret_Val = FALSE;
	int     tries = 0;
	memset(&InputReport,0,INPUTREPORTMAX);

	//The first byte is the report number.
	InputReport[0]=0;
#ifdef GARUDA_HID
	DWORD	Result;
	/*API call:ReadFile
	'Returns: the report in InputReport.
	'Requires: a device handle returned by CreateFile
	'(for overlapped I/O, CreateFile must be called with FILE_FLAG_OVERLAPPED),
	'the Input report length in bytes returned by HidP_GetCaps,
	'and an overlapped structure whose hEvent member is set to an event object.
	*/
	
	if (ReadHandle != INVALID_HANDLE_VALUE)
	{
		do {
             Result = ReadFile (ReadHandle, 
							InputReport, 
							Capabilities.InputReportByteLength, 
							&NumberOfBytesRead,
							(LPOVERLAPPED) &HIDOverlapped); 
            if (!Result)
            {
                //The WriteFile failed
                tries++;
				Sleep(100);
            }
            else
            {
                /*Data has been written to the device*/
				ret_Val = TRUE;
                break;
            }
        } while (tries < READFILE_TRIES);
		
	}
	
	/*API call:WaitForSingleObject 'Used with overlapped ReadFile.
	'Returns when ReadFile has received the requested amount of data or on timeout.
	'Requires an event object created with CreateEvent and a timeout value in 

milliseconds.*/
	
	Result = WaitForSingleObject (hEventObject, 100);//6000
	
	switch (Result)
	{
	case WAIT_OBJECT_0:
		{
			break;
		}
	case WAIT_TIMEOUT:
		{
			/*API call: CancelIo Cancels the ReadFile Requires the device 

handle.
			Returns non-zero on success.*/
			Result = CancelIo(ReadHandle);
			//A timeout may mean that the device has been removed. 
			//Close the device handles and set HidAttached = False 
			//so the next access attempt will search for the device.
			break;
		}
	default:
		{
			//Close the device handles and set HidAttached = False 
			break;
		}
	}
	
	/*
	API call: ResetEvent Sets the event object to non-signaled.Requires a handle to the 
	event object.Returns non-zero on success.*/
	
	ResetEvent(hEventObject);
	
	//Display the report data.
	DisplayInputReport();
#endif 
#ifdef GARUDA_BULK
	
	UCHAR chTemp[INPUTREPORTMAX];
	if(dev)
	{
		if(usb_bulk_read(dev, EP_IN, (char*)&InputReport[0], 64, 2000) 
			== 64)	
		{
			TRACE("Read Sucess\n");
			memcpy(chTemp,InputReport,64);
			memcpy(InputReport+1,chTemp,63);
			InputReport[0]=0;
			ret_Val = TRUE;
		}
		else
		{
			TRACE("Read failed\n");
			ret_Val = FALSE;
		}
	}
		
#endif

	return ret_Val;
}

/************************************************************************************
*	Function: WriteOutputReport 
*	Purpose:  -- calls the API which writes a report to endpoint1
*	Parameters																	
*		*OutputReport -- the report to be written								
*		ReportNumber -- 
*					 0 : Exchange Input and Output reports
*					 1 : Exchange Feature reports.
*	Returns :
*			zero if the write failed		
*************************************************************************************/
BOOL CGarudaReflashDlg::WriteOutputReport_Bulkmode(unsigned char*ucReport,DWORD dwLength) 
{ 
	DWORD	BytesWritten = 0;
	INT		Index =0;
	int     tries = 0;
    BOOL    ret_stat = TRUE;

    //The first byte is the report number.
	memset(&OutputReport,0,OUTPUTREPORTMAX);

#ifdef GARUDA_HID
	ULONG	Result;
	OutputReport[0] = 0;
	memcpy(&OutputReport[1],ucReport,dwLength);
#endif

#ifdef GARUDA_BULK    
    memcpy(&OutputReport[0],ucReport,dwLength);
#endif

#ifdef GARUDA_HID
	/*
	API Function: WriteFile
	Sends a report to the device.
	Returns: success or failure.
	Requires:
	A device handle returned by CreateFile.
	A buffer that holds the report.
	The Output Report length returned by HidP_GetCaps,
	A variable to hold the number of bytes written.
	*/
	if (WriteHandle != INVALID_HANDLE_VALUE)
	{
		do {
            Result = WriteFile  (WriteHandle,
                                 OutputReport,
                                 Capabilities.OutputReportByteLength,
                                 &BytesWritten,
                                 NULL);
            if (!Result)
            {
                //The WriteFile failed
				ret_stat = FALSE;
                tries++;
            }
            else
            {
                /*Data has been written to the device*/
                break;
            }
        } while (tries < WRITEFILE_TRIES);
	}
#endif

#ifdef GARUDA_BULK
	
	if(dev)
	{
		if(usb_bulk_write(dev, EP_OUT, (char*)&OutputReport[0], 64, 1000) 
			!= 64)
		{
			TRACE("error: bulk write failed\n");
		}
		else
		{
			ret_stat= FALSE;
		}
	}
	
#endif
	Sleep(10);
	return ret_stat;
}/************************************************************************************
*	Function: PrepareForOverlappedTransfer 
*	Purpose:  
*	Parameters: None 
*	Returns : None		
*************************************************************************************/

void CGarudaReflashDlg::PrepareForOverlappedTransfer()
{
	//Get a handle to the device for the overlapped ReadFiles.

	ReadHandle=CreateFile 
		(detailData->DevicePath,
		GENERIC_READ, 
		FILE_SHARE_READ|FILE_SHARE_WRITE,
		(LPSECURITY_ATTRIBUTES)NULL, 
		OPEN_EXISTING, 
		FILE_FLAG_OVERLAPPED, 
		NULL);

	/*API function: CreateEvent
	Requires:
	  Security attributes or Null
	  Manual reset (true). Use ResetEvent to set the event object's state to non-signaled.
	  Initial state (true = signaled) 
	  Event object name (optional)
	Returns: a handle to the event object
	*/

	if (hEventObject == 0)
	{
		hEventObject = CreateEvent(NULL,TRUE,TRUE,"");
		HIDOverlapped.hEvent = hEventObject;
		HIDOverlapped.Offset = 0;
		HIDOverlapped.OffsetHigh = 0;
	}
}

void CGarudaReflashDlg::DisplayInputReport()
{
	USHORT	ByteNumber;
	CHAR	ReceivedByte;
	//Step through the received bytes and display each.
	for (ByteNumber=0; ByteNumber < GetInputReportSize(); ByteNumber++)
	{
		//Get a byte.
		ReceivedByte = InputReport[ByteNumber];
	}
}

/************************************************************************************
*	Function: CloseHandles 
*	Purpose:  Close Read, Write and device handles 
*	Parameters: None 
*	Returns :		
*************************************************************************************/

void CGarudaReflashDlg::CloseHandles() 
{
	if (HidDevHandle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(HidDevHandle);
	}
	
	if (ReadHandle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(ReadHandle);
	}
	
	if (WriteHandle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(WriteHandle);
	}
	if(FlashThreadActive == TRUE)
	{
		free(buffer);

	}
	#ifdef GARUDA_BULK
	if(dev)
	{
		usb_close(dev);
		dev=NULL;
	}
	#endif
}

/************************************************************************************
*	Function: bReadFlashStatus 
*	Purpose:  Read flashing parameters from the device
*	Parameters: None 
*	Returns :		
*************************************************************************************/

BOOL CGarudaReflashDlg::bReadFlashStatus(int buff_length)
{
	unsigned char ucData[65] = {'0'};
	memset(&ucData,0,sizeof(ucData));
	ucData[0] = CHECKSUM_BYTE1;
	ucData[1] = CHECKSUM_BYTE2;
	ucData[2] = CHECKSUM_BYTE3;
	ucData[3] = (unsigned char)buff_length ;
	ucData[4] = (unsigned char)buff_length >> 8 ;
	//// + 32 bit checksum add for future use
	if(WriteOutputReport(&ucData[0],64))
	{
		ReadInputReport();
		if(InputReport[3] == 0x00)
		{
			/*Got the Positive response then unload the HID driver*/

			//Enable Flag Commanding Garuda TOOL with CRC data.CRC validation happens at the end of Flashing. 
			return STATUS_NOERROR;
		}
		else 
		return STATUS_INVALID_RESPONSE;
	}
	else
		return STATUS_WRITE_FAILED;
	
	return STATUS_UNKNOWNERROR;



}
/************************************************************************************
*	Function: bSendFlashCommandToDevice 
*	Purpose:  Write flash command to the device
*	Parameters: None 
*	Returns :		
*************************************************************************************/

BOOL CGarudaReflashDlg::bSendNMCommandToDevice()
{
	unsigned char ucData[65] = {'0'};
	memset(&ucData,0,sizeof(ucData));
	ucData[0] = START_NORMALMODE;
	if(!WriteOutputReport(&ucData[0],64))
	{
		ReadInputReport();
		if(InputReport[3] == 0x00)
		{
			/*Got the Positive response then unload the HID driver*/
		//	CloseHandles();
			return STATUS_NOERROR;
		}
		else 
			return STATUS_INVALID_RESPONSE;
	}
	else
		return STATUS_WRITE_FAILED;
	
	return STATUS_UNKNOWNERROR;
}

/************************************************************************************
*	Function: CheckFirmwareFunction 
*	Purpose:  Checking firmware version with the device and the file
*	Parameters: None 
*	Returns :		
*************************************************************************************/
/*BOOL CGarudaReflashDlg::CheckFirmwareFunction()
{
	BOOL bFlashStatus = TRUE;
	unsigned short uVersion = 0;
	
	if(!HidAttached)
	{
		if(!bOpenHidDevice())
			return STATUS_UNKNOWNERROR;
	}
	//Check for firmware version from the attached file and compare with the device one.
	uVersion = uchFirmWareVersion[0] << 8;
	uVersion = uVersion | uchFirmWareVersion[1]; 
	
	if(uVersion != usFirmwareVersion)
	{
		bFlashStatus = bSendNMCommandToDevice();
		if(bFlashStatus)
		{
			m_ctrlDwnStatus.SetWindowText("Device is not responding!");
			return STATUS_UNKNOWNERROR;
		}
		else
			return bFlashStatus;
	}
	else
	{	
		m_ctrlDwnStatus.SetWindowText("Device Firmware Upgradation is not required!");
	}
	return STATUS_UNKNOWNERROR;
}
*/
LRESULT CGarudaReflashDlg::Main_OnDeviceChange(WPARAM wParam, LPARAM lParam)  
{
	PDEV_BROADCAST_HDR lpdb = (PDEV_BROADCAST_HDR)lParam;
	switch(wParam) 
	{
		// Find out if a device has been attached or removed.
		// If yes, see if the name matches the device path name of 
		// the device we want to access.
	case DBT_DEVICEARRIVAL:
		
		//if (DeviceNameMatch(lParam))
		{
			TRACE("My device has been attached.");
		}
		return TRUE; 
		
	case DBT_DEVICEREMOVECOMPLETE:
		
		TRACE("A device has been removed.");
		//if (DeviceNameMatch(lParam))
		{
			TRACE("My device has been removed.");
			HidAttached = FALSE;
		}
		return TRUE; 
	default:
		return TRUE; 
	} 
	return TRUE; 
}

/************************************************************************************
*	Function: RegisterForDeviceNotifications 
*	Purpose:  Registreing device notifications for plug and unplug.
*	Parameters: None 
*	Returns :		
*************************************************************************************/
void CGarudaReflashDlg::RegisterForDeviceNotifications()
{
	// Request to receive messages when a device is attached or removed.
	// Also see WM_DEVICECHANGE in BEGIN_MESSAGE_MAP(CGarudaReflashDlg, CDialog).
	/*DEV_BROADCAST_DEVICEINTERFACE_W DevBroadcastDeviceInterface;
	HDEVNOTIFY DeviceNotificationHandle;

	DevBroadcastDeviceInterface.dbcc_size = sizeof(DevBroadcastDeviceInterface);
	DevBroadcastDeviceInterface.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
	DevBroadcastDeviceInterface.dbcc_classguid = HidGuid;

	DeviceNotificationHandle =
		RegisterDeviceNotification(m_hWnd, &DevBroadcastDeviceInterface, 
								   DEVICE_NOTIFY_WINDOW_HANDLE);*/
}

void CGarudaReflashDlg::OnButtonBl() 
{
	// TODO: Add your control notification handler code here
		pwnd = AfxGetMainWnd(); // Pointer to main window

		if(!bOpenHidDevice())
			pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is either not connected or running in Bootloader mode. Please verify.");
		else
		{
			if(!EnableBootLoader())
			{
				pwnd->SetDlgItemText(IDC_KBSEC,"Failure !");
				pwnd->SetDlgItemText(IDC_FS,"BootLoader Failed!");
			}
			else
			{
				pwnd->SetDlgItemText(IDC_KBSEC,"Success !");
				pwnd->SetDlgItemText(IDC_FS,"Garuda TOOL is enabled in BootLoader Mode.");

			}
		}
	
}

//Sends enable bootloader command to device
BOOL CGarudaReflashDlg::EnableBootLoader()
{
	unsigned char ucData[65] = {'0'};
	memset(&ucData,0,sizeof(ucData));
	ucData[0] = COMMAND_BYTE1;
	ucData[1] = COMMAND_BYTE2;
	ucData[2] = COMMAND_BYTE3;
	if(WriteOutputReport_Bulkmode(&ucData[0],64))
	{
	//	ReadInputReport();
		if(InputReport[3] == 0x00)
		{
			/*Got the Positive response then unload the HID driver*/
//			CloseHandles();
			return STATUS_NOERROR;
		}
		else 
			return STATUS_INVALID_RESPONSE;
	}
	else
		return STATUS_WRITE_FAILED;
	
	return STATUS_UNKNOWNERROR;
}

void CGarudaReflashDlg::OnLabel() 
{
	// TODO: Add your command handler code here
//	AfxMessageBox("A");
	CLabels lab;
	lab.DoModal();
	
}


int CGarudaReflashDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	m_pMenu = GetMenu();
	if(!ValidateLabelUser())
	{
		m_pMenu->RemoveMenu(ID_LABEL,MF_BYCOMMAND);	
	}
	return 0;
}
BOOL CGarudaReflashDlg::WriteOutputReport(unsigned char*ucReport,DWORD dwLength) 
{ 
	DWORD	BytesWritten = 0;
	INT		Index =0;
	ULONG	Result;
	int     tries = 0;
    BOOL    ret_stat = TRUE;
	
	//The first byte is the report number.
	OutputReport[0] = 0;
	memcpy(&OutputReport[1],ucReport,dwLength);
	
	/*
	API Function: WriteFile
	Sends a report to the device.
	Returns: success or failure.
	Requires:
	A device handle returned by CreateFile.
	A buffer that holds the report.
	The Output Report length returned by HidP_GetCaps,
	A variable to hold the number of bytes written.
	*/
	if (WriteHandle != INVALID_HANDLE_VALUE)
	{
		do {
            Result = WriteFile  (WriteHandle,
                                 OutputReport,
                                 Capabilities.OutputReportByteLength,
                                 &BytesWritten,
                                 NULL);
            if (!Result)
            {
                //The WriteFile failed
				ret_stat = FALSE;
                tries++;
            }
            else
            {
                /*Data has been written to the device*/
                break;
            }
        } while (tries < WRITEFILE_TRIES);
	}
	Sleep(10);
	return ret_stat;
}
BOOL CGarudaReflashDlg::ReadInputReport()
{
	// Retrieve an Input report from the device.
	Sleep(500);
	DWORD	Result;
	BOOL ret_Val = FALSE;
	int     tries = 0;
	memset(&InputReport,0,INPUTREPORTMAX);

	//The first byte is the report number.
	InputReport[0]=0;
	
	/*API call:ReadFile
	'Returns: the report in InputReport.
	'Requires: a device handle returned by CreateFile
	'(for overlapped I/O, CreateFile must be called with FILE_FLAG_OVERLAPPED),
	'the Input report length in bytes returned by HidP_GetCaps,
	'and an overlapped structure whose hEvent member is set to an event object.
	*/
	
	if (ReadHandle != INVALID_HANDLE_VALUE)
	{
		do {
             Result = ReadFile (ReadHandle, 
							InputReport, 
							Capabilities.InputReportByteLength, 
							&NumberOfBytesRead,
							(LPOVERLAPPED) &HIDOverlapped); 
            if (!Result)
            {
                //The WriteFile failed
                tries++;
				Sleep(100);
            }
            else
            {
                /*Data has been written to the device*/
				ret_Val = TRUE;
                break;
            }
        } while (tries < READFILE_TRIES);
		
	}
	
	/*API call:WaitForSingleObject 'Used with overlapped ReadFile.
	'Returns when ReadFile has received the requested amount of data or on timeout.
	'Requires an event object created with CreateEvent and a timeout value in 

milliseconds.*/
	
	Result = WaitForSingleObject (hEventObject, 100);//6000
	
	switch (Result)
	{
	case WAIT_OBJECT_0:
		{
			break;
		}
	case WAIT_TIMEOUT:
		{
			/*API call: CancelIo Cancels the ReadFile Requires the device 

handle.
			Returns non-zero on success.*/
			Result = CancelIo(ReadHandle);
			//A timeout may mean that the device has been removed. 
			//Close the device handles and set HidAttached = False 
			//so the next access attempt will search for the device.
			break;
		}
	default:
		{
			//Close the device handles and set HidAttached = False 
			break;
		}
	}
	
	/*
	API call: ResetEvent Sets the event object to non-signaled.Requires a handle to the 
	event object.Returns non-zero on success.*/
	
	ResetEvent(hEventObject);
	
	//Display the report data.
	DisplayInputReport();
	return ret_Val;
}
