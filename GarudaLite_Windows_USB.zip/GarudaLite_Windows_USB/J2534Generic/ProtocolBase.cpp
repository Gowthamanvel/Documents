/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ProtocolBase.cpp
 Description			: Implementation file for Protocol base class
 Date					: Jan 30, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version


_______________________________________________________________________________
******************************************************************************/


#include "stdafx.h"
#include "J2534Generic.h"
#include "ProtocolBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// Static variables
CDebugLog		*CProtocolBase::m_pclsLog = NULL;
CMap<unsigned long, unsigned long, PROTOCOLBASE_PUMP_DATA *, PROTOCOLBASE_PUMP_DATA *> CProtocolBase::m_stPumpDatabase;

// This is an Auto-Reset Event.
HANDLE			CProtocolBase::m_hWritePumpSync;
HANDLE			CProtocolBase::m_hWritePumpExit;
HANDLE			CProtocolBase::m_hWritePumpExited;
//commented the m_hWriteSyncEvent since it was creating problem for the multichannel support
HANDLE			CProtocolBase::m_hWriteSyncEvent;
CWinThread		*CProtocolBase::m_pclsWritePumpThread = NULL;
unsigned long	CProtocolBase::m_ulInstance = 0;
J2534ERROR		CProtocolBase::m_J2534WriteError = J2534_STATUS_NOERROR;
POSITION		gpos;
BOOL			bISO15765 = FALSE;

CProtocolBase::CProtocolBase(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog)
{
	// Save pointers.
	m_pclsDevice = pclsDevice;
	m_pclsLog = pclsDebugLog;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "CProtocolBase()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Initialize.
	m_bConnected = false;
	m_pclsFilterMsg = NULL;
	m_pclsPeriodicMsg = NULL;
	m_ulConnectFlag = 0;

	
	if ((m_hBuffEmptyEvent = CreateEvent(NULL, TRUE, TRUE, NULL)) == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "CProtocolBase()", 
							 DEBUGLOG_TYPE_ERROR, "Could not create Buff Empty Event");
		}
	}

	if ((m_hPendingEvent = CreateEvent(NULL, TRUE, TRUE, NULL)) == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "CProtocolBase()", 
							 DEBUGLOG_TYPE_ERROR, "Could not create Pending Event");
		}
	}


	// Keep track of instances derived from this base.
	m_ulInstance++;

	if (m_ulInstance == 1)
	{
		m_hWritePumpSync = CreateEvent(NULL, FALSE, TRUE, NULL);
		m_hWritePumpExit = CreateEvent(NULL, TRUE, TRUE, NULL);
		m_hWritePumpExited = CreateEvent(NULL, TRUE, TRUE, NULL);
		m_hWriteSyncEvent = CreateEvent(NULL,TRUE,TRUE,NULL);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "CProtocolBase()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
}

CProtocolBase::~CProtocolBase()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "~CProtocolBase()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Decrement (derived) object instance count
	m_ulInstance--;	

	// Disconnect protocol incase not disconnected yet.
	if (m_bConnected)
	{
		if (vDisconnect() != J2534_STATUS_NOERROR)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "~CProtocolBase()", 
								 DEBUGLOG_TYPE_ERROR, "vDisconnect() failed");
			}
		}
	}

	// Check if this is the last instance.DeleteFromPumpDatabase(m_ulPumpRefID);
	if(m_ulInstance < 1)
	{
		// Delete all the entries from the database incase it is not.
		DeleteFromPumpDatabase(0, true);
		StopWritePump();
		CloseHandle(m_hWritePumpSync);
		CloseHandle(m_hWritePumpExit);
		CloseHandle(m_hWritePumpExited);
		CloseHandle(m_hWriteSyncEvent);
	}

	if (m_hBuffEmptyEvent != NULL)
		CloseHandle(m_hBuffEmptyEvent);

	if (m_hPendingEvent != NULL)
		CloseHandle(m_hPendingEvent);

	// Delete Filter Class.
	if (m_pclsFilterMsg != NULL)
	{
		delete m_pclsFilterMsg;
		m_pclsFilterMsg = NULL;
	}

	// Delete Periodic Class.
	if (m_pclsPeriodicMsg != NULL)
	{
		delete m_pclsPeriodicMsg;
		m_pclsPeriodicMsg = NULL;
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "~CProtocolBase()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
}

/*-----------------------------------------------------------------------------
	Function Name	: vConnect
	Input Params	: 
	Output Params	: 
	Description		: This function is a generic Connect to connect to a
					  protocol. This function should not contain Protocol 
					  specific implementation.
-----------------------------------------------------------------------------*/
J2534ERROR CProtocolBase::vConnect(J2534_PROTOCOL				 enProtocolID,
								   unsigned long				 ulFlags,
								   unsigned long				 ulBaudRate,
								   DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
								   DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
								   DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
								   LPVOID			pVoid)
{
/*****************************IMPORTANT NOTE******************************* 
 This is a generic function and so it should not contain anything protocol
 specific stuff. If any protocol specific stuff is required, implement it
 in the class derived from this base class.
**************************************************************************/

	char					szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	BOOL					bBuffError;
	J2534ERROR				enJ2534Error;
	unsigned long			ulDevChannelRef;
	PROTOCOLBASE_PUMP_DATA	stAddData;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check for invalid Device ID.
	if (m_pclsDevice == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_DEVICE_ID);
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (J2534_ERR_INVALID_DEVICE_ID);
	}

	// Check if it is already connected.
	if (m_bConnected)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_CHANNEL_IN_USE);
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return (J2534_ERR_CHANNEL_IN_USE);
	}

	
	// Check the Events that were created in the constructor.
	if ((m_hBuffEmptyEvent == NULL) || (m_hPendingEvent == NULL))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						  "Event Handles not created");
		}
		// Set right text to be retreived when GetLastError() called.
		return(J2534_ERR_FAILED);
	}
	

	// Delete filters. (This will indirectly set the filter to Block All
	// because if the Object does not exist, default is Block All). 
	if (m_pclsFilterMsg != NULL)
	{
		delete m_pclsFilterMsg;
		m_pclsFilterMsg = NULL;
	}

	// If Periodic object there, Delete it.
	if (m_pclsPeriodicMsg != NULL)
	{
		delete m_pclsPeriodicMsg;
		m_pclsPeriodicMsg = NULL;
	}

	// Create a Rx Circular Buffer.
	m_pclsRxCircBuffer = new CCircBuffer(PASSTHRU_MSG_DATA_SIZE, &bBuffError);
	if ((m_pclsRxCircBuffer == NULL) || ((m_pclsRxCircBuffer != NULL) && bBuffError))
	{
		// Delete the Rx Buffer.
		if ((m_pclsRxCircBuffer != NULL) && bBuffError)
		{
			delete(m_pclsRxCircBuffer);
			m_pclsRxCircBuffer = NULL;
		}

		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						  "Buffer cannot be created");
		}
		// Set right text to be retreived when GetLastError() called.
		return(J2534_ERR_FAILED);
	}
	
	// Create a Tx Circular Buffer.
	m_pclsTxCircBuffer = new CCircBuffer(PASSTHRU_MSG_DATA_SIZE, &bBuffError);
	if ((m_pclsTxCircBuffer == NULL) || ((m_pclsTxCircBuffer != NULL) && bBuffError))
	{
		// Delete the Tx Buffer.
		if ((m_pclsTxCircBuffer != NULL) && bBuffError)
		{
			delete(m_pclsTxCircBuffer);
			m_pclsTxCircBuffer = NULL;
		}
		// Delete the Rx Buffer as well.
		if (m_pclsRxCircBuffer != NULL)
		{
			delete(m_pclsRxCircBuffer);
			m_pclsRxCircBuffer = NULL;
		}
		// Write to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						  "Buffer cannot be created");
		}
		// Set right text to be retreived when GetLastError() called.
		return(J2534_ERR_FAILED);
	}

	// Connect to Device.
	enJ2534Error = m_pclsDevice->vConnectProtocol(enProtocolID,
  												  ulFlags,
												  ulBaudRate,
												  pfnCallback,
												  pfirstframefnCallback,
												  psetRxstatusfnCallback,
												  pVoid,
												  &ulDevChannelRef);

	if (enJ2534Error != J2534_STATUS_NOERROR)
	{
		// Delete the Rx Buffer as well.
		if (m_pclsRxCircBuffer != NULL)
		{
			delete(m_pclsRxCircBuffer);
			m_pclsRxCircBuffer = NULL;
		}
		// Delete the Tx Buffer as well.
		if (m_pclsTxCircBuffer != NULL)
		{
			delete(m_pclsTxCircBuffer);
			m_pclsTxCircBuffer = NULL;
		}

		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return(enJ2534Error);
	}

	// Set the data to be added to the Pump Database.
	stAddData.hBuffEmptyEvent = m_hBuffEmptyEvent;
	stAddData.hPendingEvent = m_hPendingEvent;
	stAddData.pclsCircBuffer = m_pclsTxCircBuffer;
	stAddData.pclsDevice = m_pclsDevice;
	stAddData.ulDevChannelRef = ulDevChannelRef;

	if (enProtocolID == ISO15765)
		bISO15765 = TRUE;
	else
		bISO15765 = FALSE;

	// Add Tx Buffer and Device to the database for pumping message out.
	if (!AddToPumpDatabase(&stAddData, &m_ulPumpRefID))
	{
		// Disconnect Protocol from Device.
		m_pclsDevice->vDisconnectProtocol(ulDevChannelRef);

		// Delete the Rx Buffer as well.
		if (m_pclsRxCircBuffer != NULL)
		{
			delete(m_pclsRxCircBuffer);
			m_pclsRxCircBuffer = NULL;
		}
		// Delete the Tx Buffer as well.
		if (m_pclsTxCircBuffer != NULL)
		{
			delete(m_pclsTxCircBuffer);
			m_pclsTxCircBuffer = NULL;
		}
		// Write to Log
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", 
							 DEBUGLOG_TYPE_ERROR, "AddBufferEntry() failed");
		}
		return(J2534_ERR_FAILED);
	}

	// Start the WritePump thread.
	if (!StartWritePump())
	{
		// Delete the Buffer that was added earlier in the Database.
		DeleteFromPumpDatabase(m_ulPumpRefID);

		// Disconnect Protocol from Device.
		m_pclsDevice->vDisconnectProtocol(ulDevChannelRef);

		// Delete the Rx Buffer as well.
		if (m_pclsRxCircBuffer != NULL)
		{
			delete(m_pclsRxCircBuffer);
			m_pclsRxCircBuffer = NULL;
		}
		// Delete the Tx Buffer as well.
		if (m_pclsTxCircBuffer != NULL)
		{
			delete(m_pclsTxCircBuffer);
			m_pclsTxCircBuffer = NULL;
		}
		// Write to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "CProtocolBase()", 
							 DEBUGLOG_TYPE_ERROR, "StartWritePump() failed");
		}
		// Set right text to be retreived when GetLastError() called.
		return(J2534_ERR_FAILED);
	}

	// Save Connect Flag value.
	m_ulConnectFlag = ulFlags;

	// Save the ChannelID for further reference.
	m_ulDevChannelRef = ulDevChannelRef;

	// Set the Connected Flag.
	m_bConnected = true;

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vConnect()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function is a generic Disconnect to disconnect the 
//					  protocol that was connected earlier. It restores the 
//					  state it was in prior to calling vConnect(). This function
//					  should not contain Protocol specific implementation.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::vDisconnect()
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char			szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vDisconnect()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check if device is not connected.
	if (!m_bConnected)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
							 "Protocol never connected");
		}
		return (J2534_ERR_FAILED);
	}
	if(m_pclsTxCircBuffer == NULL)
		return(J2534_ERR_FAILED);

	m_pclsTxCircBuffer->ClearBuffer();

	// Disconnect from Device.

	enJ2534Error = m_pclsDevice->vDisconnectProtocol(m_ulDevChannelRef);

	if (enJ2534Error != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		//return(enJ2534Error);
	}

	SetEvent(CProtocolBase::m_hWriteSyncEvent);
	// Delete the item that was added in the Database at Connect time.
	if (!DeleteFromPumpDatabase(m_ulPumpRefID))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_FAILED);
			m_pclsLog->Write("ProtocolBase.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		//return(J2534_ERR_FAILED);
	}

	// Delete Filter if not deleted already.
	if (m_pclsFilterMsg != NULL)
	{
		// Stop all Filters.
		m_pclsFilterMsg->StopFilter();
		delete m_pclsFilterMsg;
		m_pclsFilterMsg = NULL;
	}

	// Delete Periodic if not deleted already.
	if (m_pclsPeriodicMsg != NULL)
	{
		// Stop all Periodics.
		m_pclsPeriodicMsg->StopPeriodic();
		delete m_pclsPeriodicMsg;
		m_pclsPeriodicMsg = NULL;
	}

	// Stop the Write Pump if Pump Database Empty.
	if (IsEmptyPumpDatabase())
	{
		StopWritePump();
	}

	SetEvent(CProtocolBase::m_hWriteSyncEvent);

	// Delete the Rx Buffer as well.
	if (m_pclsRxCircBuffer != NULL)
	{
		delete(m_pclsRxCircBuffer);
		m_pclsRxCircBuffer = NULL;
	}
	// Delete the Tx Buffer as well.
	if (m_pclsTxCircBuffer != NULL)
	{
		delete(m_pclsTxCircBuffer);
		m_pclsTxCircBuffer = NULL;
	}

	// Reset Flag value.
	m_ulConnectFlag = 0;

	// Reset Channel ID.
	m_ulDevChannelRef = 0;

	// Set the Connected flag.
	m_bConnected = false;

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vDisconnect()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	//return(J2534_STATUS_NOERROR);
	return enJ2534Error;
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the requested number of messages from
//					  the circular buffer sends it over to the caller. This is
//					  a genric Read and so the protocol specific implementation
//					  should be carried out in the class derived from this.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::vReadMsgs(PASSTHRU_MSG	*pstPassThruMsg,
									unsigned long	*pulNumMsgs,
									unsigned long	ulTimeout)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char			szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	BOOL			bBufferOverflow = true;
	BOOL			bOverflowed = false;
	BOOL			bBufferEmpty = true;
	DWORD			dwStartTick;
	unsigned long	ulReadMsgs;
	unsigned long	ulNumMsgs;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	dwStartTick = GetTickCount();


	ulReadMsgs = *pulNumMsgs;
	*pulNumMsgs = 0;


	do
	{
		if(m_pclsRxCircBuffer == NULL)
			return(J2534_ERR_FAILED);
		// Check to see if the buffer is overflowed.
		m_pclsRxCircBuffer->GetBufferOverflowStatus(&bBufferOverflow);
		if (bBufferOverflow)
		{
			bOverflowed = true;
		}

		if (pstPassThruMsg != NULL)
		{
			ulNumMsgs = ulReadMsgs - *pulNumMsgs;
			if (!m_pclsRxCircBuffer->Read((unsigned char *)(pstPassThruMsg+*pulNumMsgs), &ulNumMsgs))
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
									 "Circular Buffer Error");
				}
				return(J2534_ERR_FAILED);
			}
			*pulNumMsgs = *pulNumMsgs + ulNumMsgs;
		}
		else
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
								 "Buffer supplied is not big enough");
			}
			return(J2534_ERR_FAILED);
		}
		
		if(ulTimeout > 0)
		{
			// If all messages are read
			//if (*pulNumMsgs < ulReadMsgs)
			//	Sleep(1);
		}
	}
	while ((*pulNumMsgs < ulReadMsgs) && ((GetTickCount() - dwStartTick) < ulTimeout));
/*Removed this check as even buffer overflows, read must be exicuted to release load..Nikhilesh*/
	/*if (bOverflowed)
	{
		// Write status to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_BUFFER_OVERFLOW);
			m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_BUFFER_OVERFLOW);
	}*/

	if (*pulNumMsgs < ulReadMsgs)
	{
		if (*pulNumMsgs == 0)
		{
			// Write status to Log File.
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_BUFFER_EMPTY);
				m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", 
								 DEBUGLOG_TYPE_ERROR, szBuffer);
			}
			return(J2534_ERR_BUFFER_EMPTY);
		}
		if ((GetTickCount() - dwStartTick) >= ulTimeout)
		{
			// Write status to Log File.
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_TIMEOUT);
				m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", 
								 DEBUGLOG_TYPE_ERROR, szBuffer);
			}
			return(J2534_ERR_TIMEOUT);
		}
	}
	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a generic function to write msgs. to a circular 
//					  buffer that waits until it is transmitted out on the bus 
//					  or exits immediately after writing to buffer if it is 
//					  non-blocking. The message is Blocking if the given timeout
//					  value is greater than 0. This is a generic Wrie and so 
//					  the protocol specific implementation should be carried 
//					  out in the class derived from this.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
									 unsigned long	*pulNumMsgs,
									 unsigned long	ulTimeout)		
{
	//*****************************IMPORTANT NOTE******************************* 
	// This is a generic function and so it should not contain anything protocol
	// specific stuff. If any protocol specific stuff is required, implement it
	// in the class derived from this base class.
	//**************************************************************************

	char			szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	unsigned long	ulNumMsgs;
	J2534ERROR		enJ2534Error;
	BOOL			bBufferFull = true;
	unsigned long	i;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check if Buffer is full.
	if(m_pclsTxCircBuffer == NULL)
		return(J2534_ERR_FAILED);
	
	
	m_pclsTxCircBuffer->GetBufferFullStatus(&bBufferFull);
	
	if(bBufferFull)
	{
		if(ulTimeout > 0)
			return J2534_ERR_BUFFER_FULL;
		
		// Write to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vWriteMsgs()", 
				DEBUGLOG_TYPE_COMMENT, "Start");
		}
		
		Sleep(10);
	}
	m_pclsTxCircBuffer->GetBufferFullStatus(&bBufferFull);

	if(bBufferFull)
		return J2534_ERR_BUFFER_FULL;

	if (pstPassThruMsg  != NULL)
	{
		// Write msgs to the circular buffer.
		if (!m_pclsTxCircBuffer->Write(pstPassThruMsg,*pulNumMsgs))
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
					"Circular buffer error");
			}
			return(J2534_ERR_FAILED);
		}

		SetEvent(m_hWriteSyncEvent);
	}
	else
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
				"Buffer supplied is not big enough");
		}
		return(J2534_ERR_FAILED);
	}

	if (ulTimeout > 0)
	{

		DWORD startTime =  GetTickCount();
		BOOL bufferEmptyStatus = FALSE;

		do
		{
			m_pclsTxCircBuffer->GetBufferEmptyStatus(&bufferEmptyStatus);
		}
		while((startTime + ulTimeout) > GetTickCount() && !bufferEmptyStatus);

		if(!bufferEmptyStatus)
		{
			enJ2534Error = J2534_ERR_TIMEOUT;
			m_pclsTxCircBuffer->ClearBuffer();

			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
				m_pclsLog->Write("ProtocolBase.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
			return(enJ2534Error);
		}
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This a generic function to Start Periodic Msg.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::vStartPeriodicMsg(PASSTHRU_MSG  *pstPassThruMsg,
											unsigned long *pulMsgID,
											unsigned long ulTimeInterval)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char		szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vStartPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// If Periodic Class is not created, create it now.
	if (m_pclsPeriodicMsg == NULL)
	{
		if ((m_pclsPeriodicMsg = new CPeriodicMsg(m_pclsDevice, m_ulDevChannelRef, m_pclsLog)) == NULL)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "vStartMsgFiler()", DEBUGLOG_TYPE_ERROR, 
								 "Unable to create Periodic");
			}
			return(J2534_ERR_FAILED);
		}
	}

	// Setup Periodic.
	if ((enJ2534Error = m_pclsPeriodicMsg->StartPeriodic(
														pstPassThruMsg, 
														pulMsgID,
														ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vStartPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vUpdatePeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a generic function to update Periodic Msg that was
//					  started earlier.
//-----------------------------------------------------------------------------
J2534ERROR	CProtocolBase::vUpdatePeriodicMsg(		PASSTHRU_MSG	*pstrucJ2534Msg,
												unsigned long ulMsgID,
												unsigned long ulTimeInterval)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char	szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vUpdatePeriodicMsg()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	if (m_pclsPeriodicMsg == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG_ID);
			m_pclsLog->Write("ProtocolBase.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return (J2534_ERR_INVALID_MSG_ID);
	}

	// Setup Periodic.
	if ((enJ2534Error = m_pclsPeriodicMsg->UpdatePeriodic(
														pstrucJ2534Msg, 
														ulMsgID,
														ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vUpdatePeriodicMsg()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a generic function to stop Periodic Msg that was
//					  started earlier.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::vStopPeriodicMsg(unsigned long ulMsgID)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char	szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vStopPeriodicMsg()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	if (m_pclsPeriodicMsg == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG_ID);
			m_pclsLog->Write("ProtocolBase.cpp", "vStopPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return (J2534_ERR_INVALID_MSG_ID);
	}

	// Setup Filter.
	if ((enJ2534Error = m_pclsPeriodicMsg->StopPeriodic(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vStopPeriodicMsg()", 
							  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vStopPeriodicMsg()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This a generic function and so the protocol specific 
//					  implementation should be carried out in the class derived 
//					  from this.
//-----------------------------------------------------------------------------
J2534ERROR	CProtocolBase::vStartMsgFilter(
										J2534_FILTER		enFilterType,
										PASSTHRU_MSG		*pstPassThruMask,
										PASSTHRU_MSG		*pstPassThruPattern,
										PASSTHRU_MSG		*pstPassThruFlowControl,
										unsigned long		*pulFilterID)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char		szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// If Filter Class is not created, create it now.
	if (m_pclsFilterMsg == NULL)
	{
		if ((m_pclsFilterMsg = new CFilterMsg(m_pclsDevice, m_ulDevChannelRef, m_pclsLog)) == NULL)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "vStartMsgFiler()", DEBUGLOG_TYPE_ERROR, 
								 "Unable to create Filter");
			}
			return(J2534_ERR_FAILED);
		}
	}

	// Setup Filter.
	if ((enJ2534Error = m_pclsFilterMsg->StartFilter(
							   enFilterType, 
							   pstPassThruMask, 
							   pstPassThruPattern,
							   pstPassThruFlowControl,
							   pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vStartMsgFiler()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This a generic function and so the protocol specific 
//					  implementation should be carried out in the class derived 
//					  from this.
//-----------------------------------------------------------------------------
J2534ERROR	CProtocolBase::vStopMsgFilter(unsigned long ulFilterID)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char		szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vStopMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	if (m_pclsFilterMsg == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
			m_pclsLog->Write("ProtocolBase.cpp", "vStopMsgFiler()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return (J2534_ERR_INVALID_FILTER_ID);
	}

	// Setup Filter.
	if ((enJ2534Error = m_pclsFilterMsg->StopFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vStopMsgFiler()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolBase.cpp", "vStopMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function which should be implemented by
//					  the class derived from this base class.
//-----------------------------------------------------------------------------
J2534ERROR	CProtocolBase::vIoctl(J2534IOCTLID enumIoctlID,
								  void *pInput,
								  void *pOutput)
{
//*****************************IMPORTANT NOTE******************************* 
// This is a generic function and so it should not contain anything protocol
// specific stuff. If any protocol specific stuff is required, implement it
// in the class derived from this base class.
//**************************************************************************

	char	szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;
	//Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vIoctl()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	enJ2534Error = m_pclsDevice->vIoctl(m_ulDevChannelRef, enumIoctlID,pInput,pOutput);								
	
	if (enJ2534Error != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ProtocolBase.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		m_pclsLog->Write("ProtocolBase.cpp", "vIoctl()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	//Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "vIoctl()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: AddToPumpDatabase
//	Input Params	: void
//	Output Params	: void
//	Description		: This function adds a buffer and device to a database that 
//					  is used by the WritePump Thread.
//-----------------------------------------------------------------------------
BOOL CProtocolBase::AddToPumpDatabase(PROTOCOLBASE_PUMP_DATA *pstAddData,
									  unsigned long			 *pulPumpRefID)
{
	PROTOCOLBASE_PUMP_DATA			*pstPumpData;
	BOOL							bRet = true;

	if ((pulPumpRefID == NULL) || (pstAddData == NULL))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "AddToPumpDatabase()", 
							 DEBUGLOG_TYPE_ERROR, "NULL Pointer passed");
		}
		return(false);
	}

	// Check if Write Thread Sync. event is in signal state.
	if (WaitForSingleObject(m_hWritePumpSync, PROTOCOLBASE_PUMP_SYNC_TIMEOUT) 
					== WAIT_OBJECT_0)
	{
		*pulPumpRefID = GetTickCount();
		// Check if the Reference ID is duplicate.
		if (m_stPumpDatabase.Lookup(*pulPumpRefID, pstPumpData))
		{
			// Sleep upto Tick Count resolution so that we can create a unique
			// Reference ID.
			Sleep(56);
			*pulPumpRefID = GetTickCount();
		}

		// Create new item.
		pstPumpData = new(PROTOCOLBASE_PUMP_DATA);
		if (pstPumpData != NULL)
		{
			pstPumpData->hBuffEmptyEvent = pstAddData->hBuffEmptyEvent;
			pstPumpData->hPendingEvent = pstAddData->hPendingEvent;
			pstPumpData->pclsCircBuffer = pstAddData->pclsCircBuffer;
			pstPumpData->pclsDevice = pstAddData->pclsDevice;
			pstPumpData->ulDevChannelRef = pstAddData->ulDevChannelRef;

			// Set created item into the Pump Database.
			m_stPumpDatabase[*pulPumpRefID] = pstPumpData;
			// Get the position of first item in the CMap Database.
			gpos = m_stPumpDatabase.GetStartPosition();
		}
		else
		{
			bRet = false;
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "AddToPumpDatabase()", 
								 DEBUGLOG_TYPE_ERROR, "new(PROTOCOLBASE_PUMP_DATA) failed ");
			}
		}
		// Set it back to signal state.
		SetEvent(m_hWritePumpSync);
	}
	else
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "AddToPumpDatabase()", 
							 DEBUGLOG_TYPE_ERROR, "Sync. Event not signalled");
		}

		return(false);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "AddToPumpDatabase()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}

	return(bRet);
}

//-----------------------------------------------------------------------------
//	Function Name	: DeleteFromPumpDatabase
//	Input Params	: void
//	Output Params	: void
//	Description		: This function removes a buffer and a device from the 
//					  database that is used by the WritePump Thread. If the 
//					  bRemoveAll is true, the database is made empty.
//-----------------------------------------------------------------------------
BOOL CProtocolBase::DeleteFromPumpDatabase(unsigned long ulPumpRefID, 
										   BOOL			 bRemoveAll)
{
	PROTOCOLBASE_PUMP_DATA			*pstPumpData;
	BOOL							bRet = true;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "DeleteFromPumpDatabase()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check if Write Thread Sync. event is in signal state.
	if (WaitForSingleObject(m_hWritePumpSync, 
			PROTOCOLBASE_PUMP_SYNC_TIMEOUT) == WAIT_OBJECT_0)
	{
		if (bRemoveAll)
		{
			if (!m_stPumpDatabase.IsEmpty())
			{
				// Remove all the items from the Pump Database.
				m_stPumpDatabase.RemoveAll();
			}
		}
		else
		{
			if (m_stPumpDatabase.Lookup(ulPumpRefID, pstPumpData))
			{	
				if (!m_stPumpDatabase.RemoveKey(ulPumpRefID))
				{
					bRet = false;
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						m_pclsLog->Write("ProtocolBase.cpp", "DeleteFromPumpDatabase()", 
										 DEBUGLOG_TYPE_ERROR, "Could not remove Key");
					}
				}
				else
				{
					delete pstPumpData;
				}
				
				// Get the position of first item in the CMap Database.
				gpos = m_stPumpDatabase.GetStartPosition();
			}
				
		}

		// Set it back to signal state.
		SetEvent(m_hWritePumpSync);
	}
	else if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "DeleteFromPumpDatabase()", 
						 DEBUGLOG_TYPE_ERROR, "Sync. Event not signalled");
		return(false);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "DeleteFromPumpDatabase()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}

	return(bRet);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsEmptyPumpDatabase
//	Input Params	: void
//	Output Params	: void
//	Description		: This function checks to see if the Pump Database is empty.
//-----------------------------------------------------------------------------
BOOL CProtocolBase::IsEmptyPumpDatabase()
{
	BOOL	bEmpty = true;

	// Check if Write Thread Sync. event is in signal state.
	if (WaitForSingleObject(m_hWritePumpSync, PROTOCOLBASE_PUMP_SYNC_TIMEOUT) 
					== WAIT_OBJECT_0)
	{
		// Check if the Reference ID is duplicate.
		if (m_stPumpDatabase.IsEmpty())
		{
			bEmpty = true;
		}
		else
			bEmpty = false;

		// Set it back to signal state.
		SetEvent(m_hWritePumpSync);
	}
	else
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "IsEmptyPumpDatabase()", 
							 DEBUGLOG_TYPE_ERROR, "Sync. Event not signalled");
		}
		return(true);
	}

	return(bEmpty);
}

//-----------------------------------------------------------------------------
//	Function Name	: StartWritePump
//	Input Params	: void
//	Output Params	: void
//	Description		: This function starts a thread that will continuosly check
//					  if any of the registered circular buffer has a message.
//					  If yes, it will dequeue it and send it to the 
//					  corresponding device to send it out on the Bus.
//-----------------------------------------------------------------------------
BOOL CProtocolBase::StartWritePump()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "StartWritePump()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// If the write thread is not running.
	if (WaitForSingleObject(m_hWritePumpExited, 0) == WAIT_OBJECT_0)
	{
		// Create Thread.
		m_pclsWritePumpThread = AfxBeginThread((AFX_THREADPROC)WritePumpThread, NULL);

		if (m_pclsWritePumpThread == NULL)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "StartWriteThread()", 
								 DEBUGLOG_TYPE_ERROR, "WriteThread pointer returned NULL!");
			}
		}

		// Give sometime to run the thread
		// Changing 50 to 5 - Karthik
		Sleep(5);

		// Make sure the thread did not exit.
		if (WaitForSingleObject(m_hWritePumpExited, 0) == WAIT_OBJECT_0)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "StartWriteThread()", 
								 DEBUGLOG_TYPE_ERROR, "Could not create WriteThread !");
			}
			return(false);
		}
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "StartWritePump()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}

	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: StopWritePump
//	Input Params	: void
//	Output Params	: void
//	Description		: This function stops the write thread that was created
//					  earlier. 
//-----------------------------------------------------------------------------
BOOL CProtocolBase::StopWritePump()
{
	DWORD	dwExitCode;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "StopWritePump()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	SetEvent(m_hWritePumpExit);
	if (WaitForSingleObject(m_hWritePumpExited, PROTOCOLBASE_PUMPTHREAD_END_TIMEOUT) !=
		WAIT_OBJECT_0)
	{
		GetExitCodeThread(m_pclsWritePumpThread->m_hThread, &dwExitCode);
		TerminateThread(m_pclsWritePumpThread->m_hThread, dwExitCode);
		SetEvent(m_hWritePumpSync);
		SetEvent(m_hWritePumpExited);
		m_pclsWritePumpThread = NULL;
		
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "StopWriteThread()", 
				DEBUGLOG_TYPE_ERROR, "WriteThread failed graceful exit !");
		}
	
		return(false);
	}

	// Set all the Event handles to signal just incase.
	SetEvent(m_hWritePumpExit);
	SetEvent(m_hWritePumpSync);
	SetEvent(m_hWritePumpExited);

	m_pclsWritePumpThread = NULL;

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolBase.cpp", "StopWritePump()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}

	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetMsgPending
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the status to Msg. pending. This will
//					  be set to not-pending by the WritePumpThread() when all
//					  the msgs. from buffer are sent out to the Device 
//					  successfully. This function takes the timeout value and
//					  returns the remaining time.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::SetMsgPending(unsigned long	ulPumpRefID, 
										unsigned long	*pulTimeout)
{
	char						szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	PROTOCOLBASE_PUMP_DATA		*pstPumpData;
	DWORD						dwStatus;
	DWORD						dwStartTick;
	DWORD						dwTick;

	dwStartTick = GetTickCount();

	// Find the Data corressponding to a given RefID.
	if (!m_stPumpDatabase.Lookup(ulPumpRefID, pstPumpData))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "SetMsgPending()", 
							 DEBUGLOG_TYPE_ERROR, "Referenced Data not found");
		}
		// Set right text to be retreived when GetLastError() called.
		return (J2534_ERR_FAILED);
	}

	// Set the Buffer Empty to non-signal that will be signalled in WritePumpThread()
	// when the buffer is empty.
	if (WaitForSingleObject(pstPumpData->hBuffEmptyEvent, 0) == WAIT_OBJECT_0)
	{
		if (!ResetEvent(pstPumpData->hBuffEmptyEvent))
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "SetMsgPending()", 
								 DEBUGLOG_TYPE_ERROR, "Could not reset Buffer Empty Event");
			}
			// Set right text to be retreived when GetLastError() called.
			return (J2534_ERR_FAILED);
		}
	}

	// Wait for Buffer to empty.
	if ((dwStatus = WaitForSingleObject(pstPumpData->hBuffEmptyEvent, *pulTimeout)) != WAIT_OBJECT_0)
	{
		if (dwStatus == WAIT_TIMEOUT)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_TIMEOUT);
				m_pclsLog->Write("ProtocolBase.cpp", "SetMsgPending()", 
								 DEBUGLOG_TYPE_ERROR, "");
			}
			return (J2534_ERR_TIMEOUT);
		}
		else
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "SetMsgPending()", 
								 DEBUGLOG_TYPE_ERROR, "Waiting for buffer empty");
			}
			// Set right text to be retreived when GetLastError() called.
			return (J2534_ERR_FAILED);
		}
	}

	// Msg. Pending is signalled then set it to non-signalled.
	if (WaitForSingleObject(pstPumpData->hPendingEvent, 0) == WAIT_OBJECT_0)
	{
		// Set the event for this buffer to pending. This will be set
		if (!ResetEvent(pstPumpData->hPendingEvent))
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "SetMsgPending()", 
								 DEBUGLOG_TYPE_ERROR, "Could not set msg. pending");
			}
			// Set right text to be retreived when GetLastError() called.
			return (J2534_ERR_FAILED);
		}
	}

	if ((dwTick = (GetTickCount() - dwStartTick)) <= *pulTimeout)
	{
		*pulTimeout = *pulTimeout - dwTick;
	}
	else
	{
		*pulTimeout = 0;
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsMsgSent
//	Input Params	: 
//	Output Params	: 
//	Description		: This function checks the Buffer in the Pump Database 
//					  corressponding to the given Reference ID to see if the
//					  any message is pending that is not yet sent out to
//					  the device. This function takes the timeout value and
//					  returns the remaining time.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolBase::IsMsgSent(unsigned long	ulPumpRefID, 
									unsigned long	*pulTimeout)
{
	char						szBuffer[PROTOCOLBASE_ERROR_TEXT_SIZE];
	PROTOCOLBASE_PUMP_DATA		*pstPumpData;
	DWORD						dwStatus;
	DWORD						dwStartTick;
	DWORD						dwTick;

	dwStartTick = GetTickCount();

	// Find the Data corressponding to a given RefID.
	if (!m_stPumpDatabase.Lookup(ulPumpRefID, pstPumpData))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ProtocolBase.cpp", "IsMsgSent()", 
							 DEBUGLOG_TYPE_ERROR, "Referenced Data not found");
		}
		// Set right text to be retreived when GetLastError() called.
		return (J2534_ERR_FAILED);
	}

	// Wait for pending msg. to be sent out to device. This will be signalled
	// in the WritePumpThread().
	if ((dwStatus = WaitForSingleObject(pstPumpData->hPendingEvent, *pulTimeout)) != WAIT_OBJECT_0)
	{
		if (dwStatus == WAIT_TIMEOUT)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_TIMEOUT);
				m_pclsLog->Write("ProtocolBase.cpp", "IsMsgSent()", 
								 DEBUGLOG_TYPE_ERROR, szBuffer);
			}
			return (J2534_ERR_TIMEOUT);
		}
		else
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ProtocolBase.cpp", "IsMsgSent()", 
								 DEBUGLOG_TYPE_ERROR, "Wait for msg. pending failed");
			}
			// Set right text to be retreived when GetLastError() called.
			return (J2534_ERR_FAILED);
		}
	}

	if ((dwTick = (GetTickCount() - dwStartTick)) <= *pulTimeout)
	{
		*pulTimeout = *pulTimeout - dwTick;
	}
	else
	{
		*pulTimeout = 0;
	}

	return(m_J2534WriteError);
}

//-----------------------------------------------------------------------------
//	Function Name	: WritePumpThread
//	Input Params	: 
//	Output Params	: 
//	Description		: This thread peeks to see if there is any message in the
//					  circular buffers that were registered in the database.
//					  If yes, it dequeues the message and sends it to out to
//					  the corresponding device to write it out on the Bus.
//-----------------------------------------------------------------------------
UINT WritePumpThread(LPVOID lpVoid)
{
	PROTOCOLBASE_PUMP_DATA			*pstPumpData;
	DWORD							dwSync;
	unsigned long					ulKeyIdx;
	unsigned long					ulNumMsg;
	PASSTHRU_MSG *					stPassThruMsg;
	int nIdleCount  =0;

	stPassThruMsg = NULL;
	

	// Write to Log File.
	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("ProtocolBase.cpp", "WritePumpThread()", 
										   DEBUGLOG_TYPE_COMMENT, "Start");
	}	

	// Set this event to non-signal to indicate that the thread is running.
	ResetEvent(CProtocolBase::m_hWritePumpExited);
	// Set this event to non-signal. When signaled, it will exit the thread.
	ResetEvent(CProtocolBase::m_hWritePumpExit);
	
	ResetEvent(CProtocolBase::m_hWriteSyncEvent);

	gpos = NULL;
	// Check if Thread Synchronization Event is signaled and Exit Event is not
	// signaled.
	while (	WaitForSingleObject(CProtocolBase::m_hWritePumpExit, 0) != WAIT_OBJECT_0)
	{
		
		if ((dwSync = WaitForSingleObject(CProtocolBase::m_hWritePumpSync, 
										  PROTOCOLBASE_PUMP_SYNC_TIMEOUT)) == WAIT_OBJECT_0)
		{			
			// Check if the position in the CMap Database is not NULL.
			if (gpos != NULL)
				
			{
				// Get item from Database at the given position.
				CProtocolBase::m_stPumpDatabase.GetNextAssoc(gpos, ulKeyIdx, pstPumpData);

				ulNumMsg = pstPumpData->pclsCircBuffer->ulGlobalNumMsg;
				if(ulNumMsg > 0)
				{
					/*if(pstPumpData->pclsCircBuffer->ulGlobalNumMsg == 0)
					{
					WaitForSingleObject(CProtocolBase::m_hWriteSyncEvent, INFINITE);
					ResetEvent(CProtocolBase::m_hWriteSyncEvent);
					//Sleep(1);
					}*/
					
					stPassThruMsg = new PASSTHRU_MSG[ulNumMsg];// (PASSTHRU_MSG *) malloc(sizeof(PASSTHRU_MSG) * ulGlobalNumMsg);
					
					// Pull out message from this circular buffer
					if (pstPumpData->pclsCircBuffer->Read((unsigned char *)stPassThruMsg, &ulNumMsg))
					{
						if (ulNumMsg > 0)
						{
							// Send out the pulled msg. to the corressponding Device.
							if ((CProtocolBase::m_J2534WriteError = pstPumpData->pclsDevice->vWriteMsgs(
								pstPumpData->ulDevChannelRef, (PASSTHRU_MSG *) stPassThruMsg, &ulNumMsg)) != J2534_STATUS_NOERROR)
							{					
								if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
								{
									
									CProtocolBase::m_pclsLog->Write("ProtocolBase.cpp", "WritePumpThread()", 
										DEBUGLOG_TYPE_ERROR, "Device::vWriteMsgs() failed");
								}
							}
						}				
						
					}			
					
					try
					{
						if(stPassThruMsg != NULL)
						{
							delete []stPassThruMsg;
							stPassThruMsg = NULL;
						}
					}
					catch( ... )
					{
						
					}
				}
				else
				{
					WaitForSingleObject(CProtocolBase::m_hWriteSyncEvent, 1);
					ResetEvent(CProtocolBase::m_hWriteSyncEvent);
					//Sleep(1);
				}
			}
			
			// Check if the position is NULL now.
			if (gpos == NULL)				
			{
				// Get the position of first item in the CMap Database.
				gpos = CProtocolBase::m_stPumpDatabase.GetStartPosition();
				
			}
			
			// Signal the Sync event.
			SetEvent(CProtocolBase::m_hWritePumpSync);
		}		
	}
	
	// If the Synchronization event timed out, may be it never got released
	// by the other thread.
	if (dwSync == WAIT_TIMEOUT)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("ProtocolBase.cpp", "WritePumpThread()", 
				DEBUGLOG_TYPE_ERROR, "Sync. Event not signalled");
		}
	}
	
	CProtocolBase::m_pclsWritePumpThread = NULL;
	
	// Set this event to Signal incase not.
	SetEvent(CProtocolBase::m_hWritePumpExit);
	
	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("ProtocolBase.cpp", "WritePumpThread()", 
			DEBUGLOG_TYPE_COMMENT, "SetEvent(CProtocolBase::m_hWritePumpSync)");
	}
	
	// Set this event to Signal to indicate that thread exited.
	SetEvent(CProtocolBase::m_hWritePumpExited);
	
	SetEvent(CProtocolBase::m_hWriteSyncEvent);
	
	// Set this event to Signal incase not.
	SetEvent(CProtocolBase::m_hWritePumpSync);
	
	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("ProtocolBase.cpp", "WritePumpThread()", 
			DEBUGLOG_TYPE_COMMENT, "End");
	}
	
	// End thread	
	AfxEndThread(0);

	return 1;
}



