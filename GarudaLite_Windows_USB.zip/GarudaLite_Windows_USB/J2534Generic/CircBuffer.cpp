/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: CircBuffer.cpp
 Description			: interface for the CCircBuffer class.
 Date					: Jan 30, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version

*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "CircBuffer.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
/*-----------------------------------------------------------------------------
	Function Name	: CCircBuffer()
	Input Params	: void
	Output Params	: void
	Return			: None
	Description		: This is a constructor.
------------------------------------------------------------------------------*/
CCircBuffer::CCircBuffer(unsigned long ulBufferSize, 
						 BOOL *pbError)
{
	m_bBufferEmpty = true;
	m_bBufferOverWritten = false;
	m_bBufferFull = false;
	m_ulTotalSize = ulBufferSize;
	*pbError = false;
	ulGlobalNumMsg = 0;

	// Event for Synchronization.
	m_hCriticalSection = CreateMutex(NULL, FALSE, NULL);
}

/*-----------------------------------------------------------------------------
	Function Name	: ~CCircBuffer()
	Input Params	: void
	Output Params	: void
	Return			: None
	Description		: This is a destructor.
-----------------------------------------------------------------------------*/
CCircBuffer::~CCircBuffer()
{
	MsgStruct	*msg;

	// Clear buffer
	while (MsgList.size() > 0)
	{
		msg = MsgList[0];
		free(MsgList[0]->m_pucData);
		MsgList.erase(MsgList.begin());
		delete msg;
	}

	if (m_hCriticalSection != NULL)
	{
		CloseHandle(m_hCriticalSection);
		m_hCriticalSection = NULL;
	}
}

/*-----------------------------------------------------------------------------
	Function Name	: GetBufferFullStatus()
	Input Params	: 
	Output Params	: 
	Return			: 
	Description		: Checks the buffer to see if it full. The parameter will
					  contain the status. If full, true is sent otherwise false.
-----------------------------------------------------------------------------*/
BOOL CCircBuffer::GetBufferFullStatus(BOOL* pbBufferFull)
{
	*pbBufferFull = m_bBufferFull;
	return(true);
}

/*-----------------------------------------------------------------------------
	Function Name	: GetBufferEmptyStatus()
	Input Params	: 
	Output Params	: 
	Return			: 
	Description		: Checks the buffer to see if it Empty. The parameter will
					  contain the status. If Empty, true is sent otherwise false.
-------------------------------------------------------------------------------*/

BOOL CCircBuffer::GetBufferEmptyStatus(BOOL* pbBufferEmpty)
{
	*pbBufferEmpty = m_bBufferEmpty;
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetBufferOverflowStatus()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: Checks the buffer to see if it overflowed. The parameter 
//					  will contain the status. If overflowed, true is sent 
//					  otherwise false.
//-----------------------------------------------------------------------------
BOOL CCircBuffer::GetBufferOverflowStatus(BOOL* pbBufferOverflow)
{
	*pbBufferOverflow = m_bBufferOverWritten;
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: ClearBuffer()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: Clears the circular buffer by resetting the pointers
//					  and flags.
//-----------------------------------------------------------------------------
void CCircBuffer::ClearBuffer()
{

	if(WaitForSingleObject(m_hCriticalSection, 
		CIRCBUFFER_CRITICAL_SECTION_TIMEOUT) != WAIT_OBJECT_0)
	{
		return;
	}
	
	try
	{
		MsgStruct	*msg;
		// Clear buffer
		while (MsgList.size() > 0)
		{
			msg = MsgList[0];
			free(MsgList[0]->m_pucData);
			MsgList.erase(MsgList.begin());
			delete msg;
		}	
		m_bBufferEmpty = true;
		m_bBufferOverWritten = false;
		m_bBufferFull = false;
		
	}
	catch( ... )
	{
		
	}
	ReleaseMutex(m_hCriticalSection);
}

//-----------------------------------------------------------------------------
//	Function Name	: Write()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: Writes to circular buffer. Each message in the 
//					  buffer is a fixed size. 
//-----------------------------------------------------------------------------
BOOL CCircBuffer::Write(unsigned char *pucMsgs, unsigned long uiMsgLen)
{

	if(pucMsgs == NULL)
		return(false);
	
	try
	{
		if(WaitForSingleObject(m_hCriticalSection, 
			CIRCBUFFER_CRITICAL_SECTION_TIMEOUT) != WAIT_OBJECT_0)
		{
			return(false);
		}
	}
	catch( ... )
	{
		//ReleaseMutex(m_hCriticalSection);
		return false;
	}

	/*if(WaitForSingleObject(m_hCriticalSection, 
		CIRCBUFFER_CRITICAL_SECTION_TIMEOUT) != WAIT_OBJECT_0)
	{
		return(false);
	}*/

	MsgStruct	*msg;
	// copy Data to memory at write pointer.
	while (MsgList.size() >= m_ulTotalSize)
	{
		msg = MsgList[0];
		free(MsgList[0]->m_pucData);
		MsgList.erase(MsgList.begin());
		delete msg;
		m_bBufferOverWritten = true;
	}

	msg = new MsgStruct;
	msg->m_pucData = (unsigned char *) malloc (uiMsgLen*sizeof(char)+1);

	if (msg->m_pucData == NULL)
	{
		delete msg;
		ReleaseMutex(m_hCriticalSection);
		return(false);
	}

	msg->m_ulLen = uiMsgLen;

	memcpy(msg->m_pucData, pucMsgs, uiMsgLen);

	MsgList.push_back(msg);

	if(MsgList.size() == m_ulTotalSize)
	{
		m_bBufferFull = true;
	}
	else
		m_bBufferFull = false;

	m_bBufferEmpty = false;
	ulGlobalNumMsg += 1;

	ReleaseMutex(m_hCriticalSection);
	return(true);
}

BOOL CCircBuffer::Write(PASSTHRU_MSG *pstPassThruMsg, unsigned long ulNumMsgs)
{

	if(pstPassThruMsg == NULL)
		return(false);
	
	try
	{
		if(WaitForSingleObject(m_hCriticalSection, 
			CIRCBUFFER_CRITICAL_SECTION_TIMEOUT) != WAIT_OBJECT_0)
		{
			return(false);
		}
	}
	catch( ... )
	{
		ReleaseMutex(m_hCriticalSection);
		return false;
	}
	
	
	try
	{
		MsgStruct	*msg;
		
		// copy Data to memory at write pointer.
		while (MsgList.size() >= m_ulTotalSize)
		{
			msg = MsgList[0];
			free(MsgList[0]->m_pucData);
			MsgList.erase(MsgList.begin());
			delete msg;
			m_bBufferOverWritten = true;
		}
		
		for(int nIndex = 0; nIndex < ulNumMsgs;nIndex++)
		{
			
			unsigned long uiMsgLen = 	sizeof(PASSTHRU_MSG) - PASSTHRU_MSG_DATA_SIZE +
				(pstPassThruMsg + nIndex)->ulDataSize;
			unsigned char *pucMsgs = (unsigned char*)(pstPassThruMsg + nIndex);
			MsgStruct *copymsg = new MsgStruct;
			copymsg->m_pucData = (unsigned char *) malloc (uiMsgLen*sizeof(char) + 1);
			
			if (copymsg->m_pucData == NULL)
			{
				delete copymsg;
				ReleaseMutex(m_hCriticalSection);
				return(false);
			}
			
			copymsg->m_ulLen = uiMsgLen;
			
			memcpy(copymsg->m_pucData, pucMsgs, uiMsgLen);
			
			MsgList.push_back(copymsg);
		}
		
		ulGlobalNumMsg += ulNumMsgs;
		
		if(MsgList.size() >= m_ulTotalSize)
		{
			m_bBufferFull = true;
		}
		else
			m_bBufferFull = false;
		
		m_bBufferEmpty = false;		
	}
	catch( ... )
	{
		ReleaseMutex(m_hCriticalSection);
		return false;
	}
	ReleaseMutex(m_hCriticalSection);
	return true;

}

//-----------------------------------------------------------------------------
//	Function Name	: Read()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: Reads from the circular buffer. Each message in the 
//					  buffer is a fixed size. 
//-----------------------------------------------------------------------------
BOOL CCircBuffer::Read(unsigned char *pucMsgs, unsigned long * pulNumMsgs)
{

	try
	{
		if(WaitForSingleObject(m_hCriticalSection, 
			CIRCBUFFER_CRITICAL_SECTION_TIMEOUT) != WAIT_OBJECT_0)
		{
			*pulNumMsgs = 0;
			return(false);
		}
	}
	catch( ... )
	{
		ReleaseMutex(m_hCriticalSection);
		return false;
	}


	unsigned long	ulNumMsgsRead;
	MsgStruct		*msg;

	ulNumMsgsRead = 0;

	if (pucMsgs == NULL)
	{
		*pulNumMsgs = 0;
		ReleaseMutex(m_hCriticalSection);
		return(false);
	}

	try
	{
		
		// Read requested number of msgs. or until the buffer
		// is empty.
		// Read total number of message according to the input value.
		unsigned long msgToRead = ulGlobalNumMsg >= *pulNumMsgs ? *pulNumMsgs : ulGlobalNumMsg;
		while (!m_bBufferEmpty && (ulNumMsgsRead < msgToRead))
		{
			// copy Data to memory at write pointer.
			memcpy(pucMsgs, MsgList[0]->m_pucData, MsgList[0]->m_ulLen);
			
			// Advance the User buffer for next message.
			pucMsgs = pucMsgs + sizeof(PASSTHRU_MSG);
			
			msg = MsgList[0];
			//	free(MsgList[0]->m_pucData);
			MsgList.erase(MsgList.begin());
			
			m_bBufferOverWritten = false;
			
			ulNumMsgsRead++;
			
			if(MsgList.empty())
				m_bBufferEmpty = true;

			//Free msg
			if((msg != NULL) && (msg->m_pucData != NULL))
			{
				free(msg->m_pucData);
				msg->m_pucData = NULL;			
			}

			if(msg != NULL)
			{
				delete msg;
			}

		}	

		*pulNumMsgs = ulNumMsgsRead;
		if(ulNumMsgsRead > 0)
		{
			ulGlobalNumMsg -= ulNumMsgsRead;
		}
		
		m_bBufferFull = false;

	}
	catch( ... )
	{
		ReleaseMutex(m_hCriticalSection);
		return(false);
	}

	ReleaseMutex(m_hCriticalSection);
	return(true);
}
