/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: CircBuffer.h
 Description			: interface for the CCircBuffer class.
 Date					: Jan 30, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version
*******************************************************************************/


#if !defined(AFX_CIRCBUFFER_H__85CD79AD_B40D_4DB3_A5F4_A23DE9B736F6__INCLUDED_)
#define AFX_CIRCBUFFER_H__85CD79AD_B40D_4DB3_A5F4_A23DE9B736F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <vector>
#include "J2534.h"
// Constants
#define CIRCBUFFER_CRITICAL_SECTION_TIMEOUT	5000

class CCircBuffer  
{
public:
	// Constructor
	CCircBuffer(unsigned long ulBufferSize, 
				BOOL *pbError);
	~CCircBuffer();
	/*Operations*/
	BOOL						Write(unsigned char *pucMsgs, 
									unsigned long uiMsgLen);
	BOOL						Write(PASSTHRU_MSG *pstPassThruMsg, 
									  unsigned long ulNumMsgs);
	BOOL						Read(unsigned char *pucMsgs, 
									unsigned long * pulNumMsgs);
	void						ClearBuffer();
	BOOL						GetBufferFullStatus(BOOL* pbBufferFull);
	BOOL						GetBufferEmptyStatus(BOOL* pbBufferEmpty);
	BOOL						GetBufferOverflowStatus(BOOL* pbBufferOverflow);

	/*Variable Declaration*/
	BOOL						m_bBufferFull;
	BOOL						m_bBufferEmpty;
	BOOL						m_bBufferOverWritten;
	unsigned long				ulGlobalNumMsg;

private:
	typedef struct 
	{
		unsigned char	*m_pucData;
		unsigned long	m_ulLen;
	} MsgStruct;

	unsigned long				m_ulTotalSize;
	std::vector<MsgStruct *>	MsgList;
	HANDLE						m_hCriticalSection;
};
#endif // !defined(AFX_CIRCBUFFER_H__85CD79AD_B40D_4DB3_A5F4_A23DE9B736F6__INCLUDED_)
