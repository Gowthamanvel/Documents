/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: DebugLog.cpp
 Description			: implementation of the CDebugLog class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

  File		 Date			Author						Description
  Version
_____________________________________________________________________________
 
  1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
*****************************************************************************/
#include <StdAfx.h>
#include "DebugLog.h"
#include "Time.h"
#include <io.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

//-----------------------------------------------------------------------------
//	Function Name	: CDebugLog()
//	Input Params	: void
//	Output Params	: void
//	Return			: bool
//	Description		: This is a CDebugLog class constructor
//-----------------------------------------------------------------------------
CDebugLog::CDebugLog()
{
	m_hWriteLogSync = NULL;
	m_pfdLogFile = NULL;
	m_ulLoggingType = 0;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CDebugLog()
//	Input Params	: void
//	Output Params	: void
//	Return			: bool
//	Description		: This is a CDebugLog class destructor
//-----------------------------------------------------------------------------
CDebugLog::~CDebugLog()
{
	// If the Log file is open, close it.
	if (m_pfdLogFile != NULL)
	{
		Close();
	}

	// Initialize the Logging Type. (e.g. COMMENT, ERROR, DATA, ...)
	m_ulLoggingType = 0;
}

//-----------------------------------------------------------------------------
//	Function Name	: Write()
//	Input Params	: void
//	Output Params	: void
//	Return			: bool
//	Description		: This is a function that writes arguments to log file
//-----------------------------------------------------------------------------
BOOL CDebugLog::Write(CString csFile, CString csFunc, 
					  unsigned long ulType, CString csDesc)
{
	BOOL	bRet = TRUE;

	// If the File is not open (File Descriptor is NULL).
	if (m_pfdLogFile == NULL)
	{
		return(FALSE);
	}

	if (WaitForSingleObject(m_hWriteLogSync, DEBUGLOG_WRITELOG_TIMEOUT) ==
							WAIT_OBJECT_0)
	{
		ResetEvent(m_hWriteLogSync);

		switch(ulType)
		{
		case DEBUGLOG_TYPE_ERROR:
			if (m_ulLoggingType & DEBUGLOG_TYPE_ERROR)
			{
				fprintf(m_pfdLogFile, "%-20s, %-30s, ERROR, %-80s, %u\n", csFile, csFunc, 
						csDesc, GetTickCount());
				fflush(m_pfdLogFile);
			}
			break;
		case DEBUGLOG_TYPE_COMMENT:
			if (m_ulLoggingType & DEBUGLOG_TYPE_COMMENT)
			{
				fprintf(m_pfdLogFile, "%-20s, %-30s, COMMENT, %-80s, %u\n", csFile, csFunc, 
						csDesc, GetTickCount());
				fflush(m_pfdLogFile);
			}
			break;
		case DEBUGLOG_TYPE_DATA:
			if (m_ulLoggingType & DEBUGLOG_TYPE_DATA)
			{
				fprintf(m_pfdLogFile, "%-20s, %-30s, DATA, %-80s, %u\n", csFile, csFunc, 
						csDesc, GetTickCount());
				fflush(m_pfdLogFile);
			}
			break;
		default:
			bRet = FALSE;
			break;
		}	

		SetEvent(m_hWriteLogSync);
	}
	else
	{
		bRet = FALSE;
		SetEvent(m_hWriteLogSync);
	}

	return(bRet);
}

//-----------------------------------------------------------------------------
//	Function Name	: Open()
//	Input Params	: void
//	Output Params	: void
//	Return			: bool
//	Description		: This is a function that opens a given log file
//-----------------------------------------------------------------------------
BOOL CDebugLog::Open(CString csLogFileName, unsigned long ulLogType)
{
	FILE * fstream = NULL;

	// If Log File already open.
	if (m_pfdLogFile != NULL)
	{
		return(TRUE);
	}
		
	// Open the file.
	if (ulLogType & DEBUGLOG_TYPE_APPEND)
	{
		fstream = fopen(csLogFileName, "a");
	}
	else
	{
		fstream = fopen(csLogFileName, "w");
	}

	if (fstream == NULL)
	{
		return(FALSE);
	}

	//Get Current Time
	CTime curTime = CTime::GetCurrentTime();
	CString csMeridian = "", csTime = "";
	unsigned int iHr  = curTime.GetHour();
	unsigned int iMin = curTime.GetMinute();
	unsigned int iSec = curTime.GetSecond();
	if(iHr < 12)
	{		
		csMeridian = "AM";		
	}
	else	
	{		
		if(iHr >=13)
			iHr %= 12;

		csMeridian = "PM";
	}
	
	csTime.Format("%2d:%02d:%02d ", iHr, iMin, iSec);
	csTime += csMeridian;		

	//Print Headers
	if(fstream != NULL)
	{
		fprintf(fstream,"Opening Log File. Current time is %s",csTime);			
		CFile stFile;
		CString cszFile;
		CFileStatus status;
		unsigned char *ucBuffer;
		LPVOID *pBuffer;
		unsigned int uiSize;
		unsigned char ucDllVersion[100];
		time_t t;
		char tempstr[1024];
		DWORD dwBufferSize;
		GetSystemDirectory(tempstr, 1024);
		strcat(tempstr, "\\Garuda40432.dll");
		stFile.GetStatus(tempstr, status);
		dwBufferSize = GetFileVersionInfoSize("Garuda40432.dll", 0);
		ucBuffer=(unsigned char *)malloc((dwBufferSize+1)*sizeof(char));

		/*Get the file version from the resource*/
		GetFileVersionInfo(
			"Garuda40432.dll",	// pointer to filename string
			0,						// ignored
			dwBufferSize,				// size of buffer
			(LPVOID)ucBuffer			// pointer to buffer to receive file-version info.
		);

		// Query Version Number
		VerQueryValue((LPVOID) ucBuffer, 
			TEXT("\\StringFileInfo\\040904B0\\ProductVersion"), 
			(void**)&pBuffer, &uiSize);

		// Getting ucDllVersion
		strncpy((char*)ucDllVersion, (LPCTSTR) pBuffer, uiSize);
		fprintf(fstream,"\n%s Version %s", tempstr, ucDllVersion);
		fprintf(fstream,"\n%s File Size %ld bytes", tempstr, status.m_size);
		t = status.m_mtime.GetTime();
		fprintf(fstream,"\n%s Time modified : %s", tempstr, ctime(&t));
		free(ucBuffer);
		fprintf(fstream,"\n================================================");
		fprintf(fstream,"==================================================\n");
		fflush(m_pfdLogFile);
	}

	// Create Event for synchronization.
	if ((m_hWriteLogSync = CreateEvent(NULL, TRUE, TRUE, NULL)) == NULL)
	{
		// Close file.
		fclose(fstream);
		fstream = NULL;
		return(FALSE);
	}

	// Save the Logging type requested so that Write() will only log those
	// type.
	m_ulLoggingType = ulLogType;
	m_pfdLogFile = fstream;
	return(TRUE);
}

//-----------------------------------------------------------------------------
//	Function Name	: Close()
//	Input Params	: void
//	Output Params	: void
//	Return			: bool
//	Description		: This is a function that closes the given log file
//-----------------------------------------------------------------------------
BOOL CDebugLog::Close()
{
	BOOL	bRet = TRUE;

	if (WaitForSingleObject(m_hWriteLogSync, DEBUGLOG_WRITELOG_TIMEOUT) ==
							WAIT_OBJECT_0)
	{
		ResetEvent(m_hWriteLogSync);

		if (m_pfdLogFile != NULL)
		{		
			fprintf(m_pfdLogFile,"\n================================================");	
			fprintf(m_pfdLogFile,"==================================================\n");
			
			//Get Current Time
			CTime curTime = CTime::GetCurrentTime();
			
			CString csMeridian = "", csTime = "";
			unsigned int iHr = curTime.GetHour();
			unsigned int iMin = curTime.GetMinute();
			unsigned int iSec = curTime.GetSecond();
			
			if(iHr < 12)
			{		
				csMeridian = "AM";		
			}
			else	
			{		
				if(iHr >=13)
					iHr %= 12;

				csMeridian = "PM";
			}
			
			csTime.Format("%2d:%02d:%02d ", iHr, iMin, iSec);
			csTime += csMeridian;		

			fprintf(m_pfdLogFile,"Closing Log File. Current time is %s",csTime);
			
			if (!fclose(m_pfdLogFile))
			{
				m_pfdLogFile = NULL;
				m_ulLoggingType = 0;
			}
			else
			{
				bRet = FALSE;
			}
		}

		SetEvent(m_hWriteLogSync);
	}
	else
	{
		SetEvent(m_hWriteLogSync);
		ResetEvent(m_hWriteLogSync);
		if (!fclose(m_pfdLogFile))
		{
			m_pfdLogFile = NULL;
			m_ulLoggingType = 0;
		}
		else
		{
			bRet = FALSE;
		}
		SetEvent(m_hWriteLogSync);
	}
	if (bRet)
	{
		// Close the handle for synchronization.
		if (!CloseHandle(m_hWriteLogSync))
			bRet = FALSE;
		else
			m_hWriteLogSync = NULL;
	}

	return(bRet);
}

BOOL CDebugLog::Write(CString csFile, CString csFunc,J2534_PROTOCOL eProtocol, 
					  unsigned long ulType, CString csDesc)
{
	BOOL	bRet = TRUE;
	CString csProtocol;
	if(ISO15765 == eProtocol)
	{
		csProtocol = "DW-ISO15765";
	}
	else if(SW_ISO15765_PS == eProtocol)
	{
		csProtocol = "SW_ISO15765";
	}
	else
	{
		//do nothing
	}
	// If the File is not open (File Descriptor is NULL).
	if (m_pfdLogFile == NULL)
	{
		return(FALSE);
	}

	if (WaitForSingleObject(m_hWriteLogSync, DEBUGLOG_WRITELOG_TIMEOUT) ==
							WAIT_OBJECT_0)
	{
		ResetEvent(m_hWriteLogSync);

		fprintf(m_pfdLogFile, "%-20s, %-30s, %-30s, ERROR, %-80s, %u\n", csFile, csFunc, 
						csProtocol, csDesc, GetTickCount());
				fflush(m_pfdLogFile);

		/*switch(ulType)
		{
		case DEBUGLOG_TYPE_ERROR:
			if (m_ulLoggingType & DEBUGLOG_TYPE_ERROR)
			{
				fprintf(m_pfdLogFile, "%-20s, %-30s, %-30s, ERROR, %-80s, %u\n", csFile, csFunc, 
						csProtocol, csDesc, GetTickCount());
				fflush(m_pfdLogFile);
			}
			break;
		case DEBUGLOG_TYPE_COMMENT:
			if (m_ulLoggingType & DEBUGLOG_TYPE_COMMENT)
			{
				fprintf(m_pfdLogFile, "%-20s, %-30s, %-30s, COMMENT, %-80s, %u\n", csFile, csFunc, 
						csProtocol, csDesc, GetTickCount());
				fflush(m_pfdLogFile);
			}
			break;
		case DEBUGLOG_TYPE_DATA:
			if (m_ulLoggingType & DEBUGLOG_TYPE_DATA)
			{
				fprintf(m_pfdLogFile, "%-20s, %-30s, %-30s, DATA, %-80s, %u\n", csFile, csFunc, 
						csProtocol, csDesc, GetTickCount());
				fflush(m_pfdLogFile);
			}
			break;
		default:
			bRet = FALSE;
			break;
		}	*/

		SetEvent(m_hWriteLogSync);
	}
	else
	{
		bRet = FALSE;
		SetEvent(m_hWriteLogSync);
	}

	return(bRet);
}


