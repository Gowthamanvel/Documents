
#include "J2534.h"
#include "DebugLog.h"
#include "..\DeviceOEMTool\StnDevice.h"

#if !defined(AFX_PERIODICMSG_H__2C0FECAD_E74F_4EC9_B774_3C95B55299ED__INCLUDED_)
#define AFX_PERIODICMSG_H__2C0FECAD_E74F_4EC9_B774_3C95B55299ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define PERIODICMSG_ERROR_TEXT_SIZE		80
#define PERIODICMSG_LIST_SIZE			10
#define PERIODICMSG_MSGLEN_MAX			12		

#define PERIODICMSG_SYNC_TIMEOUT		5000
/*Jayasheela -removed ulDevPeriodicID member variable from this structure */
typedef struct
{
	PASSTHRU_MSG	*pstMsg;
	unsigned long	ulTimeInterval;
}
PERIODICMSGLIST;

// CPeriodicMsg Class
class CPeriodicMsg 
{
public:
	// Constructor
	CPeriodicMsg(CDeviceBase *pclsDevice, unsigned long	ulDevChannelID,
			   CDebugLog * pclsDebugLog = NULL);
	~CPeriodicMsg();

	J2534ERROR			StartPeriodic(
							PASSTHRU_MSG	*pstMsg, 
							unsigned long	*pulPeriodicID,
							unsigned long	ulTimeInterval);
	J2534ERROR			UpdatePeriodic(
							PASSTHRU_MSG	*pstMsg, 
							unsigned long	pulPeriodicID,
							unsigned long	ulTimeInterval);
	J2534ERROR			StopPeriodic(
							unsigned long	ulPeriodicID);
	J2534ERROR			StopPeriodic();

	void				GetLastErrorText(
							char *pszBuffer, 
							unsigned long ulSizeOfBuffer);

	PERIODICMSGLIST		m_stPeriodicList[PERIODICMSG_LIST_SIZE+1];

private:

	HANDLE				m_hSyncAccess;
	CDebugLog			*m_pclsLog;
	CDeviceBase			*m_pclsDevice;
	unsigned long		m_ulDevChannelID;
	char				m_szLastErrorText[PERIODICMSG_ERROR_TEXT_SIZE];

	J2534ERROR			Add(PASSTHRU_MSG *pstMsg, 
							unsigned long ulTimeInterval,
							unsigned long *pulPeriodicID);
	J2534ERROR			Delete(unsigned long ulPeriodicID);
	bool				IsPeriodicIDValid(unsigned long ulPeriodicID);
	bool				IsListFull();
	unsigned char		GetNewPeriodicID();
	void				SetLastErrorText(char *pszErrorText);
};

#endif
