/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J1850PWM.h
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support J1850VPW 
						  protocol as required by J2534.
 Date					: Feb 08, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 08, 2008	Chakravarthy				Initial Version
*******************************************************************************/


#if !defined(AFX_J1850PWM_H__B1FF588D_6A0B_4F01_859D_236E924B30C4__INCLUDED_)
#define AFX_J1850PWM_H__B1FF588D_6A0B_4F01_859D_236E924B30C4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "J2534.h"
#include "ProtocolBase.h"
#include "CircBuffer.h"

typedef struct
{
	unsigned char ucFuncID;
	bool		bValid;
}
J1850PWM_LOOKUP_TABLE;

/*Receive function*/
void OnJ1850PWMRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid);

class CJ1850PWM : public CProtocolBase  
{
public:
	CJ1850PWM(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CJ1850PWM();
	
	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);
	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);
	

	J2534ERROR				MessageValid(PASSTHRU_MSG	   *pstrucJ2534Msg,
										unsigned long  *pulNumMsgs);
	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				ClearTable();
	J2534ERROR				AddToTable(SBYTE_ARRAY *pInput);
	J2534ERROR				DeleteFromTable(SBYTE_ARRAY *pInput);
	J2534ERROR				vSetProgrammingVoltage(unsigned long ulPin,
												   unsigned long ulVoltage);

private:
	
	/*Variable declaration*/
	bool					IsMsgValid(PASSTHRU_MSG *pstPassThruMsg);
	PASSTHRU_MSG			structj1850;
	J2534_PROTOCOL			m_enJ1850Protocol;
	unsigned char			m_ucNodeAddress;
	unsigned long			m_ulNetworkLine;
	J1850PWM_LOOKUP_TABLE	m_FunctionTable[J1850PWM_LIMIT];
};

#endif // !defined(AFX_J1850PWM_H__B1FF588D_6A0B_4F01_859D_236E924B30C4__INCLUDED_)
