/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ProtocolManager.cpp
 Description			: implementation of the CProtocolManager class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version


_______________________________________________________________________________
******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "ProtocolManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProtocolManager::CProtocolManager(CDebugLog * pclsDebugLog)
{
	int nProtObjs;
	
	// Save Log Class pointer.
	m_pclsLog = pclsDebugLog;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "CProtocolManager()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	//Initialize all the class pointers to NULL. Remember the index is 1 
	//based so the 0th index is not used but I am going to initialize
	//that as well.

	for (nProtObjs = 0; nProtObjs < PROTOCOLMANAGER_OBJ_LIST_SIZE; nProtObjs++)
	{
		m_pclsProtocolObject[nProtObjs] = NULL;
		m_enProtocolConnectionList[nProtObjs] = (J2534_PROTOCOL)0;
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "CProtocolManager()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
}

CProtocolManager::~CProtocolManager()
{
	int nProtIndex;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "~CProtocolManager()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; nProtIndex++)
	{
		if (IsChannelIDValid(nProtIndex))
		{
			DeleteProtocolObj(nProtIndex);
		}
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "~CProtocolManager()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
	
}
/*-----------------------------------------------------------------------------
	Function Name	: IsProtocolConnected()
	Input Params	: void
	Output Params	: void
	Return			: None
	Description		: This function checks to see if certain protocol is 
					  connected to avoid certain improper simutaneous 
					  communication.
-----------------------------------------------------------------------------*/
BOOL CProtocolManager::IsProtocolConnected(J2534_PROTOCOL	enumProtocolID)
{
	int nProtIndex;
	switch (enumProtocolID)
	{
		case J1850VPW :
		case J1850PWM :
			for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; 
				 nProtIndex++)
			{
				if ((m_enProtocolConnectionList[nProtIndex] == J1850VPW) ||
					(m_enProtocolConnectionList[nProtIndex] == J1850PWM))
					return TRUE;
			}
			break;
		case ISO9141 :
		case ISO14230 :
			for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; 
				 nProtIndex++)
			{
				if ((m_enProtocolConnectionList[nProtIndex] == SCI_A_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_A_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO9141) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO14230)) 
					return TRUE;
			}
			break;
		case CAN :
		case ISO15765 :
		case SW_ISO15765_PS:
		case SW_CAN_PS:
		case J1939_PS:
		case J1939_CH1:

			for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; 
				 nProtIndex++)
			{
				if ((m_enProtocolConnectionList[nProtIndex] == SCI_A_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_A_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == CAN) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO15765) ||
					(m_enProtocolConnectionList[nProtIndex] == SW_ISO15765_PS) ||
					(m_enProtocolConnectionList[nProtIndex] == SW_CAN_PS) ||
					(m_enProtocolConnectionList[nProtIndex] == J1939_PS) ||
					(m_enProtocolConnectionList[nProtIndex] == J1939_CH1)) 
					return TRUE;
			}
			break;
		case ISO15765_CH1 :
		case CAN_CH1 :
		case J1939_CH2:
			for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; 
				 nProtIndex++)
			{
				if ((m_enProtocolConnectionList[nProtIndex] == SCI_A_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_A_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == CAN_CH1 ) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO15765_CH1) ||
					(m_enProtocolConnectionList[nProtIndex] == SW_ISO15765_PS) ||
					(m_enProtocolConnectionList[nProtIndex] == SW_CAN_PS) ||
					(m_enProtocolConnectionList[nProtIndex] == J1939_CH2)) 
					return TRUE;
			}
			break;
		case SCI_A_ENGINE :
		case SCI_A_TRANS :
		case SCI_B_ENGINE :
		case SCI_B_TRANS :
			for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; 
				 nProtIndex++)
			{
				if ((m_enProtocolConnectionList[nProtIndex] == SCI_A_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_A_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_ENGINE) ||
					(m_enProtocolConnectionList[nProtIndex] == SCI_B_TRANS) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO9141) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO14230) ||
					(m_enProtocolConnectionList[nProtIndex] == CAN) ||
					(m_enProtocolConnectionList[nProtIndex] == ISO15765) ||
					(m_enProtocolConnectionList[nProtIndex] == SW_ISO15765_PS) ||
					(m_enProtocolConnectionList[nProtIndex] == SW_CAN_PS)) 
					return TRUE;
			}
			break;

		case CCD:
			for (nProtIndex = 0; nProtIndex < PROTOCOLMANAGER_OBJ_LIST_SIZE; 
					nProtIndex++)
			{
				if(m_enProtocolConnectionList[nProtIndex] == CCD) 
					return TRUE;
			}
			break;

		default:
			break;
	}
	return FALSE;
}

/*-----------------------------------------------------------------------------
	Function Name	: CreateProtocolObject()
	Input Params	: void
	Output Params	: void
	Return			: None
	Description		: This function creates a Protocol specific object and 
					  stores its address in a list.
-----------------------------------------------------------------------------*/

J2534ERROR CProtocolManager::CreateProtocolObject(
												J2534_PROTOCOL	enumProtocolID,
												CDeviceBase		*pclsDevice,
												unsigned long	*pulChannelID)
{
	CProtocolBase	*pTemp = NULL;
	unsigned long	ulNewChannelID = 0;
	char			szBuffer[PROTOCOLMANAGER_ERROR_TEXT_SIZE];
	int				i;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "CreateProtocolObject()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	if (enumProtocolID != 0)
	{
		for (i = 0; i < PROTOCOLMANAGER_OBJ_LIST_SIZE; i++)
		{
			if (m_enProtocolConnectionList[i] == enumProtocolID)
				return (J2534_ERR_CHANNEL_IN_USE);
		}
		
		if (IsProtocolConnected(enumProtocolID))
			return (J2534_ERR_INVALID_PROTOCOL_ID);
	}

	switch (enumProtocolID)
	{
	case J1850VPW :
		pTemp = new CJ1850VPW(pclsDevice, m_pclsLog);
		break;
	case ISO9141 :
		pTemp = new CISO9141(pclsDevice, m_pclsLog);
		break;
	case ISO15765 :
	case ISO15765_CH1:
		pTemp = new CISO15765(pclsDevice, m_pclsLog);
		break;
	case CAN :
	case CAN_CH1:
		pTemp = new CCAN(pclsDevice, m_pclsLog);
		break;
	case J1939_PS:
	case J1939_CH1:
	case J1939_CH2:
		pTemp = new CJ1939(pclsDevice, m_pclsLog);
		break;
	case SW_CAN_PS :
		pTemp = new CSWCAN(pclsDevice, m_pclsLog);
		break;
	case SW_ISO15765_PS :
		pTemp = new CISO15765(pclsDevice, m_pclsLog);
		break;
	case ISO14230 :
		pTemp = new CISO14230(pclsDevice, m_pclsLog);
		break;
	case J1850PWM :
		pTemp = new CJ1850PWM(pclsDevice, m_pclsLog);
		break;
	case SCI_A_ENGINE :
	case SCI_A_TRANS :
	case SCI_B_ENGINE :
	case SCI_B_TRANS :
		pTemp = new CSCI(pclsDevice, m_pclsLog);
		break;
	case CCD :
		pTemp = new CCCD(pclsDevice, m_pclsLog);
		break;
	default:
		// Log when exited the function.
		if (m_pclsLog && m_pclsLog->m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_PROTOCOL_ID);
			m_pclsLog->Write("ProtocolManager.cpp", "CreateProtocolObject()", 
				DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_PROTOCOL_ID);
		break;
	}

	// Check if the Protocol Object was created successfully.
	if (pTemp == NULL)
	{
		// Log the error.
		if (m_pclsLog && m_pclsLog->m_pfdLogFile)
		{
			m_pclsLog->Write("ProtocolManager.cpp", "CreateProtocolObject()", 
							 DEBUGLOG_TYPE_ERROR, 
							 "Cannot create Protocol Object");
		}
		return(J2534_ERR_FAILED);
	}

	// Create new Channel to store the Protocol Object.
	if ((ulNewChannelID = GetNewChannelID()) == 0)
	{
		delete pTemp;

		// Log when exited the function.
		if (m_pclsLog && m_pclsLog->m_pfdLogFile)
		{
			m_pclsLog->Write("ProtocolManager.cpp", "CreateProtocolObject()", 
							 DEBUGLOG_TYPE_ERROR, 
							 "Cannot create new channel");
		}
		return(J2534_ERR_FAILED);
	}

	// Save the object address in the list.
	m_pclsProtocolObject[ulNewChannelID] = pTemp;

	// Assign new channnel ID for reference to this protocol.
	*pulChannelID = ulNewChannelID;

	m_enProtocolConnectionList[ulNewChannelID] = enumProtocolID;
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolManager.cpp", "CreateProtocolObject()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: DeleteProtocolObj()
//	Input Params	: void
//	Output Params	: void
//	Return			: None
//	Description		: This function deletes a Protocol specific 
//					  object and removes its address from the list.
//-----------------------------------------------------------------------------
J2534ERROR CProtocolManager::DeleteProtocolObj(unsigned long ulChannelID)
{
	char	szBuffer[PROTOCOLMANAGER_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "DeleteProtocolObj(ChID)", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check if the Channel ID is valid.
	if (!IsChannelIDValid(ulChannelID))
	{
		// Write to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_CHANNEL_ID);
			m_pclsLog->Write("ProtocolManager.cpp", "DeleteProtocolObj(ChID)", 
							 DEBUGLOG_TYPE_COMMENT, szBuffer);
		}
		return(J2534_ERR_INVALID_CHANNEL_ID);
	}

	// Delete the Protocol Object for this ChannelID.	
	if (m_pclsProtocolObject[ulChannelID] != NULL)
	{
		delete m_pclsProtocolObject[ulChannelID];	
		m_pclsProtocolObject[ulChannelID] = NULL;
		m_enProtocolConnectionList[ulChannelID] = (J2534_PROTOCOL)0;
	}

	// Mark this channel as unused.
	UngetChannelID(ulChannelID);

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ProtocolManager.cpp", "DeleteProtocolObj(ChID)", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: DeleteProtocolObj()
//	Input Params	: void
//	Output Params	: void
//	Return			: None
//	Description		: This function deletes a all active Protocol  
//					  objects and removes its address from the list.
//-----------------------------------------------------------------------------
void CProtocolManager::DeleteProtocolObj()
{
	int		nProtSize;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "DeleteProtocolObj()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	for (nProtSize = 0; nProtSize < PROTOCOLMANAGER_OBJ_LIST_SIZE; nProtSize++)
	{
		// Delete each Protocol Object.	
		if (m_pclsProtocolObject[nProtSize] != NULL)
		{
			delete m_pclsProtocolObject[nProtSize];	
			m_pclsProtocolObject[nProtSize] = NULL;
			m_enProtocolConnectionList[nProtSize] = (J2534_PROTOCOL)0;
		}
		// Mark this channel as unused.
		UngetChannelID(nProtSize);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ProtocolManager.cpp", "DeleteProtocolObj()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}

	return;
}
//-----------------------------------------------------------------------------
//	Function Name	: GetNewChannelID()
//	Input Params	: void
//	Output Params	: void
//	Return			: None
//	Description		: This function searches through the list and returns the
//					  first unused ChannelID if successful else returns 0.
//-----------------------------------------------------------------------------
unsigned long CProtocolManager::GetNewChannelID()
{
	unsigned int nProtSize;

	for (nProtSize = PROTOCOLMANAGER_OBJ_LIST_START_IDX; 
		 nProtSize < PROTOCOLMANAGER_OBJ_LIST_SIZE; nProtSize++)
	{
		if (m_pclsProtocolObject[nProtSize] == NULL)
			return(nProtSize);
	}

	return(0);
}

//-----------------------------------------------------------------------------
//	Function Name	: UngetChannelID()
//	Input Params	: void
//	Output Params	: void
//	Return			: None
//	Description		: This function marks the channelID as not in use.
//-----------------------------------------------------------------------------
void CProtocolManager::UngetChannelID(unsigned long ulChannelID)
{
	if ((ulChannelID > 0) && (ulChannelID < PROTOCOLMANAGER_OBJ_LIST_SIZE))
		m_pclsProtocolObject[ulChannelID] = NULL;
}

//-----------------------------------------------------------------------------
//	Function Name	: IsChannelIDValid()
//	Input Params	: void
//	Output Params	: void
//	Return			: None
//	Description		: This function checks to see if the channel ID is valid.
//-----------------------------------------------------------------------------
BOOL CProtocolManager::IsChannelIDValid(unsigned long ulChannelID)
{
	if ((ulChannelID > 0) && (ulChannelID < PROTOCOLMANAGER_OBJ_LIST_SIZE))
	{
		if (m_pclsProtocolObject[ulChannelID] != NULL)
		{
			return(TRUE);
		}
	}

	return(FALSE);
}
