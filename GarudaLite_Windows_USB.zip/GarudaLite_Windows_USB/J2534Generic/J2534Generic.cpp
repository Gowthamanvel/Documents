/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J2534Generic.cpp
 Description			: Defines the initialization routines for the DLL
 Date					: Jan 29, 2008
 Version				: 1.0
 Author				: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 29, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "DebugLog.h"

/*Global Variable Declaration*/
CDebugLog gclsLog; 

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CJ2534GenericApp

BEGIN_MESSAGE_MAP(CJ2534GenericApp, CWinApp)
	//{{AFX_MSG_MAP(CJ2534GenericApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJ2534GenericApp construction

CJ2534GenericApp::CJ2534GenericApp()
{
	//Log file name variable
	CString			cszLogFile = "";

	// Initialize the Registry read flag.
	m_bRegistryRead = FALSE;
	
	//Create the reg class pointer
	CJ2534Registry	*pclsJ2534Registry;

	//Create the registry class to find the device id.
	if ((pclsJ2534Registry = new CJ2534Registry) == NULL)
	{
		return;
	}

	/*Access the device information stored in the registry*/
	// Set the Device Type to read the J2534 registry for OEM TOOL Device.
	m_J2534Registry.enJ2534RegistryDeviceType = J2534REGISTRY_DEVICE_INNOVA_OEMTOOL;
	
	// Read J25434 registry for OEM TOOL device.
	if (pclsJ2534Registry->GetRegistry(&m_J2534Registry) == J2534REGISTRY_ERR_SUCCESS) 
	{
		// Set the Log filename to log traces for OEM TOOL J2534.
		char buffer[5000];
		GetWindowsDirectory(buffer ,5000);
		//strcpy(buffer, m_J2534Registry.chLoggingDirectory);
		CString strLogFilepath = (LPCSTR)buffer;
		cszLogFile = strLogFilepath + "\\OEMTool.csv";
		m_bRegistryRead = true;
	}
	
	// Delete the Registry Object as it is not needed anymore.
	if (pclsJ2534Registry != NULL)
	{
		delete pclsJ2534Registry;
	}
	
	// If Registry is read successfully.
	if (m_bRegistryRead) 
	{
		// Open the Log file if Logging is set to ON in the Registry.
		if ((cszLogFile != "") && (m_J2534Registry.dwLogging != 0))
		{
			gclsLog.Open(cszLogFile, m_J2534Registry.dwLogging);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CJ2534GenericApp object
CJ2534GenericApp::~CJ2534GenericApp()
{
	// If the Log File is open then Close it.
	if (gclsLog.m_pfdLogFile != NULL)
	{
		// Close the Log file.
		gclsLog.Close();
	}
}

CJ2534GenericApp theApp;
