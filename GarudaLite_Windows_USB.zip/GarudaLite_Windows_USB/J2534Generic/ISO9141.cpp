/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ISO9141.cpp
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support ISO9141 
						  protocol as required by J2534.
 Date					: Feb 20, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 20, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "ISO9141.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//-----------------------------------------------------------------------------
//	Function Name	: CISO9141
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CISO9141 class
//-----------------------------------------------------------------------------
CISO9141::CISO9141(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
			CProtocolBase(pclsDevice, pclsDebugLog)
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "CISO9141()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Initialize.
	m_bConnected = false;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "CISO9141()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	m_bLoopback = false;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CISO9141
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CISO9141 class
//-----------------------------------------------------------------------------
CISO9141::~CISO9141()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "~CISO9141()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "~CISO9141()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO9141::vConnect(J2534_PROTOCOL	enProtocolID,
							  unsigned long   ulFlags,
							  unsigned long	ulBaudRate,
							  DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
							  DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
						      DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
							  LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error = J2534_ERR_NOT_SUPPORTED;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	/*Get the Check Sum Flag from the connection flags*/
//	m_ulChecksumFlag = ((ulFlags >> 9) & 0x01);
//	ulFlags = (((ulFlags >> 12) & 0x01) << 1);
//	ulFlags |= m_ulChecksumFlag;

	
	if ((ulBaudRate != 4800) && 
		(ulBaudRate != 9600) &&
		(ulBaudRate != 9615) && 
		(ulBaudRate != 9800) &&
		(ulBaudRate != 10000) && 
		(ulBaudRate != ISO9141_DATA_RATE_DEFAULT) &&
		(ulBaudRate != 10416) &&
		(ulBaudRate != 10870) && 
		(ulBaudRate != 11905) &&
		(ulBaudRate != 12500) && 
		(ulBaudRate != 13158) &&
		(ulBaudRate != 13889) && 
		(ulBaudRate != 14706) &&
		(ulBaudRate != 15625) && 
		(ulBaudRate != 19200))
	{
		return(J2534_ERR_INVALID_BAUDRATE);
	}
	
	// Call Connect of Base.
	//In initial Implementation, ISO14230 & ISO9141 both are same for Firmware for processing
	//To address the tata motors, P1 Max Timeout Issue, reverted ISO14230 to enProtocolID
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID /*ISO14230*/,
												ulFlags, 
												ulBaudRate,
												OnISO9141RxMessage, 
												NULL,NULL,
												this)) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(enJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO9141::vDisconnect()
{
	char			szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "CISO9141()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CISO9141::vReadMsgs(PASSTHRU_MSG		*pstPassThruMsg,
							   unsigned long	*pulNumMsgs,
							   unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CISO9141::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
								unsigned long	*pulNumMsgs,
								unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != ISO9141)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ISO9141.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		// Check if msg. format is valid.
		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ISO9141.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO9141::vStartPeriodicMsg(PASSTHRU_MSG		*pstPassThruMsg,
									   unsigned long	*pulMsgID,
									   unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != ISO9141)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO9141.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO9141.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CISO9141::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CISO9141::vStartMsgFilter(J2534_FILTER 	enumFilterType,
									  PASSTHRU_MSG	*pstMask,
									  PASSTHRU_MSG	*pstPattern,
									  PASSTHRU_MSG	*pstFlowControl,
									  unsigned long	*pulFilterID)
{
	char		szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// NOTE : If request is for PASS filter, try setting this filter in device 
	//		  as well. If the device cannot set and returns an 
	//		  error, ignore it. Some device drivers may not be able to set 
	//		  hardware filters. Anyway it will be filtered by our software
	//		  filter.  

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != ISO9141) ||
		(pstPattern->ulProtocolID != ISO9141))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO9141.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check Filter Type.
	if (enumFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO9141.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_FILTER_ID);
	}
	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CISO9141::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[ISO9141_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO9141.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO9141.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function. This function is used to read
//					  and write all the protocol hardware and software
//					  configuration parameters for a given enumIoctlID.
//-----------------------------------------------------------------------------
J2534ERROR  CISO9141::vIoctl(J2534IOCTLID enumIoctlID,
								 void *pInput,
								 void *pOutput)
{
	J2534ERROR	enumJ2534Error;
	char	szBuffer[ISO9141_ERROR_TEXT_SIZE];	
		
	enumJ2534Error = J2534_STATUS_NOERROR;

	// IoctlID values
	switch(enumIoctlID)
	{
		case GET_CONFIG:			// Get configuration

			enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);

			break;

		case SET_CONFIG:			// Set configuration

			enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);
			break;

		case FIVE_BAUD_INIT:		// CARB (5-baud) initialization

			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														pInput,
														pOutput))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;

		case FAST_INIT:				// Fast initialization

			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														pInput,
														pOutput))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}

			break;

		case CLEAR_TX_BUFFER:		// Clear all messages in its transmit queue
			if(m_pclsTxCircBuffer != NULL)
			{
				m_pclsTxCircBuffer->ClearBuffer();
				if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER,
														   NULL,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
			}
			break;

		case CLEAR_RX_BUFFER:		// Clear all messages in its receive queue
			if(m_pclsRxCircBuffer != NULL)
			{
				m_pclsRxCircBuffer->ClearBuffer();
				if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER,
														   NULL,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
			}
			break;

		case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
			if (m_pclsPeriodicMsg != NULL)
			{
				delete m_pclsPeriodicMsg;
				m_pclsPeriodicMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
		case CLEAR_MSG_FILTERS:		// Clear all message filters
			if (m_pclsFilterMsg != NULL)
			{
				delete m_pclsFilterMsg;
				m_pclsFilterMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;

		default:					// Others not supported

			enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
			break;
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
		if (enumJ2534Error != J2534_STATUS_NOERROR)
			m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		else
			m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
							 szBuffer);
	}
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			"End");
	}	

	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: OnISO9141Rx
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  ISO9141 messages.
//-----------------------------------------------------------------------------
void OnISO9141RxMessage(PASSTHRU_MSG *pstPassThruMsg, 
						LPVOID pVoid)
{
	CISO9141					*pclsISO9141;
	FILTERMSG_CONFORM_REQ	stConformReq;

	pstPassThruMsg->ulProtocolID=(unsigned long)ISO9141;
	pclsISO9141 = (CISO9141 *) pVoid;

	// Check for NULL pointer.
	if (pclsISO9141 == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CISO9141.cpp", "OnISO9141Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}

	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("CISO9141.cpp", "OnISO9141Rx()", 
						 DEBUGLOG_TYPE_COMMENT, "Rx Message CallBack");
	}

	// Check if this is a Rx First Byte message.
	if (pstPassThruMsg->ulRxStatus & 0x02)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CISO9141.cpp", "OnISO9141Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "Rx First Byte CALLBACK");
		}

		// Enqueue to Circ Buffer.
		pclsISO9141->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}
	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CISO9141.cpp", "OnISO9141Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}
		if (pclsISO9141->m_bLoopback == false)
			return;
		// Enqueue to Circ Buffer.
		pclsISO9141->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}

	// Apply Filters and see if msg. is required.
	if (pclsISO9141->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsISO9141->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			// Enqueue to Circ Buffer.
			pclsISO9141->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}
	return;
}

//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CISO9141::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg)
{
	if ((pstPassThruMsg->ulDataSize < ISO9141_MSG_SIZE_MIN) || 
		(pstPassThruMsg->ulDataSize > ISO9141_MSG_SIZE_MAX))
	{
		return(false);
	}

	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CISO9141::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[ISO9141_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;
	
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														  pSconfig,
														  NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
		
			case LOOPBACK:			// Loopback
				pSconfig->ulValue = m_bLoopback;
				break;

			case P1_MAX:			// P1_MAX
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "P1_MAX", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P3_MIN:			// P3_MIN

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "P3_MIN", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P4_MIN:			// P4_MIN

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "P4_MIN", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			/*Jayasheela-added case to handle W0 parameter */
			case W0:							//W0
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "W0", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case W1:				// W1

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "W1", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W2:				// W2
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "W2", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W3:				// W3
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "W3", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W4:				// W4
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "W4", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
				/*removed W5 parameter */

			case TIDLE:

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "TIDLE", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TINIL:

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "TINIL", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TWUP:

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "TWUP", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case PARITY:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "PARITY", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case DATA_BITS:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "DATA_BITS", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case FIVE_BAUD_MOD:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "FIVE_BAUD_MOD", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}

	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------

J2534ERROR  CISO9141::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char			szBuffer[ISO9141_ERROR_TEXT_SIZE];	

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;

	for (ulCount=0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate

				if ((pSconfig->ulValue < 5) || (pSconfig->ulValue > 500000))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if ((pSconfig->ulValue == 4800)  ||  (pSconfig->ulValue == 9600)  || 
					(pSconfig->ulValue == 9615)  ||  (pSconfig->ulValue == 9800)  ||  
					(pSconfig->ulValue == 10000) ||  (pSconfig->ulValue == 10400) ||
					(pSconfig->ulValue == 10416) ||  (pSconfig->ulValue == 10870) || 
					(pSconfig->ulValue == 11905) ||  (pSconfig->ulValue == 12500) ||  
					(pSconfig->ulValue == 13158) || (pSconfig->ulValue == 13889)  || 
					(pSconfig->ulValue == 14706) ||  (pSconfig->ulValue == 15625) || 
					(pSconfig->ulValue == 19200))
				{
					
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
				}
				else
					return J2534_ERR_INVALID_BAUDRATE;

				break;
			case LOOPBACK:			// Loopback

				if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				m_bLoopback = pSconfig->ulValue;
				break;
			case P1_MAX:			// P1_MAX
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P3_MIN:			// P3_MIN
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P4_MIN:			// P4_MIN
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			/*Jayasheela-Added to handle W0 parameter */
			case W0:				// W0
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case W1:				// W1
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W2:				// W2
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W3:				// W3
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W4:				// W4
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TIDLE:
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TINIL:
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TWUP:
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case PARITY:
				
				if ((pSconfig->ulValue < ISO9141_NO_PARITY) || 
					(pSconfig->ulValue > ISO9141_EVEN_PARITY))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
	
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case DATA_BITS:
				if ((pSconfig->ulValue < ISO9141_8_DATABITS) || 
					(pSconfig->ulValue > ISO9141_7_DATABITS))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			
			case FIVE_BAUD_MOD:
				/*Jayasheela -Added to check range */
				if ((pSconfig->ulValue < ISO9141_5_BAUD_REG_MIN) || 
					(pSconfig->ulValue > ISO9141_5_BAUD_REG_MAX))
						return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO9141.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}


