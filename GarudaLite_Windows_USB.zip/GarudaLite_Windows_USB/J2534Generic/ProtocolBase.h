/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ProtocolBase.h
 Description			: interface for the CProtocolBase class.
 Date					: Jan 30, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#ifndef _PROTOCOLBASE_H_
#define _PROTOCOLBASE_H_

#include "afxtempl.h"
#include "J2534.h"
#include "CircBuffer.h"
#include "FilterMsg.h"
#include "PeriodicMsg.h"
#include "DebugLog.h"
#include "..\DeviceOEMTool\StnDevice.h"


//Constants
#define PROTOCOLBASE_ERROR_TEXT_SIZE			80
#define PROTOCOLBASE_PUMPTHREAD_END_TIMEOUT		5000
#define PROTOCOLBASE_PUMP_SYNC_TIMEOUT			3000

typedef struct
{
	CCircBuffer		*pclsCircBuffer;
	CDeviceBase		*pclsDevice;
	HANDLE			hPendingEvent;
	HANDLE			hBuffEmptyEvent;
	unsigned long	ulDevChannelRef;
}
PROTOCOLBASE_PUMP_DATA;

UINT WritePumpThread(LPVOID lpVoid);

class CProtocolBase  
{
public:

	CProtocolBase(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CProtocolBase();
	
	virtual J2534ERROR					vConnect(J2534_PROTOCOL	enProtocolID,
												 unsigned long   ulFlags,
												 unsigned long	ulBaudRate,
												 DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
												 DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
												 DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
												 LPVOID			pVoid=NULL);

	virtual J2534ERROR					vDisconnect();
	
	virtual J2534ERROR					vReadMsgs(PASSTHRU_MSG *pstrucJ2534Msg, 
							 					  unsigned long *pulNumMsgs, 
												  unsigned long ulTimeout);

	virtual J2534ERROR					vWriteMsgs(PASSTHRU_MSG *pstrucJ2534Msg, 
												   unsigned long *pulNumMsgs, 
												   unsigned long ulTimeout);

	virtual J2534ERROR					vStartPeriodicMsg(
												PASSTHRU_MSG	*pstrucJ2534Msg,
												unsigned long *pulMsgID,
												unsigned long ulTimeInterval);
	virtual J2534ERROR					vUpdatePeriodicMsg(
												PASSTHRU_MSG	*pstrucJ2534Msg,
												unsigned long pulMsgID,
												unsigned long ulTimeInterval);

	virtual J2534ERROR					vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR					vStartMsgFilter(
												J2534_FILTER	enFilterType,
												PASSTHRU_MSG	*pstrucJ2534Mask,
												PASSTHRU_MSG	*pstrucJ2534Pattern,
												PASSTHRU_MSG	*pstrucJ2534FlowControl,
												unsigned long	*pulFilterID);

	virtual J2534ERROR					vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR					vIoctl(J2534IOCTLID enumIoctlID,
												void *pInput,
												void *pOutput);
	
	BOOL								AddToPumpDatabase(
												PROTOCOLBASE_PUMP_DATA *pstAddData,
												unsigned long		   *pulPumpRefID);
	BOOL								DeleteFromPumpDatabase(
												unsigned long ulPumpRefID, 
												BOOL		  bRemoveAll=false);
	BOOL								IsEmptyPumpDatabase();
	BOOL								StartWritePump();
	BOOL								StopWritePump();
	
	J2534ERROR							SetMsgPending(unsigned long	ulPumpRefID, 
													  unsigned long	*pulTimeout);
	J2534ERROR							IsMsgSent(unsigned long	ulPumpRefID, 
												  unsigned long	*pulTimeout);

	J2534ERROR vProgrammingVoltage		(unsigned long ulPin,
	   									unsigned long ulVoltage);

	/*Variable Declaration*/

	HANDLE								m_hBuffEmptyEvent;
	HANDLE								m_hPendingEvent;

										// Used to synchronize between write and read.
										// While writing, we will set this event. When this event is set, which means, we have some data to read.
										// So, read thread can use this to read data.
	static HANDLE						m_hWriteSyncEvent;	
	CDeviceBase							*m_pclsDevice;
	CCircBuffer							*m_pclsRxCircBuffer;
	CCircBuffer							*m_pclsTxCircBuffer;

	/*Create Filter and Periodic Message Classes */
	CFilterMsg							*m_pclsFilterMsg;
	CPeriodicMsg						*m_pclsPeriodicMsg;
	
	BOOL								m_bConnected;
	unsigned long						m_ulConnectFlag;
	unsigned long						m_ulDevChannelRef;
	unsigned long						m_ulPumpRefID;
	
	static J2534ERROR					m_J2534WriteError;
	static CDebugLog					*m_pclsLog;
	static CMap<unsigned long, unsigned long, PROTOCOLBASE_PUMP_DATA *, PROTOCOLBASE_PUMP_DATA *> m_stPumpDatabase;
	static HANDLE						m_hWritePumpSync;
	static HANDLE						m_hWritePumpExit;
	static HANDLE						m_hWritePumpExited;
	static CWinThread					*m_pclsWritePumpThread;
	static unsigned long				m_ulInstance;
	BOOL								m_bLoopback;
	unsigned long						m_ulChecksumFlag;

private:
	char								m_szLastErrorText[PROTOCOLBASE_ERROR_TEXT_SIZE];
	J2534ERROR							TranslateDeviceError(CDeviceBase *pclsDevice, 
															J2534ERROR enDeviceError);
};

#endif
