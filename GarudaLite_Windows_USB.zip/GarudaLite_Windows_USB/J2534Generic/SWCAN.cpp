/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: SWCAN.cpp
 Description			: Implementation for the CSWCAN class.
 Date					: Feb 15, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 15, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "SWCAN.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//-----------------------------------------------------------------------------
//	Function Name	: CSWCAN
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CCAN class
//-----------------------------------------------------------------------------

CSWCAN::CSWCAN(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
			CProtocolBase(pclsDevice, pclsDebugLog)
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "CSWCAN()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Initialize.
	m_bConnected = FALSE;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "CSWCAN()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	m_bLoopback = FALSE;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CSWCAN
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CCAN class
//-----------------------------------------------------------------------------
CSWCAN::~CSWCAN()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "~CSWCAN()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "~CSWCAN()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}
//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSWCAN::vConnect(J2534_PROTOCOL	enProtocolID,
							unsigned long   ulFlags,
							unsigned long	ulBaudRate,
							DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
						    DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
						    DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
							LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}
	/*Jayasheela -store protocol id*/
	if(enProtocolID==SW_CAN_PS)
	{
		m_enSWCANProtocol=SW_CAN_PS;
	}
	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID, ulFlags, ulBaudRate,
												OnSWCANRxMessage,NULL,NULL,this))
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	m_ulPPSS = 0;
	m_ulSWCAN_SpeedChange_Enable = 0;
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSWCAN::vDisconnect()
{
	char			szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "CSWCAN()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CSWCAN::vReadMsgs(PASSTHRU_MSG	*pstPassThruMsg,
							 unsigned long	*pulNumMsgs,
							 unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, "Start");
	}


	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CSWCAN::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
						    unsigned long	*pulNumMsgs,
						    unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}


	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != m_enSWCANProtocol)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SWCAN.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		// Check if msg. format is valid.
		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SWCAN.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}
	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}
	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSWCAN::vStartPeriodicMsg(PASSTHRU_MSG		*pstPassThruMsg,
								   unsigned long	*pulMsgID,
								   unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;


	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != m_enSWCANProtocol)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWCAN.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWCAN.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CSWCAN::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CSWCAN::vStartMsgFilter(J2534_FILTER		enumFilterType,
									PASSTHRU_MSG		*pstMask,
									PASSTHRU_MSG		*pstPattern,
								    PASSTHRU_MSG		*pstFlowControl,
									unsigned long		*pulFilterID)
{
	char		szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// NOTE : If request is for PASS filter, try setting this filter in device 
	//		  as well. If the device SWCANnot set and returns an 
	//		  error, ignore it. Some device drivers may not be able to set 
	//		  hardware filters. Anyway it will be filtered by our software
	//		  filter.  

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != m_enSWCANProtocol) ||
		(pstPattern->ulProtocolID != m_enSWCANProtocol))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}
	// Check Filter Type.
	if (enumFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_FILTER_ID);
	}

	if (!IsMsgValid(pstPattern, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	if (!IsMsgValid(pstMask, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CSWCAN::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[SWCAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWCAN.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function. This function is used to read
//					  and write all the protocol hardware and software
//					  configuration parameters for a given enumIoctlID.
//-----------------------------------------------------------------------------
J2534ERROR  CSWCAN::vIoctl(J2534IOCTLID enumIoctlID,
						 void *pInput,
						 void *pOutput)
{
	J2534ERROR	enumJ2534Error;
	char	szBuffer[SWCAN_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			"Start");
	}

	// IoctlID values
	switch(enumIoctlID)
	{
	case GET_CONFIG:			// Get configuration
			enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);
		break;
		
	case SET_CONFIG:			// Set configuration
		enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);
		break;
		
	case CLEAR_TX_BUFFER:		// Clear all messages in its transmit queue
			if( m_pclsTxCircBuffer != NULL)
			{
			m_pclsTxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			}
		break;
		
	case CLEAR_RX_BUFFER:		// Clear all messages in its receive queue
		
		if( m_pclsRxCircBuffer != NULL)
			{
			m_pclsRxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		break;
		
	case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
		
			if (m_pclsPeriodicMsg != NULL)
			{
				delete m_pclsPeriodicMsg;
				m_pclsPeriodicMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		break;
		
	case CLEAR_MSG_FILTERS:		// Clear all message filters

			if (m_pclsFilterMsg != NULL)
			{
				delete m_pclsFilterMsg;
				m_pclsFilterMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		break;

	case SW_CAN_HS:

			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}	
		break;
	case SW_CAN_NS:

			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
				return(enumJ2534Error);
			}	
		break;
	default:					// Others not supported
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		break;
	}
	
	if (enumJ2534Error != J2534_STATUS_NOERROR)
	{
		// Write status to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
	}
	else
	{
		// Write status to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
	}
	
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CSWCAN::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[SWCAN_ERROR_TEXT_SIZE];

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_NULLPARAMETER);
	}

	pSconfig = pInput->pConfigPtr;
	
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
		case DATA_RATE:			// Data Rate
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
		case LOOPBACK:			// Loopback
			pSconfig->ulValue = m_bLoopback;
			break;
		case BIT_SAMPLE_POINT:	// Bit Sample Point
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
		case SYNC_JUMP_WIDTH:	// Sync Jump Width
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
			/*Jayasheela-application sends ioctl id's as per J2534 spec 2
			  but HFCP defines different id's,so require mapping*/
		case 0x00008001:
			/*Jayasheela -handling J1962_PINS for getconfig */
			//pSconfig->ulValue = m_ulPPSS;
			pSconfig->Parameter = J1962_PINS;
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			pSconfig->Parameter =(J2534_IOCTLPARAMID) 0x00008001;
			break;
		case 0x00008010:
			pSconfig->Parameter = SWCAN_HS_DATA_RATE;
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008010;
			break;
		case 0x00008011:
			pSconfig->Parameter = SWCAN_SPEEDCHANGE_ENABLE;
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008011;
			break;
		case 0x00008012:	
			pSconfig->Parameter = SWCAN_RES_SWITCH;
			if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008012;
			break;
		default:
			return(J2534_ERR_NOT_SUPPORTED);
		}
		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CSWCAN::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char			szBuffer[SWCAN_ERROR_TEXT_SIZE];	

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_NULLPARAMETER);
	}

	pSconfig = pInput->pConfigPtr;

	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}

				break;

			case LOOPBACK:			// Loopback
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					m_bLoopback = pSconfig->ulValue;
				break;

			case BIT_SAMPLE_POINT:	// Bit Sample Point
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
				break;

			case SYNC_JUMP_WIDTH:	// Sync Jump Width
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
				break;

			case 0x00008001:

				pSconfig->Parameter = J1962_PINS;
				enumJ2534Error = J1962Pins(pSconfig->ulValue);
				if(enumJ2534Error == J2534_STATUS_NOERROR)
				{
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					if(enumJ2534Error == J2534_STATUS_NOERROR)
					{
						m_ulPPSS = pSconfig->ulValue;
					}
				}
				else
					enumJ2534Error = J2534_ERR_INVALID_IOCTL_VALUE;
				pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008001;
				break;

			case 0x00008010:	
					pSconfig->Parameter = SWCAN_HS_DATA_RATE;
					if ((pSconfig->ulValue < 5) || (pSconfig->ulValue > 500000))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008010;
				break;

			case 0x00008011:	
					pSconfig->Parameter = SWCAN_SPEEDCHANGE_ENABLE;
					if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
						return(J2534_ERR_INVALID_IOCTL_VALUE);

					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer,"returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					if(enumJ2534Error == J2534_STATUS_NOERROR)
						m_ulSWCAN_SpeedChange_Enable = pSconfig->ulValue;
					pSconfig->Parameter = (J2534_IOCTLPARAMID)0x00008011;
				break;

			case 0x00008012:	
					pSconfig->Parameter = SWCAN_RES_SWITCH;
					if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 2))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer,"returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					pSconfig->Parameter = (J2534_IOCTLPARAMID)0x00008012;
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}

J2534ERROR  CSWCAN::J1962Pins(unsigned long ulValue)
{
	J2534ERROR	enumJ2534Error;
	enumJ2534Error = J2534_STATUS_NOERROR;
	if ((ulValue < 0) || (ulValue > 0xFFFF))
		return(J2534_ERR_INVALID_IOCTL_VALUE);
	if ((ulValue & 0xFF00 > 0x1000) || (ulValue & 0x00FF > 0x0010))
		return(J2534_ERR_INVALID_IOCTL_VALUE);
	if ((ulValue != 0x0000) && ((ulValue >> 8) & 0x00FF) == (ulValue & 0x00FF))
		return(J2534_ERR_INVALID_IOCTL_VALUE);
	if (((ulValue >> 8) == 4) || (ulValue == 4) ||
		((ulValue >> 8) == 5) || (ulValue == 5) ||
		((ulValue >> 8) == 16) || (ulValue == 16))
		return(J2534_ERR_INVALID_IOCTL_VALUE);
	// J1962 Pins
	if ((ulValue == 0x0000) || 	(ulValue == 0x0100))
	{
		enumJ2534Error = J2534_STATUS_NOERROR;
	}
	else
	{
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CSWCAN::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter)
{
	if (!bFilter)
		if ((pstPassThruMsg->ulDataSize < SWCAN_MSG_SIZE_MIN) || 
			(pstPassThruMsg->ulDataSize > SWCAN_MSG_SIZE_MAX))
		{
			return(false);
		}

	if ((m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CANBOTH) == 0)
	{
		if (m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CAN29BIT)
		{	
			if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) == 0)
			{
				return(false);
			}
		}
		else
		{
			if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) != 0)
			{
				return(false);
			}
		}
	}
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: OnSWCANRxMessage
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  SWCAN messages.
//-----------------------------------------------------------------------------

void OnSWCANRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid)
{
	CSWCAN					*pclsSWCAN;
	FILTERMSG_CONFORM_REQ	stConformReq;
	pclsSWCAN = (CSWCAN *) pVoid;

	// Check for NULL pointer.
	if (pclsSWCAN == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("SWCAN.cpp", "OnSWCANRx()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}


	// Check if the message is valid as per the Connect Flag is set.
	if ((pclsSWCAN->m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CANBOTH) == 0)
	{
		if (pclsSWCAN->m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CAN29BIT)
		{	
			if ((pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_CAN29BIT) == 0)
			{
				return;
			}
		}
		else
		{
			if ((pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_CAN29BIT) != 0)
			{
				return;
			}
		}
	}

	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("SWCAN.cpp", "OnSWCANRx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}

		if (pclsSWCAN->m_ulSWCAN_SpeedChange_Enable == 1)
		{
			if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) == 0)
			{
				if ((pstPassThruMsg->ucData[2] == 0x01) &&
					(pstPassThruMsg->ucData[3] == 0x01) &&
					(pstPassThruMsg->ucData[4] == 0xFE))
				{
					if ((pstPassThruMsg->ucData[5] == 0x02) &&
						(pstPassThruMsg->ucData[6] == 0xA5))
					{
						if (pstPassThruMsg->ucData[7] == 0x01)
						{
							pclsSWCAN->m_bNormalHighSpeed = false;
						}
						else if (pstPassThruMsg->ucData[7] == 0x02)
						{
							pclsSWCAN->m_bNormalHighSpeed = true;
						}
						else if (pstPassThruMsg->ucData[7] == 0x03)
						{
							if (pclsSWCAN->m_bNormalHighSpeed)
							{
								// Normal Speed to High Speed - 
								// Functionally Addressed Programming Mode
								pclsSWCAN->vIoctl(SW_CAN_HS, NULL, NULL);
							}
							else
							{
								// High Speed to Normal Speed - 
								// Functionally Addressed Return to Normal Mode
								pclsSWCAN->vIoctl(SW_CAN_NS, NULL, NULL);
							}
						}
					}
				}
				else if ((pstPassThruMsg->ucData[2] == 0x02) &&
					(pstPassThruMsg->ucData[3] >= 0x41) &&
					(pstPassThruMsg->ucData[3] <= 0x5F))
				{
					if ((pstPassThruMsg->ucData[4] == 0x02) &&
						(pstPassThruMsg->ucData[5] == 0xA5))
					{
						if (pstPassThruMsg->ucData[6] == 0x01)
						{
							pclsSWCAN->m_bNormalHighSpeed = false;
						}
						else if (pstPassThruMsg->ucData[6] == 0x02)
						{
							pclsSWCAN->m_bNormalHighSpeed = true;
						}
						else if (pstPassThruMsg->ucData[6] == 0x03)
						{
							if (pclsSWCAN->m_bNormalHighSpeed)
							{
								// Normal Speed to High Speed - 
								// Functionally Addressed Programming Mode
								pclsSWCAN->vIoctl(SW_CAN_HS, NULL, NULL);
							}
							else
							{
								// High Speed to Normal Speed - 
								// Functionally Addressed Return to Normal Mode
								pclsSWCAN->vIoctl(SW_CAN_NS, NULL, NULL);
							}
						}
					}
				}
			}
		}

		if (pclsSWCAN->m_bLoopback == false)
			return;
		// Enqueue to Circ Buffer.
		pclsSWCAN->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}
    else
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CCAN.cpp", "OnCANRx()",DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}
		
		// Enqueue to Circ Buffer.
		pclsSWCAN->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}

	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("SWCAN.cpp", "OnSWCANRx()", 
						 DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK");
	}
	// Apply Filters and see if msg. is required.
	if (pclsSWCAN->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsSWCAN->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			// Enqueue to Circ Buffer.
			pclsSWCAN->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}
	return;
}
