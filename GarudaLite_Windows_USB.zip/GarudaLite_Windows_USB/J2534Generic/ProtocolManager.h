/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ProtocolManager.h
 Description			: Interface for CProtocolManager class.
 Date					: Jan 30, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version


_______________________________________________________________________________
******************************************************************************/
#include "J2534.h"
#include "..\DeviceOEMTool\DeviceBase.h"
#include "ProtocolBase.h"
#include "CAN.h"
#include "SWCAN.h"
#include "J1850PWM.h"
#include "ISO9141.h"
#include "ISO14230.h"
#include "J1850VPW.h"
//#include "SWISO15765.h"
#include "SCI.h"
#include "ISO15765.h"
#include "CCD.h"
#include "J1939.h"

#if !defined(AFX_PROTOCOLMANAGER_H__EEEE7ADE_C86C_4715_A536_2F16CCB71BDE__INCLUDED_)
#define AFX_PROTOCOLMANAGER_H__EEEE7ADE_C86C_4715_A536_2F16CCB71BDE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/*Size of Protocol List. This is set to a high number that may never be used and 
result wasting memory. However, it will only be allocating 400 bytes and that is 
not significant*/
#define PROTOCOLMANAGER_OBJ_LIST_START_IDX	1
#define PROTOCOLMANAGER_OBJ_LIST_SIZE		400	
#define PROTOCOLMANAGER_ERROR_TEXT_SIZE		 80


class CProtocolManager  
{
public:
	CProtocolManager(CDebugLog * pclsDebugLog = NULL);
	~CProtocolManager();

	// Creates & stores protocol object address
	BOOL					IsProtocolConnected(J2534_PROTOCOL	enumProtocolID);
	J2534ERROR				CreateProtocolObject(J2534_PROTOCOL	enumProtocolID,
												 CDeviceBase		*pclsDevice,
												 unsigned long	*pulChannelID);
	J2534ERROR				DeleteProtocolObj(unsigned long ulChannelID);
	void					DeleteProtocolObj();
	BOOL					IsChannelIDValid(unsigned long ulChannelID);
	CDebugLog				*m_pclsLog;
	/*Contains pointers to Protocol Objects (index is 1 based). This array
	 should have been replaced by CList as we do not know the size until
	 runtime. The size of this array is currently set to a large number 
	 that may result in waste of memory. However, the reason we chose an
	 array instead of CList is because the performance is better although
	 by wasting some memory that is not significant.*/

	CProtocolBase			*m_pclsProtocolObject[PROTOCOLMANAGER_OBJ_LIST_SIZE];
	J2534_PROTOCOL			m_enProtocolConnectionList[PROTOCOLMANAGER_OBJ_LIST_SIZE];

private:
	unsigned long			GetNewChannelID();
	void					UngetChannelID(unsigned long ulChannelID);
};

#endif // !defined(AFX_PROTOCOLMANAGER_H__EEEE7ADE_C86C_4715_A536_2F16CCB71BDE__INCLUDED_)
