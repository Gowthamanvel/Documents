/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J1850PWM.cpp
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support J1850VPW 
						  protocol as required by J2534.
 Date					: Feb 08, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 08, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "J1850PWM.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

CJ1850PWM::CJ1850PWM(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
		   CProtocolBase(pclsDevice, pclsDebugLog)
{
	//	m_pCFilterMsg = NULL;	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "CJ1850PWM()", DEBUGLOG_TYPE_COMMENT, "Start");
	}
	
	// Initialize.
	m_bConnected = false;
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "CJ1850PWM()", DEBUGLOG_TYPE_COMMENT, 
			"End");
	}
	
	//Initialize the speed
	m_bLoopback = false;
	m_ucNodeAddress = J1850PWM_DEFAULT_NODE_ADDRESS;
	m_ulNetworkLine = 0;
	for (int i = 0; i < J1850PWM_LIMIT; i++)
	{
		// Clear all data entries
		m_FunctionTable[i].ucFuncID = NULL;
		m_FunctionTable[i].bValid = false;
	}
}

CJ1850PWM::~CJ1850PWM()
{	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "~CJ1850PWM()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "~CJ1850PWM()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::vConnect(
						J2534_PROTOCOL	enProtocolID,
						unsigned long   ulFlags,
						unsigned long	ulBaudRate,
						DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
						DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
						DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
						LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error = J2534_ERR_NOT_SUPPORTED;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	if(enProtocolID == J1850PWM)
	{
		if(ulBaudRate<J1850PWM_DATA_RATE_DEFAULT ||ulBaudRate > J1850PWM_MAXDATA_RATE)
		//if((ulBaudRate != J1850PWM_DATA_RATE_DEFAULT) && (ulBaudRate != J1850PWM_MAXDATA_RATE))
		{
			return(J2534_ERR_INVALID_BAUDRATE);
		}
		m_enJ1850Protocol = J1850PWM;
	}

	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID, 
												ulFlags, 
												ulBaudRate,
												OnJ1850PWMRxMessage, 
												NULL,NULL,
												this))!= J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(enJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::vDisconnect()
{
	char			szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "CJ1850PWM()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::vReadMsgs(PASSTHRU_MSG		*pstPassThruMsg,
						   unsigned long	*pulNumMsgs,
						   unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
						    unsigned long	*pulNumMsgs,
						    unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != m_enJ1850Protocol)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("J1850PWM.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}
		
		// Check if msg. format is valid.
		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("J1850PWM.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}
	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::vStartPeriodicMsg(PASSTHRU_MSG		*pstPassThruMsg,
								   unsigned long	*pulMsgID,
								   unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != m_enJ1850Protocol)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1850PWM.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1850PWM.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CJ1850PWM::vStartMsgFilter(J2534_FILTER		enumFilterType,
									  PASSTHRU_MSG		*pstMask,
									  PASSTHRU_MSG		*pstPattern,
									  PASSTHRU_MSG		*pstFlowControl,
									  unsigned long		*pulFilterID)
{
	char		szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulOne;
	ulOne = 1;


	// NOTE : If request is for PASS filter, try setting this filter in device 
	//		  as well. If the device J1850PWMnot set and returns an 
	//		  error, ignore it. Some device drivers may not be able to set 
	//		  hardware filters. Anyway it will be filtered by our software
	//		  filter.  

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check to see if message structure is valid
	enJ2534Error = MessageValid(pstPattern, &ulOne);

	if (enJ2534Error != J2534_STATUS_NOERROR)
		return(enJ2534Error);

	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != m_enJ1850Protocol) ||
		(pstPattern->ulProtocolID != m_enJ1850Protocol))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1850PWM.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check Filter Type.
	if (enumFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1850PWM.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_FILTER_ID);
	}
	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CJ1850PWM::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1850PWM.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function which should be implemented by
//					  the class derived from this base class.
//-----------------------------------------------------------------------------
J2534ERROR	CJ1850PWM::vIoctl(J2534IOCTLID enumIoctlID,
							   void *pInput,
							   void *pOutput)
{
	char	szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	J2534ERROR enumJ2534Error = J2534_STATUS_NOERROR;

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	switch(enumIoctlID)
	{
	case GET_CONFIG:			// Get configuration	
		enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);
		break;
		
	case SET_CONFIG:			// Set configuration
		enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);
		break;
		
	case CLEAR_TX_BUFFER: 	// Clear all messages in its transmit queue
		if( m_pclsTxCircBuffer != NULL)
		{
		m_pclsTxCircBuffer->ClearBuffer();
		/*Send the IOCTL to device also*/
		if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER,
												   NULL,
												   NULL))														
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
		}
		}
		break;
	case CLEAR_RX_BUFFER:// Clear all messages in its receive queue
		if( m_pclsRxCircBuffer != NULL)
		{
		m_pclsRxCircBuffer->ClearBuffer();
		/*Send the IOCTL to device also*/
		if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER,
												   NULL,
												   NULL))														
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
		}
		}
		break;
	case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
		if (m_pclsPeriodicMsg != NULL)
		{
			delete m_pclsPeriodicMsg;
			m_pclsPeriodicMsg = NULL;
		}
		/*Send the IOCTL to device also*/
		if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS,
												   NULL,
												   NULL))														
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
		}
		break;
	case CLEAR_MSG_FILTERS:		// Clear all message filters
		if (m_pclsFilterMsg != NULL)
		{
			delete m_pclsFilterMsg;
			m_pclsFilterMsg = NULL;
		}
		/*Send the IOCTL to device also*/
		if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS,
												   NULL,
												   NULL))														
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
		}
		break;
	case CLEAR_FUNCT_MSG_LOOKUP_TABLE:	// Clear the whole functional message
										// look-up table
		enumJ2534Error = ClearTable();
		
		break;
		
	case ADD_TO_FUNCT_MSG_LOOKUP_TABLE:	// Add functional address(es) to the
										// functional message look-up table
		enumJ2534Error = AddToTable((SBYTE_ARRAY *)pInput);
		
		break;
		
	case DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE: // Delete functional address(es) 
											// from the functional message 
											// look-up table 
		enumJ2534Error = DeleteFromTable((SBYTE_ARRAY *)pInput);
		break;
		
	default:							// Others not supported
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		break;
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
		if (enumJ2534Error != J2534_STATUS_NOERROR)
			m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		else
			m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
							 szBuffer);
	}

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: OnJ1850PWMRx
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  J1850PWM messages.
//-----------------------------------------------------------------------------
void OnJ1850PWMRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid)
{
	CJ1850PWM					*pclsJ1850PWM;
	FILTERMSG_CONFORM_REQ	stConformReq;

	pclsJ1850PWM = (CJ1850PWM *) pVoid;

	// Check for NULL pointer.
	if (pclsJ1850PWM == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CJ1850PWM.cpp", "OnJ1850PWMRx()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}
	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CJ1850PWM.cpp", "OnJ1850PWMRx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}
		if (pclsJ1850PWM->m_bLoopback == false)
			return;
		// Enqueue to Circ Buffer.
		pclsJ1850PWM->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}

	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("CJ1850PWM.cpp", "OnJ1850PWMRx()", 
						 DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK");
	}

	// Apply Filters and see if msg. is required.
	if (pclsJ1850PWM->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsJ1850PWM->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			// Enqueue to Circ Buffer.
			pclsJ1850PWM->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}

	return;
}
//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CJ1850PWM::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg)
{
	if ((pstPassThruMsg->ulDataSize < J1850PWM_MSG_SIZE_MIN) || 
		(pstPassThruMsg->ulDataSize > J1850PWM_MAX_DATALENGTH))
	{
		return(false);
	}
	if (pstPassThruMsg->ucData[2] != m_ucNodeAddress)
	{
		// Message with wrong node ID in the 3rd data byte
		return(false);
	}
	return(true);
}

J2534ERROR CJ1850PWM::MessageValid(PASSTHRU_MSG	   *pstrucJ2534Msg,
								   unsigned long  *pulNumMsgs)
{
	unsigned long	ulIdx1;
	
	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{		
		if ((pstrucJ2534Msg + ulIdx1)->ulDataSize == 0 ||
			(pstrucJ2534Msg + ulIdx1)->ulDataSize > J1850PWM_MAX_DATALENGTH)
		{
			// Message with data length being 0 bytes or 
			// greater than 4128 bytes
			*pulNumMsgs = 0;
			return(J2534_ERR_INVALID_MSG);
		}
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[J1850PWM_ERROR_TEXT_SIZE];
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;
	
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
					return(enumJ2534Error);
				}

				break;

			case LOOPBACK:			// Loopback
				pSconfig->ulValue = m_bLoopback;
				break;
			
			case NODE_ADDRESS:		// Node Address

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
					return(enumJ2534Error);
				}

				break;

			case NETWORK_LINE:		// Network Line

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
					return(enumJ2534Error);
				}
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}

	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char			szBuffer[J1850PWM_ERROR_TEXT_SIZE];	

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_INVALID_IOCTL_VALUE);
	}

	pSconfig = pInput->pConfigPtr;

	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "SetConfig Parameter %lu Value %lu", 
				pSconfig->Parameter, pSconfig->ulValue);
			m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
		switch (pSconfig->Parameter)
		{
		case DATA_RATE:			// Data Rate

			if ((pSconfig->ulValue  != J1850PWM_DATA_RATE_DEFAULT) && 
				(pSconfig->ulValue  != J1850PWM_MAXDATA_RATE))
			
					return(J2534_ERR_INVALID_IOCTL_VALUE);
			
			if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														pSconfig,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
			
		case LOOPBACK:			// Loopback
			
			if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
				return(J2534_ERR_INVALID_IOCTL_VALUE);
			
			if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
													   pSconfig,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			m_bLoopback = pSconfig->ulValue;
			break;	
						
		case NODE_ADDRESS:		// Node Address
			
			if (pSconfig->ulValue <= 0x00 && pSconfig->ulValue >= 0xFF)
				return(J2534_ERR_INVALID_IOCTL_VALUE);
			
			if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														pSconfig,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
			
		case NETWORK_LINE:		// Network Line
			
			if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 2))
				return(J2534_ERR_INVALID_IOCTL_VALUE);
			
			if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														pSconfig,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
			
		default:
			return(J2534_ERR_NOT_SUPPORTED);
		}
		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: ClearTable
//	Input Params	: 
//	Output Params	: 
//	Description		: This function is to clear the function table.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::ClearTable()
{
	J2534ERROR enumJ2534Error;
	char			szBuffer[J1850PWM_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	for (int i = 0; i < J1850PWM_LIMIT; i++)
	{
		// Clear all data entries
		m_FunctionTable[i].ucFuncID = NULL;
		m_FunctionTable[i].bValid = false;
	}

	if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_FUNCT_MSG_LOOKUP_TABLE,
											   m_FunctionTable,
											   NULL))														
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
		}
	}
	// Clear Func ID table
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: AddToTable
//	Input Params	: 
//	Output Params	: 
//	Description		: This function is to add functional address(es) to the 
//					  function table.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::AddToTable(SBYTE_ARRAY *pInput)
{
	J2534ERROR		enumJ2534Error;
	int				i, j;
	char			szBuffer[J1850PWM_ERROR_TEXT_SIZE];	
	
	enumJ2534Error = J2534_STATUS_NOERROR;
	
	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);
	
	for (j = 0; j < pInput->ulNumOfBytes; j++)
	{
		for (i = 0; i < J1850PWM_LIMIT; i++)
		{
			if (m_FunctionTable[i].bValid == false)
			{
				m_FunctionTable[i].ucFuncID = pInput->pucBytePtr[j];
				
				// Set Func ID table
				m_FunctionTable[i].bValid = true;
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "Added 0x%02X", pInput->pucBytePtr[j]);
					m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						szBuffer);
				}				
				break;
			}
			
			if (m_FunctionTable[i].ucFuncID == pInput->pucBytePtr[j])
				break;
		}
		
		// Limit is already reached
		if (i == J1850PWM_LIMIT)
		{
			enumJ2534Error = J2534_ERR_EXCEEDED_LIMIT;
			return(enumJ2534Error);
		}
	}
	
	if (enumJ2534Error = CProtocolBase::vIoctl(ADD_TO_FUNCT_MSG_LOOKUP_TABLE,
												m_FunctionTable,
												NULL))														
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
	}
	return(enumJ2534Error);
}
//-----------------------------------------------------------------------------
//	Function Name	: DeleteFromTable
//	Input Params	: 
//	Output Params	: 
//	Description		: This function is to delete functional address(es) from  
//					  the function table.
//-----------------------------------------------------------------------------
J2534ERROR CJ1850PWM::DeleteFromTable(SBYTE_ARRAY *pInput)
{
	J2534ERROR		enumJ2534Error;
	bool			bDelete;
	int				i, j;
	char			szBuffer[J1850PWM_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	for (j = 0; j < pInput->ulNumOfBytes; j++)
	{
		bDelete = false;
		for (i = 0; i < J1850PWM_LIMIT; i++)
		{
			if (m_FunctionTable[i].ucFuncID == pInput->pucBytePtr[j])
			{
				// Clear the specified llokup table
				m_FunctionTable[i].ucFuncID = NULL;
				m_FunctionTable[i].bValid = false;
				bDelete = true;
			}

			// Shift all entries following the deleted entry by one slot
			if (bDelete == true)
			{
				m_FunctionTable[i] = m_FunctionTable[i+1];
		
				if (i == J1850PWM_LIMIT - 1) 
				{
					// Reset the last entry in DB
					m_FunctionTable[i].ucFuncID = NULL;
					m_FunctionTable[i].bValid = false;
				}
			}
		}
	}

	if (enumJ2534Error = CProtocolBase::vIoctl(DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE,
												m_FunctionTable,
												NULL))														
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("J1850PWM.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
	}
	
	return(enumJ2534Error);
}

