/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ISO14230.cpp
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support ISO14230 
						  protocol as required by J2534.
 Date					: Feb 11, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 11, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "StdAfx.h"
#include "ISO14230.h"

//-----------------------------------------------------------------------------
//	Function Name	: CISO14230
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CISO14230 class
//-----------------------------------------------------------------------------
CISO14230::CISO14230(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
			CProtocolBase(pclsDevice, pclsDebugLog)
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "CISO14230()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Initialize.
	m_bConnected = false;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "CISO14230()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	m_bLoopback = FALSE;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CISO14230
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CISO14230 class
//-----------------------------------------------------------------------------
CISO14230::~CISO14230()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "~CISO14230()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "~CISO14230()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vConnect(J2534_PROTOCOL	enProtocolID,
							  unsigned long   ulFlags,
							  unsigned long	ulBaudRate,
							  DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
							  DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
							  DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
							  LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	/*Get the Check Sum Flag from the connection flags*/
	m_ulChecksumFlag = ((ulFlags >> 9) & 0x01);
	/*Jayasheela-commented the below code to fix the 28th issue 
	  need to send the connect flags to firmaware as it is without any modification*/
	//ulFlags = (((ulFlags >> 12) & 0x01) << 1);
	//ulFlags |= m_ulChecksumFlag;

	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID, 
												ulFlags, 
												ulBaudRate,
												OnISO14230RxMessage, 
												NULL,NULL,this)) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vDisconnect()
{
	char			szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "CISO14230()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vReadMsgs(PASSTHRU_MSG		*pstPassThruMsg,
							   unsigned long	*pulNumMsgs,
							   unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
								unsigned long	*pulNumMsgs,
								unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != ISO14230)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ISO14230.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		// Check if msg. format is valid.
		if (!IsMsgValid(pstPassThruMsg + ulIdx1))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("ISO14230.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vStartPeriodicMsg(PASSTHRU_MSG		*pstPassThruMsg,
									   unsigned long	*pulMsgID,
									   unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != ISO14230)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO14230.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO14230.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vUpdatePeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions updates a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vUpdatePeriodicMsg(PASSTHRU_MSG		*pstPassThruMsg,
									   unsigned long	ulMsgID,
									   unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != ISO14230)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO14230.cpp", "vUpdatePeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO14230.cpp", "vUpdatePeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vUpdatePeriodicMsg(pstPassThruMsg,
														 ulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vUpdatePeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CISO14230::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CISO14230::vStartMsgFilter(J2534_FILTER 	enumFilterType,
									  PASSTHRU_MSG	*pstMask,
									  PASSTHRU_MSG	*pstPattern,
									  PASSTHRU_MSG	*pstFlowControl,
									  unsigned long	*pulFilterID)
{
	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// NOTE : If request is for PASS filter, try setting this filter in device 
	//		  as well. If the device cannot set and returns an 
	//		  error, ignore it. Some device drivers may not be able to set 
	//		  hardware filters. Anyway it will be filtered by our software
	//		  filter.  

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != ISO14230) ||
		(pstPattern->ulProtocolID != ISO14230))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO14230.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check Filter Type.
	if (enumFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO14230.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_FILTER_ID);
	}
	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CISO14230::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[ISO14230_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("ISO14230.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("ISO14230.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function. This function is used to read
//					  and write all the protocol hardware and software
//					  configuration parameters for a given enumIoctlID.
//-----------------------------------------------------------------------------
J2534ERROR  CISO14230::vIoctl(J2534IOCTLID enumIoctlID,
								 void *pInput,
								 void *pOutput)
{
	J2534ERROR	enumJ2534Error;
	char	szBuffer[ISO14230_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// IoctlID values
	switch(enumIoctlID)
	{
		case GET_CONFIG:			// Get configuration
			enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);
			break;

		case SET_CONFIG:			// Set configuration
			enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);
			break;

		case FIVE_BAUD_INIT:		// CARB (5-baud) initialization

			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														pInput,
														pOutput))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
				return(enumJ2534Error);
			}
			break;

		case FAST_INIT:				// Fast initialization

			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														pInput,
														pOutput))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
				return(enumJ2534Error);
			}
			break;

		case CLEAR_TX_BUFFER:		// Clear all messages in its transmit queue
			if( m_pclsTxCircBuffer != NULL)
			{
			m_pclsTxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			}
			break;

		case CLEAR_RX_BUFFER:		// Clear all messages in its receive queue
			if( m_pclsRxCircBuffer != NULL)
			{
			m_pclsRxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			}
			break;

		case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
			if (m_pclsPeriodicMsg != NULL)
			{
				delete m_pclsPeriodicMsg;
				m_pclsPeriodicMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
		case CLEAR_MSG_FILTERS:		// Clear all message filters
			if (m_pclsFilterMsg != NULL)
			{
				delete m_pclsFilterMsg;
				m_pclsFilterMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
			break;
		default:					// Others not supported
			enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
			break;
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
		if (enumJ2534Error != J2534_STATUS_NOERROR)
			m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		else
			m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
							 szBuffer);
	}

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: OnISO14230Rx
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  ISO14230 messages.
//-----------------------------------------------------------------------------
void OnISO14230RxMessage(PASSTHRU_MSG *pstPassThruMsg, 
						LPVOID pVoid)
{
	CISO14230					*pclsISO14230;
	FILTERMSG_CONFORM_REQ	stConformReq;

	pclsISO14230 = (CISO14230 *) pVoid;

	// Check for NULL pointer.
	if (pclsISO14230 == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CISO14230.cpp", "OnISO14230Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}
	// Check if this is a Rx First Byte message.
	if (pstPassThruMsg->ulRxStatus & 0x02)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CISO14230.cpp", "OnISO14230Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "Rx First Byte CALLBACK");
		}

		// Enqueue to Circ Buffer.
		pclsISO14230->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}

	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if (pclsISO14230->m_bLoopback == false)
			return;
		// Enqueue to Circ Buffer.
		pclsISO14230->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}

	// Apply Filters and see if msg. is required.
	if (pclsISO14230->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsISO14230->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			if (pclsISO14230->m_ulChecksumFlag)
				pstPassThruMsg->ulExtraDataIndex--;
			// Enqueue to Circ Buffer.
			pclsISO14230->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}
	return;
}

//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CISO14230::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg)
{
	if ((pstPassThruMsg->ulDataSize < ISO14230_MSG_SIZE_MIN) || 
		(pstPassThruMsg->ulDataSize > (ISO14230_MSG_SIZE_MAX + m_ulChecksumFlag)))
	{
		return(false);
	}
	// If no address information
	if ((pstPassThruMsg->ucData[0] & 0xC0) == 0)
	{
		// Length byte included
		if ((pstPassThruMsg->ucData[0] & 0x3F) == 0)
		{
			if (pstPassThruMsg->ulDataSize - m_ulChecksumFlag
				- 2 != pstPassThruMsg->ucData[1])
			{
				// length of data not match length byte in header
				return(false);
			}
		}
		// Length byte not included
		else
		{
			if (pstPassThruMsg->ulDataSize - m_ulChecksumFlag
				- 1 != (pstPassThruMsg->ucData[0] & 0x3F))
			{
				// length of data not match length byte in header
				return(false);
			}
		}
	}

	// If with address information
	else if (((pstPassThruMsg->ucData[0] & 0xC0) == 0x80) ||
		((pstPassThruMsg->ucData[0] & 0xC0) == 0xC0))
	{
		// Length byte included
		if ((pstPassThruMsg->ucData[0] & 0x3F) == 0)
		{
			if (pstPassThruMsg->ulDataSize - m_ulChecksumFlag
				- 4 != pstPassThruMsg->ucData[3])
			{
				// length of data not match length byte in header
				return(false);
			}
		}
		// Length byte not included
		else
		{
			if (pstPassThruMsg->ulDataSize - m_ulChecksumFlag
				- 3 != (pstPassThruMsg->ucData[0] & 0x3F))
			{
				// length of data not match length byte in header
				return(false);
			}
		}
	}
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CISO14230::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[ISO14230_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;
	
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case LOOPBACK:			// Loopback
				pSconfig->ulValue = m_bLoopback;
				break;

			case P1_MAX:			// P1_MAX
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "P1_MAX", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P3_MIN:			// P3_MIN

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "P3_MIN", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P4_MIN:			// P4_MIN

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "P4_MIN", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case W1:				// W1

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "W1", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W2:				// W2
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "W2", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W3:				// W3
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "W3", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W4:				// W4
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "W4", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W5:				// W5
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "W5", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TIDLE:

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "TIDLE", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TINIL:

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "TINIL", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TWUP:

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "TWUP", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case PARITY:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "PARITY", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case DATA_BITS:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "DATA_BITS", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case FIVE_BAUD_MOD:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "FIVE_BAUD_MOD", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CISO14230::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char			szBuffer[ISO14230_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}
	pSconfig = pInput->pConfigPtr;
	for (ulCount=0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate

				/*Check if the IOCTL value is not in range */
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case LOOPBACK:			// Loopback

				if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				m_bLoopback = pSconfig->ulValue;
				break;
			case P1_MAX:			// P1_MAX
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P3_MIN:			// P3_MIN
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case P4_MIN:			// P4_MIN
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W1:				// W1
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W2:				// W2
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W3:				// W3
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W4:				// W4
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case W5:				// W5

				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TIDLE:
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TINIL:
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case TWUP:
				
				if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))
					return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case PARITY:
				
				if ((pSconfig->ulValue < ISO14230_NO_PARITY) || 
					(pSconfig->ulValue > ISO14230_EVEN_PARITY))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
	
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case DATA_BITS:
				if ((pSconfig->ulValue < ISO14230_8_DATABITS) || 
					(pSconfig->ulValue > ISO14230_7_DATABITS))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			
			case FIVE_BAUD_MOD:
				/*Jayasheela-checking valid values */
				if ((pSconfig->ulValue < ISO9141_5_BAUD_REG_MIN) || 
					(pSconfig->ulValue > ISO9141_5_BAUD_REG_MAX))
						return(J2534_ERR_INVALID_IOCTL_VALUE);

				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("ISO14230.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		pSconfig++;
	}
	return(enumJ2534Error);
}


