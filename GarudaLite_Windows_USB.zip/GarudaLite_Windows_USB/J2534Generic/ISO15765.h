/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ISO15765.h
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support ISO15765
						  protocol as required by J2534.
 Date					: Feb 21, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 21, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#if !defined(AFX_ISO15765_H__CAD6B044_BA8D_4575_A2AA_0D3890AF3786__INCLUDED_)
#define AFX_ISO15765_H__CAD6B044_BA8D_4575_A2AA_0D3890AF3786__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProtocolBase.h"

void OnISO15765RxMessage(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid);
/*Jayasheela-callback function to handle flow control message after recv First frame*/
void OnISO15765FirstFrame(PASSTHRU_MSG pstPassThruMsg,
						  LPVOID pVoid,unsigned long *ulFCMessId,unsigned char *ucFCMessData,
						  int *iFCMessDataLen,unsigned long *ulFCMsgTxflags,bool *bFoundFCMessId);

void OnISO15765SetRxstatus(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid);

class CISO15765 : public CProtocolBase  
{
public:
	CISO15765(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CISO15765();

	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);
	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vUpdatePeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long ulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);

private:
	bool				IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter = false);


public:
	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	/* Ravi: Added the variables needed for CAN / ISO 15765 */
	float					m_fSamplePoint;
	float					m_fJumpWidth;
	unsigned long			m_ulCANIDtype;
	unsigned long			m_ulCANExtAddr;
	/*Jayasheela-using single variable to hold protocol id */
	J2534_PROTOCOL			m_enISO15765Protocol;
	unsigned long			m_ulBlockSize;
	unsigned long			m_ulBlockSizeTx;
	unsigned long			m_ulSTmin;
	unsigned long			m_ulSTminTx;
	unsigned long			m_ulWftMax;
	/*Jayasheela-as Dual and SW 15765 code is merged so added below variables*/
	J2534ERROR				J1962Pins(unsigned long ulValue);
	unsigned long			m_ulSWCAN_SpeedChange_Enable;
	bool					m_bNormalHighSpeed;
	unsigned long			m_ulPPSS;
};

#endif // !defined(AFX_ISO15765_H__CAD6B044_BA8D_4575_A2AA_0D3890AF3786__INCLUDED_)
