/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: SWISO15765.h
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support SWISO15765
						  protocol as required by J2534.
 Date					: Feb 21, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 21, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#if !defined(AFX_SWISO15765_H__754592CE_CE86_41B5_B1CE_D82D8B8E3AD3__INCLUDED_)
#define AFX_SWISO15765_H__754592CE_CE86_41B5_B1CE_D82D8B8E3AD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProtocolBase.h"

void OnSWISO15765RxMessage(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid);

class CSWISO15765 : public CProtocolBase  
{

public:
	CSWISO15765(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CSWISO15765();

	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);
	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);

private:
	bool				IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter = false);


public:
	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				J1962Pins(unsigned long ulValue);

	J2534_PROTOCOL			m_enSWISO15765Protocol;
	unsigned long			m_ulSWCAN_SpeedChange_Enable;
	bool					m_bNormalHighSpeed;
	unsigned long			m_ulPPSS;
	/*Jayasheela-removed m_bJ1962Pins -pin slection is handled in firmware */
	//bool					m_bJ1962Pins;
};

#endif // !defined(AFX_SWISO15765_H__754592CE_CE86_41B5_B1CE_D82D8B8E3AD3__INCLUDED_)
