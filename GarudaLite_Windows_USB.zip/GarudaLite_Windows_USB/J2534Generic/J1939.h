// J1939.h: interface for the J1939 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_J1939_H__55D11B18_EA67_44EA_977B_C510ECDCBD16__INCLUDED_)
#define AFX_J1939_H__55D11B18_EA67_44EA_977B_C510ECDCBD16__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProtocolBase.h"




class CJ1939 : public CProtocolBase  
{
public:
	CJ1939(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CJ1939();

	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);
	virtual J2534ERROR	vDisconnect();
	
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vUpdatePeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long ulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);
	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);


private:
	bool				IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter = false);

public:
	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	float					m_fSamplePoint;
	float					m_fJumpWidth;
	unsigned long			m_ulCANIDtype;
	unsigned long			m_ulCANExtAddr;

	/*Jayasheela-using single variable to hold protocol id */
	J2534_PROTOCOL			m_enJ1939Protocol;
	/*Jayasheela-as Dual and SW 15765 code is merged so added below variables*/
	J2534ERROR				J1962Pins(unsigned long ulValue);
	bool					m_addressClaimed;
	unsigned char			m_uchClaimedAddress;
	unsigned long			m_ulJ1939_T1;
	unsigned long			m_ulJ1939_T2;
	unsigned long			m_ulJ1939_T3;
	unsigned long			m_ulJ1939_T4;
	unsigned long			m_ulJ1939_BRDCST_MIN_DELAY;
};

#endif // !defined(AFX_J1939_H__55D11B18_EA67_44EA_977B_C510ECDCBD16__INCLUDED_)
