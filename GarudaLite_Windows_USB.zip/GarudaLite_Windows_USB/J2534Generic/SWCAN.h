/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: SWCAN.h
 Description			: interface for the CSWCAN class.
 Date					: Feb 15, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 15, 2008	Chakravarthy				Initial Version
*******************************************************************************/
#if !defined(AFX_SWCAN_H__E15058B8_C45B_4882_866A_D11358607993__INCLUDED_)
#define AFX_SWCAN_H__E15058B8_C45B_4882_866A_D11358607993__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "J2534.h"
#include "ProtocolBase.h"
#include "CircBuffer.h"

/*Receive SWCAN Messages*/
void OnSWCANRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid);

class CSWCAN : public CProtocolBase  
{

public:
	
	CSWCAN(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CSWCAN();

	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);
	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);

private:

	bool				IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter = false);

public:

	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				J1962Pins(unsigned long ulValue);

	J2534_PROTOCOL			m_enSWCANProtocol;
	unsigned long 			m_ulSWCAN_SpeedChange_Enable;
	bool					m_bNormalHighSpeed;
	unsigned long			m_ulPPSS;
	/*Jayasheela-removed m_bJ1962Pins flag pin selection is handled in firmaware*/
	//bool					m_bJ1962Pins;
};

#endif // !defined(AFX_SWCAN_H__E15058B8_C45B_4882_866A_D11358607993__INCLUDED_)
