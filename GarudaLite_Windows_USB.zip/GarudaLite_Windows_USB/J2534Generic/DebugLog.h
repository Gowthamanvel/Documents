/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: DebugLog.h
 Description			: This is the main header file for CDebugLog class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

  File		 Date			Author						Description
  Version
_____________________________________________________________________________
 
  1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
*****************************************************************************/

#include "stdafx.h"
#include "J2534.h"

#ifndef _DEBUGLOG_H_
#define _DEBUGLOG_H_

#define DEBUGLOG_FILE_EXPORT			"J2534Export.cpp"
#define DEBUGLOG_FILE_ISO15765			"ISO15765.cpp"
#define DEBUGLOG_FILE_CAN				"Can.cpp"
#define DEBUGLOG_FILE_J1850VPW			"J1850VPW.cpp"
#define DEBUGLOG_FILE_J1850PWM			"J1850PWM.cpp"
#define DEBUGLOG_FILE_ISO9141			"ISO9141.cpp"
#define DEBUGLOG_FILE_ISO14230			"ISO14230.cpp"
#define DEBUGLOG_FILE_SCI_A_ENGINE		"SCI.cpp"
#define DEBUGLOG_FILE_SCI_A_TRANS		"SCI.cpp"
#define DEBUGLOG_FILE_SCI_B_ENGINE		"SCI.cpp"
#define DEBUGLOG_FILE_SCI_B_TRANS		"SCI.cpp"
#define DEBUGLOG_FILE_SWCAN_ISO15765	"SWCAN_ISO15765.cpp"
#define DEBUGLOG_FILE_SWCAN_CAN			"SWCAN_CAN.cpp"
#define DEBUGLOG_FILE_CCD				"CCD.cpp"
#define DEBUGLOG_FILE_BASE				"J2534Base.cpp"
				
// Logging Type
#define	DEBUGLOG_TYPE_ERROR				0x01
#define	DEBUGLOG_TYPE_COMMENT			0x02
#define	DEBUGLOG_TYPE_DATA				0x04
#define	DEBUGLOG_TYPE_APPEND			0x80000000

#define DEBUGLOG_WRITELOG_TIMEOUT		1000

class CDebugLog
{
	public:
		CDebugLog();
		~CDebugLog();
		BOOL Write(CString csFile, 
				   CString csFunc, 
				   unsigned long ulType, 
				   CString csDesc);
		BOOL Write(CString csFile,
				   CString csFunc,
				   J2534_PROTOCOL csProtocol, 
				   unsigned long ulType,
				   CString csDesc);
		BOOL Open (CString csLogFileName, 
				   unsigned long ulLogType);

		BOOL Close();

		FILE			*m_pfdLogFile;			// Log File Descriptor.

	private:
		HANDLE			m_hWriteLogSync;		// Handle for WriteToLog synch.
		unsigned long	m_ulLoggingType;		// Type of Logging.
};
#endif
