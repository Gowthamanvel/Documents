/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: FilterMsg .h
 Description			: Implementation for the CFilterMsg  class.
 Date					: Feb 19, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 19, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#if !defined(AFX_FILTERMSG_H__B76C7A5A_FF0E_4C6A_B1A3_2B0EA9B4BA49__INCLUDED_)
#define AFX_FILTERMSG_H__B76C7A5A_FF0E_4C6A_B1A3_2B0EA9B4BA49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "J2534.h"
#include "DebugLog.h"
#include "..\DeviceOEMTool\StnDevice.h"

typedef enum
{
	FILTERMSG_CONFORM_YES = 1,			// Msg. conforms to given Filter.
	FILTERMSG_CONFORM_NO,				// Msg. does not conform to Filter.
} 
FILTERMSGCONFORM;

typedef struct
{
	unsigned long ulProtocolID;
	unsigned long ulRxStatus;
	unsigned long ulTxFlags;
	unsigned long ulTimeStamp;
	unsigned long ulDataSize;
	unsigned long ulExtraDataIndex;
	unsigned char ucData[FILTERMSG_MSGLEN_MAX];
}
FILTERMSG_MSG;

typedef struct
{
	bool	bReqPass;
	bool	bReqBlock;
	bool	bReqFlowControl;
}
FILTERMSG_CONFORM_REQ;

/* Removed the redundent Dev filter ref ID */
typedef struct
{
	J2534_FILTER  enFilterType;
	FILTERMSG_MSG *pstMask;
	FILTERMSG_MSG *pstPattern;
	FILTERMSG_MSG *pstFlowControl;
}
FILTERMSGLIST;
class CFilterMsg  
{
public:
	// Constructor
	CFilterMsg(CDeviceBase *pclsDevice, unsigned long	ulDevChannelID,
			   CDebugLog * pclsDebugLog = NULL);
	
	~CFilterMsg();

	/* Removed the redundent Dev filter ref ID */
	J2534ERROR			StartFilter(
									J2534_FILTER	enFilterType, 
									PASSTHRU_MSG	*pstMask, 
									PASSTHRU_MSG	*pstPattern,
									PASSTHRU_MSG	*pstFlowControl,
									unsigned long	*pulFilterID);
	J2534ERROR			StopFilter(unsigned long	ulFilterID);
	J2534ERROR			StopFilter();

	bool				IsMsgRequired(
										PASSTHRU_MSG			*pstMsg,
										FILTERMSG_CONFORM_REQ	*pConformReq);
	bool				GetFCMsgID(PASSTHRU_MSG pstRxMsg, unsigned long *ulFCMsgId,
								   unsigned char * ucFCMsgData,unsigned long *ulFCMsgTxflags,
								   unsigned long * ulpos);

	bool				SearchFlowControlFilter(PASSTHRU_MSG	*pstMsg);

	bool				SearchPatternId(PASSTHRU_MSG *pstRxMsg);

	FILTERMSGLIST		m_stFilterList[FILTERMSG_LIST_SIZE+1];
	bool IsFlowControlFilterSet();

private:

	HANDLE				m_hSyncAccess;
	CDebugLog			*m_pclsLog;
	CDeviceBase			*m_pclsDevice;
	unsigned long		m_ulDevChannelID;
	char				m_szLastErrorText[FILTERMSG_ERROR_TEXT_SIZE];

	J2534ERROR			Add(J2534_FILTER enFilterType, 
							PASSTHRU_MSG *pstMask, 
							PASSTHRU_MSG *pstPattern,
							PASSTHRU_MSG *pstFlowControl,
						    unsigned long *pulFilterID);
	J2534ERROR			Delete(unsigned long ulFilterID);
	bool				IsFlowControlUnique(
							PASSTHRU_MSG *pstPattern,
							PASSTHRU_MSG *pstFlowControl);
	bool				IsFilterIDValid(unsigned long ulFilterID);
	bool				IsListFull();
	unsigned char		GetNewFilterID();
	FILTERMSGCONFORM	MsgConform(
								PASSTHRU_MSG *pstMsg, 
								J2534_FILTER enFilterType);
};
#endif // !defined(AFX_FILTERMSG_H__B76C7A5A_FF0E_4C6A_B1A3_2B0EA9B4BA49__INCLUDED_)
