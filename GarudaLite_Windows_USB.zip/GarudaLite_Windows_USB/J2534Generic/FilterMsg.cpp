/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: FilterMsg .cpp
 Description			: Implementation for the CFilterMsg  class.
 Date					: Feb 19, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 19, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "FilterMsg.h"
#include "math.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/*Inline macro function*/
//inline unsigned long  ntohl (unsigned long n){return (n << 24) | ( (n << 8) & 0x00ff0000) | ( (n >> 8) & 0x0000ff00) | (n >> 24);}
//inline unsigned short ntohs (unsigned short n) { return (n << 8)  | (n >> 8); }
#define uword(n)  (*(WORD*)&n)
#define ulong(n)  (*(DWORD*)&n)

/*Jayasheel -variables to store filterindex and extended addrs bits */
unsigned long ulfilterindex,ulCANIDsize;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//-----------------------------------------------------------------------------
//	Function Name	: CFilterMsg
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CFilterMsg class.
//-----------------------------------------------------------------------------
CFilterMsg::CFilterMsg(CDeviceBase *pclsDevice, unsigned long	ulDevChannelID,
					   CDebugLog *pclsDebugLog)
{
	int	i;

	// Save pointers.
	m_pclsLog = pclsDebugLog;
	m_pclsDevice = pclsDevice;
	m_ulDevChannelID = ulDevChannelID;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "CFilterMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Initialize the FilterType portion of the list.
	/*Jayasheela-filter msg id strts from 1*/
	for (i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{
		m_stFilterList[i].enFilterType = J2534_FILTER_NONE;
		m_stFilterList[i].pstMask = NULL;
		m_stFilterList[i].pstPattern = NULL;
		m_stFilterList[i].pstFlowControl = NULL;
/* Ravi : Deleted the Device Filter ID */
	}

	m_hSyncAccess = CreateEvent(NULL, FALSE, TRUE, NULL);

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "CFilterMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CFilterMsg
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CFilterMsg class
//-----------------------------------------------------------------------------
CFilterMsg::~CFilterMsg()
{
	int i;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "~CFilterMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}
	// Stop all Filters
	StopFilter();

	// Delete the resources. Jayasheela : changed the refernce from 0 to 1
	for (i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{
		if (m_stFilterList[i].pstMask != NULL)
		{	
			delete m_stFilterList[i].pstMask;
			m_stFilterList[i].pstMask = NULL;
		}

		if (m_stFilterList[i].pstPattern != NULL)
		{	
			delete m_stFilterList[i].pstPattern;
			m_stFilterList[i].pstPattern = NULL;
		}

		if (m_stFilterList[i].pstFlowControl != NULL)
		{	
			delete m_stFilterList[i].pstFlowControl;
			m_stFilterList[i].pstFlowControl = NULL;
		}

		m_stFilterList[i].enFilterType = J2534_FILTER_NONE;
/* Ravi : Deleted the Device Filter ID */
	}

	CloseHandle(m_hSyncAccess);

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "~CFilterMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: StartFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function starts a given msg. filter and returns a
//					  Msg. ID for reference.
//-----------------------------------------------------------------------------
J2534ERROR CFilterMsg::StartFilter(
							   J2534_FILTER		enFilterType, 
							   PASSTHRU_MSG		*pstMask, 
							   PASSTHRU_MSG		*pstPattern,
							   PASSTHRU_MSG		*pstFlowControl,
							   unsigned long	*pulFilterID)

{
	char			szBuffer[FILTERMSG_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Synchronize Access to this function.
	if (WaitForSingleObject(m_hSyncAccess, FILTERMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		return(J2534_ERR_FAILED);	
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check if NULL pointers.
	if ((pstPattern == NULL) || (pstMask == NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NULLPARAMETER);
		m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
						 szBuffer);
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_NULLPARAMETER);
	}
	
	// If Flow Control Filter
	if (enFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		if (pstFlowControl == NULL)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NULLPARAMETER);
			m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
			SetEvent(m_hSyncAccess);
			return(J2534_ERR_NULLPARAMETER);
		}
	}
	// Is number of Filters exceeded the maximum.
	if (IsListFull())
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_EXCEEDED_LIMIT);
		m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
						 szBuffer);
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_EXCEEDED_LIMIT);
	}

	// If Flow Control Filter
	if ((enFilterType == J2534_FILTER_FLOW_CONTROL) && (pstFlowControl != NULL))
	{
		// Check if the Datasize and TxFlags are the same for Pattern,
		// Mask and FlowControl messages.
		if ((pstPattern->ulDataSize > FILTERMSG_MSGLEN_MAX) || 
			(pstFlowControl->ulDataSize != pstMask->ulDataSize) ||
			(pstFlowControl->ulDataSize != pstPattern->ulDataSize) ||
			(pstFlowControl->ulTxFlags != pstMask->ulTxFlags) ||
			(pstFlowControl->ulTxFlags != pstPattern->ulTxFlags))

		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
			SetEvent(m_hSyncAccess);
			return(J2534_ERR_INVALID_MSG);
		}

		// Check to see if the Filter is Unique.
		if (!IsFlowControlUnique(pstPattern, pstFlowControl))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_UNIQUE);
			m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
			SetEvent(m_hSyncAccess);
			return(J2534_ERR_NOT_UNIQUE);
		}
	}
	else
	{
		// Check if the Datasize and TxFlags are the same for Pattern,
		// and Mask messages.
		if ((pstPattern->ulDataSize > FILTERMSG_MSGLEN_MAX) || 
			(pstMask->ulDataSize != pstPattern->ulDataSize) ||
			(pstMask->ulTxFlags != pstPattern->ulTxFlags) /*||
			(pstFlowControl != NULL)*/)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
				m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			SetEvent(m_hSyncAccess);
			return(J2534_ERR_INVALID_MSG);
		}
	}

	// Set Filter in Device as well if it is a PASS or FLOW_CONTROL filter.
	/* jayasheela - added Block filter checking */
	if ((enFilterType == J2534_FILTER_PASS) || (enFilterType == J2534_FILTER_FLOW_CONTROL)||
		 (enFilterType == J2534_FILTER_BLOCK))
	{

		/* Ravi : Changed to send the address of the filter ID address got from the 
		passthrustartfilter call */
		if ((enJ2534Error = m_pclsDevice->vStartFilter(m_ulDevChannelID, enFilterType, pstMask, 
													 pstPattern, pstFlowControl, 
													 pulFilterID)) 
						  != J2534_STATUS_NOERROR)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
				m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			// Return error only if it is a Flow Control filter.
			// If it is any other filter do not return an error as
			// some devices may not be capable of setting at all
			// or so many filters. Anyway in cases like that the
			// software filter will take care of it.
			if (enFilterType == J2534_FILTER_FLOW_CONTROL)
			{
				SetEvent(m_hSyncAccess);
				return(enJ2534Error);
			}
		}
	}
	

	// Add the filter info. to our internal Database.
	/* Ravi : Removed the local place holder for the filter ID */
	if ((enJ2534Error = Add(enFilterType, pstMask, pstPattern, 
							pstFlowControl, pulFilterID)) !=
							J2534_STATUS_NOERROR)
	{
		// Stop the Device Filter.
		m_pclsDevice->vStopFilter(m_ulDevChannelID, *pulFilterID);
		// Log error to file.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(enJ2534Error);
	}

	SetEvent(m_hSyncAccess);
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("FilterMsg.cpp", "StartFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: StopFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops the filter corresspond to a given ID.
//-----------------------------------------------------------------------------
J2534ERROR CFilterMsg::StopFilter(unsigned long ulFilterID)

{
	char			szBuffer[FILTERMSG_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;
	

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "StopFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, FILTERMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "StopFilter()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		return(J2534_ERR_FAILED);	
	}

	// Validate if the periodic msg. for this FilterID was started earlier.
	if (!IsFilterIDValid(ulFilterID))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
			m_pclsLog->Write("FilterMsg.cpp", "StopFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_FILTER_ID);
	}

	SetEvent(m_hSyncAccess);

	// Stop the filter in device if it were set earlier.
	/*jayasheela-changed the code bcz:if it is a block filter it wont enter into the if stmt
	  if ((ulDevFilterID != -1) && (enFilterType != J2534_FILTER_BLOCK))*/
	/* Ravi : Use the filter ID directly and removed the Block filter type check */
	if (ulFilterID != -1) 
	{
		if ((enJ2534Error = m_pclsDevice->vStopFilter(m_ulDevChannelID, ulFilterID)) 
						  != J2534_STATUS_NOERROR)
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
				m_pclsLog->Write("FilterMsg.cpp", "StopFilter()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(enJ2534Error);
		}
	}

	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, FILTERMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "StopFilter()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		return(J2534_ERR_FAILED);	
	}

	// Delete the filter
	Delete(ulFilterID);
	SetEvent(m_hSyncAccess);

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("FilterMsg.cpp", "StopFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: StopFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This is an override function that stops all the filters.
//-----------------------------------------------------------------------------
/* Ravi : Stop filter for all is used to clear all the activities done inthe DLL
and the firmware shall take care of deleting on its own when disconnect is received */
J2534ERROR CFilterMsg::StopFilter()

{
	char			szBuffer[FILTERMSG_ERROR_TEXT_SIZE];
	unsigned long	i;

	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, FILTERMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "StopFilter(All)", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		return(J2534_ERR_FAILED);	
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("FilterMsg.cpp", "StopFilter(All)", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Run through all the Filters and delete all of them.
	for (i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{
		// Delete the filter
		Delete(i);
	}

	SetEvent(m_hSyncAccess);

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("FilterMsg.cpp", "StopFilter(All)", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: Add
//	Input Params	: void
//	Output Params	: void
//	Description		: This function assigns a Msg. ID, adds message to 
//					  internal buffer and returns the FilterID to user.
//-----------------------------------------------------------------------------
/* Ravi : Removed the local place holder for the filter ID */
J2534ERROR CFilterMsg::Add(J2534_FILTER enFilterType, 
							   PASSTHRU_MSG *pstMask, 
							   PASSTHRU_MSG *pstPattern,
							   PASSTHRU_MSG *pstFlowControl,
							   unsigned long *pulFilterID)
{
	char			szBuffer[FILTERMSG_ERROR_TEXT_SIZE];
	unsigned long	ulFilterID;

	ulFilterID = *pulFilterID;

	if((ulFilterID < 1) && (ulFilterID > (FILTERMSG_LIST_SIZE+1)))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_EXCEEDED_LIMIT);
			m_pclsLog->Write("FilterMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_EXCEEDED_LIMIT);	
	}

	// Save Mask filter in our internal buffer.
	if ((m_stFilterList[ulFilterID].pstMask = new FILTERMSG_MSG) == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     "Could not create Object for Filter Mask");
		}
		return(J2534_ERR_FAILED);	
	}
	memcpy(m_stFilterList[ulFilterID].pstMask, pstMask, 
		   min(sizeof(FILTERMSG_MSG), sizeof(PASSTHRU_MSG)));

	// Save Pattern filter in our internal buffer.
	if ((m_stFilterList[ulFilterID].pstPattern = new FILTERMSG_MSG) == NULL)
	{
		delete m_stFilterList[ulFilterID].pstMask;
		m_stFilterList[ulFilterID].pstMask = NULL;
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     "Could not create Object for Filter Pattern");
		}
		return(J2534_ERR_FAILED);	
	}
	memcpy(m_stFilterList[ulFilterID].pstPattern, pstPattern, 
		   min(sizeof(FILTERMSG_MSG), sizeof(PASSTHRU_MSG)));

	// If the filter to be added is a FlowControl Filter.
	if (enFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		// Save FlowControl filter in our internal buffer.
		if ((m_stFilterList[ulFilterID].pstFlowControl = new FILTERMSG_MSG) == NULL)
		{
			delete m_stFilterList[ulFilterID].pstMask;
			m_stFilterList[ulFilterID].pstMask = NULL;
			delete m_stFilterList[ulFilterID].pstPattern;
			m_stFilterList[ulFilterID].pstPattern = NULL;
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("FilterMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
								 "Could not create Object for Filter FlowControl");
			}
			return(J2534_ERR_FAILED);	
		}
		memcpy(m_stFilterList[ulFilterID].pstFlowControl, pstFlowControl, 
			   min(sizeof(FILTERMSG_MSG), sizeof(PASSTHRU_MSG)));
	}

	// Save Filter Type.
	m_stFilterList[ulFilterID].enFilterType = enFilterType;


	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: Delete
//	Input Params	: void
//	Output Params	: void
//	Description		: This function removes the filter from the Database that 
//					  was added earlier.
//-----------------------------------------------------------------------------
J2534ERROR CFilterMsg::Delete(unsigned long ulFilterID)
{
	if (m_stFilterList[ulFilterID].pstMask != NULL)
	{
		delete m_stFilterList[ulFilterID].pstMask;
		m_stFilterList[ulFilterID].pstMask = NULL;
	}

	if (m_stFilterList[ulFilterID].pstPattern != NULL)
	{
		delete m_stFilterList[ulFilterID].pstPattern;
		m_stFilterList[ulFilterID].pstPattern = NULL;
	}

	if (m_stFilterList[ulFilterID].pstFlowControl != NULL)
	{
		delete m_stFilterList[ulFilterID].pstFlowControl;
		m_stFilterList[ulFilterID].pstFlowControl = NULL;
	}

	m_stFilterList[ulFilterID].enFilterType = J2534_FILTER_NONE;

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetNewFilterID
//	Input Params	: void
//	Output Params	: void
//	Description		: If all FilterIDs are used, returns 0 otherwise returns new
//					  FilterID to be used.
//-----------------------------------------------------------------------------
unsigned char CFilterMsg::GetNewFilterID()
{
	unsigned char	ucIdx;

	for (ucIdx = 1; ucIdx <= FILTERMSG_LIST_SIZE; ucIdx++)
	{
		if (m_stFilterList[ucIdx].enFilterType == J2534_FILTER_NONE)
			return(ucIdx);
	}
	
	return(0);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsFilterIDValid
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if the given FilterID is valid.
//-----------------------------------------------------------------------------
bool CFilterMsg::IsFilterIDValid(unsigned long ulFilterID)
{
	if (ulFilterID > 0 && ulFilterID <= FILTERMSG_LIST_SIZE)
	{
		if (m_stFilterList[ulFilterID].enFilterType != J2534_FILTER_NONE)
			return(true);
	} 
	
	return(false);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsListFull
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if the list to store Filter info. is full.
//-----------------------------------------------------------------------------
bool CFilterMsg::IsListFull()
{
	unsigned long ucIdx;

	for (ucIdx = 1; ucIdx <= FILTERMSG_LIST_SIZE; ucIdx++)
	{
		if (m_stFilterList[ucIdx].enFilterType == J2534_FILTER_NONE)
			return(false);
	}
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsFlowControlUnique
//	Input Params	: void
//	Output Params	: void
//	Description		: This functions iterates through all the current Filters
//					  and checks to see if the Flow Control ID is unique. If 
//					  it is unique, it returns true otherwise returns false.
//-----------------------------------------------------------------------------
bool CFilterMsg::IsFlowControlUnique(PASSTHRU_MSG *pstPattern,
									 PASSTHRU_MSG *pstFlowControl)
{
	bool				bUnique = true;
	unsigned long		i, j;

	// Run through all the Filters to see if the requested FLOW_CONTROL_FILTER is unique.
	for (i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{
		if (m_stFilterList[i].enFilterType == J2534_FILTER_FLOW_CONTROL)
		{
			if (m_stFilterList[i].pstFlowControl->ulDataSize == pstFlowControl->ulDataSize)
			{
				// Check all the Header bytes of given FlowControl Msg. to see 
				// if they match with the Filter already in Database.
				for (j = 0; j < m_stFilterList[i].pstFlowControl->ulDataSize; j++)
				{
					if (m_stFilterList[i].pstFlowControl->ucData[j] == 
						pstFlowControl->ucData[j])
					{
						if (bUnique)
							bUnique = false;
					}
					else
					{
						bUnique = true;
						break;
					}
				}
				if (!bUnique)
					return(false);
			}
				
			if (m_stFilterList[i].pstPattern->ulDataSize == pstPattern->ulDataSize)
			{
				// Check all the Header bytes of given Pattern Msg. to see 
				// if they match with the Filter already in Database.
				for (j = 0; j < m_stFilterList[i].pstPattern->ulDataSize; j++)
				{
					if (m_stFilterList[i].pstPattern->ucData[j] == pstPattern->ucData[j])
					{
						if (bUnique)
							bUnique = false;
					}
					else
					{
						bUnique = true;
						break;
					}
				}
				if (!bUnique)
					return(false);
			}
		}
	}
		
	return(bUnique);
}
//-----------------------------------------------------------------------------
//	Function Name	: IsMsgRequired
//	Input Params	: void
//	Output Params	: void
//	Description		: This function applies all the currently set filters for 
//					  and determines if the msg. is required. If returned true
//					  msg. is required (passed) otherwise not.
//-----------------------------------------------------------------------------
bool CFilterMsg::IsMsgRequired(PASSTHRU_MSG				*pstMsg,
							   FILTERMSG_CONFORM_REQ	*pConformReq)
{
	FILTERMSGCONFORM	enConformPass = FILTERMSG_CONFORM_NO;
	FILTERMSGCONFORM	enConformBlock = FILTERMSG_CONFORM_NO;
	FILTERMSGCONFORM	enConformFlowControl = FILTERMSG_CONFORM_NO;

	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, FILTERMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("FilterMsg.cpp", "IsMsgRequired()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		return(false);	
	}

	// Find out if the msg. conforms to all current Pass Filters if requested.
	if (pConformReq->bReqPass)
		enConformPass = MsgConform(pstMsg, J2534_FILTER_PASS);

	// Find out if the msg. conforms to all current Block Filter if requrested.
	if (pConformReq->bReqBlock)
		enConformBlock = MsgConform(pstMsg, J2534_FILTER_BLOCK);

	// Find out if the msg. conforms to all current Block Filter if requested.
	if (pConformReq->bReqFlowControl)
		enConformFlowControl = MsgConform(pstMsg, J2534_FILTER_FLOW_CONTROL);

	// Check the results of PASS. BLOCK and FLOW_CONTROL filters to decide
	// as per J2534 standard whether the message is required or not.
	if (((enConformPass == FILTERMSG_CONFORM_YES) ||
		 (enConformFlowControl == FILTERMSG_CONFORM_YES)) &&
		(enConformBlock != FILTERMSG_CONFORM_YES))
	{
		SetEvent(m_hSyncAccess);
		return(true);
	}
	SetEvent(m_hSyncAccess);
	return(false);
}

//-----------------------------------------------------------------------------
//	Function Name	: MsgConform
//	Input Params	: void
//	Output Params	: void
//	Description		: Run Filters on a given msg. and return whether the msg. 
//					  conforms to the given Filter type or not.
//-----------------------------------------------------------------------------
FILTERMSGCONFORM CFilterMsg::MsgConform(PASSTHRU_MSG *pstMsg, 
										J2534_FILTER enFilterType)
{
	FILTERMSGCONFORM	enFilterConform = FILTERMSG_CONFORM_NO;
	unsigned long		i, j;

	// Run through all the Filters
	for (i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{
		if (m_stFilterList[i].enFilterType == enFilterType)
		{
	//		if (m_stFilterList[i].pstPattern->ulDataSize <= pstMsg->ulDataSize)
			{
				for (j = 0; j < m_stFilterList[i].pstPattern->ulDataSize; j++)
				{
					if ((m_stFilterList[i].pstMask->ucData[j] & pstMsg->ucData[j]) ==
						(m_stFilterList[i].pstMask->ucData[j] & m_stFilterList[i].pstPattern->ucData[j]))
					{
						if (enFilterConform != FILTERMSG_CONFORM_YES)
							enFilterConform = FILTERMSG_CONFORM_YES;
					}
					else
					{
						enFilterConform = FILTERMSG_CONFORM_NO;
						break;
					}
				}
				if (enFilterConform == FILTERMSG_CONFORM_YES)
					return(FILTERMSG_CONFORM_YES);
			}
		}
	}
		
	return(enFilterConform);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsFlowControlFilterSet
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if any flow control filter being set.
//-----------------------------------------------------------------------------
bool CFilterMsg::IsFlowControlFilterSet()
{
	unsigned long ulFilterID;

	for (ulFilterID = 1; ulFilterID <= FILTERMSG_LIST_SIZE; ulFilterID++)
	{
		if (m_stFilterList[ulFilterID].enFilterType == J2534_FILTER_FLOW_CONTROL)
			return(true);
	}
	
	return(false);
}
//-----------------------------------------------------------------------------
//	Function Name	: GetFCMsgID
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if any flow control filter being set.
//-----------------------------------------------------------------------------
bool CFilterMsg::GetFCMsgID(PASSTHRU_MSG pstRxMsg, unsigned long *ulFCMsgId,
							unsigned char * ucFCMsgData,unsigned long *ulFCMsgTxflags,
							unsigned long * ulpos)
{
	bool bReturn = FALSE;
	if(0!=ulfilterindex)
	{
		*ulpos=0;
		*ulFCMsgId = ntohl(ulong(m_stFilterList[ulfilterindex].pstFlowControl->ucData[0]));

		if(ulCANIDsize==5)
		{
			ucFCMsgData[(*ulpos)++] = m_stFilterList[ulfilterindex].pstFlowControl->ucData[4];
		}
		//Copy TX flags
		*ulFCMsgTxflags = m_stFilterList[ulfilterindex].pstFlowControl->ulTxFlags;

		bReturn = TRUE;
	}
	return bReturn;
}

//-----------------------------------------------------------------------------
//	Function Name	: SearchFlowControlFilter
//	Input Params	: Tx message
//	Output Params	: True or false
//	Description		: Checks to see if any flow control filter being set for that 
//					  message id which needs to be trasmit
//-----------------------------------------------------------------------------
bool CFilterMsg::SearchFlowControlFilter(PASSTHRU_MSG	*pstTxMsg)
{
	bool bFoundFCMsg=FALSE;
	bool bTxFrameExt = FALSE;

	// Run through all the Filters and find the Flow control message
	if(pstTxMsg->ulTxFlags & ISO15765_ADDR_TYPE)
	{
		bTxFrameExt = TRUE;
	}
	for (unsigned int i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{
		if (m_stFilterList[i].enFilterType == J2534_FILTER_FLOW_CONTROL)
		{
			if((TRUE == bTxFrameExt) && ((m_stFilterList[i].pstFlowControl->ulTxFlags) & ISO15765_ADDR_TYPE ))
			{
				for (unsigned int j = 0; j < 5; j++)
				{
					if ((pstTxMsg->ucData[j] == m_stFilterList[i].pstFlowControl->ucData[j]))
					{
						if(4==j)
						{
							bFoundFCMsg = TRUE;
						}								 
					}
					else
					{
						break;
					}
				}
				if(bFoundFCMsg)
				{
					break;
				}
			}
			else if((FALSE == bTxFrameExt) && (!((m_stFilterList[i].pstFlowControl->ulTxFlags) & ISO15765_ADDR_TYPE )))
			{
				//check extended address bit in Tx flags of set filter 
				for (unsigned int j = 0; j < 4; j++)
				{
					if ((pstTxMsg->ucData[j] == m_stFilterList[i].pstFlowControl->ucData[j]))
					{
						if(3==j)
						{
							bFoundFCMsg = TRUE;
						}								 
					}
					else
					{
						break;
					}
				}
				if(bFoundFCMsg)
				{
					break;
				}
			}
		}
	}
	return(bFoundFCMsg);
}
//-----------------------------------------------------------------------------
//	Function Name	: GetFCMsgID
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if any flow control filter being set.
//-----------------------------------------------------------------------------
bool CFilterMsg::SearchPatternId(PASSTHRU_MSG *pstRxMsg)
{
	unsigned long	i, j;
	bool bPattrenMatchFound;
	ulfilterindex=0;
	ulCANIDsize=0;
	// Run through all the Filters and find the Patren Msg filter for the FF received
	bPattrenMatchFound = FALSE;

	for (i = 1; i <= FILTERMSG_LIST_SIZE; i++)
	{		
		if (m_stFilterList[i].enFilterType == J2534_FILTER_FLOW_CONTROL)
		{
			/*check extended address bit in Tx flags */
			if(((m_stFilterList[i].pstFlowControl->ulTxFlags) & ISO15765_ADDR_TYPE) )
			{
				for (j = 0; j < 5; j++)
				{
					if (pstRxMsg->ucData[j] == m_stFilterList[i].pstPattern->ucData[j])
					{
						if(4 == j)
						{
							bPattrenMatchFound  = TRUE;
						}
					}
					else
					{
						break;
					}
				}
				if(bPattrenMatchFound)
				{
					break;
				}
			}			
			/*check extended address bit in Tx flags */
			else 
			{
				for (j = 0; j < 4; j++)
				{
					if (pstRxMsg->ucData[j] == m_stFilterList[i].pstPattern->ucData[j])
					{
						if(3 == j)
						{
							bPattrenMatchFound = TRUE;
						}
					}
					else
					{
						break;
					}

				}
				if(bPattrenMatchFound)
				{
					break;
				}
			}
		}
	}
	if(bPattrenMatchFound)
	{
		//update Rxstatus flag values-7th bit is ISO15765_ADDR_TYPE and 8th bit is CAN_29BIT_ID
		// Ravi : I assume that its 11 bit or 29bit is set by Firmware. Hence commented
		//pstRxMsg->ulRxStatus |= (m_stFilterList[i].pstPattern->ulTxFlags & 0x00000100);
		if(j==5)
		{
			pstRxMsg->ulRxStatus |= ISO15765_ADDR_TYPE;
		}
		ulfilterindex = i;
		ulCANIDsize=j;

	}
	return bPattrenMatchFound;
}
