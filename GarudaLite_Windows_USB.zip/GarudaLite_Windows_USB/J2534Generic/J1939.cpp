// J1939.cpp: implementation of the J1939 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "J1939.h"


void OnJ1939RxMessage(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid);
void OnReceiveJ1939RxStatus(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid);


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
//	Function Name	: CJ1939
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CISO15765 class
//-----------------------------------------------------------------------------
CJ1939::CJ1939(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
			CProtocolBase(pclsDevice, pclsDebugLog)
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "CJ1939()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "CJ1939()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	m_bLoopback = FALSE;
	m_addressClaimed = FALSE;
	m_uchClaimedAddress = 0xFF;
	m_ulJ1939_T1 = 750;
	m_ulJ1939_T2 = 1250;
	m_ulJ1939_T3 = 1250;
	m_ulJ1939_T4 = 1050;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CJ1939
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CISO15765 class
//-----------------------------------------------------------------------------
CJ1939::~CJ1939()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "~CJ1939()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "~CJ1939()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vConnect(J2534_PROTOCOL	enProtocolID,
								unsigned long   ulFlags,
								unsigned long	ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
								DEVICEBASE_CALLBACK_J1939_SETRXSTATUS_FUNC psetRxstatusfnCallback,
								LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vConnect()",enProtocolID, DEBUGLOG_TYPE_COMMENT, "Start");
	}

	m_enJ1939Protocol = enProtocolID;


	if((enProtocolID == J1939_PS) || (enProtocolID == J1939_CH1) || (enProtocolID == J1939_CH2))
	{
 		if (ulBaudRate != J1939_DATA_RATE_DEFAULT)
			
		{
			return(J2534_ERR_INVALID_BAUDRATE);
		}
	}

	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID, ulFlags, ulBaudRate,
												OnJ1939RxMessage,NULL,
												OnReceiveJ1939RxStatus,this))
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vConnect()",m_enJ1939Protocol, DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vConnect()",m_enJ1939Protocol,DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	if((enProtocolID == J1939_PS) || (enProtocolID == J1939_CH1) || (enProtocolID == J1939_CH2))
	{
		
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vDisconnect()
{
	char			szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vDisconnect()",m_enJ1939Protocol,DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vDisconnect()",m_enJ1939Protocol, DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "CJ1939()",m_enJ1939Protocol, DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vReadMsgs(PASSTHRU_MSG	*pstPassThruMsg,
								unsigned long	*pulNumMsgs,
								unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vReadMsgs()",m_enJ1939Protocol, DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vReadMsgs()",m_enJ1939Protocol, DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		if (enJ2534Error == J2534_ERR_BUFFER_EMPTY)
		{
			if (((m_pclsFilterMsg == NULL) || (!m_pclsFilterMsg->IsFlowControlFilterSet())))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NO_FLOW_CONTROL);
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					m_pclsLog->Write("J1939.cpp", "vReadMsgs()",m_enJ1939Protocol, DEBUGLOG_TYPE_ERROR, 
									 szBuffer);
				}
				return(J2534_ERR_NO_FLOW_CONTROL);
			}
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vReadMsgs()",m_enJ1939Protocol, DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
								unsigned long	*pulNumMsgs,
								unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vWriteMsgs()",m_enJ1939Protocol, DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
 		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != m_enJ1939Protocol)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("J1939.cpp", "vWriteMsgs()",m_enJ1939Protocol,
								  DEBUGLOG_TYPE_ERROR, szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		//Checking whether data > 8 bytes or not
		if ((pstPassThruMsg + ulIdx1)->ulDataSize > J1939_MSG_SIZE_MAX_SF)
		{
			//If not claimed, return J2534_ERR_ADDRESS_NOT_CLAIMED.
			//If claimed,check source address and claimed address are matching or not
			if(!m_addressClaimed || ((pstPassThruMsg + ulIdx1)->ucData[3] != m_uchClaimedAddress))			
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NO_FLOW_CONTROL);
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					m_pclsLog->Write("J1939.cpp", "vWriteMsgs()",m_enJ1939Protocol,
						DEBUGLOG_TYPE_ERROR, szBuffer);
				}

				return(J2534_ERR_ADDRESS_NOT_CLAIMED);
			}
		}

		// Check if msg. format is valid.
		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("J1939.cpp", "vWriteMsgs()",m_enJ1939Protocol,
								  DEBUGLOG_TYPE_ERROR, szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}
	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vWriteMsgs()",m_enJ1939Protocol,DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vStartPeriodicMsg(PASSTHRU_MSG	*pstPassThruMsg,
										unsigned long	*pulMsgID,
										unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != m_enJ1939Protocol)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}
	/* By comparing ulDataSize with ISO15765_MSG_SIZE_MAX_SF
	   will result to failure in J1699 test so it has been changed to 
	   PERIODICMSG_MSGLEN_MAX.
	   As per J2534 we need to compare ulDataSize with ISO15765_MSG_SIZE_MAX_SF
	   need to take decision.for the time being we kept as it is to make it 
	   work with J1699 application.*/
	//if ((pstPassThruMsg->ulDataSize > ISO15765_MSG_SIZE_MAX_SF))
	if ((pstPassThruMsg->ulDataSize > PERIODICMSG_MSGLEN_MAX))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	/*if ((pstPassThruMsg->ulDataSize == PERIODICMSG_MSGLEN_MAX))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO15765.cpp", "vStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
	//	return(J2534_ERR_INVALID_MSG);
	}*/

	if (pstPassThruMsg ->ulDataSize > PERIODICMSG_MSGLEN_MAX && 
			!m_addressClaimed)
	{
		return(J2534_ERR_ADDRESS_NOT_CLAIMED);

	}
	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_ADDRESS_NOT_CLAIMED);
	}

	
	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vUpdatePeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vUpdatePeriodicMsg(PASSTHRU_MSG	*pstPassThruMsg,
										unsigned long	ulMsgID,
										unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != m_enJ1939Protocol)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vUpdatePeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}
	/* By comparing ulDataSize with ISO15765_MSG_SIZE_MAX_SF
	   will result to failure in J1699 test so it has been changed to 
	   PERIODICMSG_MSGLEN_MAX.
	   As per J2534 we need to compare ulDataSize with ISO15765_MSG_SIZE_MAX_SF
	   need to take decision.for the time being we kept as it is to make it 
	   work with J1699 application.*/
	//if ((pstPassThruMsg->ulDataSize > ISO15765_MSG_SIZE_MAX_SF))
	if ((pstPassThruMsg->ulDataSize > PERIODICMSG_MSGLEN_MAX))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	/*if ((pstPassThruMsg->ulDataSize == PERIODICMSG_MSGLEN_MAX))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("ISO15765.cpp", "vStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
	//	return(J2534_ERR_INVALID_MSG);
	}*/

	if (pstPassThruMsg ->ulDataSize > PERIODICMSG_MSGLEN_MAX && !m_addressClaimed)
			
	{
		return(J2534_ERR_ADDRESS_NOT_CLAIMED);

	}
	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vUpdatePeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_ADDRESS_NOT_CLAIMED);
	}


	
	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vUpdatePeriodicMsg(pstPassThruMsg,
														 ulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vUpdatePeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vUpdatePeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CJ1939::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CJ1939::vStartMsgFilter(J2534_FILTER	enumFilterType,
									   PASSTHRU_MSG		*pstMask,
									   PASSTHRU_MSG		*pstPattern,
									   PASSTHRU_MSG		*pstFlowControl,
									   unsigned long	*pulFilterID)
{
	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// NOTE : If request is for PASS filter, try setting this filter in device 
	//		  as well. If the device cannot set and returns an 
	//		  error, ignore it. Some device drivers may not be able to set 
	//		  hardware filters. Anyway it will be filtered by our software
	//		  filter.  

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}
	// Check Filter Type.
	if ((enumFilterType != J2534_FILTER_PASS) && (enumFilterType != J2534_FILTER_BLOCK))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_FILTER_ID);
	}
	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != m_enJ1939Protocol) ||
		(pstPattern->ulProtocolID != m_enJ1939Protocol))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check Filter Type.

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPattern, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	if (!IsMsgValid(pstMask, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}
	
	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CJ1939::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[J1939_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("J1939.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("J1939.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function. This function is used to read
//					  and write all the protocol hardware and software
//					  configuration parameters for a given enumIoctlID.
//-----------------------------------------------------------------------------
J2534ERROR  CJ1939::vIoctl(J2534IOCTLID enumIoctlID,
							  void *pInput,
							  void *pOutput)
{
	J2534ERROR	enumJ2534Error;
	char	szBuffer[ISO15765_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumIoctlID);
		m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			"Start");
	}
	// IoctlID values
	switch(enumIoctlID)
	{
		case GET_CONFIG:			// Get configuration
			enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);
			break;
		case SET_CONFIG:			// Set configuration
			enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);
			break;
		case CLEAR_TX_BUFFER:		// Clear all messages in its transmit queue
			if(m_pclsTxCircBuffer != NULL)
			{
			m_pclsTxCircBuffer->ClearBuffer();
			enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER, NULL, NULL);
			}
			break;
		case CLEAR_RX_BUFFER:		// Clear all messages in its receive queue
			if(m_pclsRxCircBuffer != NULL)
			{
			m_pclsRxCircBuffer->ClearBuffer();
			enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER, NULL, NULL);
			}
			break;
		case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
			if (m_pclsPeriodicMsg != NULL)
			{
				delete m_pclsPeriodicMsg;
				m_pclsPeriodicMsg = NULL;
			}
			enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS, NULL, NULL);
			break;
		case CLEAR_MSG_FILTERS:		// Clear all message filters
			if (m_pclsFilterMsg != NULL)
			{
				delete m_pclsFilterMsg;
				m_pclsFilterMsg = NULL;
			}
			enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS, NULL, NULL);
			break;

		case PROTECT_J1939_ADDR:		// Clear all message filters
			if (pInput == NULL)
			{
				enumJ2534Error = J2534_ERR_NULLPARAMETER;
			}
			else
			{
				if(((SBYTE_ARRAY*)pInput)->ulNumOfBytes != 9)
				{
					enumJ2534Error = J2534_ERR_INVALID_IOCTL_VALUE;
				}
				else if( (((SBYTE_ARRAY*)pInput)->pucBytePtr[0] == 0xFE) || (((SBYTE_ARRAY*)pInput)->pucBytePtr[0] == 0xFF))
				{
					enumJ2534Error = J2534_ERR_INVALID_IOCTL_VALUE;
				}
				else
				{
					enumJ2534Error = CProtocolBase::vIoctl(PROTECT_J1939_ADDR, pInput, NULL);
				}
			}
			break;			

		default:					// Others not supported
			enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
			break;
	}
	
	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
		if (J2534_STATUS_NOERROR != enumJ2534Error)
		{
			m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		else
		{
			m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
							 szBuffer);
		}
	}
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			"End");
	}	
	return(enumJ2534Error);
}


//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CJ1939::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[J1939_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;

	/* Ravi : Changed the structure of code */
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "Parameter is 0x%02X", pSconfig->Parameter);
			m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
		switch (pSconfig->Parameter)
		{
		
		case DATA_RATE:			// Data Rate
			
			//J2534 Specification Supports only 500kbps. To support Garuda J2534 baudrate > 0.5 Mbps && <= 1Mbps
			if ((pSconfig->ulValue < 5) || (pSconfig->ulValue > 1000000))
			{
				enumJ2534Error = J2534_ERR_INVALID_IOCTL_VALUE;
			}
			else
			{
				enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG, pSconfig, NULL);
			}
			break;
			
		case LOOPBACK:			// Loopback
			if (pSconfig->ulValue > 1)
			{
				enumJ2534Error = J2534_ERR_INVALID_IOCTL_VALUE;
			}
			else
			{
				enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG, pSconfig, NULL);
				if(J2534_STATUS_NOERROR == enumJ2534Error)
				{
					m_bLoopback = pSconfig->ulValue;
				}
			}
			break;
		case J1939_T1:
			{
				m_ulJ1939_T1 = pSconfig->ulValue;
				enumJ2534Error = J2534_STATUS_NOERROR;
			}
			break;
		case J1939_T2:
			{
				m_ulJ1939_T2 = pSconfig->ulValue;
				enumJ2534Error = J2534_STATUS_NOERROR;
			}
			break;
		case J1939_T3:
			{
				m_ulJ1939_T3 = pSconfig->ulValue;
				enumJ2534Error = J2534_STATUS_NOERROR;
			}
			break;
		case J1939_T4:
			{
				m_ulJ1939_T4 = pSconfig->ulValue;
				enumJ2534Error = J2534_STATUS_NOERROR;
			}
			break;
		case J1939_BRDCST_MIN_DELAY:
			{
				m_ulJ1939_BRDCST_MIN_DELAY = pSconfig->ulValue;
				enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG, pSconfig, NULL);
			}
			break;
		default:
			enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		}


		if (J2534_STATUS_NOERROR != enumJ2534Error) // If something is wrong
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
			break;
		}

		pSconfig++;
	}

	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CJ1939::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char			szBuffer[J1939_ERROR_TEXT_SIZE];

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;
	
	/* Ravi : Changed the structure of code */
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "Parameter is 0x%02X", pSconfig->Parameter);
			m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate
				enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG, pSconfig, NULL);
				break;

			case LOOPBACK:		// Loopback
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														  pSconfig,
														  NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				//pSconfig->ulValue = m_bLoopback;
				break;
		case J1939_T1:
			{
				pSconfig->ulValue  = m_ulJ1939_T1;
			}
			break;
		case J1939_T2:
			{
				pSconfig->ulValue  = m_ulJ1939_T2;
			}
			break;
		case J1939_T3:
			{
				pSconfig->ulValue  = m_ulJ1939_T3;
			}
			break;
		case J1939_T4:
			{
				pSconfig->ulValue  = m_ulJ1939_T4;
			}
			break;
		case J1939_BRDCST_MIN_DELAY:
			{
				pSconfig->ulValue  = m_ulJ1939_BRDCST_MIN_DELAY;				
			}
			break;

			default:
				enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		}

		if (J2534_STATUS_NOERROR != enumJ2534Error) // If something is wrong
		{
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				m_pclsLog->Write("J1939.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
			break;
		}
		pSconfig++;
	}

	return(enumJ2534Error);
}
//-----------------------------------------------------------------------------
//	Function Name	: OnReceiveJ1939RxStatus
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  of Address Claim or Address Lost Indication.
//-----------------------------------------------------------------------------
void OnReceiveJ1939RxStatus(PASSTHRU_MSG *pstPassThruMsg, 
							LPVOID pVoid)
{
	CJ1939					*pclsJ1939;
	unsigned long RX_STATUS_ADDRESS_CLAIMED = 0x10000;
	unsigned long RX_STATUS_ADDRESS_LOST = 0x20000;
	ULONG ulDataSize;
	char	szBuffer[J1939_ERROR_TEXT_SIZE];	
	
	pclsJ1939 = (CJ1939 *) pVoid;
	
	// Check for NULL pointer.
	if (pclsJ1939 == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("J1939.cpp", "OnJ1939RxMessage()", 
				DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}

	//Rx Status: 
	//16th bit - 1: Address Claim, 0: No indication of address claim
	//17th bit - 1: Address Lost, 0: No indication of Address lost

	//Checking for Address Claimed or not
	if((pstPassThruMsg->ulRxStatus & RX_STATUS_ADDRESS_CLAIMED) ==  RX_STATUS_ADDRESS_CLAIMED)
	{
		pclsJ1939->m_addressClaimed = true;
		pclsJ1939->m_uchClaimedAddress = pstPassThruMsg->ucData[0];
	}

	//Checking for Address Lost or not
	if((pstPassThruMsg->ulRxStatus & RX_STATUS_ADDRESS_LOST) ==  RX_STATUS_ADDRESS_LOST)
	{
		pclsJ1939->m_addressClaimed = false;
		pclsJ1939->m_uchClaimedAddress = 0xFF;
	}
				  
	
	if(pclsJ1939->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
		(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
		pstPassThruMsg->ulDataSize))==FALSE)
	{
		TRACE("FAIL:Write Circular buf (NORMAL)\n");
	}
	else
	{
		TRACE("pass:Write Circular buf (NORMAL)\n");
	}
	
	return;
}

//-----------------------------------------------------------------------------
//	Function Name	: OnJ1939RxMessage
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  J1939 messages.
//-----------------------------------------------------------------------------
void OnJ1939RxMessage(PASSTHRU_MSG *pstPassThruMsg, 
						 LPVOID pVoid)
{
	CJ1939					*pclsJ1939;
	FILTERMSG_CONFORM_REQ	stConformReq;

	//FILTERMSG_CONFORM_REQ	stConformReq;
	ULONG ulDataSize;
	char	szBuffer[J1939_ERROR_TEXT_SIZE];	

	pclsJ1939 = (CJ1939 *) pVoid;

	// Check for NULL pointer.
	if (pclsJ1939 == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("J1939.cpp", "OnJ1939RxMessage()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}
	
	//Checking whether Msg Id is 29 bit or not
	if ((pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_CAN29BIT) == 0)
	{
		return;
	}

	//Discard the messages, if datasize > 12 (4 Byte Header + 8 Data Bytes) and address is not claimed
	if((pstPassThruMsg->ulDataSize > 13) && !pclsJ1939->m_addressClaimed )
	{
		return;
	}

	/* Ravi : Integrated the code */
	// Check if this is a Tx done indication.
	if (pstPassThruMsg->ulRxStatus & 0x08)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("J1939.cpp", "OnJ1939RxMessage()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx Done CALLBACK");
		}

		ulDataSize = pstPassThruMsg->ulDataSize;
		pstPassThruMsg->ulDataSize = 5;
		pstPassThruMsg->ulExtraDataIndex = 0;

		// Write status to Log File.
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "pstPassThruMsg->ulTxFlags 0x%X", pstPassThruMsg->ulTxFlags);
			CProtocolBase::m_pclsLog->Write("ISO15765.cpp", "OnISO15765Rx()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
			sprintf(szBuffer, "pstPassThruMsg->ulDataSize 0x%X", pstPassThruMsg->ulDataSize);
			CProtocolBase::m_pclsLog->Write("ISO15765.cpp", "OnISO15765Rx()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}

		// Enqueue to Circ Buffer.
		if(pclsJ1939->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize))==FALSE)
		{
			TRACE("FAIL:Write Circular buf (TXDONE)\n");
		}
		else
		{
			TRACE("pass:Write Circular buf (TXDONE)\n");
		}

		return;
	}

	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CISO15765.cpp", "OnISO15765Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}

		if (pclsJ1939->m_bLoopback == false)
			return;

		pstPassThruMsg->ulDataSize = ulDataSize;
		pstPassThruMsg->ulExtraDataIndex = pstPassThruMsg->ulDataSize;

		// Enqueue to Circ Buffer.
		if(pclsJ1939->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
			(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
			pstPassThruMsg->ulDataSize))==FALSE)
		{
			TRACE("FAIL:Write Circular buf (LOOPBACK)\n");
		}
		else
		{
			TRACE("pass:Write Circular buf (LOOPBACK)\n");
		}
		return;
	}
	
	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("J1939.cpp", "OnJ1939RxMessage()", 
						 DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK");
	}

	// Apply Filters and see if msg. is required.
	if (pclsJ1939->m_pclsFilterMsg != NULL)
	{
		if(pstPassThruMsg->ulDataSize > 13)
		{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;

		if (pclsJ1939->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
			{
				CProtocolBase::m_pclsLog->Write("J1939.cpp", "OnJ1939RxMessage()",
					DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK PreEnd");
			}
			
			// Enqueue to Circ Buffer.
			if(pclsJ1939->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
				(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
				pstPassThruMsg->ulDataSize))==FALSE)
			{
				TRACE("FAIL:Write Circular buf (NORMAL)\n");
			}
			else
			{
				TRACE("pass:Write Circular buf (NORMAL)\n");
			}
		}
		}
		else
		{
			
			if(pclsJ1939->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
				(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
				pstPassThruMsg->ulDataSize))==FALSE)
			{
				TRACE("FAIL:Write Circular buf (NORMAL)\n");
			}
			else
			{
				TRACE("pass:Write Circular buf (NORMAL)\n");
			}
		}
	}
	return;
}
//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CJ1939::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter)
{
	if (!bFilter)
	{
		if ((pstPassThruMsg->ulDataSize < J1939_MSG_SIZE_MIN) || 
			(pstPassThruMsg->ulDataSize > J1939_MSG_SIZE_MAX))
		{
			return(false);
		}
		
		if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) == 0)
		{
			return(false);
		}
		
	}
	else
	{
		if ((pstPassThruMsg ->ulDataSize > PERIODICMSG_MSGLEN_MAX) && !m_addressClaimed)			
			return(J2534_ERR_ADDRESS_NOT_CLAIMED);		
	}

	return(true);

}