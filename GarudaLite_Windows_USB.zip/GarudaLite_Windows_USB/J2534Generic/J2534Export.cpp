/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J2534Export.cpp
 Description			: This is the main header file for J2534
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 29, 2008	Chakravarthy				Initial Version


_______________________________________________________________________________
******************************************************************************/

#include "StdAfx.h"
#include "J2534Generic.h"
#include "J2534.h"
#include "..\DeviceOEMTool\StnDevice.h"
//#include "..\DeviceOEMTool\StnDevice.h"
#include "ProtocolManager.h"

/*Global Variable Declaration*/
extern CJ2534GenericApp theApp;
extern CDebugLog		gclsLog;
CProtocolManager		gclsProtocolManager(&gclsLog);
CDeviceBase		*gpclsDevice = NULL;
unsigned long   gulDeviceID = 0;

/* Used to log the ENTER and EXIT of each API */
/* Should be defined alswys bcz flag will take care of log data*/
#ifndef J2534API_LOG
	#define J2534API_LOG                       
#endif

#ifdef J2534API_LOG
	FILE *tempFile;
#endif

BOOL LogData ;
CString gpcLogPath;
/*-----------------------------------------------------------------------------
	Function Name	: PassThruOpen()
	Input Params	: None
					  
	Output Params	: None

	Return			: Returns an Error Status.
	Description		: This function opens connection to a device.
					  This is a very first function that a user must call
					  before using any other exported functions.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR WINAPI PassThruOpen(void *pName, 
										  unsigned long *pulDeviceID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char				szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR			enJ2534Error;

	LogData = false;

	SetPathForLog();
	IsDebugLogEnable();
#ifdef J2534API_LOG
	if(LogData)
	{
		if((tempFile = fopen(gpcLogPath,"w"))!= NULL)
		{
			fprintf(tempFile,"-------------------------------------------------------------------------------------------");
			fprintf(tempFile,"\n\n");
			fprintf(tempFile,"%lu ",GetTickCount());
			fprintf(tempFile,"PassThruOpen-ENTER");
			fprintf(tempFile,"\tDeviceID (Not Assigned):0x%X",*pulDeviceID);
		}
	}
#endif	
	
	//gclsLog.Open("C:\\Log.txt",DEBUGLOG_TYPE_APPEND);


	// Log when entered the function.
	if(gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_COMMENT, 
					  "Start");
	}
	
	// Error out if J2534 Registry for the device is not read.
	if (!theApp.m_bRegistryRead)
	{
		enJ2534Error = J2534_ERR_FAILED;
		if(gclsLog.m_pfdLogFile)
		{
			gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_ERROR, 
						  "Registry not available or incorrect entries");
		}	
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}
#endif
		// Set right text to be retreived when PassThruGetLastError() called.
		return (enJ2534Error);
	}

	// Check if Device is already open.
	if (gpclsDevice != NULL)
	{
		enJ2534Error = J2534_ERR_DEVICE_IN_USE;
		if (!gpclsDevice->vIsDeviceConnected())
		{
			enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
			if(gclsLog.m_pfdLogFile)
			{
				sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
				gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_ERROR, 
					szBuffer);
			}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}
#endif
			return (enJ2534Error);
		}
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}
#endif
		return (enJ2534Error);
	}

	// Check for NULL pointers
	if (pulDeviceID == NULL)
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}
#endif
		return (enJ2534Error);
	}
	
	/*Create a device object for communication*/
	//gpclsDevice = new CDeviceOEMTool(&gclsLog);
	gpclsDevice = new CStnDevice(&gclsLog);

	// Check if Device Object is created.
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_FAILED;
		if(gclsLog.m_pfdLogFile)
		{
			gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_ERROR, 
						  "Device Innova not created");
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}
#endif
		return(enJ2534Error);
	}
	// Open the Device Connection and return the Device ID otherwise error out.
	if ((enJ2534Error = gpclsDevice->vOpenDevice()) == J2534_STATUS_NOERROR)
	{
		// Return Device ID and set the Device Open flag.
		gulDeviceID++;
		*pulDeviceID = gulDeviceID;
	}
	else
	{
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		delete gpclsDevice;
		gpclsDevice = NULL;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}
#endif
		return(enJ2534Error);
	}
	// Log when exited the function.
	if(gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruOpen()", DEBUGLOG_TYPE_COMMENT, 
					  szBuffer);
	}
	//Jayasheela-implemeted session management
	gpclsDevice->vSessionCommand(1);

	/*if(enJ2534Error != J2534_STATUS_NOERROR)
	{
		return enJ2534Error;
	}*/

#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tDeviceID:0x%X",*pulDeviceID);
	}	
#endif
	return enJ2534Error;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruClose()
	Input Params	: None
					  
	Output Params	: None

	Return			: Returns an Error Status.
	Description		: This function closes connection to a device.
					  This is the very last function that a user must call
					  before the application exits.
---------------------------------------------------------------------------*/
extern "C" J2534ERROR WINAPI PassThruClose(unsigned long ulDeviceID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char				szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	int nProtObjects	 =	0;
	J2534ERROR			enJ2534Error = J2534_STATUS_NOERROR;

#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\n\n");
		fprintf(tempFile,"%lu ",GetTickCount());
		fprintf(tempFile,"PassThruClose-ENTER");
		fprintf(tempFile,"\tDeviceID:0x%X",ulDeviceID);
	}
#endif
	// Log when entered the function.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruClose()", DEBUGLOG_TYPE_COMMENT, 
					  "Start");
	}

	// Check for invalid Device ID
	if ((ulDeviceID != gulDeviceID) || (gpclsDevice == NULL))
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruClose()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected(FALSE))
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruClose()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
		return (enJ2534Error);
	}

	// In case user did not call disconnect prior to calling PassThruClose(),
	// disconnect from all the actively connected channels first
	for (nProtObjects = 0; nProtObjects < PROTOCOLMANAGER_OBJ_LIST_SIZE; nProtObjects++)
	{
		if (gclsProtocolManager.m_pclsProtocolObject[nProtObjects] != NULL)
		{
			gclsProtocolManager.m_pclsProtocolObject[nProtObjects]->vDisconnect();

			// Delete all the Protocol Objects that were created.
			gclsProtocolManager.DeleteProtocolObj(nProtObjects);
		}
	}

	//Jayasheela-implemeted session management
	gpclsDevice->vSessionCommand(0);

	/*if(enJ2534Error != J2534_STATUS_NOERROR)
	{
		return enJ2534Error;
	}*/

	gpclsDevice->vCloseDevice();
	// Delete Device Object.
	delete gpclsDevice;
	gpclsDevice = NULL;
	gulDeviceID = 0;

	// Log when exited the function.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruClose()", DEBUGLOG_TYPE_COMMENT, 
					  szBuffer);
	}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fclose(tempFile);
	}	
#endif

	//gclsLog.Close();
	return enJ2534Error;
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruConnect()
	Input Params	: ulChannelNum - Used for multiple ch. of same protocol.
					  (This parameter is taken off of the specification.
					  Therefore, on the header file, this value is 
					  hardcoded to 1.)
					  enumProtocolID - ProtocolID of Protocol to be connected.
					  ulTxMsgBuffSize - Transmit Msg. Buffer Size.
					  ulRxMsgBuffSize - Receive Msg. Buffer Size (size of 
										circular buffer.
					  (This buffer size parameters are taken off of the 
					  specification.
					  Therefore, on the header file, this value is 
					  hardcoded to 4096.)
					  ulFlags - Flags used for connection, normally set to zero.
					  
	Output Params	: pulChannelID - Channel ID created by this dll. This is
									 returned to user for all future reference.

	Return			: Returns an Error Status.
	Description		: This is an exported API to connect to a device.
					  This is a very first function that a user must call
					  before using any other exported functions.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruConnect(unsigned long ulDeviceID,
											  J2534_PROTOCOL enumProtocolID,
											  unsigned long ulFlags,
											  unsigned long ulBaudRate,
											  unsigned long *pulChannelID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char		szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error ;
	unsigned long	ulCANIDsupport, ulCANIDtype,ulChecksumFlag;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruConnect-ENTER");
	fprintf(tempFile,"\tDeviceID:0x%X",ulDeviceID);
	fprintf(tempFile,"\tProtocolID:0x%X",	enumProtocolID);
	fprintf(tempFile,"\tConnectFlags:0x%X ",ulFlags);
	fprintf(tempFile,"\tBaudRate:0x%X",ulBaudRate);
	}
#endif	
	/*jayasheela-check for SWCAN and SWCAN_ISO15765*/
	if(0x00008008==enumProtocolID)
		enumProtocolID=(J2534_PROTOCOL)0x00000088;

	else if(0x00008007==enumProtocolID)
		enumProtocolID=(J2534_PROTOCOL)0x00000087;

	/*Nikhilesh-check for ISO15765_CH2 and CAN_CH2*/
	else if(0x00009000==enumProtocolID)
		enumProtocolID=(J2534_PROTOCOL)0x00000090;

	else if(0x00009400==enumProtocolID)
		enumProtocolID=(J2534_PROTOCOL)0x00000094;

	
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_COMMENT, 
			"Start");
		sprintf(szBuffer, "DevID=%u ProtID=%u Flags=0x%02X Baud=%u",
			ulDeviceID, enumProtocolID, ulFlags, ulBaudRate);
		gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_DATA,
			szBuffer);
	}
	
	// Getting the CAN ID type
	ulCANIDsupport = ((ulFlags >> 11) & 0x01);

	if ((ulCANIDsupport != 0) && 
		(enumProtocolID != CAN) && (enumProtocolID != ISO15765) &&
		(enumProtocolID != CAN_CH1) && (enumProtocolID != ISO15765_CH1) &&
		(enumProtocolID != SW_ISO15765_PS) && (enumProtocolID != SW_CAN_PS))
	{
		enJ2534Error = J2534_ERR_INVALID_FLAGS;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return(enJ2534Error);
	}

	// Getting the checksum flag
	ulChecksumFlag = ((ulFlags >> 9) & 0x01);

	if ((enumProtocolID != ISO9141 && enumProtocolID != ISO14230) && 
		(ulChecksumFlag != 0))
	{
		enJ2534Error = J2534_ERR_INVALID_FLAGS;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return(enJ2534Error);
	}
	
	// Getting the CAN ID type
	ulCANIDtype = ((ulFlags >> 8) & 0x01);

	if ((ulCANIDtype != 0) && 
		(enumProtocolID != CAN) && (enumProtocolID != ISO15765) &&
		(enumProtocolID != CAN_CH1) && (enumProtocolID != ISO15765_CH1) &&
		(enumProtocolID != SW_ISO15765_PS) && (enumProtocolID != SW_CAN_PS) &&
		(enumProtocolID != J1939_PS) && (enumProtocolID != J1939_CH1)&& (enumProtocolID != J1939_CH2))

	{
		enJ2534Error = J2534_ERR_INVALID_FLAGS;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return(enJ2534Error);
	}

	//Suresh - return invalid baud rate
	if ((enumProtocolID == CAN) || (enumProtocolID == ISO15765) ||
		(enumProtocolID == CAN_CH1) || (enumProtocolID == ISO15765_CH1))
	{
		//Added suppport for 10,20,50,100,800 kbps baud rate on CAN
		//if(ulBaudRate != 125000 && ulBaudRate != 250000 && ulBaudRate != 500000
		//	&& ulBaudRate != 1000000)
		//	return J2534_ERR_INVALID_BAUDRATE;

		if ((ulBaudRate != ISOCAN_DATA_RATE_LOW) && 
			(ulBaudRate != ISOCAN_DATA_RATE_DEFAULT) && 
			(ulBaudRate != ISOCAN_DATA_RATE_MEDIUM) &&
			(ulBaudRate != ISOCAN_DATA_RATE_HIGH) &&
			(ulBaudRate != ISOCAN_DATA_RATE_10_KBPS) &&
			(ulBaudRate != ISOCAN_DATA_RATE_20_KBPS) &&
			(ulBaudRate != ISOCAN_DATA_RATE_50_KBPS) &&
			(ulBaudRate != ISOCAN_DATA_RATE_100_KBPS) &&
			(ulBaudRate != ISOCAN_DATA_RATE_800_KBPS))
		{
			return(J2534_ERR_INVALID_BAUDRATE);
		}		
	}

	//Checking for Baud Rate and Ext Id Flags for J1939
	if ((enumProtocolID == J1939_PS) || (enumProtocolID == J1939_CH1) ||
		(enumProtocolID == J1939_CH2))
	{
		
		//Checking for the Ext Bit Set or not
		if(ulCANIDtype == 0)
		{
			enJ2534Error = J2534_ERR_INVALID_FLAGS;
#ifdef J2534API_LOG
			if(LogData)
			{
				fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
				fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
			}
#endif

			return(enJ2534Error);
		}

		//J1939 Supports only 250 kbps
		if (ulBaudRate != J1939_DATA_RATE_DEFAULT)
		{
			return(J2534_ERR_INVALID_BAUDRATE);
		}		
	}

	/*Jayasheela-check data rate valid range */
	if(enumProtocolID==SW_CAN_PS)
	{
		if(ulBaudRate<DATA_RATE_MIN ||ulBaudRate>DATA_RATE_MAX)
		{
			enJ2534Error = J2534_ERR_INVALID_BAUDRATE;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
			return(enJ2534Error);
		}
	}
	
	// Check for invalid Device ID
	if ((ulDeviceID != gulDeviceID) || (gpclsDevice == NULL))
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return (enJ2534Error);
	}
	
	// Check for NULL parameters.
	if (pulChannelID == NULL)
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return (enJ2534Error);
	}
	
	// Create Protocol Object.
	if ((enJ2534Error = gclsProtocolManager.CreateProtocolObject(
							enumProtocolID, gpclsDevice, pulChannelID)) != 
							J2534_STATUS_NOERROR)
	{
		
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return(enJ2534Error);
	}

	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[*pulChannelID]->vConnect(
								enumProtocolID, 
								ulFlags, 
								ulBaudRate)) !=	J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruConnect()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
		// Delete the Protocol Object that was created earlier.
		gclsProtocolManager.DeleteProtocolObj(*pulChannelID);
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}
#endif
		return(enJ2534Error);
	}

    TRACE("Connect flags %ld\n", ulFlags);

#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value: 0x%X",enJ2534Error);
		fprintf(tempFile,"\tReturned ChannelID:0x%X",*pulChannelID);
	}		
#endif
	return (enJ2534Error);
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruDisconnect()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
	Output Params	: 
	Return			: Returns an Error Status.
	Description		: This is an exported API to disconnect the device.
------------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruDisconnect(unsigned long ulChannelID)
{
	
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char			szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error ;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruDisconnect-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X",ulChannelID);
	}
#endif

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_COMMENT, 
					  "Start");
		sprintf(szBuffer, "ulChannelID=%u", ulChannelID);
		gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_DATA,
					  szBuffer);
	}
	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (enJ2534Error);
	}
	
	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (enJ2534Error);
	}
	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return(enJ2534Error);
	}

	// Disconnect to Protocol
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->vDisconnect())
							!= J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return(enJ2534Error);
	}
	// Delete Protocol Object for this channel.
	if ((enJ2534Error = gclsProtocolManager.DeleteProtocolObj(ulChannelID)) !=
							J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return(enJ2534Error);
	}

	// Log when exited the function.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		gclsLog.Write("J2534Export.cpp", "PassThruDisconnect()", DEBUGLOG_TYPE_COMMENT, 
					  szBuffer);
	}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}	
#endif
	return(enJ2534Error);
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruReadMsgs()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pulNumMsgs - Number of msgs requested by user to be read.
					  ulTimeout - The timeout value to read msgs.

	Output Params	: pstrucJ2534Msg - Address of location where the data read
									   should be placed.
					  pulNumMsgs - Number of msgs actually read.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding 
					  function of that class to read messages.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruReadMsgs(unsigned long ulChannelID,
											   PASSTHRU_MSG  *pstrucJ2534Msg,
											   unsigned long *pulNumMsgs,
											   unsigned long ulTimeout)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char			szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;
	//DWORD			dwStartTick;

	pstrucJ2534Msg->ulDataSize =0;

	ulTimeout += 6000;
#ifdef J2534API_LOG	
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruReadMsgs-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X ",ulChannelID);
	fprintf(tempFile,"\tulTimeout:0x%X ",ulTimeout);
	}
#endif

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "Channel %lu NumMsg %lu Timeout %lu", 
			ulChannelID, *pulNumMsgs, ulTimeout);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "pstrucJ2534Msg->ucData %lu", 
			&pstrucJ2534Msg->ucData);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "Data %02X %02X %02X %02X", 
			pstrucJ2534Msg->ucData[0], pstrucJ2534Msg->ucData[1], 
			pstrucJ2534Msg->ucData[2], pstrucJ2534Msg->ucData[3]);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
		if(LogData)
		{
			fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
			fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
		}

#endif
		return (enJ2534Error);
	}
	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return (enJ2534Error);
	}
	// Check for NULL pointers
	if ((pstrucJ2534Msg == NULL) || (pulNumMsgs == NULL))
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile," TimeStamp:%lu ",GetTickCount());
	}
#endif
		return (enJ2534Error);
	}
	if (*pulNumMsgs == 0)
	{
		enJ2534Error = J2534_ERR_FAILED;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile," TimeStamp:%lu ",GetTickCount());
	}
#endif
		return(enJ2534Error);
	}

	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
		if(LogData)
		{
			fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
			fprintf(tempFile," TimeStamp:%lu ",GetTickCount());
		}
#endif
		return(enJ2534Error);
	}
	
	// Write Msg.
	
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->vReadMsgs(pstrucJ2534Msg,
		pulNumMsgs,
		ulTimeout))
		!= J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
		
		
		
#ifdef J2534API_LOG
		if(LogData)
		{   
			fprintf(tempFile,"\tNumMsgs:0x%X",*pulNumMsgs);
			fprintf(tempFile,"\tProtocolId:0x%X",pstrucJ2534Msg->ulProtocolID);
			fprintf(tempFile,"\tDataSize:0x%X",pstrucJ2534Msg->ulDataSize);
			fprintf(tempFile,"\tRxStatus:0x%X",pstrucJ2534Msg->ulRxStatus);
			fprintf(tempFile,"\tData:");
			for(int nIndex = 0 ; nIndex < pstrucJ2534Msg->ulDataSize ; nIndex++)
				fprintf(tempFile," 0x%X",pstrucJ2534Msg->ucData[nIndex]);

			fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
			fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
		}
#endif
		return(enJ2534Error);
	}
	
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "ProtocolID 0x%X", pstrucJ2534Msg->ulProtocolID);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "Tx Flags 0x%X", pstrucJ2534Msg->ulTxFlags);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "ExtraDataIndex 0x%X", pstrucJ2534Msg->ulExtraDataIndex);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "TimeStamp 0x%X", pstrucJ2534Msg->ulTimeStamp);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "Rx Status 0x%X", pstrucJ2534Msg->ulRxStatus);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "Data Size 0x%X", pstrucJ2534Msg->ulDataSize);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		
		if(pstrucJ2534Msg->ulDataSize > 0)
		{
			int j = 0;
			int i = 0;
			for(i = 0; i < pstrucJ2534Msg->ulDataSize && i < 15; i++)
			{
				j += sprintf(szBuffer + j, "%02X ",pstrucJ2534Msg->ucData[i]);				
			}
			
			if(i >= 15)
				j += sprintf(szBuffer + j, "...");
		}
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "pstrucJ2534Msg->ucData %lu", 
			&pstrucJ2534Msg->ucData);
		gclsLog.Write("J2534Export.cpp", "PassThruReadMsgs()", 
			DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	
	for (unsigned long ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Get the HFCP Protocol ID for DLL and the Device layer
		if(0x00000088 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00008008;
		if(0x00000087 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00008007;
	}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tNumMsgs:0x%X",*pulNumMsgs);
		fprintf(tempFile,"\tProtocolId:0x%X",pstrucJ2534Msg->ulProtocolID);
		fprintf(tempFile,"\tDataSize:0x%X",pstrucJ2534Msg->ulDataSize);
		fprintf(tempFile,"\tRxStatus:0x%X",pstrucJ2534Msg->ulRxStatus);
		fprintf(tempFile,"\tData:");
		for(int nIndex = 0 ; nIndex < pstrucJ2534Msg->ulDataSize ; nIndex++)
			fprintf(tempFile," 0x%X",pstrucJ2534Msg->ucData[nIndex]);

		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}	
#endif
	
	return(enJ2534Error);	
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruWriteMsgs()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pulNumMsgs - Number of msgs requested by user to write.
					  ulTimeout - The timeout value to write msgs.
					  pstrucJ2534Msg - Address of location where the data is
									   that should be placed on the bus.
	Output Params	: 
					  
	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding
					  function of that class to write messages.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruWriteMsgs(unsigned long ulChannelID,
												PASSTHRU_MSG	   *pstrucJ2534Msg,
												unsigned long *pulNumMsgs,
												unsigned long ulTimeout)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char		szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruWriteMsgs-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X ",ulChannelID);
	fprintf(tempFile,"\tNumMsgs:0x%X ",*pulNumMsgs);
	fprintf(tempFile,"\tTimeout:0x%X",ulTimeout);
	fprintf(tempFile,"\tProtocolId:0x%X ",pstrucJ2534Msg->ulProtocolID);
	fprintf(tempFile,"\tDataSize:0x%X",pstrucJ2534Msg->ulDataSize);
	fprintf(tempFile,"\tTxFlags:0x%X",pstrucJ2534Msg->ulTxFlags);
	fprintf(tempFile,"\tData:");
	for(int nIndex = 0 ; nIndex < pstrucJ2534Msg->ulDataSize ; nIndex++)
		fprintf(tempFile," 0x%X ",pstrucJ2534Msg->ucData[nIndex]);
	}
#endif

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
		sprintf(szBuffer, "Tx Flag 0x%X", pstrucJ2534Msg->ulTxFlags);
		gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);

		sprintf(szBuffer, "Timeout %lu", ulTimeout);
		gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
		if(pstrucJ2534Msg->ulDataSize > 0)
		{
			int j = 0;
			int i = 0;
			for(i = 0; i < pstrucJ2534Msg->ulDataSize && i < 15; i++)
			{
				j += sprintf(szBuffer + j, "%02X ",pstrucJ2534Msg->ucData[i]);				
			}

			if(i >= 15)
				j += sprintf(szBuffer + j, "...");
		}
		gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return (enJ2534Error);
	}
	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return (enJ2534Error);
	}
	// Check for NULL pointers
	if ((pstrucJ2534Msg == NULL) || (pulNumMsgs == NULL))
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return (enJ2534Error);
	}

	if (*pulNumMsgs == 0)
	{
		enJ2534Error = J2534_ERR_FAILED;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return(enJ2534Error);
	}
	
	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return(enJ2534Error);
	}

	for (unsigned long ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Get the HFCP Protocol ID for DLL and the Device layer
		if(0x00008008 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00000088;
		if(0x00008007 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00000087;
		if(0x00009000 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00000090;
		if(0x00009400 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00000094;
	}

	// Write Msg.
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->vWriteMsgs(pstrucJ2534Msg,
																						  pulNumMsgs,
																						  ulTimeout))
							!= J2534_STATUS_NOERROR)
	{

		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}

		for (int ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
		{
			// Get the HFCP Protocol ID for DLL and the Device layer
			if(0x00000088 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
				(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00008008;
			if(0x00000087 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
				(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00008007;
			if(0x00000090  == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
				(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00009000;
			if(0x00000094  == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
				(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00009400;

		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif
		return(enJ2534Error);
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "pstrucJ2534Msg->ucData %lu", 
			&pstrucJ2534Msg->ucData);
		gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		gclsLog.Write("J2534Export.cpp", "PassThruWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	for (int ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Get the HFCP Protocol ID for DLL and the Device layer
		if(0x00000088 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00008008;
		if(0x00000087 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00008007;
		if(0x00000090 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00009000 ;
		if(0x00000094 == (pstrucJ2534Msg + ulIdx1)->ulProtocolID)
			(pstrucJ2534Msg + ulIdx1)->ulProtocolID = 0x00009400 ;
	}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
		fprintf(tempFile,"\tTimeStamp:%lu ",GetTickCount());
	}
#endif

	return enJ2534Error;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruStartPeriodicMsg()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pstrucJ2534Msg - Address of location where the msg. is 
									   that needs to be started periodically.
					  
					  ulTimeInterval - The time between msgs to be sent out.

	Output Params	: pulMsgID - MsgID created by this DLL for this msg. for
								 all future references to this msg.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding 
					  virtual function of that class to start a periodic 
					  message.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStartPeriodicMsg(unsigned long ulChannelID, 
													   PASSTHRU_MSG *pMsgJ2534, 
													   unsigned long *pulMsgID, 
													   unsigned long ulTimeInterval)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char		szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

#ifdef J2534API_LOG	
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruStartPeriodicMsg-ENTER");
	fprintf(tempFile,"\tulChannelID:0x%X",ulChannelID);
	fprintf(tempFile,"\tulTimeInterval:0x%X",ulTimeInterval);
	fprintf(tempFile,"\tPeriodic Msg structure:");
	fprintf(tempFile,"\tProtocolId:0x%X ",pMsgJ2534->ulProtocolID);
	fprintf(tempFile,"\tDataSize:0x%X",pMsgJ2534->ulDataSize);
	fprintf(tempFile,"\tTxFlags:0x%X",pMsgJ2534->ulTxFlags);
	fprintf(tempFile,"\tData:");
	for(int nIndex = 0 ; nIndex < pMsgJ2534->ulDataSize ; nIndex++)
		fprintf(tempFile," 0x%X ",pMsgJ2534->ucData[nIndex]);
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", 
					  DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Do not allow the intervals less than MIN_INTERVAL_VAL milliseconds or greater than 
	// MAX_INTERVAL_VAL
	if(ulTimeInterval < MIN_INTERVAL_VAL || ulTimeInterval > MAX_INTERVAL_VAL)
	{
		enJ2534Error = J2534_ERR_INVALID_TIME_INTERVAL;
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
			szBuffer);
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return enJ2534Error; // Time interval should be > MIN_INTERVAL_VAL

	}
	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}
	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}
	// Check for NULL pointers
	if ((pMsgJ2534 == NULL) || (pulMsgID == NULL))
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return(enJ2534Error);
	}
	
	// Get the HFCP Protcol ID for processing for DLL and Device Layer
	if (0x00008008 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000088;
	if(0x00008007 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000087;
	if (0x00009000 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000090;
	if(0x00009400 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000094;


	// Start Periodic Msg.
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->\
							vStartPeriodicMsg(
											pMsgJ2534,
											pulMsgID,
											ulTimeInterval))
					  != J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		// Get the HFCP Protcol ID for processing for DLL and Device Layer
		if (0x00000088 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00008008;
		if(0x00000087 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00008007;
		if (0x00000090 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00009000;
		if(0x00000094 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00009400;
		return(enJ2534Error);
	}
	// Get the HFCP Protcol ID for processing for DLL and Device Layer
	if (0x00000088 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00008008;
	if(0x00000087 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00008007;
	if (0x00000090 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00009000;
	if(0x00000094 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00009400;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
	return (enJ2534Error);
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruUpdatePeriodicMsg()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  pstrucJ2534Msg - Address of location where the msg. is 
									   that needs to be started periodically.
					  
					  ulTimeInterval - The time between msgs to be sent out.

	Output Params	: pulMsgID - MsgID created by this DLL for this msg. for
								 all future references to this msg.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding 
					  virtual function of that class to start a periodic 
					  message.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruUpdatePeriodicMsg(unsigned long ulChannelID, 
													   PASSTHRU_MSG *pMsgJ2534, 
													   unsigned long ulMsgID, 
													   unsigned long ulTimeInterval)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char		szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

#ifdef J2534API_LOG	
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruUpdatetPeriodicMsg-ENTER");
	fprintf(tempFile,"\tulChannelID:0x%X",ulChannelID);
	fprintf(tempFile,"\tulTimeInterval:0x%X",ulTimeInterval);
	fprintf(tempFile,"\tPeriodic Msg structure:");
	fprintf(tempFile,"\tProtocolId:0x%X ",pMsgJ2534->ulProtocolID);
	fprintf(tempFile,"\tDataSize:0x%X",pMsgJ2534->ulDataSize);
	fprintf(tempFile,"\tTxFlags:0x%X",pMsgJ2534->ulTxFlags);
	fprintf(tempFile,"\tData:");
	for(int nIndex = 0 ; nIndex < pMsgJ2534->ulDataSize ; nIndex++)
		fprintf(tempFile," 0x%X ",pMsgJ2534->ucData[nIndex]);
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruUpdatePeriodicMsg()", 
					  DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Do not allow the intervals less than MIN_INTERVAL_VAL milliseconds or greater than 
	// MAX_INTERVAL_VAL
	if(ulTimeInterval < MIN_INTERVAL_VAL || ulTimeInterval > MAX_INTERVAL_VAL)
	{
		enJ2534Error = J2534_ERR_INVALID_TIME_INTERVAL;
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruUpdatePeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
			szBuffer);
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return enJ2534Error; // Time interval should be > MIN_INTERVAL_VAL

	}
	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruUpdatePeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}
	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruUpdatePeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}
	// Check for NULL pointers
	if (pMsgJ2534 == NULL)
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruUpdatePeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruUpdatePeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return(enJ2534Error);
	}
	
	// Get the HFCP Protcol ID for processing for DLL and Device Layer
	if (0x00008008 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000088;
	if(0x00008007 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000087;
	if (0x00009000 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000090;
	if(0x00009400 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00000094;


	// Start Periodic Msg.
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->\
							vUpdatePeriodicMsg(
											pMsgJ2534,
											ulMsgID,
											ulTimeInterval))
					  != J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartPeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		// Get the HFCP Protcol ID for processing for DLL and Device Layer
		if (0x00000088 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00008008;
		if(0x00000087 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00008007;
		if (0x00000090 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00009000;
		if(0x00000094 == pMsgJ2534->ulProtocolID)
			pMsgJ2534->ulProtocolID = 0x00009400;
		return(enJ2534Error);
	}
	// Get the HFCP Protcol ID for processing for DLL and Device Layer
	if (0x00000088 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00008008;
	if(0x00000087 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00008007;
	if (0x00000090 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00009000;
	if(0x00000094 == pMsgJ2534->ulProtocolID)
		pMsgJ2534->ulProtocolID = 0x00009400;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
	return (enJ2534Error);
}


/*-----------------------------------------------------------------------------
	Function Name	: PassThruStopPeriodicMsg()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  ulMsgID - MsgID for a msg. that was started before.
	Output Params	: 
	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding 
					  virtual function of that class to stop a periodic 
					  message.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStopPeriodicMsg(unsigned long ulChannelID,
													  unsigned long ulMsgID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	J2534ERROR enJ2534Error;
	char szBuffer[J2534MAIN_ERROR_TEXT_SIZE];

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruStopPeriodicMsg-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X",ulChannelID);
	fprintf(tempFile,"\tMsgID:0x%X",ulMsgID);
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruStopPeriodicMsg()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStopPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned Value:0x%X",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}
	//Check weather the device connected
	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStopPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned Value:0x%X",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStopPeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned Value:0x%X",enJ2534Error);
	}
#endif
		return(enJ2534Error);
	}

	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->\
							vStopPeriodicMsg(ulMsgID))
					  != J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStopPeriodicMsg()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned Value:0x%X",enJ2534Error);
	}
#endif
		return(enJ2534Error);
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruStopPeriodicMsg()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned Value:0x%X",enJ2534Error);
	}		
#endif
	return(enJ2534Error);
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruStartMsgFilter()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  enumFilterType - Filter Type PASS_FILTER or BLOCK_FILTER.
					  
					  pstrucJ2534Mask - The mask to be used to filter msg.
					  pstrucJ2534Pattern - Pattern that the msg. should match
										   with after applying mask.

	Output Params	: pulMsgID - MsgID created by this DLL for this filter for
								 all future references to this msg.

	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding 
					  virtual function of that class to start filtering 
					  messages with the given filter.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStartMsgFilter(unsigned long	ulChannelID,
													 J2534_FILTER	enumFilterType,
													 PASSTHRU_MSG	*pstrucJ2534Mask,
													 PASSTHRU_MSG	*pstrucJ2534Pattern,
													 PASSTHRU_MSG	*pstrucJ2534FlowControl,
													 unsigned long *pulFilterID)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char		szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error ;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruStartMsgFilter-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X ",ulChannelID);
	fprintf(tempFile,"\tFilterType:0x%X",enumFilterType);
	fprintf(tempFile,"\tMASK");
	fprintf(tempFile,"\tProtocolId:0x%X ",pstrucJ2534Mask->ulProtocolID);
	fprintf(tempFile,"\tDataSize:0x%X ",pstrucJ2534Mask->ulDataSize);
	fprintf(tempFile,"\tTxFlags:0x%X ",pstrucJ2534Mask->ulTxFlags);
	fprintf(tempFile,"\tData:");
	for(int nIndex = 0 ; nIndex < pstrucJ2534Mask->ulDataSize ; nIndex++)
		fprintf(tempFile,"\t0x%X ",pstrucJ2534Mask->ucData[nIndex]);
	fprintf(tempFile,"\tPattern");
	fprintf(tempFile,"\tProtocolId:0x%X ",pstrucJ2534Pattern->ulProtocolID);
	fprintf(tempFile,"\tDataSize:0x%X ",pstrucJ2534Pattern->ulDataSize);
	fprintf(tempFile,"\tTxFlags:0x%X ",pstrucJ2534Pattern->ulTxFlags);
	fprintf(tempFile,"\tData:");
	for(int nIndex = 0 ; nIndex < pstrucJ2534Pattern->ulDataSize ; nIndex++)
		fprintf(tempFile,"\t 0x%X ",pstrucJ2534Pattern->ucData[nIndex]);
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Mask");
		sprintf(szBuffer, "DataSize is %d", pstrucJ2534Mask->ulDataSize);
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
								 DEBUGLOG_TYPE_COMMENT, szBuffer);

		if(pstrucJ2534Mask->ulDataSize > 0)
		{
			int j = 0;
			int i = 0;

			for(i = 0; i < pstrucJ2534Mask->ulDataSize && i < 15; i++)
			{
				j += sprintf(szBuffer + j, "%02X ",pstrucJ2534Mask->ucData[i]);				
			}

			if(i >= 15)
				j += sprintf(szBuffer + j, "...");
		}
		else
		{
			sprintf(szBuffer, "DataSize is 0");
		}
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	TRACE("Mask Length %d Pattern Length %d ",pstrucJ2534Mask->ulDataSize
		                                      ,pstrucJ2534Pattern->ulDataSize);

	TRACE("Mask data %d Pattern Data %d ",pstrucJ2534Mask->ucData[0]
		                                      ,pstrucJ2534Pattern->ucData[0]);

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Pattern");
		sprintf(szBuffer, "DataSize is %d", pstrucJ2534Pattern->ulDataSize);
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
								 DEBUGLOG_TYPE_COMMENT, szBuffer);

		if(pstrucJ2534Pattern->ulDataSize > 0)
		{
			int j = 0;
			int i = 0;
			for(i = 0; i < pstrucJ2534Pattern->ulDataSize && i < 15; i++)
			{
				j += sprintf(szBuffer + j, "%02X ",pstrucJ2534Pattern->ucData[i]);				
			}

			if(i >= 15)
				j += sprintf(szBuffer + j, "...");
		}
		else
		{
			sprintf(szBuffer, "DataSize is 0");
		}
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile && enumFilterType == 3)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "FlowControl");
		if(pstrucJ2534FlowControl->ulDataSize > 0)
		{
			int j = 0;
			int i = 0;
			for(i = 0; i < pstrucJ2534FlowControl->ulDataSize && i < 15; i++)
			{
				j += sprintf(szBuffer + j, "%02X ",pstrucJ2534FlowControl->ucData[i]);				
			}

			if(i >= 15)
				j += sprintf(szBuffer + j, "...");
		}
		else
		{
			sprintf(szBuffer, "DataSize is 0");
		}
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;

		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);		
	}
#endif
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);		
	}
#endif
		return (enJ2534Error);
	}
	// Check for NULL pointers
	if ((pstrucJ2534Mask == NULL) || (pstrucJ2534Pattern == NULL) || 
		(pulFilterID == NULL))
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFitler()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);		
	}
#endif
		return (enJ2534Error);
	}

	// Check for NULL pointers
	if ((pstrucJ2534FlowControl == NULL) && (enumFilterType == J2534_FILTER_FLOW_CONTROL))
	{
		enJ2534Error = J2534_ERR_NULLPARAMETER;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFitler()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);		
	}
#endif
		return (enJ2534Error);
	}
	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFitler()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);		
	}
#endif
		return(enJ2534Error);
	}

	// Get the HFCP Protcol ID for processing for DLL and Device Layer
	if ( 0x00008008 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00000088;
	}
	else if(0x00008007 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00000087;
	}
	else if(0x00009000 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00000090;
	}
	else if(0x00009400 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00000094;
	}

	if ( 0x00008008 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00000088;
	}
	else if(0x00008007 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00000087;
	}
	else if(0x00009000 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00000090;
	}
	else if(0x00009400 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00000094;
	}

	if(NULL!=pstrucJ2534FlowControl)
	{
		if (0x00008008 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00000088;
		}
		else if(0x00008007 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00000087;
		}
		else if(0x00009000 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00000090;
		}
		else if(0x00009400 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00000094;
		}
	}

	// Start Msg. Filter
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->\
								vStartMsgFilter(
										  enumFilterType,
										  pstrucJ2534Mask,
										  pstrucJ2534Pattern,
										  pstrucJ2534FlowControl,
										  pulFilterID))
					  != J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		
		// Get the J2534 Protcol ID 
		if ( 0x00000088 == pstrucJ2534Mask->ulProtocolID)
		{
			pstrucJ2534Mask->ulProtocolID = 0x00008008;
		}
		else if(0x00000087 == pstrucJ2534Mask->ulProtocolID)
		{
			pstrucJ2534Mask->ulProtocolID = 0x00008007;
		}
		else if(0x00000090 == pstrucJ2534Mask->ulProtocolID)
		{
			pstrucJ2534Mask->ulProtocolID = 0x00009000;
		}
		else if(0x00000094 == pstrucJ2534Mask->ulProtocolID)
		{
			pstrucJ2534Mask->ulProtocolID = 0x00009400;
		}

		if ( 0x00000088 == pstrucJ2534Pattern->ulProtocolID)
		{
			pstrucJ2534Pattern->ulProtocolID = 0x00008008;
		}
		else if(0x00000087 == pstrucJ2534Pattern->ulProtocolID)
		{
			pstrucJ2534Pattern->ulProtocolID = 0x00008007;
		}
		else if(0x00000090 == pstrucJ2534Pattern->ulProtocolID)
		{
			pstrucJ2534Pattern->ulProtocolID = 0x00009000;
		}
		else if(0x00000094 == pstrucJ2534Pattern->ulProtocolID)
		{
			pstrucJ2534Pattern->ulProtocolID = 0x00009400;
		}

		if(NULL!=pstrucJ2534FlowControl)
		{
			if (0x00000088 == pstrucJ2534FlowControl->ulProtocolID)
			{
				pstrucJ2534FlowControl->ulProtocolID = 0x00008008;
			}
			else if(0x00000087 == pstrucJ2534FlowControl->ulProtocolID)
			{
				pstrucJ2534FlowControl->ulProtocolID = 0x00008007;
			}
			else if(0x00000090 == pstrucJ2534FlowControl->ulProtocolID)
			{
				pstrucJ2534FlowControl->ulProtocolID = 0x00009000;
			}
			else if(0x00000094 == pstrucJ2534FlowControl->ulProtocolID)
			{
				pstrucJ2534FlowControl->ulProtocolID = 0x00009400;
			}
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		//fprintf(tempFile,"\tPassThruStartMsgFilter-EXIT on error");
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);		
	}
#endif
		return(enJ2534Error);
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		gclsLog.Write("J2534Export.cpp", "PassThruStartMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	// Get the J2534 Protcol ID 
	if ( 0x00000088 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00008008;
	}
	else if(0x00000087 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00008007;
	}
	else if(0x00000090 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00009000;
	}
	else if(0x00000094 == pstrucJ2534Mask->ulProtocolID)
	{
		pstrucJ2534Mask->ulProtocolID = 0x00009400;
	}

	if ( 0x00000088 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00008008;
	}
	else if(0x00000087 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00008007;
	}
	else if(0x00000090 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00009000;
	}
	else if(0x00000094 == pstrucJ2534Pattern->ulProtocolID)
	{
		pstrucJ2534Pattern->ulProtocolID = 0x00009400;
	}

	if(NULL!=pstrucJ2534FlowControl)
	{
		if (0x00000088 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00008008;
		}
		else if(0x00000087 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00008007;
		}
		else if(0x00000090 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00009000;
		}
		else if(0x00000094 == pstrucJ2534FlowControl->ulProtocolID)
		{
			pstrucJ2534FlowControl->ulProtocolID = 0x00009400;
		}
	}

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	fprintf(tempFile,"\tFilterID:0x%X",*pulFilterID);
	}

#endif
	return enJ2534Error;
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruStopMsgFilter()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  ulMsgID - MsgID of a Filter msg. that was started before.
	Output Params	: 
	Return			: Returns an Error Status.
	Description		: This function gets a pointer to a specific Protocol 
					  Object and uses the pointer to call the corressponding 
					  virtual function of that class to stop filtering 
					  messages for the given MsgID.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruStopMsgFilter(unsigned long ulChannelID,
													unsigned long ulFilterID)
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char		szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruStopMsgFilter-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X",ulChannelID);
	fprintf(tempFile,"\tFilterID:0x%X",ulFilterID);
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Main.cpp", "PassThruStopMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}
	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Main.cpp", "PassThruStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Main.cpp", "PassThruStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Main.cpp", "PassThruStopMsgFitler()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return(enJ2534Error);
	}

	// Start Msg. Filter
	if ((enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->\
								vStopMsgFilter(ulFilterID))
					  != J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Main.cpp", "PassThruStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return(enJ2534Error);
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Main.cpp", "PassThruStopMsgFilter()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
	
#endif
	return(enJ2534Error);
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruSetProgrammingVoltage()
	Input Params	: ulPin - The pin on which the programming voltage will be 
							  set.
					  ulVoltage - The voltage (in milli-volts) to be set.
	Output Params	: 
	Return			: Returns an Error Status.
	Description		: This function sets a programming voltage on a specific
					  pin.
-----------------------------------------------------------------------------*/

extern "C" J2534ERROR  WINAPI PassThruSetProgrammingVoltage(unsigned long ulDeviceID,
															unsigned long ulPin,
													        unsigned long ulVoltage)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char	szBuffer[J2534MAIN_ERROR_TEXT_SIZE];

	J2534ERROR			enJ2534Error ;

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruSetProgrammingVoltage-ENTER");
	fprintf(tempFile,"\tDeviceID:0x%X",ulDeviceID);
	fprintf(tempFile,"\tPin:0x%X",ulPin);
	fprintf(tempFile,"\tVoltage:0x%X",ulVoltage);
	}
#endif
	
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "Start Pin %lu Voltage %lu", ulPin, ulVoltage);
		gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	
	// Check for invalid Device ID
	if ((ulDeviceID != gulDeviceID) || (gpclsDevice == NULL))
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X ",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	if ((enJ2534Error = gpclsDevice->vProgrammingVoltage(ulDeviceID,ulPin,ulVoltage)) 
					  == J2534_STATUS_NOERROR)
	{
		// Write to Log File.
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", 
							 DEBUGLOG_TYPE_COMMENT, szBuffer);
		}
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
 		if (enJ2534Error == J2534_STATUS_NOERROR)
			gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", 
							 DEBUGLOG_TYPE_COMMENT, szBuffer);
		else
			gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruSetProgrammingVoltage()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
	return(enJ2534Error);
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruReadVersion()
	Input Params	: pDllVersion - Pointer to DLL version string.
					  pApiVersion - Pointer to API version string.
	Output Params	: 
	Return			: Returns Dll & Api Version Numbers.
	Description		: This function gets the Dll Version Number and Api Version
					  Number.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruReadVersion(unsigned long ulDeviceID,
												  char *pchFirmwareVersion,
												  char *pchDllVersion,
												  char *pchApiVersion)
{
	
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	J2534ERROR			enJ2534Error;
	char	szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruReadVersion-ENTER");
	}
#endif
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check for invalid Device ID
	if ((ulDeviceID != gulDeviceID) || (gpclsDevice == NULL))
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return (enJ2534Error);
	}

	if (pchFirmwareVersion == NULL || pchDllVersion == NULL || 
		pchApiVersion == NULL) 
	{ 
		enJ2534Error = J2534_ERR_NULLPARAMETER; 
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return(enJ2534Error); 
	} 
	
	enJ2534Error = gpclsDevice->vGetRevision((char*)pchFirmwareVersion,(char*)pchDllVersion,(char*)pchApiVersion);

	if(enJ2534Error != J2534_STATUS_NOERROR)
	{
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}
#endif
		return enJ2534Error;
	}

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
	}	
#endif
	return(enJ2534Error);
}
/*-----------------------------------------------------------------------------
	Function Name	: PassThruGetLastError()
	Input Params	: ulErrorID - ID that identifies the type of error.
						(Out of specification)
					  pErrorDescription - Pointer to error description string.
	Output Params	: 
	Return			: Returns an Error Description.
	Description		: This function gets an Error ID and matches it to an error 
					  string.
-----------------------------------------------------------------------------*/

extern "C" J2534ERROR  WINAPI PassThruGetLastError(char *pchErrorDescription)
{
	
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char	szBufferGetLastError[J2534MAIN_ERROR_TEXT_SIZE];
	char	szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	memset(szBufferGetLastError, 0, J2534MAIN_ERROR_TEXT_SIZE);

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "PassThruGetLastError()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}
	
	// Check for NULL pointers
	if (pchErrorDescription == NULL)
	{
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NULLPARAMETER);
			gclsLog.Write("J2534Export.cpp", "PassThruGetLastError()", 
						  DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return (J2534_ERR_NULLPARAMETER);
	}
	
	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_DEVICE_ID);
			gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		//Suresh - return status no error
		return J2534_STATUS_NOERROR;
	}
	
	/*Get the device vesrion*/
	gpclsDevice->vGetLastError(szBufferGetLastError);
	strcpy(pchErrorDescription, szBufferGetLastError);

	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned %s", pchErrorDescription);
		gclsLog.Write("J2534Export.cpp", "PassThruGetLastError()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

/*-----------------------------------------------------------------------------
	Function Name	: PassThruIoctl()
	Input Params	: ulChannelID - ChannelID that was created by this DLL at
									Connect time.
					  ulIoctlID - IoctlID that identifies the Ioctl call.
	Output Params	: 
	Return			: Returns an Error Status.
	Description		: This function is used to read and write all the protocol 
					  hardware and software configuration parameters for a 
					  given ulIoctlID.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI PassThruIoctl(unsigned long ulChannelID,
											J2534IOCTLID enumIoctlID,
											void *pInput,
											void *pOutput)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	char	szBuffer[J2534MAIN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;//  = J2534_STATUS_NOERROR;
	//return enJ2534Error;
	
	SCONFIG_LIST *list;
	SCONFIG *ioctlvalue;
	SBYTE_ARRAY *list1;
#ifdef J2534API_LOG
	if(LogData)
	{
	fprintf(tempFile,"\n\n");
	fprintf(tempFile,"%lu ",GetTickCount());
	fprintf(tempFile,"PassThruIoctl-ENTER");
	fprintf(tempFile,"\tChannelID:0x%X ",ulChannelID);
	fprintf(tempFile,"\tenumIoctlID:0x%X ",enumIoctlID);
	}
#endif

	/*Suresh - returning invalid IOControl id */
	if(enumIoctlID < 0)
		return J2534_ERR_INVALID_IOCTL_ID;

	/*Jayasheela-checking for SWCAN_HS and SWCAN_NS */
	if(0x00008000==enumIoctlID)
	{
		enumIoctlID=(J2534IOCTLID)0x00000080;
	}
	else if(0x00008001==enumIoctlID)
	{
		enumIoctlID=(J2534IOCTLID)0x00000087;
	}
	else
	{
			// Do nothing
	}
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "Start IoctlID %d", enumIoctlID);
		gclsLog.Write("J2534Export.cpp", "PassThruIoctl()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	// Check for invalid Device ID
	if (gpclsDevice == NULL)
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruIoctl()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\t Input:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif
		return (enJ2534Error);
	}

	if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Main.cpp", "PassThruIoctl()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif
		return (enJ2534Error);
	}

	// If READ_VBATT, do it because it requires no connection
 	if ((enumIoctlID == READ_VBATT))  
	{
		// Make sure pInput is not NULL
		if (pOutput == NULL)
			return(J2534_ERR_NULLPARAMETER);

		enJ2534Error = gpclsDevice->vIoctl( ulChannelID,
											enumIoctlID,
											NULL,
											pOutput);
	
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif
		return(enJ2534Error);
	}
	/*jayasheela-added to send the READ_PROG_VOLTAGE command*/
	if ((enumIoctlID == READ_PROG_VOLTAGE))  
	{
		// Make sure pInput is not NULL

		return(J2534_ERR_NOT_SUPPORTED);//Nikhilesh

		/*enJ2534Error = gpclsDevice->vIoctl( ulChannelID,
											enumIoctlID,
											NULL,
											pOutput);
		unsigned long *pulProgVoltage;
        pulProgVoltage = (unsigned long *)pOutput;
		*pulProgVoltage = 0xFFFFFFFF; //0x00002fa8;
		enJ2534Error = J2534_STATUS_NOERROR;*/
		
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif
		return(enJ2534Error);
	}
	
	// Check if the requested Channel ID is valid.
	if (!gclsProtocolManager.IsChannelIDValid(ulChannelID))
	{
		enJ2534Error = J2534_ERR_INVALID_CHANNEL_ID;
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruIoctl()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif
		return(enJ2534Error);
	}

	// Validate IoctlID
	/* Ravi : replaced the values 0x8000 / 0x8001 with Macros SW_CAN_HS / SW_CAN_NS 
		Deleted assignment of enumIoctlID with Macros SW_CAN_HS / SW_CAN_NS */
	/*Jaaysheela-added check with values 0x8000 or 0x8001 for now need to discuss */
	/*Jaaysheela-commented need to discuss*/
	/*if (((enumIoctlID < GET_CONFIG) || (enumIoctlID > READ_PROG_VOLTAGE)) &&
		((enumIoctlID != 0x8000) || (enumIoctlID != 0x8001)))
	{
		enJ2534Error = J2534_ERR_INVALID_IOCTL_ID;
		return(J2534_ERR_INVALID_IOCTL_ID);
	}*/

	if( (enJ2534Error = gclsProtocolManager.m_pclsProtocolObject[ulChannelID]->vIoctl( enumIoctlID,
											pInput,pOutput))!= J2534_STATUS_NOERROR)
	{
		if (gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruIoctl()", DEBUGLOG_TYPE_ERROR, 
				szBuffer);
		}
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif

	//Suresh - Check for error not supported
	if(enumIoctlID == SET_CONFIG && ulChannelID == 1 && enJ2534Error != J2534_ERR_INVALID_IOCTL_VALUE)
		return J2534_ERR_NOT_SUPPORTED;

		return(enJ2534Error);
	}
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Main.cpp", "PassThruIoctl()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	if(0x00000004 == enumIoctlID )
	{
		list1=(SBYTE_ARRAY *)pInput;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput NumOfBytes:0x%X",list1->ulNumOfBytes);
		//for(int i=0;i<list1->ulNumOfBytes;i++)
		//{
			fprintf(tempFile,"\tInput BytePtr:0x%X ",*list1->pucBytePtr);
			//list1++;
		//}
	}
#endif
		list1=(SBYTE_ARRAY *)pOutput;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tpOutput NumOfBytes:0x%X",list1->ulNumOfBytes);
		for(int i=0;i<list1->ulNumOfBytes;i++)
		{
			fprintf(tempFile,"\tpOutput BytePtr:0x%X ",*list1->pucBytePtr);
			list1->pucBytePtr++;
		}
	}
#endif
	}
	else if(0x00000001 == enumIoctlID ||0x00000002 == enumIoctlID  )
	{
		list=(SCONFIG_LIST *)pInput;
		ioctlvalue =(SCONFIG *) list->pConfigPtr;
#ifdef J2534API_LOG
	if(LogData)
	{
		fprintf(tempFile,"\tInput NumOfParams:0x%X",list->ulNumOfParams);
		for(int i=0;i<list->ulNumOfParams;i++)
		{
			fprintf(tempFile,"\tInput Parameter:0x%X",ioctlvalue->Parameter);
			fprintf(tempFile,"\tInput Value:0x%X ",ioctlvalue->ulValue);
			ioctlvalue++;
		}
	}
#endif
	}
	else 
	{
#ifdef J2534API_LOG
	if(LogData)
	{

		fprintf(tempFile,"\tReturned value:0x%X",enJ2534Error);
		fprintf(tempFile,"\tInput:0x%X pOutput:0x%X",pInput,pOutput);
	}
#endif
	}
	return(enJ2534Error);
}


#ifdef GARUDA_TOOL
/*-----------------------------------------------------------------------------
	Function Name	: LoggingStatus()
	Input Params	: pDllVersion - Pointer to DLL version string.
					  pApiVersion - Pointer to API version string.
	Output Params	: 
	Return			: Returns Dll & Api Version Numbers.
	Description		: This function gets the Dll Version Number and Api Version
					  Number.
-----------------------------------------------------------------------------*/
extern "C" J2534ERROR  WINAPI LoggingStatus(unsigned long ulDeviceID,unsigned long bLogFlag,
											SYSTEMTIME * Time)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	J2534ERROR			enJ2534Error;

	char	szBuffer[J2534MAIN_ERROR_TEXT_SIZE];


	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		gclsLog.Write("J2534Export.cpp", "LoggingStatus()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Check for invalid Device ID
	if ((ulDeviceID != gulDeviceID) || (gpclsDevice == NULL))
	{
		enJ2534Error = J2534_ERR_INVALID_DEVICE_ID;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (enJ2534Error);
	}

		if (!gpclsDevice->vIsDeviceConnected())
	{
		enJ2534Error = J2534_ERR_DEVICE_NOT_CONNECTED;
		if(gclsLog.m_pfdLogFile)
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", DEBUGLOG_TYPE_ERROR, 
						  szBuffer);
		}
		return (enJ2534Error);
	}

	enJ2534Error = gpclsDevice->vLoggingStatus(bLogFlag,Time);

	if(enJ2534Error != J2534_STATUS_NOERROR)
	{
		return enJ2534Error;
	}
	// Write to Log File.
	if (gclsLog.m_pfdLogFile)
	{
		sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
		gclsLog.Write("J2534Export.cpp", "PassThruReadVersion()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}
	return(enJ2534Error);
}
#endif

/*-----------------------------------------------------------------------------
	Function Name	: IsDebugLogEnable()
	Input Params	: gcIniFile - ini file name used to store protocol type 
					  supported by ecu.
					  gcSection - Section in ini file.
					  gcKey - Key value in ini File
	Output Params	: gcDebugLogEnable -Variable to store retrived data.
	Return			: Returns an Error Status.
	Description		: This function is used to gcDebugLogEnable flasg value.
-----------------------------------------------------------------------------*/
void IsDebugLogEnable()
{
	int flgDebugLog =0;
	long            lSuccess;
    char            chTempstr[J2534REGISTRY_MAX_STRING_LENGTH];
	char			pchCurText[J2534REGISTRY_MAX_STRING_LENGTH];
	DWORD			dwValueread = 0;
    DWORD           dwDatasize;     
    DWORD           dwDword,dwString; 
    HKEY            hMainkey;
    HKEY            hTempkey;
    dwDword = REG_DWORD,dwString = REG_SZ;
    hTempkey = NULL;
    strcpy(chTempstr, J2534REGISTRY_KEY_PATH);
    strcpy(pchCurText, J2534REGISTRY_COMPANY);
	
    lSuccess = RegOpenKeyEx(HKEY_LOCAL_MACHINE, chTempstr, 0,KEY_READ,&hMainkey);
    if(lSuccess==ERROR_SUCCESS) 
    {
        dwDatasize=J2534REGISTRY_MAX_STRING_LENGTH;
        lSuccess = RegOpenKeyEx(hMainkey, pchCurText,0, KEY_READ, &hTempkey);
        if (lSuccess==ERROR_SUCCESS)
        {
            
			dwDatasize = sizeof(dwValueread);
			lSuccess = RegQueryValueEx(hTempkey, "J2534_Log", NULL, &dwDword, 
				(unsigned char *)&dwValueread, &dwDatasize);

		    RegCloseKey(hTempkey);
            hTempkey = NULL;
        }
    }
    RegCloseKey(hMainkey);
	if(dwValueread)
	{
		LogData = TRUE;
	}
	else
	{
		LogData = FALSE;
	}  
}
/*-----------------------------------------------------------------------------
	Function Name	: SetPathForLog()
	Description		: This function is used to getpath.
-----------------------------------------------------------------------------*/
void SetPathForLog()
{	
	char strPath[MAX_PATH];
	::GetModuleFileName(NULL,strPath,MAX_PATH);
	CString LogPath(strPath);
	int fpos = LogPath.ReverseFind('\\');
	if (fpos != -1)
	LogPath = LogPath.Left(fpos + 1); 
	LogPath = LogPath + "J2534DLLLog.txt ";
	gpcLogPath = LogPath;
}
