/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: CAN.h
 Description			: interface for the CCAN class.
 Date					: Jan 30, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Jan 30, 2008	Chakravarthy				Initial Version
*******************************************************************************/


#if !defined(AFX_CAN_H__F605B11C_3CCD_4299_83B4_DF3B4F9E7DF2__INCLUDED_)
#define AFX_CAN_H__F605B11C_3CCD_4299_83B4_DF3B4F9E7DF2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "J2534.h"
#include "ProtocolBase.h"
#include "CircBuffer.h"

void OnCANRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid);

class CCAN : public CProtocolBase  
{
public:
	
	CCAN(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CCAN();

	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);

	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vUpdatePeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long ulMsgID,
								unsigned long ulTimeInterval);

	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);

private:
	BOOL IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, BOOL bFilter = FALSE);


public:

	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	float					m_fSamplePoint;
	float					m_fJumpWidth;
	J2534_PROTOCOL			m_enCANProtocol;
};

#endif // !defined(AFX_CAN_H__F605B11C_3CCD_4299_83B4_DF3B4F9E7DF2__INCLUDED_)
