// PeriodicMsg.cpp: implementation of the CPeriodicMsg class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "J2534Generic.h"
#include "PeriodicMsg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//-----------------------------------------------------------------------------
//	Function Name	: CPeriodicMsg
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CPeriodicMsg class.
//-----------------------------------------------------------------------------
CPeriodicMsg::CPeriodicMsg(CDeviceBase *pclsDevice, unsigned long	ulDevChannelID,
						   CDebugLog *pclsDebugLog)
{
	int	i;

	// Save pointers.
	m_pclsLog = pclsDebugLog;
	m_pclsDevice = pclsDevice;
	m_ulDevChannelID = ulDevChannelID;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "CPeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Initialize the PeriodicType portion of the list.
	/*jayasheela changed i value to 1 bcz periodic id starts from 1 */
	for (i = 1; i <= PERIODICMSG_LIST_SIZE; i++)
	{
		m_stPeriodicList[i].pstMsg = NULL;
		m_stPeriodicList[i].ulTimeInterval = 0;
	}

	m_hSyncAccess = CreateEvent(NULL, FALSE, TRUE, NULL);

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "CPeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CPeriodicMsg
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CPeriodicMsg class
//-----------------------------------------------------------------------------
CPeriodicMsg::~CPeriodicMsg()
{
	int i;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "~CPeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop all Periodic
	StopPeriodic();

	// Delete the resources. Jayasheela : changed the index from 0 to 1
	for (i = 1; i <= PERIODICMSG_LIST_SIZE; i++)
	{
		if (m_stPeriodicList[i].pstMsg != NULL)
		{	
			delete m_stPeriodicList[i].pstMsg;
			m_stPeriodicList[i].pstMsg = NULL;
		}

		m_stPeriodicList[i].ulTimeInterval = 0;
	}

	CloseHandle(m_hSyncAccess);

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "~CPeriodicMsg()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: StartPeriodic
//	Input Params	: 
//	Output Params	: 
//	Description		: This function starts a given msg. periodic and returns a
//					  Periodic. ID for reference.
//-----------------------------------------------------------------------------
J2534ERROR CPeriodicMsg::StartPeriodic(
							   PASSTHRU_MSG		*pstMsg, 
							   unsigned long	*pulPeriodicID,
							   unsigned long	ulTimeInterval)

{
	char			szBuffer[PERIODICMSG_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Synchronize Access to this function.
	if (WaitForSingleObject(m_hSyncAccess, PERIODICMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("PeriodicMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		SetLastErrorText("PeriodicMsg : Failed Synchronization");
		return(J2534_ERR_FAILED);	
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check if NULL pointers.
	if (pstMsg == NULL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
						 szBuffer);
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_MSG);
	}

	// Is number of Periodic exceeded the maximum.
	if (IsListFull())
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_EXCEEDED_LIMIT);
		m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
						 szBuffer);
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_EXCEEDED_LIMIT);
	}

	// Check if the Datasize and TxFlags are the same for Pattern,
	// and Mask messages.
	if (pstMsg->ulDataSize > PERIODICMSG_MSGLEN_MAX)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_MSG);
	}
	

	// Start Periodic on Device.
	if ((enJ2534Error = m_pclsDevice->vStartPeriodic(
										m_ulDevChannelID, pstMsg, 
										ulTimeInterval, pulPeriodicID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(enJ2534Error);
	}

	// Add the periodic info. to our internal Database.
	if ((enJ2534Error = Add(pstMsg, ulTimeInterval,pulPeriodicID)) !=
						J2534_STATUS_NOERROR)
	{
		// Stop the Device Periodic.
		m_pclsDevice->vStopPeriodic(m_ulDevChannelID,*pulPeriodicID);
		// Log error to file.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(enJ2534Error);
	}

	SetEvent(m_hSyncAccess);

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: UpdatePeriodic
//	Input Params	: 
//	Output Params	: 
//	Description		: This function updates a given msg. periodic if Periodic Id is valid
//					  
//-----------------------------------------------------------------------------
J2534ERROR CPeriodicMsg::UpdatePeriodic(
							   PASSTHRU_MSG		*pstMsg, 
							   unsigned long	ulPeriodicID,
							   unsigned long	ulTimeInterval)

{
	char			szBuffer[PERIODICMSG_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Synchronize Access to this function.
	if (WaitForSingleObject(m_hSyncAccess, PERIODICMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("PeriodicMsg.cpp", "UpdatePeriodic()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		SetLastErrorText("PeriodicMsg : Failed Synchronization");
		return(J2534_ERR_FAILED);	
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "UpdatePeriodic()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check if NULL pointers.
	if (pstMsg == NULL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		m_pclsLog->Write("PeriodicMsg.cpp", "UpdatePeriodic()", DEBUGLOG_TYPE_ERROR, 
						 szBuffer);
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_MSG);
	}

	// Check if the Datasize and TxFlags are the same for Pattern,
	// and Mask messages.
	if (pstMsg->ulDataSize > PERIODICMSG_MSGLEN_MAX)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			m_pclsLog->Write("PeriodicMsg.cpp", "UpdatePeriodic()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_MSG);
	}

	// Validate if the periodic msg. for this PeriodicID was started earlier.
	if (!IsPeriodicIDValid(ulPeriodicID))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
			m_pclsLog->Write("PeriodicMsg.cpp", "UpdatePeriodic()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_MSG_ID);
	}
	

	// Start Periodic on Device.
	if ((enJ2534Error = m_pclsDevice->vUpdatePeriodic(
										m_ulDevChannelID, pstMsg, 
										ulTimeInterval, ulPeriodicID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(enJ2534Error);
	}


	SetEvent(m_hSyncAccess);

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: StopPeriodic
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops the periodic corresspond to a given ID.
//-----------------------------------------------------------------------------
J2534ERROR CPeriodicMsg::StopPeriodic(unsigned long ulPeriodicID)

{
	char			szBuffer[PERIODICMSG_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, PERIODICMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		SetLastErrorText("PeriodicMsg : Failed Synchronization");
		return(J2534_ERR_FAILED);	
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Validate if the periodic msg. for this PeriodicID was started earlier.
	if (!IsPeriodicIDValid(ulPeriodicID))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
			m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(J2534_ERR_INVALID_MSG_ID);
	}

	// Stop the periodic in device if it were set earlier.
	if ((enJ2534Error = m_pclsDevice->vStopPeriodic(m_ulDevChannelID, ulPeriodicID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("PeriodicMsg.cpp", "StartPeriodic()", DEBUGLOG_TYPE_ERROR, 
							 szBuffer);
		}
		SetEvent(m_hSyncAccess);
		return(enJ2534Error);
	}

	// Delete the periodic
	Delete(ulPeriodicID);

	SetEvent(m_hSyncAccess);

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: StopPeriodic
//	Input Params	: 
//	Output Params	: 
//	Description		: This is an override function that stops all the periodics.
//-----------------------------------------------------------------------------
J2534ERROR CPeriodicMsg::StopPeriodic()

{
	char			szBuffer[PERIODICMSG_ERROR_TEXT_SIZE];
	unsigned long	i;

	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, PERIODICMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic(All)", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		SetLastErrorText("PeriodicMsg : Failed Synchronization");
		return(J2534_ERR_FAILED);	
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic(All)", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Run through all the Periodics and delete all of them.
	for (i = 1; i <= PERIODICMSG_LIST_SIZE; i++)
	{
		// Delete the periodic
		Delete(i);
	}

	SetEvent(m_hSyncAccess);
	return(J2534_ERR_INVALID_MSG_ID);
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("PeriodicMsg.cpp", "StopPeriodic(All)", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: Add
//	Input Params	: void
//	Output Params	: void
//	Description		: This function assigns a Msg. ID, adds message to 
//					  internal buffer and returns the PeriodicID to user.
//-----------------------------------------------------------------------------
J2534ERROR CPeriodicMsg::Add(PASSTHRU_MSG *pstMsg, 
							 unsigned long ulTimeInterval,
							 unsigned long *pulPeriodicID)
{
	unsigned long	ulPeriodicID;
	char			szBuffer[PERIODICMSG_ERROR_TEXT_SIZE];

	ulPeriodicID=*pulPeriodicID;

	if ((ulPeriodicID < 1) && (ulPeriodicID > (PERIODICMSG_LIST_SIZE+1)))
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_EXCEEDED_LIMIT);
			m_pclsLog->Write("PeriodicMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_EXCEEDED_LIMIT);	
	}

	// Save Mask periodic in our internal buffer.
	if ((m_stPeriodicList[ulPeriodicID].pstMsg = new PASSTHRU_MSG) == NULL)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("PeriodicMsg.cpp", "Add()", DEBUGLOG_TYPE_ERROR, 
						     "Could not create Object for Periodic Mask");
		}
		SetLastErrorText("PeriodicMsg : Could not create Object for Periodic Msg.");
		return(J2534_ERR_FAILED);	
	}
	memcpy(m_stPeriodicList[ulPeriodicID].pstMsg, pstMsg, 
		   min(sizeof(PASSTHRU_MSG), sizeof(PASSTHRU_MSG)));

	// Save Time Interval.
	m_stPeriodicList[ulPeriodicID].ulTimeInterval = ulTimeInterval;

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: Delete
//	Input Params	: void
//	Output Params	: void
//	Description		: This function removes the periodic from the Database that 
//					  was added earlier.
//-----------------------------------------------------------------------------
J2534ERROR CPeriodicMsg::Delete(unsigned long ulPeriodicID)
{
	if (m_stPeriodicList[ulPeriodicID].pstMsg != NULL)
	{
		delete m_stPeriodicList[ulPeriodicID].pstMsg;
		m_stPeriodicList[ulPeriodicID].pstMsg = NULL;
	}

	m_stPeriodicList[ulPeriodicID].ulTimeInterval = 0;


	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetNewPeriodicID
//	Input Params	: void
//	Output Params	: void
//	Description		: If all PeriodicIDs are used, returns 0 otherwise returns new
//					  PeriodicID to be used.
//-----------------------------------------------------------------------------
unsigned char CPeriodicMsg::GetNewPeriodicID()
{
	unsigned char	ucIdx;

	for (ucIdx = 1; ucIdx <= PERIODICMSG_LIST_SIZE; ucIdx++)
	{
		if (m_stPeriodicList[ucIdx].pstMsg == NULL)
			return(ucIdx);
	}
	
	return(0);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsPeriodicIDValid
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if the given PeriodicID is valid.
//-----------------------------------------------------------------------------
bool CPeriodicMsg::IsPeriodicIDValid(unsigned long ulPeriodicID)
{
	if (ulPeriodicID > 0 && ulPeriodicID <= PERIODICMSG_LIST_SIZE)
	{
		if (m_stPeriodicList[ulPeriodicID].pstMsg != NULL)
			return(true);
	}
	
	return(false);
}

//-----------------------------------------------------------------------------
//	Function Name	: IsListFull
//	Input Params	: void
//	Output Params	: void
//	Description		: Checks to see if the list to store Periodic info. is full.
//-----------------------------------------------------------------------------
bool CPeriodicMsg::IsListFull()
{
	unsigned long ucIdx;

	for (ucIdx = 1; ucIdx <= PERIODICMSG_LIST_SIZE; ucIdx++)
	{
		if (m_stPeriodicList[ucIdx].pstMsg == NULL)
			return(false);
	}
	
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetLastErrorText()
//	Input Params	: 
//	Output Params	: 
//	Return			: Returns an Error Status.
//	Description		: This function sets the error Text. The last error occured
//					  could be retreived by the user by calling 
//					  GetLastErrorText().
//-----------------------------------------------------------------------------
void CPeriodicMsg::SetLastErrorText(char *pszErrorText)
{

	// Update the global with the last Error text so that the right 
	// error text is returned when calling GetLastErrorText().
	strncpy(m_szLastErrorText, pszErrorText, 
		   min((sizeof(m_szLastErrorText) - 1), strlen(pszErrorText)));
	strcpy(m_szLastErrorText, pszErrorText);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetLastErrorText()
//	Input Params	: szBuffer		 - Buffer in which the Text is returned.
//					  ulSizeOfBuffer - Size of Buffer provided by the user.
//	Output Params	: 
//	Return			: Returns an Error Status.
//	Description		: This function returns the error Text that was set by 
//					  SetLastErrorText().
//-----------------------------------------------------------------------------
void CPeriodicMsg::GetLastErrorText(char *pszBuffer, unsigned long ulSizeOfBuffer)
{
	// Synchronize Access this function.
	if (WaitForSingleObject(m_hSyncAccess, PERIODICMSG_SYNC_TIMEOUT) 
							!= WAIT_OBJECT_0)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("PeriodicMsg.cpp", "GetLastErrorText()", DEBUGLOG_TYPE_ERROR, 
						     "Failed Synchronization");
		}
		return;	
	}

	// Copy the Last Error Text that 
	strncpy(pszBuffer, m_szLastErrorText, 
			min(strlen(m_szLastErrorText), (ulSizeOfBuffer - 1)));
	strcpy(pszBuffer, m_szLastErrorText);

	SetEvent(m_hSyncAccess);
}


