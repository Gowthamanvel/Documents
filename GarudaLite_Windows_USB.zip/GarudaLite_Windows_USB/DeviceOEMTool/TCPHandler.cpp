#include "stdafx.h"
#include "TCPHandler.h"

/*
 *	Declaration of Thread Function for Accepting Client Connection & Reading Request
 *	data from client
 */
static DWORD WINAPI fnReadClientRequests(LPVOID lpParam);


//==========================================================================================
// CONTRUCTOR & DESTRUCTOR for the class CTCPHandler
//==========================================================================================
CTCPHandler::CTCPHandler()
{
	CSWICEGlobalMgr &cGblMgr = CSWICEGlobalMgr::GetSWICEGlobalMgr();

	//To initialize the TCP logfile
	m_pTCPDebugLog = cGblMgr.m_pDSServerDebugLog;

	//To initialize the class members
	m_dwReadThreadId = 0;
	m_hReadHandle = 0;
	m_serverSockId = INVALID_SOCKET;
	callbackNewClientConnection = NULL;
	callbackReceivedClientRequest = NULL;
	callbackClientLostConnection = NULL;
	m_strFileName = "TCPHandler.cpp";
}
CTCPHandler::~CTCPHandler()
{
	//To kill the thread
	if(m_hReadHandle != NULL)
		TerminateThread(m_hReadHandle,0);

	//To free the memory allocated for m_pTCPDebugLog
	if(m_pTCPDebugLog != NULL)
		delete m_pTCPDebugLog;
}
//==========================================================================================
// Name        : SetCallbackForNewConnection
// Author      : Vijay Kumar
// Description : Function to activate callback for New client connection
// I/P params  : fnptrNewClientConnection *fp
// Return      : NONE 		
//==========================================================================================
void CTCPHandler::SetCallbackForNewConnection(fnptrNewClientConnection fp)
{
	callbackNewClientConnection = fp;
}
//==========================================================================================
// Name        : fnptrReceivedClientRequest
// Author      : Vijay Kumar
// Description : Function to activate callback for Receiving client request
// I/P params  : fnptrReceivedClientRequest *fp
// Return      : NONE 		
//==========================================================================================
void CTCPHandler::SetCallbackForReceiveClientRequest(fnptrReceivedClientRequest fp)
{
	callbackReceivedClientRequest = fp;
}
//==========================================================================================
// Name        : fnptrReceivedClientRequest
// Author      : Vijay Kumar
// Description : Function to activate callback for Client Lost connection
// I/P params  : fnptrClientLostConnection *fp
// Return      : NONE 		
//==========================================================================================
void CTCPHandler::SetCallbackForClientLostConnection(fnptrClientLostConnection fp)
{
	callbackClientLostConnection = fp;
}
//==========================================================================================
// Name        : InitializeTCPServer
// Author      : Vijay Kumar
// Description : Function to intialize the server to accept clients and receives client requests
// I/P params  : NONE
// Return      : NONE 		
//==========================================================================================
bool CTCPHandler::InitializeTCPServer()
{
	struct sockaddr_in sockaddr;

	//To initalize the m_bAvailable array
	for(int nIdx =0;nIdx < MAX_DS_CLIENTS;nIdx++)
		m_bAvailable[nIdx] = false;

#ifdef WINDOWS_SYSTEM
	WSADATA wsaData;
	
	//To initialize the winsock library
	if(WSAStartup(0x101, &wsaData))
	{
		WriteDebugLog("InitializeTCPServer()",ENM_LOG_ERROR,WINSOCK_INIT_FAIL);//To support debugging
		return false;
	}
	
	WriteDebugLog("InitializeTCPServer()",ENM_LOG_IMP,WINSOCK_INIT_SUCCESS);//To support debugging
#endif
	
	//To create the server socket
	m_serverSockId = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if(m_serverSockId == INVALID_SOCKET)
	{
		WriteDebugLog("InitializeTCPServer()",ENM_LOG_ERROR,CREATE_SOCK_FAIL);//To support debugging
		return false;
	}
	
	WriteDebugLog("InitializeTCPServer()",ENM_LOG_IMP,CREATE_SOCK_SUCCESS);//To support debugging

	//To initialize the sockaddr_in structure
	sockaddr.sin_family = AF_INET;
    sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	sockaddr.sin_port = htons(PORT_NO);
	
	//To bind the socket
	if(bind(m_serverSockId,(struct sockaddr*)&sockaddr,sizeof(struct sockaddr_in)) == SOCKET_ERROR)
	{
		WriteDebugLog("InitializeTCPServer()",ENM_LOG_ERROR,BIND_SOCK_FAIL);//To support debugging
		return false;
	}

	WriteDebugLog("InitializeTCPServer()",ENM_LOG_IMP,BIND_SOCK_SUCCESS);//To support debugging
	
	//To listen the client connections
	if(listen(m_serverSockId,MAX_DS_CLIENTS) == SOCKET_ERROR)
	{
		WriteDebugLog("InitializeTCPServer()",ENM_LOG_ERROR,LISTEN_PORT_FAIL);//To support debugging
		return false;
	}

	WriteDebugLog("InitializeTCPServer()",ENM_LOG_IMP,LISTEN_PORT_SUCCESS);//To support debugging
	
	//Create thread to accept client connecions and read client request data
	m_hReadHandle = CreateThread(NULL,0,fnReadClientRequests,this,0,&m_dwReadThreadId);
	if(m_hReadHandle == NULL)
	{
		WriteDebugLog("InitializeTCPServer()",ENM_LOG_ERROR,CREATE_TCP_THREAD_FAIL);//To support debugging
		return false;
	}

	WriteDebugLog("InitializeTCPServer()",ENM_LOG_IMP,CREATE_TCP_THREAD_SUCCESS);//To support debugging
	return true;
}

//==========================================================================================
// Name        : CheckForAcceptConnection
// Author      : Vijay Kumar
// Description : It polls on the port to accept the new client connections
// I/P params  : SOCKET serversockId, server socket id
//				 SOCKET &clientsockId
//				 struct sockaddr_in &sockaddr
//				 int nType, nType - 0 if strIpAddress is passing as address otherwise name
// Return      : SOCKET_ERROR  - when server lost its connection.
//				 SUCCESS - when sever accepts new connection
//				 TIME_OUT -  when no connections are there to accept 		
//==========================================================================================
int CTCPHandler::CheckForAcceptConnection(SOCKET serversockId,SOCKET &clientsockId,struct sockaddr_in &sockaddr)
{
	std::string strTemp;
	fd_set fdReadSet;
	struct timeval timeout;
	int nResult;
	int nClientLength = 0;
	struct sockaddr_in sockaddr1;
	int nIdx;

	//To set the timeout value
	timeout.tv_sec = 0;
	timeout.tv_usec = 5;

	//To reset the fdReadSet
	FD_ZERO(&fdReadSet);
	FD_SET(serversockId,&fdReadSet);
	
	nResult = select(1,&fdReadSet,NULL,NULL,&timeout);
	FD_CLR(serversockId,&fdReadSet);

	if(nResult == SOCKET_ERROR || nResult == TIME_OUT_ERROR)
		return TIME_OUT;

	nClientLength = sizeof(struct sockaddr_in);
	nResult = accept(serversockId,(struct sockaddr*)&sockaddr1,&nClientLength);
	if(nResult == SOCKET_ERROR)
		return SOCKET_ERROR;

	//To get the available id to assign to new client
	for(nIdx = 0;nIdx < MAX_DS_CLIENTS;nIdx++)
	{
		if(!m_bAvailable[nIdx])
			break;
	}

	if(nIdx == MAX_DS_CLIENTS)
	{
		
	}
	else
	{
		WriteDebugLog("CheckForAcceptConnection()",ENM_LOG_IMP,NEW_CONNECTION_ACCEPT);//To support debugging

		m_bAvailable[nIdx] = true;
		m_clientSockIds[nIdx] = nResult;
		
		//To support the call back
		if(callbackNewClientConnection != NULL)
			callbackNewClientConnection(nIdx);
	}

	clientsockId = nResult;
	return SUCCESS;
}

//==========================================================================================
// Name        : GetClientMessage
// Author      : Vijay Kumar
// Description : 
// I/P params  : SOCKET sockId
//				 unsigned char *puchBuffer
//				 int nBufferSize
// Return      : SOCKET_ERROR  - when server lost its connection.
//				 SUCCESS - when sever accepts new connection
//				 TIME_OUT -  when no connections are there to accept 		
//==========================================================================================
int CTCPHandler::GetClientMessage(SOCKET sockId,unsigned char *puchBuffer,int nBufferSize,int &nMessageSize)
{
	int nStatus;
	int nBytesRead;
	unsigned char uchFrameType = 0;
	unsigned int nPayLoadLength = 0;
	unsigned char uchChecksum = 0;
	unsigned char uchComputedChecksum = 0;
	
	//Checking for start of message
	nStatus = CheckForStartOfMessage(sockId);
	if(nStatus != SUCCESS)
		return nStatus;

	WriteDebugLog("GetClientMessage()",ENM_LOG_COMMENT,NEW_CLIENT_REQUEST);//To support debugging

	//Reading the PayLoad Length of the message
	nStatus = ReadDataFromPort(sockId,puchBuffer,2,nBytesRead);
	if(nStatus != SUCCESS)
	{
		WriteDebugLog("GetClientMessage()",ENM_LOG_ERROR,TCP_PAYLOAD_LENGTH_ERR);//To support debugging
		return nStatus;
	}

	nPayLoadLength = puchBuffer[1];
	nPayLoadLength |= (puchBuffer[0] << 8);

	WriteDebugLog("GetClientMessage()",ENM_LOG_COMMENT|ENM_LOG_DESCRIPTION,FormatDescription(TCP_PAYLOAD_LENGTH,nPayLoadLength));//To support debugging

	//Reading the FrameType
	nStatus = ReadDataFromPort(sockId,puchBuffer,1,nBytesRead);
	if(nStatus != SUCCESS)
	{
		WriteDebugLog("GetClientMessage()",ENM_LOG_ERROR,FRAME_TYPE_ERR);//To support debugging
		return nStatus;
	}

	//Validating the Frame Type
	if(puchBuffer[0] != FRAME_TYPE)
	{
		WriteDebugLog("GetClientMessage()",ENM_LOG_ERROR,FormatDescription(FRAME_TYPE_INVALID,puchBuffer[0]));//To support debugging
		return FRAMETYPE_ERROR;
	}

	//Reading the PayLoad of the TCP Frame
	nStatus = ReadDataFromPort(sockId,puchBuffer + 1,nPayLoadLength-1,nBytesRead);
	if(nStatus != SUCCESS)
	{
		WriteDebugLog("GetClientMessage()",ENM_LOG_ERROR,FormatDescription(PAYLOAD_ERR,nBytesRead));//To support debugging
		return nStatus;
	}

	//To update the message length
	nMessageSize = nBytesRead;

	WriteDebugLog("GetClientMessage()",ENM_LOG_COMMENT|ENM_LOG_DESCRIPTION,puchBuffer,nPayLoadLength,true);//To support debugging

	//Reading the Checksum of the message
	nStatus = ReadDataFromPort(sockId,&uchChecksum,1,nBytesRead);
	if(nStatus != SUCCESS)
	{
		WriteDebugLog("GetClientMessage()",ENM_LOG_ERROR,CHECKSUM_ERR);//To support debugging
		return nStatus;
	}

	WriteDebugLog("GetClientMessage()",ENM_LOG_COMMENT|ENM_LOG_DESCRIPTION,FormatDescription(CHECKSUM,uchChecksum));//To support debugging

	//To compute the checksum
	uchComputedChecksum = ComputeChecksum(puchBuffer,nPayLoadLength);

	//comparing checksum received and computed
	if(uchChecksum != uchComputedChecksum)
	{
		WriteDebugLog("GetClientMessage()",ENM_LOG_COMMENT|ENM_LOG_DESCRIPTION,FormatDescription(CHECKSUM_INVALID,uchComputedChecksum));//To support debugging
		return CHECKSUM_ERROR;
	}
	
	return SUCCESS;
}

//==========================================================================================
// Name        : CheckForStartOfMessage
// Author      : Vijay Kumar
// Description : It polls on the port to read the start of message
// I/P params  : SOCKET sockId - client Id of the socket
// Return      : SOCKET_ERROR  - when client lost its connection.with server
//				 SUCCESS - when sever reads start of message from client
//				 TIME_OUT		
//==========================================================================================
int CTCPHandler::CheckForStartOfMessage(SOCKET sockId)
{
	fd_set fdReadSet;
	struct timeval timeout;
	int nResult;
	unsigned char chBuffer[MAX_TCP_MESSAGE_LENGTH];
	int nRetryIdx;

	//To set the timeout value
	timeout.tv_sec = 0;
	timeout.tv_usec = 5;

	nRetryIdx = 0;
	while(nRetryIdx++ < MAX_ITERATIONS)
	{
		//To get the server socket id
		FD_ZERO(&fdReadSet);
		FD_SET(sockId,&fdReadSet);
		
		nResult = select(1,&fdReadSet,NULL,NULL,&timeout);
		FD_CLR(sockId,&fdReadSet);

		//checking for TIME_OUT or SOCKET_ERROR
		if(nResult == SOCKET_ERROR || nResult == TIME_OUT_ERROR)
			continue;

		//read the data from port
		nResult = recv(sockId,(char*)chBuffer,START_MESSAGE_LENGTH,0);

		//checking for client connection
		if(nResult == 0 || nResult == SOCKET_ERROR)
		{
			return SOCKET_ERROR;
		}
		
		//checking for the start of the message
		if(chBuffer[0] == START_OF_MESSAGE)
		{
			return SUCCESS;
		}
	}

	return TIME_OUT;
}

//==========================================================================================
// Name        : ReadDataFromPort
// Author      : Vijay Kumar
// Description : It polls on the port to read the nBufferSize bytes from client
// I/P params  : SOCKET sockId - client Id of the socket
//				 char *puchBuffer
//				 int nBufferSize
// Return      : It returns SOCKET_ERROR  - when client lost its connection.with server,
//				 SUCCESS - when sever reads start of message from client otherwise it returns the
//				 no. of bytes read		
//==========================================================================================
int CTCPHandler::ReadDataFromPort(SOCKET sockId,unsigned char *puchBuffer,int nBufferSize,int &nBytesRead)
{
	fd_set fdReadSet;
	struct timeval timeout;
	int nResult;
	int nRetryIdx;

	nBytesRead = 0;

	//To set the timeout value
	timeout.tv_sec = 0;
	timeout.tv_usec = 5;

	nRetryIdx = 0;
	while((nRetryIdx++ < MAX_ITERATIONS) && (nBytesRead < nBufferSize))
	{
		//To get the server socket id
		FD_ZERO(&fdReadSet);
		FD_SET(sockId,&fdReadSet);
		
		nResult = select(1,&fdReadSet,NULL,NULL,&timeout);
		FD_CLR(sockId,&fdReadSet);

		//checking for TIME_OUT or SOCKET_ERROR
		if(nResult == SOCKET_ERROR || nResult == TIME_OUT_ERROR)
			continue;

		//read the data from port
		nResult = recv(sockId,(char*)puchBuffer + nBytesRead,nBufferSize - nBytesRead,0);
		if(nResult == 0 || nResult == SOCKET_ERROR)
		{
			return SOCKET_ERROR;
		}

		nBytesRead += nResult;	
	}

	if(nBytesRead == nBufferSize)
		return SUCCESS;

	return TIME_OUT;
}
//==========================================================================================
// Name        : ComputeChecksum
// Author      : Vijay Kumar
// Description : It computes the check sum  of the received message
// I/P params  : char *puchBuffer
//				 int nBufferSize
// Return      : It returns calculated checksum		
//==========================================================================================
unsigned char CTCPHandler::ComputeChecksum(const unsigned char *puchBuffer,int nBufferSize)
{
	unsigned char uchChecksum = 0;

	for(int nByteIdx = 0;nByteIdx < nBufferSize;nByteIdx++)
		uchChecksum += puchBuffer[nByteIdx];

	uchChecksum = 0xFF - uchChecksum;

	return uchChecksum;
}
//==========================================================================================
// Name        : SendMessageToClient
// Author      : Vijay Kumar
// Description : It sends the server response to client
// I/P params  : int nClientId
//				 unsigned char *puchBuffer
//				 int nBufferSize
// Return      : NONE	
//==========================================================================================
void CTCPHandler::SendMessageToClient(int nClientId,unsigned char *puchBuffer,int nBuffersize)
{
	int nBytesSent = 0;
	int nRetVal;
	unsigned char uchTCPFrmBuffer[MAX_TCP_MESSAGE_LENGTH];
	int nTCPFrameLength;

	WriteDebugLog("SendMessageToClient()",ENM_LOG_COMMENT,FormatDescription("Message Length",nBuffersize));//To support debugging
	//WriteDebugLog("SendMessageToClient()",ENM_LOG_COMMENT|ENM_LOG_DESCRIPTION,puchBuffer,nBuffersize,true);//To support debugging

	if(m_bAvailable[nClientId])
	{
		//Format TCP frame
		nTCPFrameLength = FormatTCPFrame(uchTCPFrmBuffer,puchBuffer,nBuffersize);
		while(nBytesSent != nTCPFrameLength)
		{
			nRetVal = send(m_clientSockIds[nClientId],(char*)uchTCPFrmBuffer+ nBytesSent,nTCPFrameLength-nBytesSent,0);
			if(nRetVal == SOCKET_ERROR)
			{
				//Client lost the connection
				break;
			}
			nBytesSent += nRetVal;
		}
	}
	WriteDebugLog("SendMessageToClient()",ENM_LOG_IMP,"TCP Message sent");//To support debugging

}
//==========================================================================================
// Name        : FormatTCPFrame
// Author      : Vijay Kumar
// Description : This functions formats the server response data to TCP Frame format
// I/P params  : unsigned char *pTCPFrmBuffer
//				 unsigned char *pchMsgBuffer
//				 int nBufferSize
// Return      : It returns the length of the TCP Frame formatted	
//==========================================================================================
int CTCPHandler::FormatTCPFrame(unsigned char *pTCPFrmBuffer,const unsigned char *pchMsgBuffer,int nBuffersize)
{
	unsigned char uchChecksum;
	unsigned int nDataLength;

	if(pTCPFrmBuffer != NULL && pchMsgBuffer != NULL)
	{
		nDataLength = nBuffersize + 1;//adding 1byte for FRAME TYPE
		pTCPFrmBuffer[0] = START_OF_MESSAGE;
		pTCPFrmBuffer[1] = (unsigned char)(nDataLength >> 0x08);
		pTCPFrmBuffer[2] = (unsigned char) nDataLength;
		pTCPFrmBuffer[3] = FRAME_TYPE;

		memcpy(pTCPFrmBuffer+4,pchMsgBuffer,nBuffersize);

		//calculate the checksum
		uchChecksum = ComputeChecksum(pTCPFrmBuffer + 3,nDataLength);

		pTCPFrmBuffer[nDataLength + 3] = uchChecksum;
	}

	return nDataLength + 4;
}
//==========================================================================================
// Name        : WriteDebugLog
// Author      : Vijay Kumar
// Description : Function to log the debug statements
// I/P params  : 
// Return      : It returns true if it logs the debug statment otherwise false	
//==========================================================================================
bool CTCPHandler::WriteDebugLog(std::string strFunctionName,int nDebugType,std::string strDescription)
{
	CSWICEGlobalMgr &cGblMgr = CSWICEGlobalMgr::GetSWICEGlobalMgr();

	//checking whether logfile created or not
	if(m_pTCPDebugLog == NULL)
		return false;

	//checking enmDebugType enables or not
	if((cGblMgr.m_nTCPHandlerLogType & nDebugType) == 0)
		return false;

	//logging the debug statment
	return m_pTCPDebugLog->Write(m_strFileName,strFunctionName,(enum DEBUG_STATEMENT_TYPE)nDebugType,strDescription);
}
//==========================================================================================
// Name        : WriteDebugLog
// Author      : Vijay Kumar
// Description : Function to log the debug statements
// I/P params  : 
// Return      : It returns true if it logs the debug statment otherwise false	
//==========================================================================================
bool CTCPHandler::WriteDebugLog(std::string strFunctionName,int nDebugType,unsigned char *puchBuffer,
		unsigned long ulLength,bool bHex)
{
	CSWICEGlobalMgr &cGblMgr = CSWICEGlobalMgr::GetSWICEGlobalMgr();

	//checking whether logfile created or not
	if(m_pTCPDebugLog == NULL)
		return false;

	//checking enmDebugType enables or not
	if((cGblMgr.m_nTCPHandlerLogType & nDebugType) == 0)
		return false;

	//logging the debug statment
	return m_pTCPDebugLog->Write(m_strFileName,strFunctionName,(enum DEBUG_STATEMENT_TYPE)nDebugType,puchBuffer,ulLength,bHex);
}
//==========================================================================================
// Name        : fnReadClientRequests
// Author      : Vijay Kumar
// Description : Thread function to accept client connections and client requests
// I/P params  : LPVOID lpParam
// Return      : DWORD 		
//==========================================================================================
DWORD WINAPI fnReadClientRequests(LPVOID lpParam)
{
	CTCPHandler *pcTCPHnd;
	SOCKET serversockId;
	SOCKET clientsockId;
	SOCKET *pClientIds;;
	struct sockaddr_in clientsockaddr;
	unsigned char uchBuffer[MAX_TCP_MESSAGE_LENGTH];
	int nResult;
	int nMessageSize;

	pcTCPHnd = (CTCPHandler*)lpParam;
	serversockId  = pcTCPHnd->m_serverSockId;
	pClientIds = pcTCPHnd->m_clientSockIds;

	while(1)
	{
		//accept new client connections
 		nResult = pcTCPHnd->CheckForAcceptConnection(serversockId,clientsockId,clientsockaddr);
		if(nResult == SOCKET_ERROR)
		{
			//Error in accepting client connections
		}

		//To read the client requests
		for(int nIdx =0;nIdx <MAX_DS_CLIENTS;nIdx++)
		{
			if(pcTCPHnd->m_bAvailable[nIdx])
			{
				nResult = pcTCPHnd->GetClientMessage(pClientIds[nIdx],uchBuffer,sizeof(uchBuffer),nMessageSize);
				if(nResult == SOCKET_ERROR)
				{
					//Client Lost its connection with server. Free client Id
					pcTCPHnd->m_bAvailable[nIdx] = false;

					//To support the callback
					if(pcTCPHnd->callbackClientLostConnection != NULL)
					{
						pcTCPHnd->callbackClientLostConnection(nIdx);
					}
				}
				else if(nResult == SUCCESS)
				{
					//To support the callback 
					if(pcTCPHnd->callbackReceivedClientRequest != NULL)
					{
						pcTCPHnd->callbackReceivedClientRequest(nIdx,uchBuffer+1,nMessageSize);
					}
				}
			}
		}

		Sleep(1);
	}

	return 0;
}
