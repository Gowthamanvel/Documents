/******************************************************************************
					Global Edge Softwrae Ltd.,
*****************************************************************************
 Project Name			: Garuda Lite - J2534 API
 File Name				: StnDevice.h
 Description			: implementation of StnDevice class
 Date					: Jan 06, 2020
 Version				: 1.0
 Author					: Chethankumar
 Revision				: 
 Copyright (c) 2020 Global Edge Software Ltd

 File		 Date			Author						Description
 Version
_____________________________________________________________________________
 
 1.0		 Jan 06, 2020	Chethankumar M S		Bridge between STN commands and J2534 API
_____________________________________________________________________________
*****************************************************************************/

#include "stdafx.h"
#include "StnDevice.h"
#include <string.h>
//#include <iostream>
#include <wchar.h>
#include <tchar.h>
#include <initguid.h>
#include <windows.h>
#include <Setupapi.h>
#include <string>
#include <chrono>
#include <thread>
#pragma comment (lib, "Setupapi.lib")

//Buffer length
#define BUFF_LEN 20
#define GarudaLiteBaudRate	921600

DWORD dwEventMask;

DEVICEBASE_CALLBACK_RX_FUNC RxfunCallBack;
DEVICEBASE_CALLBACK_FC_FUNC OnFirstFramefunCallBack;
LPVOID gpCAN ;
DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC OnISO15765RxMsgSetstatusfnCallBack;
int filterCount = 0;
bool flowControlReceived = TRUE;
int seperationTime = 0x00;
unsigned long baudrate;

void GetComPort(TCHAR* pszComePort, const WCHAR* vid, const WCHAR* pid)
{
	HDEVINFO DeviceInfoSet;
	DWORD DeviceIndex = 0;
	SP_DEVINFO_DATA DeviceInfoData;
	PCSTR DevEnum = "USB";
	WCHAR ExpectedDeviceId[80] = { 0 }; //Store hardware id
	BYTE szBuffer[1024] = { 0 };
	DEVPROPTYPE ulPropertyType;
	DWORD dwSize = 0;
	DWORD Error = 0;
	//create device hardware id
	wcscpy_s(ExpectedDeviceId, L"vid_");
	wcscat_s(ExpectedDeviceId, _T(vid));
	wcscat_s(ExpectedDeviceId, L"&pid_");
	wcscat_s(ExpectedDeviceId, pid);
	//SetupDiGetClassDevs returns a handle to a device information set
	DeviceInfoSet = SetupDiGetClassDevs(
		NULL,
		DevEnum,
		NULL,
		DIGCF_ALLCLASSES | DIGCF_PRESENT);
	if (DeviceInfoSet == INVALID_HANDLE_VALUE)
		return;
	//Fills a block of memory with zeros
	ZeroMemory(&DeviceInfoData, sizeof(SP_DEVINFO_DATA));
	DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
	//Receive information about an enumerated device
	while (SetupDiEnumDeviceInfo(
		DeviceInfoSet,
		DeviceIndex,
		&DeviceInfoData))
	{
		DeviceIndex++;
		//Retrieves a specified Plug and Play device property
		if (SetupDiGetDeviceRegistryProperty(DeviceInfoSet, &DeviceInfoData, SPDRP_HARDWAREID,
			&ulPropertyType, (BYTE*)szBuffer,
			sizeof(szBuffer),   // The size, in bytes
			&dwSize))
		{
			HKEY hDeviceRegistryKey;
			//Get the key
			hDeviceRegistryKey = SetupDiOpenDevRegKey(DeviceInfoSet, &DeviceInfoData, DICS_FLAG_GLOBAL, 0, DIREG_DEV, KEY_READ);
			if (hDeviceRegistryKey == INVALID_HANDLE_VALUE)
			{
				Error = GetLastError();
				break; //Not able to open registry
			}
			else
			{
				// Read in the name of the port
				char pszPortName[BUFF_LEN];
				DWORD dwSize = sizeof(pszPortName);
				DWORD dwType = 0;
				if ((RegQueryValueEx(hDeviceRegistryKey, "PortName", NULL, &dwType, (LPBYTE)pszPortName, &dwSize) == ERROR_SUCCESS) && (dwType == REG_SZ))
				{
					// Check if it really is a com port
					if (_tcsnicmp(pszPortName, _T("COM"), 3) == 0)
					{
						int nPortNr = _ttoi(pszPortName + 3);
						if (nPortNr != 0)
						{
							_tcscpy_s(pszComePort, BUFF_LEN, pszPortName);
						}
					}
				}
				// Close the key now that we are finished with it
				RegCloseKey(hDeviceRegistryKey);
			}
		}
	}
	if (DeviceInfoSet)
	{
		SetupDiDestroyDeviceInfoList(DeviceInfoSet);
	}
}



CStnDevice::CStnDevice(CDebugLog * pclsDebugLog) : CDeviceBase(pclsDebugLog)
{
    
	DeviceConnected = FALSE;
	hSerCom = NULL;
	hCallBckThread = NULL;
	m_CmdAck = NULL;
	m_ulLastErrorCode = J2534_ERR_NOT_SUPPORTED;
	ProtocolConnected = J2534_PROTOCOL_NUM;
	StnResponse = NONE;

	fpSerialInput = NULL;
	fpSerialOut = NULL;
}


CStnDevice::~CStnDevice()
{

	CloseSerialPort();

	/* Close all the handles if opened and clear all variables*/

}


/*****************************************************************************
*            CALL BACK Function for receive
******************************************************************************/
DWORD WINAPI CallBackFun(void* vP)
{
	BOOL Status = FALSE;
	DWORD dwEventMask;
	int result = 0;
	int length = 0;


	CStnDevice  *pStnDev = reinterpret_cast<CStnDevice*>(vP);

	Status = SetCommMask(pStnDev->hSerCom, EV_RXCHAR);

	while(pStnDev->DeviceConnected)
	{
		
		Status = WaitCommEvent(pStnDev->hSerCom, &dwEventMask, NULL);
		pStnDev->StnResponse = NONE;
		if(Status != 0)
		{
			pStnDev->ReadResponseFromGaruda(&length);
			if(pStnDev->ProtocolConnected != J2534_PROTOCOL_NUM)
			{
				if(strncmp((const char *)pStnDev->SerialBuffer,"?", 1) == 0)
				{
					pStnDev->StnResponse = NEGATIVE_ACK;
				}
				else
				{

					result = strncmp((const char *)pStnDev->SerialBuffer,"OK", 2);
					if(result != 0)
					{
						result = strncmp((const char *)pStnDev->SerialBuffer,"ERROR", 5);
						if(result != 0)
						{
							result = strncmp((const char *)pStnDev->SerialBuffer,"DATA", 4);
							if(result != 0)
							{
								result = strncmp((const char *)pStnDev->SerialBuffer,"SEARCHING", 9);
								if(result != 0)
									pStnDev->StnResponse = SEARCHING;
							
								switch(pStnDev->ProtocolConnected)
								{
									case ISO15765:
										break;

									default:
										break;
								}
							}
							pStnDev->StnResponse = STN_NO_DATA;
						}
						pStnDev->StnResponse = CAN_ERROR;
					}
					pStnDev->StnResponse = POSITIVE_ACK;
				}
			}

			SetEvent(pStnDev->m_CmdAck);
		}

	}

	return 0;
}


/******************************************************************************
   Function Name    : vOpenDevice()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice::vOpenDevice()
{
	DWORD dwID = 0;

    /*If device already opened, return J2534_ERR_DEVICE_IN_USE.*/
    if(DeviceConnected)
        return J2534_ERR_DEVICE_IN_USE;

	if(!OpenSerialPort())
		return J2534_ERR_DEVICE_NOT_CONNECTED;

	SetCommMask(hSerCom, EV_RXCHAR);

	if (fpSerialInput != NULL)
		fclose(fpSerialInput);

	if (fpSerialOut != NULL)
		fclose(fpSerialOut);

	fpSerialInput = fopen("Serial_Input_Comm.txt", "w");
	fpSerialOut = fopen("Serial_Output_Comm.txt", "w");

/*	if(hCallBckThread == NULL)
    {
		hCallBckThread = ::CreateThread (NULL, 0, &CallBackFun, this, 0, &dwID);
    }
	
	m_CmdAck = CreateEvent(NULL, TRUE, FALSE, NULL);

*/
	
    return J2534_STATUS_NOERROR;
}

/******************************************************************************
   Function Name    : vCloseDevice()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice::vCloseDevice()
{
	if(!DeviceConnected)
        return J2534_ERR_DEVICE_NOT_CONNECTED;

	/* Close all the handles if opened and clear all variables*/

	CloseSerialPort();

	if (fpSerialInput != NULL)
		fclose(fpSerialInput);

	if (fpSerialOut != NULL)
		fclose(fpSerialOut);

	return J2534_STATUS_NOERROR;

}


/******************************************************************************
   Function Name    : vConnectProtocol()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice::vConnectProtocol(
										J2534_PROTOCOL  enProtocolID,
										unsigned long   ulFlags,
										unsigned long   ulBaudRate,
										DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
										DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
										DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
										LPVOID          pVoid,
										unsigned long   *pulChannelID)
{
	unsigned char protocolID[3] ;
	BOOL ExtndID = FALSE;
	BOOL Error = FALSE;
	baudrate = ulBaudRate;
	if(ProtocolConnected != J2534_PROTOCOL_NUM)
		return J2534_ERR_NOT_SUPPORTED;

	switch(enProtocolID)
	{
		case J1850VPW:
			return J2534_ERR_INVALID_PROTOCOL_ID;
			break;
		case J1850PWM:
			return J2534_ERR_INVALID_PROTOCOL_ID;
			break;
		case ISO9141:
			return J2534_ERR_INVALID_PROTOCOL_ID;
			break;
		case ISO14230:
			return J2534_ERR_INVALID_PROTOCOL_ID;
			break;
		case CAN:
		case ISO15765:

			RxfunCallBack = pfnCallback;
			OnFirstFramefunCallBack = pfirstframefnCallback;
			OnISO15765RxMsgSetstatusfnCallBack = psetRxstatusfnCallback;
			gpCAN = pVoid;

			/*Currently 250kbps for RAW CAN is not supported by STN*/

			ExtndID = (ulFlags & 0x100) && 1;
			
			if( (ulBaudRate != ISO15765_DATA_RATE_DEFAULT) && (ulBaudRate != ISO15765_DATA_RATE_LOW) && (ulBaudRate != ISO15765_DATA_RATE_MEDIUM) && (ulBaudRate != ISO15765_DATA_RATE_HIGH))
				return J2534_ERR_INVALID_BAUDRATE;

			if(ulBaudRate == ISO15765_DATA_RATE_DEFAULT)
			{
				if(ExtndID)
				{
					protocolID[0] = '3';
					protocolID[1] = '4';
				}
				else
				{
					protocolID[0] = '3';
					protocolID[1] = '3';
				}
			}
			else if (ulBaudRate == ISO15765_DATA_RATE_MEDIUM)
			{
				if (ExtndID)
				{
					protocolID[0] = '3';
					protocolID[1] = '6';
				}
				else
				{
					protocolID[0] = '3';
					protocolID[1] = '5';
				}
			}
			else if(ulBaudRate == ISO15765_DATA_RATE_LOW)
			{
				if(ExtndID)
				{
					protocolID[0] = '3';
					protocolID[1] = '6';
				}
				else
				{
					protocolID[0] = '3';
					protocolID[1] = '5';
				}
			}
			else 
			{
				if (ExtndID)
				{
					protocolID[0] = '3';
					protocolID[1] = '6';
				}
				else
				{
					protocolID[0] = '3';
					protocolID[1] = '5';
				}
			}
			
			Error = SetProtocolCommand((const char *)protocolID);
			if(!Error)
				return J2534_ERR_FAILED;

			ProtocolConnected = ISO15765;

			break;
		case ISO15765_CH1:

			RxfunCallBack = pfnCallback;
			OnFirstFramefunCallBack = pfirstframefnCallback;
			OnISO15765RxMsgSetstatusfnCallBack = psetRxstatusfnCallback;
			gpCAN = pVoid;

			ExtndID = (ulFlags & 0x100) && 1;

			if ((ulBaudRate != ISO15765_DATA_RATE_DEFAULT) && (ulBaudRate != ISO15765_DATA_RATE_LOW) && (ulBaudRate != ISO15765_DATA_RATE_MEDIUM) && (ulBaudRate != ISO15765_DATA_RATE_HIGH))
				return J2534_ERR_INVALID_BAUDRATE;

			if (ulBaudRate == ISO15765_DATA_RATE_LOW)
			{
				if (ExtndID)
				{
					protocolID[0] = '5';
					protocolID[1] = '4';
				}
				else
				{
					protocolID[0] = '5';
					protocolID[1] = '3';
				}
			}
			else if (ulBaudRate == ISO15765_DATA_RATE_MEDIUM)
			{
				if (ExtndID)
				{
					protocolID[0] = '5';
					protocolID[1] = '4';
				}
				else
				{
					protocolID[0] = '5';
					protocolID[1] = '3';
				}
			}
			else if (ulBaudRate == ISO15765_DATA_RATE_DEFAULT)
			{
				if (ExtndID)
				{
					protocolID[0] = '5';
					protocolID[1] = '4';
				}
				else
				{
					protocolID[0] = '5';
					protocolID[1] = '3';
				}
			}
			else
			{
				if (ExtndID)
				{
					protocolID[0] = '5';
					protocolID[1] = '4';
				}
				else
				{
					protocolID[0] = '5';
					protocolID[1] = '3';
				}
			}

			Error = SetProtocolCommand((const char*)protocolID);
			if (!Error)
				return J2534_ERR_FAILED;

			ProtocolConnected = ISO15765_CH1;

			break;
		case J1939_CH1:
			J2534_ERR_INVALID_PROTOCOL_ID;
			break;
		default:
			return J2534_ERR_INVALID_PROTOCOL_ID;
	}
	


	return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vDisconnectProtocol()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice::vDisconnectProtocol(unsigned long ulChannelID)
{

	ProtocolConnected = J2534_PROTOCOL_NUM;
	if (CloseProtocolCommand())
		return J2534_ERR_FAILED;

	return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vWriteMsgs()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice:: vWriteMsgs(unsigned long    ulChannelID,
                                       PASSTHRU_MSG *pstPassThruMsg,
                                       unsigned long    *pulNumMsgs)
{
	int dlc = 0;
	BOOL result = FALSE;
	dlc = (pstPassThruMsg->ulDataSize - 4);

	/*For multi frame */
	if(dlc > 7)
	{
		SendISO15765Frame(pstPassThruMsg,dlc);
	}
	else	/*For single frame*/
	{
		SendSingleFrame(pstPassThruMsg,dlc);
	}

	
	return J2534_ERR_FAILED;
}


/******************************************************************************
   Function Name    : vStartPeriodic()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice:: vStartPeriodic(unsigned long    ulChannelID,
                                           PASSTHRU_MSG     *pstMsg,
                                           unsigned long    ulTimeInterval,
                                           unsigned long    *pulPeriodicRefID)
{
	return J2534_ERR_NOT_SUPPORTED;
	//return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vStopPeriodic()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice:: vStopPeriodic(unsigned long ulChannelID,
                                          unsigned long ulPeriodicRefID)
{

	return J2534_ERR_NOT_SUPPORTED;
	//return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vStartFilter()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice:: vStartFilter(unsigned long  ulChannelID,
                                         J2534_FILTER   enFilterType,
                                         PASSTHRU_MSG   *pstMask,
                                         PASSTHRU_MSG   *pstPattern,
                                         PASSTHRU_MSG   *pstFlowControl,
                                         unsigned long  *pulFilterRefID)
{

	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	int indx = 0;
	int length = 0;
	unsigned char passFilterCmnd[30] = {'S','T','F','P','A'};
	unsigned char blockFilterCmnd[30] ={'S','T','F','B','A'};
	unsigned char flowcontrolCmnd[30] = {'S','T','F','F','C','A'};
	unsigned char asciiBytes[30] ;
//	unsigned char FilterCmnd[16] = "STCFCPA6F1,610\r";

	if(enFilterType == J2534_FILTER_FLOW_CONTROL)
	{
		//Setting Pattern
		indx = 6;
		DecimalToAscii(pstPattern,asciiBytes,pstPattern->ulDataSize);
		if (pstPattern->ulTxFlags == 0x100)
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes, 8);
			indx = indx + 8;
		}
		else
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes[5], 3);
			indx = indx + 3;
		}

		flowcontrolCmnd[indx] = ',';
		indx++;

		//Setting Mask
		memset(asciiBytes,0,30);
		DecimalToAscii(pstMask,asciiBytes,pstMask->ulDataSize);
		if (pstMask->ulTxFlags == 0x100)
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes, 8);
			indx = indx + 8;
		}
		else
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes[5], 3);
			indx = indx + 3;
		}

		flowcontrolCmnd[indx] = '\r';
		indx++;
		
		//Sending STFPA [Pattern],[Mask]
		PurgeComm(hSerCom,PURGE_RXCLEAR);
		SendCommandToGaruda(flowcontrolCmnd,indx);
		Sleep(20);

		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
		if(stnResponse != POSITIVE_ACK)
			return J2534_ERR_FAILED;
	
		//Setting Flow control
		indx = 6;
		DecimalToAscii(pstFlowControl,asciiBytes,pstFlowControl->ulDataSize);
		if (pstFlowControl->ulTxFlags == 0x100)
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes, 8);
			indx = indx + 8;
		}
		else
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes[5], 3);
			indx = indx + 3;
		}
		
		flowcontrolCmnd[indx] = ',';
		indx++;

		//Setting Mask
		memset(asciiBytes,0,30);
		DecimalToAscii(pstMask,asciiBytes,pstMask->ulDataSize);
		if (pstMask->ulTxFlags == 0x100)
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes, 8);
			indx = indx + 8;
		}
		else
		{
			memcpy(&flowcontrolCmnd[indx], &asciiBytes[5], 3);
			indx = indx + 3;
		}

		flowcontrolCmnd[indx] = '\r';
		indx++;

		PurgeComm(hSerCom,PURGE_RXCLEAR);
		SendCommandToGaruda(flowcontrolCmnd,indx);
		Sleep(20);
		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';

		stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
		if(stnResponse != POSITIVE_ACK)
			return J2534_ERR_INVALID_MSG;

		//Chethan: for testing
		SetHeaderByte(pstFlowControl);

	}
	*pulFilterRefID = ++filterCount;
	
	return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vStopFilter()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice:: vStopFilter(unsigned long ulChannelID,
                                        unsigned long ulFilterRefID)
{

	unsigned char clearFilterCmnd[7] = "STFPC\r";
	int length = 0;
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;

	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(clearFilterCmnd,6);
	Sleep(20);

	WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if(stnResponse == NEGATIVE_ACK)
		return J2534_ERR_FAILED;

	return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vIoctl()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice:: vIoctl(unsigned long ulChannelID,
                                   J2534IOCTLID enumIoctlID,
                                   void *pInput,
                                   void *pOutput)
{

	return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vGetRevision()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice::vGetRevision(char *pchFirmwareVersion,
                                        char *pchDllVersion,
                                        char *pchApiVersion)
{
	strcpy(pchFirmwareVersion, "01.00.00");
	strcpy(pchDllVersion,"00.00.00.10");
	strcpy(pchApiVersion,"04.04");

	return J2534_STATUS_NOERROR;
}


/******************************************************************************
   Function Name    : vGetLastError()
   Input Params     :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
J2534ERROR CStnDevice::vGetLastError(char *pErrorDescription)
{
    if(pErrorDescription == NULL)
    {
        return J2534_ERR_NULLPARAMETER ;
    }
    switch(m_ulLastErrorCode)
    {
    case J2534_STATUS_NOERROR:
        strcpy(pErrorDescription , "Function call successful");
        break ;
    case J2534_ERR_NOT_SUPPORTED:
        strcpy(pErrorDescription , "Function not supported");
        break ;
    case J2534_ERR_INVALID_CHANNEL_ID:
        strcpy(pErrorDescription , "Invalid ChannelID value");
        break ;
    case J2534_ERR_INVALID_PROTOCOL_ID:
        strcpy(pErrorDescription , "Invalid ProtocolID value");
        break ;
    case J2534_ERR_NULLPARAMETER:
        strcpy(pErrorDescription , "NULL pointer supplied where a valid pointer is required");
        break ;

    case J2534_ERR_INVALID_IOCTL_VALUE:
        strcpy(pErrorDescription , "Invalid value for Ioctl parameter");
        break ;
    case J2534_ERR_INVALID_FLAGS:
        strcpy(pErrorDescription , "Invalid flag values");
        break ;
    case J2534_ERR_FAILED:
        //strcpy(pErrorDescription , "Undefined error., use PassThruGetLastError for description of error");
		strcpy(pErrorDescription , "Undefined error.");
        break ;

    case J2534_ERR_INVALID_DEVICE_ID:
        strcpy(pErrorDescription , "Device not connected to PC");
        break ;

    case J2534_ERR_TIMEOUT:
        strcpy(pErrorDescription , "Timeout. No message available to read or could not read the specified number of messages. The actual number of messages read is placed in <NumMsgs>");

        break ;
    case J2534_ERR_INVALID_MSG:
        strcpy(pErrorDescription , "Invalid message structure pointed to by pMsg ");
        break ;
    case J2534_ERR_INVALID_TIME_INTERVAL:
        strcpy(pErrorDescription , "Invalid TimeInterval value");
        break ;

    case J2534_ERR_EXCEEDED_LIMIT:
        strcpy(pErrorDescription , "Exceeded maximum number of message IDs or allocated space");
        break ;

    case J2534_ERR_INVALID_MSG_ID:
        strcpy(pErrorDescription , "Invalid MsgID value");
        break ;
    case J2534_ERR_DEVICE_IN_USE:
        strcpy(pErrorDescription , "Device already open and/or in use");
        break ;
    case J2534_ERR_INVALID_IOCTL_ID:
        strcpy(pErrorDescription , "Invalid IoctlID value");
        break ;

    case J2534_ERR_BUFFER_EMPTY:
        strcpy(pErrorDescription , "Protocol message buffer empty");
        break ;

    case J2534_ERR_BUFFER_FULL:
        strcpy(pErrorDescription , "Protocol message buffer full");
        break ;
    case J2534_ERR_BUFFER_OVERFLOW:
        strcpy(pErrorDescription , "Protocol message buffer overflow");
        break ;
    case J2534_ERR_PIN_INVALID:
        strcpy(pErrorDescription , "Invalid pin number");
        break ;

    case J2534_ERR_CHANNEL_IN_USE:
        strcpy(pErrorDescription , "Channel already in use");
        break ;
    case J2534_ERR_MSG_PROTOCOL_ID:
        strcpy(pErrorDescription , "Protocol type does not match the protocol associated with Channel ID");
        break ;

    case J2534_ERR_INVALID_FILTER_ID:
        strcpy(pErrorDescription , " Invalid MsgID value");
        break ;
    case J2534_ERR_NO_FLOW_CONTROL:
        strcpy(pErrorDescription , "An attempt was made to send a message on an ISO15765 ChannelID before a flow control filter was established.");
        break ;
    case J2534_ERR_NOT_UNIQUE:
        strcpy(pErrorDescription , "  A CAN ID in PatternMsg or FlowControlMsg matches either ID in an existing Flow Control Filter");
        break ;
    case J2534_ERR_INVALID_BAUDRATE:
        strcpy(pErrorDescription , "Desired baud rate cannot be achieved within tolerances");
        break ;
    case J2534_ERR_DEVICE_NOT_CONNECTED:
        strcpy(pErrorDescription , "Device not connected");
        break ;
    default :
        strcpy(pErrorDescription , "Unknown Last error !!");
        break ;
    }
    return J2534_STATUS_NOERROR ;
}




J2534ERROR CStnDevice::vUpdatePeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	pulPeriodicRefID)
{

	return J2534_STATUS_NOERROR ;
}


J2534ERROR CStnDevice::vProgrammingVoltage(unsigned long ulDeviceID,
									    unsigned long ulPin,
									    unsigned long ulVoltage)
{
	return J2534_STATUS_NOERROR ;
}


BOOL  CStnDevice::vIsDeviceConnected(BOOL bFlag)
{
	return DeviceConnected;
}

/******************************************************************************
   Function Name    : OpenSerialPort()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
bool CStnDevice::OpenSerialPort(void)
{
	BOOL Status = FALSE;
	DCB dcbSerialParams = { 0 };

	TCHAR pszPortName[BUFF_LEN] = { 0 };

	//function to get com id
	GetComPort(pszPortName, L"03EB", L"5745");

	//Implement the query and validation part later

	hSerCom = CreateFile(pszPortName,          // for COM1�COM9 only
						GENERIC_READ | GENERIC_WRITE, //Read/Write
						0,               // No Sharing
						NULL,            // No Security
						OPEN_EXISTING,   // Open existing port only
						0,               // Non Overlapped I/O
						NULL);
				 
	if( hSerCom == INVALID_HANDLE_VALUE)
		return FALSE;
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
	Status = GetCommState(hSerCom, &dcbSerialParams);
	dcbSerialParams.BaudRate = 2000000;  // Setting BaudRate = 9600
	dcbSerialParams.ByteSize = 8;         // Setting ByteSize = 8
	dcbSerialParams.StopBits = ONESTOPBIT;// Setting StopBits = 1
	dcbSerialParams.Parity   = NOPARITY;  // Setting Parity = None  
	SetCommState(hSerCom, &dcbSerialParams);
	DeviceConnected = TRUE;

	return TRUE;
}



/******************************************************************************
   Function Name    : CloseSerialPort()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
void CStnDevice::CloseSerialPort(void)
{
	if(DeviceConnected)
		CloseHandle(hSerCom);

	DeviceConnected = FALSE;

}


/******************************************************************************
   Function Name    : SendCommandToGaruda()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
BOOL CStnDevice::SendCommandToGaruda(unsigned char* command,DWORD dwLength)
{
	DWORD dNoOFBytestoWrite;         // No of bytes to write into the port
	DWORD dNoOfBytesWritten = 0;     // No of bytes written to the port
	dNoOFBytestoWrite = dwLength;

	/*
	for (int nIdx = 0; nIdx < dwLength;nIdx++)
		fputc(command[nIdx], fpSerialOut);

	if(dwLength > 0)
		fputc('\n', fpSerialOut);
		*/

	fputs((char*) command, fpSerialOut);

	WriteFile(hSerCom,        // Handle to the Serial port
			command,     // Data to be written to the port
			dNoOFBytestoWrite,  //No of bytes to write
			&dNoOfBytesWritten, //Bytes written
			NULL);

	if(dNoOfBytesWritten == dNoOFBytestoWrite)
		return TRUE;
	
	return FALSE;
}

/******************************************************************************
   Function Name    : ReadResponseFromGaruda()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/	
void CStnDevice::ReadResponseFromGaruda(int * length)
{
	char TempChar; //Temporary character used for reading
	DWORD NoBytesRead = 0;
	int i = 0;
	memset(SerialBuffer,0,SERIAL_BUFFER_SIZE);

	do
	{
		ReadFile( hSerCom,           //Handle of the Serial port
				&TempChar,       //Temporary character
				sizeof(TempChar),//Size of TempChar
				&NoBytesRead,    //Number of bytes read
				NULL);
		
		if(NoBytesRead > 0)
		{
			SerialBuffer[i] = TempChar;// Store Tempchar into buffer
			i++;
		}
		
	}while ((SerialBuffer[i-1] != '>'));

	*length = i;

	if (i > 0)
	{
		fputs((char*)SerialBuffer, fpSerialInput);
	}
}


/******************************************************************************
   Function Name    : GetDataFromResponse()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
STN_RESPONSE CStnDevice::GetDataFromResponse(const char *response,PASSTHRU_MSG * data)
{
	STN_RESPONSE stnResponse = NONE;
	PASSTHRU_MSG* msg = new PASSTHRU_MSG;
	J2534_PROTOCOL  enProtocolID;
	unsigned char recvData[512] ;

	if(response[2] == '>')
	{
		return POSITIVE_ACK;
	}
	else if(strstr(response,"?") != NULL)
	{
		return NEGATIVE_ACK;
	}
	else if(strstr(response,"OK") != NULL)
	{
		return POSITIVE_ACK;
	}
	else if(strstr(response,"ERROR") != NULL)
	{
		return STN_ERROR;
	}
	else if(strstr(response,"NO DATA") != NULL)
	{
		return STN_NO_DATA;
	}
	else if(strstr(response,"UNABLE") !=NULL)
	{
		return UNABLE_TO_CONNECT;
	}
	else if (strstr(response, "DATA") != NULL)
	{
		return POSITIVE_ACK;
	}
/*	else if (strstr(response, "FC RX TIMEOUT") != NULL)
	{
		return POSITIVE_ACK;
	}*/
	else
	{
		processRxFrame((const char*)SerialBuffer, msg); 
		return POSITIVE_ACK;
	}	

	return STN_NO_DATA;
}

bool CStnDevice::processRxFrame(const char* rxData, PASSTHRU_MSG* msg)
{
	bool bResult = true;
	//bool isExtCAN;
	int dataLength = 0;
	int bytesReceived = 0;
	char tmpBuffer[512];
	int ntmpIdx = 0;
	int nASCIIConsequtiveCount = 0;
	bool isHeaderExt = true;

	memset(tmpBuffer, 0, 512);
	while (*rxData != '>')
	{
		if (*rxData == '\r')
		{
			if (ntmpIdx != 0)
			{
				ParseISO15765Frame((const char*)tmpBuffer, isHeaderExt, msg, &dataLength, &bytesReceived);
			}

			ntmpIdx = 0;
			nASCIIConsequtiveCount = 0;
			memset(tmpBuffer, 0, 512);
		}
		else
		{
			if (*rxData != ' ')
			{
				nASCIIConsequtiveCount++;
				if (nASCIIConsequtiveCount == 3)
					isHeaderExt = false;

				tmpBuffer[ntmpIdx++] = *rxData;
			}
			else
			{
				nASCIIConsequtiveCount = 0;
			}
		}

		rxData++;
	}
	OnISO15765RxMsgSetstatusfnCallBack(msg, gpCAN);
	RxfunCallBack(msg, gpCAN);
	return bResult;
}


bool CStnDevice::ParseISO15765Frame(const char* rxDataBytes, bool isExtCAN, PASSTHRU_MSG* msg,  int* dataLength, int* bytesRecevied)
{
	bool bResult = true;
	bool Error = FALSE;
	int nDataIdx = 3;
	byte dataBytesCAN[100];
	int nDataByteLength = 0;
	unsigned long ulHeader = 0;
	std::string strRxDataBytes = rxDataBytes;
	std::string strTemp = std::string("");

	//Setting dataIdx for Extended CAN
	if (isExtCAN)
		nDataIdx = 8;

	//To read the header / CAN ID
	strTemp = strRxDataBytes.substr(0, nDataIdx);
	ulHeader = strtoul(strTemp.c_str(), NULL, 16);

	//To read CAN databytes
	strRxDataBytes = strRxDataBytes.substr(nDataIdx, strRxDataBytes.length() - nDataIdx);
	nDataIdx = 0;
	while (strRxDataBytes != "")
	{
		if (strRxDataBytes.length() >= 2)
		{
			strTemp = strRxDataBytes.substr(0, 2);
			strRxDataBytes = strRxDataBytes.substr(2, strRxDataBytes.length() - 2);
		}
		else
		{
			strTemp = strRxDataBytes;
			strRxDataBytes = "";
		}

		dataBytesCAN[nDataIdx++] = (byte)strtoul(strTemp.c_str(), 0, 16);
	}

	//Parse CAN Frame
	byte pciByte = dataBytesCAN[0] & 0xF0;
	
	switch (pciByte)
	{
		case 0x00: //Single Frame
		{
			nDataIdx = 0;

			//Setting Header
			msg->ucData[nDataIdx++] = ((ulHeader & 0xFF000000 ) >> 24);
			msg->ucData[nDataIdx++] = ((ulHeader & 0x00FF0000) >> 16 );
			msg->ucData[nDataIdx++] = ((ulHeader & 0x0000FF00) >> 8);
			msg->ucData[nDataIdx++] = ((ulHeader&0xFF));

			//Copy databytes and setting data length
			(*dataLength) = dataBytesCAN[0];
			memcpy(msg->ucData + nDataIdx, dataBytesCAN + 1, (*dataLength));

			msg->ulProtocolID = 0x06;
			msg->ulTxFlags = 00;
			msg->ulTimeStamp = GetTickCount();
			msg->ulExtraDataIndex = (*dataLength) + 4;
			msg->ulRxStatus = 0x00;
			msg->ulDataSize = (*dataLength) + 4;
			(*bytesRecevied) = (*dataLength);

		}
		break;
		case 0x10: //First Frame
		{
			nDataIdx = 0;

			//Setting Header
			msg->ucData[nDataIdx++] = ((ulHeader & 0xFF000000) >> 24);
			msg->ucData[nDataIdx++] = ((ulHeader & 0x00FF0000) >> 16);
			msg->ucData[nDataIdx++] = ((ulHeader & 0x0000FF00) >> 8);
			msg->ucData[nDataIdx++] = ((ulHeader & 0xFF));
			//Copying 6 Bytes from First Frame
			memcpy(msg->ucData + nDataIdx, dataBytesCAN + 2, 6);
			nDataIdx += 5;

			//Setting data length received
			(*dataLength) = ((((dataBytesCAN[0] & 0x0F) << 8) | dataBytesCAN[1]) & 0x0FFF);
			msg->ulDataSize = (*dataLength) + 4;
			(*bytesRecevied) = 6;
			msg->ulProtocolID = 0x06;
			msg->ulTimeStamp = GetTickCount();
			msg->ulExtraDataIndex = (*dataLength) + 4;
			msg->ulRxStatus = 0x00;
		}
		break;
		case 0x20: //Consequtive Frame
		{
			int nRemainingBytes = (*dataLength) - (*bytesRecevied);
			int nBytesToRead = 7;

			//Computing no. of bytes to copy
			if (nRemainingBytes < 7)
				nBytesToRead = nRemainingBytes;

			//Copying nBytesToRead Bytes from consequtive frame
		 	nDataIdx = (*bytesRecevied) + 4;
			memcpy(msg->ucData + nDataIdx, dataBytesCAN + 1, nBytesToRead);

			(*bytesRecevied) += nBytesToRead;

		}
		break;
		case 0x30: //Flow Control
		{
			
		}
		break;
	}
	return bResult;
}

/******************************************************************************
   Function Name    : SetProtocolCommand()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
bool CStnDevice::SetProtocolCommand(const char* protocolNum)
{
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	int length = 0;
	unsigned char StnCmnd[7] = {'S','T','P'};
	unsigned char OpenCmnd[6] = "STPO\r";
	unsigned char HeaderCmnd[6] = "ATH1\r";
	unsigned char ECHOCmnd[6] = "ATE0\r";
	unsigned char BaudCmnd[14] = "STSBR2000000\r";
	unsigned char Long_Message[6] = "ATAL\r";
	unsigned char FilterCmnd[16] = "STCFCPA6F1,610\r";
	unsigned char FilterExtCmnd[26] = "STCFCPA18DA00FB,18DAFB00\r";
	StnCmnd[3] = protocolNum[0];
	StnCmnd[4] = protocolNum[1];
	StnCmnd[5] = '\r';
	unsigned int ulBaudRate = baudrate;
    PurgeComm(hSerCom, PURGE_RXCLEAR);
	SendCommandToGaruda(StnCmnd,6);
	
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	//if(stnResponse != POSITIVE_ACK)
	//	return FALSE;
	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(OpenCmnd,5);
	
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if(stnResponse != POSITIVE_ACK)
		return FALSE;

	PurgeComm(hSerCom, PURGE_RXCLEAR);
	Error = SendCommandToGaruda(HeaderCmnd,5);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if(stnResponse != POSITIVE_ACK)
		return FALSE;
	//Sending Turn off ECHO command
	PurgeComm(hSerCom, PURGE_RXCLEAR);
	Error = SendCommandToGaruda(ECHOCmnd, 5);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
	if (stnResponse != POSITIVE_ACK)
		return FALSE;
	Error = SetProtocolBaudRate(ulBaudRate);
	if (!Error)
		return J2534_ERR_FAILED;
	//Sending the command to Change the baudrate(2MBPS)
	PurgeComm(hSerCom, PURGE_RXCLEAR);
	Error = SendCommandToGaruda(BaudCmnd, 13);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
	if (stnResponse != POSITIVE_ACK)
		return FALSE;
	//Sending the command to obd long message
	PurgeComm(hSerCom, PURGE_RXCLEAR);
	Error = SendCommandToGaruda(Long_Message, 5);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
	if (stnResponse != POSITIVE_ACK)
		return FALSE;
	//Sending the command for flow control address pair.
    PurgeComm(hSerCom, PURGE_RXCLEAR);
	Error = SendCommandToGaruda(FilterCmnd, 15);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
	if (stnResponse != POSITIVE_ACK)
		return FALSE;
	//Sending the command for flow control for ext address pair.
	PurgeComm(hSerCom, PURGE_RXCLEAR);
	Error = SendCommandToGaruda(FilterExtCmnd, 25);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
	if (stnResponse != POSITIVE_ACK)
		return FALSE;
	return TRUE;
}

bool CStnDevice::SetProtocolBaudRate(unsigned long BaudRate)
{
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	int length = 0;

	//setting the baudrates for the protocol
	if (BaudRate == 125000)
	{
		unsigned char Baud[13] = "STPBR125000\r";
		PurgeComm(hSerCom, PURGE_RXCLEAR);
		Error = SendCommandToGaruda(Baud, 12);

		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
		if (stnResponse != POSITIVE_ACK)
			return FALSE;

	}
	if (BaudRate == 250000)
	{
		unsigned char Baud[13] = "STPBR250000\r";
		PurgeComm(hSerCom, PURGE_RXCLEAR);
		Error = SendCommandToGaruda(Baud, 12);

		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
		if (stnResponse != POSITIVE_ACK)
			return FALSE;

	}
	if (BaudRate == 500000)
	{ 
		unsigned char Baud[13] = "STPBR500000\r";
		PurgeComm(hSerCom, PURGE_RXCLEAR);
		Error = SendCommandToGaruda(Baud, 12);

		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
		if (stnResponse != POSITIVE_ACK)
			return FALSE;

	}
	if (BaudRate == 1000000)
	{
		unsigned char Baud[14] = "STPBR1000000\r";
		PurgeComm(hSerCom, PURGE_RXCLEAR);
		Error = SendCommandToGaruda(Baud, 13);

		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
		if (stnResponse != POSITIVE_ACK)
			return FALSE;
	}

	return TRUE;
}

/*bool CStnDevice::SetProtocolTimeout(unsigned long Timeout)
{
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	int length = 0;

		unsigned char Time[14] = "STCTOR 150,150\r";
		PurgeComm(hSerCom, PURGE_RXCLEAR);
		Error = SendCommandToGaruda(Time, 13);

		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char*)SerialBuffer, NULL);
		if (stnResponse != POSITIVE_ACK)
			return FALSE;

	return TRUE;
}*/

/******************************************************************************
   Function Name    : SetHeaderByte()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
bool CStnDevice::SetHeaderByte(PASSTHRU_MSG * pstMsg)
{
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	int length = 0;
	unsigned char setHeaderCmnd[30] = {'A','T','S','H'};
	unsigned char setHeaderExtCmnd[30] = {'A','T','C','P'};
	unsigned char asciiBytes[40] ;

	DecimalToAscii(pstMsg,asciiBytes,4);

	setHeaderExtCmnd[4] = asciiBytes[0];
	setHeaderExtCmnd[5] = asciiBytes[1];
	setHeaderExtCmnd[6] = '\r';

	memcpy(&setHeaderCmnd[4],&asciiBytes[2],6);
	setHeaderCmnd[10] = '\r';

	if(pstMsg->ulTxFlags & 0x100)
	{
		PurgeComm(hSerCom,PURGE_RXCLEAR);
		SendCommandToGaruda(setHeaderExtCmnd,7);
		WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
		if(stnResponse != POSITIVE_ACK)
			return FALSE;
	}

	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(setHeaderCmnd,11);

	WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if(stnResponse != POSITIVE_ACK)
		return FALSE;

	return TRUE;
}


/******************************************************************************
   Function Name    : CloseProtocolCommand()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
bool CStnDevice::CloseProtocolCommand(void)
{
	unsigned char StnCmnd[6] = "STPC\r";
	STN_RESPONSE stnResponse =NONE;
	int length = 0;
	BOOL Error = FALSE;

	PurgeComm(hSerCom,PURGE_RXCLEAR);
	Error = SendCommandToGaruda(StnCmnd,5);
	if(Error)
		return FALSE;
	else
	{
		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		SerialBuffer[length] = '\0';
		stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
		if(stnResponse != POSITIVE_ACK)
			return FALSE;
	}

	return TRUE;
}

/******************************************************************************
   Function Name    : SendISO15765Frame()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
bool CStnDevice::SendISO15765Frame(PASSTHRU_MSG * pstPassThruMsg, DWORD dwLength)
{
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	PASSTHRU_MSG ptMsg ;
//	using namespace std::chrono_literals;
	int indx = 0;
	int length = 0;
	int totalMsgLength = 0;
	unsigned char setHeaderCmnd[30] = {'A','T','S','H'};
//	unsigned char obdRequest[30] = "STPXd:";
	unsigned char obdRequest[30] = "STPXl:";
	unsigned char asciiBytes[2*PASSTHRU_MSG_DATA_SIZE] ;

	//memcpy(&ptMsg,pstPassThruMsg,sizeof(PASSTHRU_MSG));

	DecimalToAscii(pstPassThruMsg,asciiBytes,pstPassThruMsg->ulDataSize);
	asciiBytes[pstPassThruMsg->ulDataSize*2] = '\r';

	totalMsgLength = dwLength;
	/*Setting the header bytes for the message*/
	//if(!SetHeaderByte(pstPassThruMsg))
	//	return FALSE;
	asciiBytes[(dwLength * 2) + 8] = '\r';
	obdRequest[9] = GetAsciiChar((dwLength % 10));
	obdRequest[8] = GetAsciiChar(((dwLength%100) - (dwLength%10))/10);
	obdRequest[7] = GetAsciiChar(((dwLength%1000) - (dwLength%100))/100);
	obdRequest[6] = GetAsciiChar((dwLength - (dwLength%1000))/1000);
	obdRequest[10] = ',';
	obdRequest[11] = 't';
	obdRequest[12] = ':';
	obdRequest[13] = '5';
	obdRequest[14] = '0';
	obdRequest[15] = '0';
	obdRequest[16] = '0';
	obdRequest[17] = '\r';
	

	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(obdRequest,18);
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
//	unsigned char obdRequest[30];
	//	using namespace std::chrono_literals;
//	unsigned char asciiBytes[40];
//	DecimalToAscii(pstPassThruMsg, asciiBytes, pstPassThruMsg->ulDataSize);
//	memcpy(&obdRequest[6], &asciiBytes[8], (dwLength * 2)+1);
//	obdRequest[(dwLength * 2)] = '\r';

//	PurgeComm(hSerCom, PURGE_RXCLEAR);
//	SendCommandToGaruda(obdRequest, (dwLength * 2) + 1);
	/*TX_DONE indication*/
	ptMsg.ulRxStatus = 0x00000009;
//	memset(&ptMsg.ucData[4],0,PASSTHRU_MSG_DATA_SIZE - 4);
	ptMsg.ulDataSize = 4;
	ptMsg.ulExtraDataIndex = 4;
	memcpy(ptMsg.ucData,pstPassThruMsg->ucData,4);
	RxfunCallBack(&ptMsg,gpCAN);


	PurgeComm(hSerCom, PURGE_RXCLEAR);
	SendCommandToGaruda(&asciiBytes[8],(dwLength*2)+1);
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	/*Wait for the response
/*	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);*/



   // SerialBuffer[length] = '\0';
  //  stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);

#if 0
	/*construct single frame*/
	obdRequest[0] = '1';
	obdRequest[1] = GetAsciiChar((totalMsgLength & 0xF00) >> 8);
	obdRequest[2] = GetAsciiChar((totalMsgLength & 0x0F0) >> 4);
	obdRequest[3] = GetAsciiChar((totalMsgLength & 0x00F));
	memcpy(&obdRequest[4],&asciiBytes[8],12);
	indx = 20;
	obdRequest[16] = '\r';

	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(obdRequest,17);

	/*Wait for the response*/
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if(flowControlReceived == TRUE)
		flowControlReceived = FALSE;
	else
		return FALSE;


	/*TX_DONE indication*/
	ptMsg.ulRxStatus = 0x00000009;
	memset(&ptMsg.ucData[4],0,PASSTHRU_MSG_DATA_SIZE - 4);
	ptMsg.ulDataSize = 4;
	ptMsg.ulExtraDataIndex = 4;
	RxfunCallBack(&ptMsg,gpCAN);

	totalMsgLength -= 6;
	unsigned char CF_PCI = 1;

	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(responseOffCmnd,5);
	/*Wait for the response*/
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);

	/*Construct the ISO15765 frames*/
	while(totalMsgLength > 0)
	{
		if(totalMsgLength < 8)
		{
			PurgeComm(hSerCom,PURGE_RXCLEAR);
			SendCommandToGaruda(responseOnCmnd,5);
			/*Wait for the response*/
			Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
			ReadResponseFromGaruda(&length);
		}

		memset(obdRequest,0,30);
		/*Send the consecutive frames*/
		obdRequest[0] = '2';
		obdRequest[1] = GetAsciiChar(CF_PCI);
		memcpy(&obdRequest[2],&asciiBytes[indx],14);
		indx = indx + 14;
		obdRequest[16] = '\r';
		totalMsgLength = totalMsgLength - 7;

		PurgeComm(hSerCom,PURGE_RXCLEAR);
		SendCommandToGaruda(obdRequest,17);

		/*Wait for the response*/
		Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
		ReadResponseFromGaruda(&length);
		/*STN will return "NO DATA" , So please ignore the response*/

		if(CF_PCI == 0x0F)
			CF_PCI = 0;
		else
			CF_PCI++;


		//Sleep(seperationTime);
	}
#endif

	SerialBuffer[length] = '\0';
/*	auto start = std::chrono::high_resolution_clock::now();
	std::this_thread::sleep_for(2000ms);
	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli>elapsed = end - start;*/
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if (stnResponse != POSITIVE_ACK)
		return FALSE;

	return TRUE;
}


/******************************************************************************
   Function Name    : SendSingleFrame()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
bool CStnDevice::SendSingleFrame(PASSTHRU_MSG * pstPassThruMsg,DWORD dwLength)
{
	BOOL Error = FALSE;
	STN_RESPONSE stnResponse = NONE;
	PASSTHRU_MSG ptMsg ;
	int indx = 0;
	int length = 0;
	unsigned char setHeaderCmnd[30] = {'A','T','S','H'};
	unsigned char obdRequest[30] ;
//	using namespace std::chrono_literals;
	unsigned char asciiBytes[40] ;
	//memcpy(&ptMsg,pstPassThruMsg,sizeof(PASSTHRU_MSG));
	DecimalToAscii(pstPassThruMsg,asciiBytes,pstPassThruMsg->ulDataSize);

	//obdRequest[0] = '0';
	//obdRequest[1] = '0'+ dwLength;
	memcpy(&obdRequest[0],&asciiBytes[8],(dwLength*2));
	obdRequest[(dwLength*2)] = '\r';

	/*PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(setHeaderCmnd,11);

	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	//if(stnResponse != POSITIVE_ACK)
	//	return FALSE;
	*/

	/*Setting the header bytes for the message*/
	//if(!SetHeaderByte(pstPassThruMsg))
	//	return FALSE;

	/*Send the data after setting the header*/
	//Sleep(10);
	PurgeComm(hSerCom,PURGE_RXCLEAR);
	SendCommandToGaruda(obdRequest,(dwLength*2)+1);

	/*TX_DONE indication*/
   	ptMsg.ulRxStatus = 0x00000009;

	ptMsg.ulDataSize = 4;
	ptMsg.ulExtraDataIndex = 4;
	memcpy(ptMsg.ucData,pstPassThruMsg->ucData,4);
	RxfunCallBack(&ptMsg,gpCAN);

	/*Wait for the response*/
	Error = WaitCommEvent(hSerCom, &dwEventMask, NULL);
	ReadResponseFromGaruda(&length);
	SerialBuffer[length] = '\0';
    //delay
/*	auto start = std::chrono::high_resolution_clock::now();
	std::this_thread::sleep_for(2000ms);
	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double, std::milli>elapsed = end - start;*/
	stnResponse = GetDataFromResponse((const char *)SerialBuffer,NULL);
	if(stnResponse != POSITIVE_ACK)
		return FALSE;

	return TRUE;
}


/******************************************************************************
   Function Name    : DecimalToAscii()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
void CStnDevice::DecimalToAscii(void *pInput , void *pOutput,int length)
{
	PASSTHRU_MSG *reqMsg = NULL;
	unsigned char *asciiBytes = NULL;
	unsigned char data;

	asciiBytes = (unsigned char *)pOutput;
	reqMsg = (PASSTHRU_MSG *)pInput;
	//length = reqMsg->ulDataSize;

	for(int i = 0,j	= 0 ; i < length ; i++)
	{
		data = GetAsciiChar((reqMsg->ucData[i]>> 4) & 0x0F);
		asciiBytes[j] = data;
		j++;
		data = GetAsciiChar(reqMsg->ucData[i] & 0x0F);
		asciiBytes[j] = data;
		j++;
	}
}


/******************************************************************************
   Function Name    : GetAsciiChar()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
unsigned char CStnDevice::GetAsciiChar(unsigned char data)
{
	unsigned char asciiByte;

	if((data >= 0) && (data <= 9))
		asciiByte = '0' + data;
	else
		asciiByte = 'A' + data - 10 ;

	return asciiByte;
}


/******************************************************************************
   Function Name    : AsciiToDecimal()
   Input Params :
   Output Params    :
   Return           :
   Description      :
******************************************************************************/
unsigned char  CStnDevice::GetDecimalValue(unsigned char ascii)
{
	if((ascii >= '0') && (ascii <= '9'))
		return ascii - '0';
	else if((ascii >= 'A') && (ascii <= 'F'))
		return ascii - 'A' + 10;
	else if((ascii >= 'a') && (ascii <= 'f'))
		return ascii - 'a' + 10;
	else
		return ascii;

}
