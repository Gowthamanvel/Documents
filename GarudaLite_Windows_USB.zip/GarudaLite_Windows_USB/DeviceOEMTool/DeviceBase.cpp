/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: DeviceBase.cpp
 Description			: implementation of the CDebugLog class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

  File		 Date			Author						Description
  Version
_____________________________________________________________________________
 
  1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
******************************************************************************/

#include "stdafx.h"
#include "DeviceBase.h"

//-----------------------------------------------------------------------------
//	Function Name	: CDeviceBase()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
CDeviceBase::CDeviceBase(CDebugLog * pclsDebugLog)
{
       
	m_pclsLog = pclsDebugLog;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "CDeviceBase()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "CDeviceBase()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CDeviceBase()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
CDeviceBase::~CDeviceBase()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "~CDeviceBase()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "~CDeviceBase()", 
						 DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: vOpenDevice()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vOpenDevice()
{
	//*************************** IMPORTANT NOTE ******************************
	// Implement the following:
	// 1. Reset internal Data Structure if any.
	// 2. Reset Device Driver specific Data Structures if any. 
	// 3. If device already opened, return J2534_ERR_DEVICE_IN_USE.
	// 4. Open the Connection to Device otherwise return 
	//    J2534_ERR_DEVICE_NOT_CONNECTED.
	// 5. Hard Reset the Devive if feature supported by Device Driver.
	// 6. If no error, return J2534_STATUS_NOERROR.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "~CDeviceBase()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "~CDeviceBase()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vCloseDevice()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vCloseDevice()
{
	//**************************** IMPORTANT NOTE *****************************
	// Always close the device and cleanup or whatever
	// it takes to restore the state before the OpenDevice was called.
	// If the device is not physically connected, still
	// reset all the internal data structures and cleanup so that the 
	// next call to OpenDevice() could be carried out successfully in an ideal
	// situation.
	//
	// Implement the following:
	// 1. Check if the device is open. If not, return J2534_STATUS_NOERROR.
	// 2. Close connection to Device. (Even if the device is not physically
	//	  connected. 
	// 3. Release and cleanup any resource that were created after call to 
	//	  vOpenDevice() even if the device is not physically connected.
	// 4. Return an appropriate error if there is any, otherwise return
	//	  J2534_STATUS_NOERROR. Always cleanup and release any resource
	//	  even if you are returning "Device not Connected". In other words 
	//	  restore the state prior to vOpenDevice() was called. If for some reason
	//	  the state cannot be restored (e.g potential memory leak, etc.) then
	//	  never return J2534_STATUS_NOERROR or J2534_DEVICE_NOT_CONNECTED.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vCloseDevice()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vCloseDevice()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vConnectProtocol()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: This function shall connect to a requested Protocol
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vConnectProtocol(J2534_PROTOCOL	enProtocolID,
										unsigned long   ulFlags,
										unsigned long	ulBaudRate,
										DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
										DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
 										DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
										LPVOID			pVoid,
										unsigned long	*pulChannelID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. enProtocolID - Refer to J2534 Documentation
	// 2. ulFlags	   - Refer to J2534 Documentation (Manuf. specific bits could
	//					 be used for device specific e.g.- Channel # incase of
	//					 more than one channel of same Protocol is supported by
	//					 a device).
	// 3. ulBaudRate   - Refer to J2534 Documentation.
	// 4. pfnCallback  - Callback to be called when a message is received.
	// 5. pVoid		   - This pointer should be saved along with the Callback
	//					 so as to be able to send this pointer value back as
	//					 a parameter when the Callback is called.
	// 6. pulChannelID - ChannelID to be returned by this function for future
	//					 references to the channel connected.
	//
	// IMPLEMENT THE FOLLOWING:
	//
	// 1. Check to see if the protocol is supported by this device otherwise
	//	  return J2534_ERR_NOT_SUPPORTED.
	// 2. Check to if requested protocol is mutually exclusive. e.g. if CAN
	//	  is already connected and user requested ISO15765 on the same pin
	//	  or vice versa. If there is a resource conflict return 
	//	  J2534_INVALID_PROTOCOL_ID.
	// 3. Check to see if the requested Baud Rate is supported by this device 
	//	  otherwise return J2534_ERR_NOT_SUPPORTED. 
	// 4. Check to see if the feature requested in Flags that are relevent to
	//	  the requested protocol are supported otherwise error out appropriatly.
	//	  by this device otherwise return J2534_ERR_NOT_SUPPORTED.
	// 5. Check to see manufacturer (device) specific flag bits. If not correct,
	//	  return J2534_ERR_INVALID_FLAGS.
	// 6. Check to see if the given channel is in use. If yes, return 
	//	  J2534_ERR_CHANNEL_IN_USE.
	// 7. Check to see Physical Connection by calling IsDeviceConnected(). If
	//	  not connected, J2534_ERR_DEVICE_NOT_CONNECTED.
	// 8. Open and Initialize the Protocol Connection with the Device Driver as
	//	  as per the request. Check the flag bits that is relevent to the 
	//	  requested protocol and process it accordingly. Perform Go On Bus at
	//	  the requested Baud Rate.
	// 9. Setup a callback to be called when a message for this protocol and
	//	  and channel is received. The callback when called upon receiving a 
	//	  message shall send the PASSTHRU_MSG structure completely filled and 
	//	  formatted as desired by the J2534 standard for each protocol.
	// 10.Default Block all messages if supported by the driver otherwise it 
	//	  will be blocked anyways by the software Filter in J2534 layer.
	// 11.If successful send the Channel ID back to caller
	//	  for future reference and return J2534_STATUS_NOERROR. 
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vConnectProtocol()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vConnectProtocol()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnectProtocol()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vDisconnectProtocol(unsigned long	ulChannelID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID -  Channel ID returned by vConnectProtocol() for reference.
	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check to see Physical Connection by calling IsDeviceConnected(). If
	//	  not connected, J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Check to see if the ChannelID is valid. If not, return
	//	  J2534_ERR_INVALID_CHANNEL_ID.
	// 3. Disconnect this protocol and clean up and release any resource that
	//	  were created after call to vConnectProtocol() for this ChannelID.
	//	  If successful, return J2534_STATUS_NOERROR.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vDisconnectProtocol()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vDisconnectProtocol()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

#ifdef GARUDA_TOOL
//-----------------------------------------------------------------------------
//	Function Name	: vLoggingStatus()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vLoggingStatus(unsigned long bLogFlag,SYSTEMTIME *LogTime)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];


	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vLoggingStatus()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vLoggingStatus()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);


}
#endif 

#ifdef GARUDA_TOOL
//-----------------------------------------------------------------------------
//	Function Name	: vSessionCommand()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vSessionCommand(unsigned long bsessionFlag)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];


	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vSessionCommand()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vSessionCommand()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);


}
#endif 
//-----------------------------------------------------------------------------
//	Function Name	: vGetRevision()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vGetRevision(	char *pchFirmwareVersion,
									    char *pchDllVersion,
									    char *pchApiVersion)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];


	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vGetRevision()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vGetRevision()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vWriteMsgs(unsigned long	ulChannelID,
								   PASSTHRU_MSG		*pstPassThruMsg,
								   unsigned long	*pulNumMsgs)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID	 - Channel ID returned by vConnectProtocol() for reference.
	// 2. pstPassThruMsg - Pointer to the PASSTHRU_MSG structure that contains the
	//					   information of the message to be sent out.
	// 3. pulNumMsgs     - Number of msgs. contained in the buffer pointed by
	//					   pstPassThruMsg.
	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check to see Physical Connection by calling IsDeviceConnected(). If
	//	  not connected, J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Write the requested msg. out on the Device Bus. If the message cannot 
	//	  be written out on the Device Bus within a constant timeout value, 
	//	  return J2534_ERR_TIMEOUT. Always confirm that the requested msgs. 
	//	  have been transmitted successfully on the Bus before returning
	//	  J2534_STATUS_NOERROR. If the msg. is not successfully transmitted
	//	  retry until IOCTL with CLEAR_TX_BUFFER or PassThruDisconnect or 
	//	  PassThruClose is called.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vWriteMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vWriteMsgs()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: StartPeriodic()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vStartPeriodic(unsigned long	ulChannelID, 
									   PASSTHRU_MSG		*pstMsg, 
									   unsigned long	ulTimeInterval, 
									   unsigned long	*pulPeriodicRefID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID	   - Channel ID returned by vConnectProtocol() for reference.
	// 2. pstMsg	       - Points to message for Periodic.
	// 3. ulTimeInterval   - Time Interval for Periodic msg..
	// 4. pulPeriodicRefID - Return the Periodic ID for reference.

	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check to see Physical Connection by calling IsDeviceConnected(). If
	//	  not connected, J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Check to see if the Time Interval is valid. If not, return 
	//	  J2534_ERR_INVALID_TIME_INTERVAL.
	// 3. If the device does not support any functionality required by J2534, 
	//	  return J2534_ERR_NOT_SUPPORTED.
	// 4. If successfully started Periodic, return PeriodicID for reference and
	//	  return J2534_STATUS_NOERROR. 
	//	  THE VALID PERIODIC ID RETURNED SHOULD NOT BE 0.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vStartPeriodic()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vStartPeriodic()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vUpdatePeriodic()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vUpdatePeriodic(unsigned long	ulChannelID, 
									   PASSTHRU_MSG		*pstMsg, 
									   unsigned long	ulTimeInterval, 
									   unsigned long	ulPeriodicRefID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID	   - Channel ID returned by vConnectProtocol() for reference.
	// 2. pstMsg	       - Points to message for Periodic.
	// 3. ulTimeInterval   - Time Interval for Periodic msg..
	// 4. pulPeriodicRefID - Return the Periodic ID for reference.

	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check to see Physical Connection by calling IsDeviceConnected(). If
	//	  not connected, J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Check to see if the Time Interval is valid. If not, return 
	//	  J2534_ERR_INVALID_TIME_INTERVAL.
	// 3. If the device does not support any functionality required by J2534, 
	//	  return J2534_ERR_NOT_SUPPORTED.
	// 4. If successfully started Periodic, return PeriodicID for reference and
	//	  return J2534_STATUS_NOERROR. 
	//	  THE VALID PERIODIC ID RETURNED SHOULD NOT BE 0.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vUpdatePeriodic()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vUpdatePeriodic()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}


//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodic()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vStopPeriodic(unsigned long	ulChannelID,
									  unsigned long	ulPeriodicRefID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID	   - Channel ID returned by vConnectProtocol() for 
	//						 reference.
	// 2. ulPeriodicRefID  - Periodic ID returned by vStartMsgFilter() for 
	//						 reference.

	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check if the Device is connected. If not, return 
	//	  J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Stop the Periodic referenced by ulPeriodicRefID and ulChannelID.
	// 3. Return J2534_STATUS_NOERROR if successful.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vStopPeriodic()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vStopPeriodic()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartFilter()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vStartFilter(
							   unsigned long	ulChannelID,
							   J2534_FILTER		enFilterType, 
							   PASSTHRU_MSG		*pstMask, 
							   PASSTHRU_MSG		*pstPattern,
							   PASSTHRU_MSG		*pstFlowControl,
							   unsigned long	*pulFilterRefID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID	 - Channel ID returned by vConnectProtocol() for reference.
	// 2. enFilterType	 - Filter Type (PASS, BLOCK or FLOW_CONTROL).
	// 3. pstMask	     - Points to message mask.
	// 4. pstPattern	 - Points to message pattern.
	// 5. pstFlowControl - Points to message FlowControl.
	// 6. pulFilterRefID - Return the Filter ID for reference.

	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check to see Physical Connection by calling IsDeviceConnected(). If
	//	  not connected, J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Only implement PASS or FLOW_CONTROL filter. If the device is not 
	//	  capable of setting PASS filter, it is still not a problem because the 
	//	  messages will be software filtered by J2534 layer. 
	//	  THE VALID FILTER ID RETURNED SHOULD NOT BE 0.
	// 3. Return J2534_STATUS_NOERROR if successful.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vStartFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vStartFilter()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: StopFilter()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vStopFilter(
							   unsigned long	ulChannelID,
							   unsigned long	ulFilterRefID)
{
	//*************************** IMPORTANT NOTE ******************************
	// PARAMETER DESCRIPTION:
	//
	// 1. ulChannelID	 - Channel ID returned by vConnectProtocol() for reference.
	// 2. ulFilterRefID  - Filter ID returned by vStartMsgFilter() for reference.

	//
	// IMPLEMENT THE FOLLOWING:
	
	// 1. Check if the Device is connected. If not, return 
	//	  J2534_ERR_DEVICE_NOT_CONNECTED.
	// 2. Stop the Filter referenced by ulFilterRefID and ulChannelID.
	// 3. Return J2534_STATUS_NOERROR if successful.
	// (Anytime if there is an error that is not defined in J2534ERROR,
	//  call SetLastErrorText() to set the error text and return 
	//  J2534_ERR_FAILED)
	//*************************************************************************

	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vStopFilter()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vStopFilter()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}


	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: Ioctl()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vIoctl(unsigned long	ulChannelID,
							   J2534IOCTLID enumIoctlID,
							   void *pInput,
							   void *pOutput)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vIoctl()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vIoctl()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vProgrammingVoltage()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase::vProgrammingVoltage(unsigned long ulDeviceID,
									    unsigned long ulPin,
									    unsigned long ulVoltage)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vProgrammingVoltage()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vProgrammingVoltage()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(J2534_ERR_NOT_SUPPORTED);
}

//-----------------------------------------------------------------------------
//	Function Name	: vIsDeviceConnected()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
BOOL CDeviceBase::vIsDeviceConnected(BOOL bFlag)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vIsDeviceConnected()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vIsDeviceConnected()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}

	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: vGetLastError()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: 
//-----------------------------------------------------------------------------
J2534ERROR CDeviceBase:: vGetLastError(char *pErrorDescription)
{
	char	szBuffer[DEVICEBASE_ERROR_TEXT_SIZE];

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DeviceBase.cpp", "vGetLastError()", 
						 DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NOT_SUPPORTED);
		m_pclsLog->Write("DeviceBase.cpp", "vGetLastError()", 
						 DEBUGLOG_TYPE_ERROR, szBuffer);
	}
	return(J2534_ERR_NOT_SUPPORTED);
}

