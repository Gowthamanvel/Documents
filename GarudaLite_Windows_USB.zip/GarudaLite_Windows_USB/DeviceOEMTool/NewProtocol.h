#ifndef _NEWPROTOCOL_H_
#define _NEWPROTOCOL_H_

#define J1850PWM_LIMIT					32		

/*Initialize Commands*/
#define PROTOCOL_SETBAUDRATE			0x01
#define PROTOCOL_SETBAUDRATE_ACK		0x01
#define PROTOCOL_ENABLECANCOM			0x02
#define PROTOCOL_ENABLECANCOM_ACK		0x02
#define PROTOCOL_DISABLECOM				0x03
#define PROTOCOL_DISABLECOM_ACK			0x03

/*Firmware and PCB version*/
#define GET_FIRMWARE_VERSION			0x04		
#define GET_FIRMWARE_VERSION_ACK		0x04	
#define	GETPCB_VERSION					0x05
#define	GETPCB_VERSION_ACK				0x05

/*IOCTL Message Commands*/
#define ECU_IOCTL_COMMAND				0x06					
#define ECU_IOCTL_RESPONSE				0x06		

/*Set Programming Voltage*/
#define ECU_SETPROGRAMMINGVOLTAGE		0x07			
#define ECU_SETPROGRAMMINGVOLTAGE_ACK	0x07

/*Send Message Commands*/
#define ECU_SENDMESSAGE					0x08					
#define ECU_SENDMESSAGE_ACK				0x08	
			
/*Periodic Commands*/
#define ECU_SEND_PERIODICMESSAGE		0x09
#define ECU_SEND_PERIODICMESSAGE_ACK	0x09
#define START_NEW_PERIODIC_MSG_TXN		0x01
#define UPDATE_DATA_TO_MSG_ID			0x02
#define STOP_PERIODIC_MSG_TXN			0x03
#define SUSPEND_ALL_PERIODIC_MSG_TXN	0x04
#define CHANGE_MSG_PERIODICITY			0x05

/*Read Message Commands*/
#define ECU_READMESSAGE					0x0A
#define ECU_READMESSAGE_ACK				0x0A

/*Filter Commands*/
#define ECU_START_MSGFILTER				0x0B
#define ECU_START_MSGFILTER_ACK			0x0B
#define ECU_STOP_MSGFILTER				0x0C
#define ECU_STOP_MSGFILTER_ACK			0x0C


/*Jayasheela-added for periodic message trasmission
  indiaction for ISO15765 only*/
#define ECU_ISO15765PERIODIC_MSG_IND    0x0D


/*Protocl ID for Non Standard Protocls*/
#define ECU_PROTOCOL_ID					0xFF

/* Device Start-Stop logging to Flash */
#ifdef GARUDA_TOOL
	#define DEVICE_STARTLOGGING				0xF0
	#define DEVICE_STOPLOGGING				0xF1
    #define DEVICE_STARTSESSION				0x01
    #define DEVICE_STOPSESSION				0x00
#endif

#endif


