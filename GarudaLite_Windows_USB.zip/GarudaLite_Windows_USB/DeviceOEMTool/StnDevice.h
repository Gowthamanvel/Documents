/******************************************************************************
					Global Edge Softwrae Ltd.,
*****************************************************************************
 Project Name			: Garuda Lite - J2534 API
 File Name				: StnDevice.h
 Description			: Interface file for StnDevice class
 Date					: Jan 06, 2020
 Version				: 1.0
 Author					: Chethankumar
 Revision				: 
 Copyright (c) 2020 Global Edge Software Ltd

 File		 Date			Author						Description
 Version
_____________________________________________________________________________
 
 1.0		 Jan 06, 2020	Chethankumar M S				Initial Version
_____________________________________________________________________________
*****************************************************************************/

#ifndef _STNDEVICE_H_
#define _STNDEVICE_H_

#include "DeviceBase.h"

#define GL_VID			0x03EB
#define GL_PID			0x5745

#define SERIAL_BUFFER_SIZE			512

//ISO15765 Related things
#define ISO15765_DATA_RATE_DEFAULT   500000
#define ISO15765_DATA_RATE_MEDIUM    250000
#define ISO15765_DATA_RATE_LOW       125000
#define ISO15765_DATA_RATE_HIGH      1000000

/*Chethan: Declare ST,AT commands */

typedef enum {
POSITIVE_ACK,
NEGATIVE_ACK,
STN_ERROR,
CAN_ERROR,
DATA_ERROR,
SEARCHING,
STN_NO_DATA,
BUS_ERROE,
BUS_BUSY,
BUFFER_FULL,
RX_ERROR,
OUT_OF_MEMORY,
STOPPED,
UNABLE_TO_CONNECT,
MESSAGE,
NONE
}STN_RESPONSE;


class CStnDevice : public CDeviceBase  
{
public:
	CStnDevice(CDebugLog * pclsDebugLog=NULL);
 	virtual ~CStnDevice();

	//J2534 API's 
	virtual J2534ERROR vOpenDevice();
	virtual J2534ERROR vCloseDevice();
	virtual J2534ERROR vConnectProtocol(
							J2534_PROTOCOL	enProtocolID,
							unsigned long   ulFlags, 
							unsigned long	ulBaudRate,
							DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
							DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
 						    DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
							LPVOID			pVoid,
							unsigned long	*pulChannelID);

	virtual J2534ERROR vDisconnectProtocol(unsigned long ulChannelID);

	virtual J2534ERROR vGetRevision(char *pchFirmwareVersion,
								    char *pchDllVersion,
								    char *pchApiVersion);

	virtual J2534ERROR vWriteMsgs(unsigned long	ulChannelID,
								  PASSTHRU_MSG	*pstPassThruMsg,
								  unsigned long	*pulNumMsgs);
							

	virtual J2534ERROR vStartPeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	*pulPeriodicRefID);

	virtual J2534ERROR vUpdatePeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	pulPeriodicRefID);
							

	virtual J2534ERROR vStopPeriodic(unsigned long	ulChannelID,
									unsigned long	ulPeriodicRefID);
						
	virtual J2534ERROR vStartFilter(unsigned long	ulChannelID,
									J2534_FILTER	enFilterType, 
									PASSTHRU_MSG	*pstMask, 
									PASSTHRU_MSG	*pstPattern,
									PASSTHRU_MSG	*pstFlowControl,
									unsigned long	*pulFilterRefID);

	virtual J2534ERROR vStopFilter(unsigned long	ulChannelID,
								   unsigned long	ulFilterRefID);

	virtual J2534ERROR vIoctl(unsigned long	ulChannelID,
							  J2534IOCTLID enumIoctlID,
							  void *pInput,
							  void *pOutput);

	virtual J2534ERROR vProgrammingVoltage(unsigned long ulDeviceID,
									    unsigned long ulPin,
									    unsigned long ulVoltage);

	virtual BOOL  vIsDeviceConnected(BOOL bFlag = true);

	virtual J2534ERROR  vGetLastError(char *pErrorDescription);


public:
	
	BOOL								DeviceConnected;	
	J2534ERROR							m_ulLastErrorCode;
	HANDLE								hSerCom;
	HANDLE								hCallBckThread;
	HANDLE								m_CmdAck;
	UCHAR								SerialBuffer[SERIAL_BUFFER_SIZE];
	STN_RESPONSE						StnResponse;
	STN_RESPONSE						TempResponse;
	J2534_PROTOCOL						ProtocolConnected;

public:
	bool OpenSerialPort(void);
	BOOL WriteATCommand(char* buffer);
	void CloseSerialPort(void);
	BOOL SendCommandToGaruda(unsigned char* command,DWORD dwLength);
	BOOL SendCommandToGarudaA(unsigned char* command, DWORD dwLength);
	void ReadResponseFromGaruda(int * length);
	bool SetProtocolCommand(const char* protocolNum);

	bool CloseProtocolCommand(void);
	bool ECHOCommand(const char* RxData);
	bool SendISO15765Frame(PASSTHRU_MSG * data,DWORD dwLength);
	bool SendSingleFrame(PASSTHRU_MSG * data, DWORD dwLength);
	bool SetHeaderByte(PASSTHRU_MSG * pstMsg);

	STN_RESPONSE GetDataFromResponse(const char *response, PASSTHRU_MSG * data);
	unsigned char GetDecimalValue(unsigned char ascii);
	void DecimalToAscii(void *pInput , void *pOutput,int length);
	unsigned char GetAsciiChar(unsigned char data);
	J2534ERROR AsciiMsgToByteArray(void *pInput , void *pOutput);
	J2534ERROR ByteArrayToAsciiMsg(void *pInput , void *pOutput);
	/*Chethan: The current project doesn't have implementation for encryption*/
	J2534ERROR AesCtrEncrypt(void *pInput , void *pOutput);
	J2534ERROR AesCtrDecrypt(void *pInput , void *pOutput);

	FILE* fpSerialOut;
	FILE* fpSerialInput;
private:
	bool processRxFrame(const char* rxData, PASSTHRU_MSG* data);
	bool ParseISO15765Frame(const char* rxDataBytes, bool isExtCAN, PASSTHRU_MSG* msg, int* dataLength, int* bytesRecevied);
	bool SetProtocolBaudRate(unsigned long BaudRate);
	bool SetProtocolTimeout(unsigned long Timeout);
};

#endif