/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ProtoclBase.h
 Description			: Interface for the CProtoclBase class.
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

  File		 Date			Author						Description
  Version
_____________________________________________________________________________
 
  1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
*****************************************************************************/

#include "DebugLog.h"
#include "J2534.h"
#include "J2534Registry.h"

class CProtoclBase
{
public:
	SCONFIG_LIST *pInput;
	CDeviceBase(CDebugLog * pclsDebugLog=NULL);
	~CDeviceBase();
	
	virtual J2534ERROR vOpenDevice(J2534REGISTRY_CONFIGURATION * punDeviceSettings);

	virtual J2534ERROR vCloseDevice();

	virtual J2534ERROR vConnectProtocol(J2534_PROTOCOL	enProtocolID,
										unsigned long   ulFlags, 
										unsigned long	ulBaudRate,
										DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
										LPVOID			pVoid,
										unsigned long	*pulChannelID);

	virtual J2534ERROR vStartAllPassFilter(unsigned long	ulChannelID,
											unsigned long ulFlags);
	virtual J2534ERROR vStopAllPassFilter(unsigned long	ulChannelID);
	virtual J2534ERROR vDisconnectProtocol(unsigned long	ulChannelID);

	virtual J2534ERROR vGetRevision(unsigned long ulDeviceID,
									char *pchFirmwareVersion,
									char *pchDllVersion,
									char *pchApiVersion);

	virtual J2534ERROR vWriteMsgs(unsigned long	ulChannelID,
								  PASSTHRU_MSG	*pstPassThruMsg, 
								  unsigned long	*pulNumMsgs);

	virtual J2534ERROR vStartPeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	*pulPeriodicRefID);

	virtual J2534ERROR vStopPeriodic(unsigned long	ulChannelID,
									 unsigned long	ulPeriodicRefID);

	virtual J2534ERROR vStartFilter(unsigned long	ulChannelID,
									J2534_FILTER	enFilterType, 
									PASSTHRU_MSG	*pstMask, 
									PASSTHRU_MSG	*pstPattern,
									PASSTHRU_MSG	*pstFlowControl,
									unsigned long	*pulFilterRefID);
	
	virtual J2534ERROR vStopFilter(unsigned long	ulChannelID,
								   unsigned long	ulFilterRefID);
	
	virtual J2534ERROR vIoctl(unsigned long	ulChannelID,
								J2534IOCTLID enumIoctlID,
							   void *pInput,
							   void *pOutput);

	virtual J2534ERROR vProgrammingVoltage(unsigned long ulDeviceID,
									    unsigned long ulPin,
									    unsigned long ulVoltage);

	virtual bool	   vIsDeviceConnected(bool bFlag = true);

	void			   GetLastErrorText(char *pszBuffer, 
										unsigned long ulSizeOfBuffer);

	virtual J2534ERROR   vGetLastError(char *pErrorDescription);

#ifdef GARUDA_TOOL
		virtual J2534ERROR   vLoggingStatus(unsigned long bLogFlag,SYSTEMTIME *Time);
		virtual	J2534ERROR   vSessionCommand(unsigned long bsessionFlag);
#endif

	virtual J2534ERROR vCheckLock(char *pszLock,unsigned char *pucResult); 
	virtual J2534ERROR vAddLock(char *pszLock,unsigned char *pucResult);
	virtual J2534ERROR vDeleteLock(char *pszLock,unsigned char *pucResult);
	virtual J2534ERROR vTurnAuxOff(); 
	virtual J2534ERROR vTurnAuxOn(); 

	CDebugLog		   *m_pclsLog;

	void				SetLastErrorText(char *pszErrorText);

	char				m_szLastErrorText[DEVICEBASE_ERROR_TEXT_SIZE];
};

#endif
