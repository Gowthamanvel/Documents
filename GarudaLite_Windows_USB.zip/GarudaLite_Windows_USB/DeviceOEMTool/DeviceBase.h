/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: DeviceBase.h
 Description			: Interface file for devicebase class
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

  File		 Date			Author						Description
  Version
_____________________________________________________________________________
 
  1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
*****************************************************************************/

#ifndef _CDEVICEBASE_H_
#define _CDEVICEBASE_H_

#include "J2534.h"
#include "DebugLog.h"

/*Directive for switching between Garuda and Innova DLL configuration*/
#define GARUDA_TOOL 

#define DEVICEBASE_ERROR_TEXT_SIZE		80

// typedef the Rx Callback.
typedef void (*DEVICEBASE_CALLBACK_RX_FUNC)(PASSTHRU_MSG *pstPassThruMsg, LPVOID lpVoid);

typedef void (*DEVICEBASE_CALLBACK_FC_FUNC)(PASSTHRU_MSG pstRxMsg,
											LPVOID lpVoid,
											unsigned long *ulFCMsgId,
											unsigned char *ucFCMsgData,
											int *iFCMsgDataLen,
											unsigned long *ulTxflags,
											bool *bFoundFCMsgId
											);
typedef void(*DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC)(PASSTHRU_MSG *pstPassThruMsg,
																LPVOID lpVoid);


typedef void(*DEVICEBASE_CALLBACK_J1939_SETRXSTATUS_FUNC)(PASSTHRU_MSG *pstPassThruMsg,
																LPVOID lpVoid);
class CDeviceBase
{
public:
	
	CDeviceBase(CDebugLog * pclsDebugLog=NULL);
	
	~CDeviceBase();

	virtual J2534ERROR vOpenDevice();

	virtual J2534ERROR vCloseDevice();

	virtual J2534ERROR vConnectProtocol(J2534_PROTOCOL	enProtocolID,
										unsigned long   ulFlags, 
										unsigned long	ulBaudRate,							
										DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
										DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
										DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
										LPVOID			pVoid,
										unsigned long	*pulChannelID);
	
	virtual J2534ERROR vDisconnectProtocol(unsigned long ulChannelID);

	virtual J2534ERROR vGetRevision(char *pchFirmwareVersion,
									char *pchDllVersion,
									char *pchApiVersion);
#ifdef GARUDA_TOOL
	virtual J2534ERROR vLoggingStatus(unsigned long bLogFlag,SYSTEMTIME *Time );
	virtual	J2534ERROR vSessionCommand(unsigned long bsessionFlag);
#endif

	virtual J2534ERROR vWriteMsgs(unsigned long	ulChannelID,
								  PASSTHRU_MSG	*pstPassThruMsg, 
								  unsigned long	*pulNumMsgs);

	virtual J2534ERROR vStartPeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	*pulPeriodicRefID);
	virtual J2534ERROR vUpdatePeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	pulPeriodicRefID);

	virtual J2534ERROR vStopPeriodic(unsigned long	ulChannelID,
									 unsigned long	ulPeriodicRefID);

	virtual J2534ERROR vStartFilter(unsigned long	ulChannelID,
									J2534_FILTER	enFilterType, 
									PASSTHRU_MSG	*pstMask, 
									PASSTHRU_MSG	*pstPattern,
									PASSTHRU_MSG	*pstFlowControl,
									unsigned long	*pulFilterRefID);
	
	virtual J2534ERROR vStopFilter(unsigned long	ulChannelID,
								   unsigned long	ulFilterRefID);
	
	virtual J2534ERROR vIoctl(unsigned long	ulChannelID,
								J2534IOCTLID enumIoctlID,
							   void *pInput,
							   void *pOutput);

	virtual J2534ERROR vProgrammingVoltage(unsigned long ulDeviceID,
									    unsigned long ulPin,
									    unsigned long ulVoltage);

	virtual BOOL	   vIsDeviceConnected(BOOL bFlag = true);
	virtual J2534ERROR  vGetLastError(char *pErrorDescription);
	
	/*Log Enable Function Class*/
	CDebugLog		   *m_pclsLog;
};

#endif
