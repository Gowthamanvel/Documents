/*********************************************************************************
					Dearborn Electronics India Pvt Ltd.,
**********************************************************************************
 Project Name			: Garuda - OEM Tool - Config app Version 1.0
 File Name				: ConfigApp.cpp
 Description			: Implementation of the Config application
 Date					: Feb 21, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_____________________________________________________________________________________
 
  1.0		 Feb 21, 2008	Chakravarthy				Initial Version
  1.1		 Apr 09, 2008	Chakravarthy				Added WriteRegistry Function
														to write values into registry 
_____________________________________________________________________________________
*********************************************************************************/

#include "stdafx.h"
#include "windows.h"
#include <process.h>
#include "resource.h"
#include "windowsx.h"
#include "stdio.h"
#include "shellapi.h"
#include "commctrl.h"
#include <tchar.h>
#include "Commdlg.h"
#include "objbase.h"
#include <initguid.h>
#include "winuser.h"

extern "C" 
{
	#include "hidsdi.h"
	#include <setupapi.h>
	#include <dbt.h>
}

#define INPUTREPORTMAX				64  // Defines the maximum number of bytes in input report
#define OUTPUTREPORTMAX				64 // Maximum number of bytes in output report

#define VID_1X						0x0471 //Device Vendor ID
#define PID_1X						0x5741 //Device Product ID

#define VID_2X						0x03EB //Device Vendor ID
#define PID_2X						0x5743 //Device Product ID

#define J2534REGISTRY_KEY_PATH			"Software\\PassThruSupport.04.04"
#define J2534REGISTRY_DEVICE_ID			"DeviceId"
#define J2534REGISTRY_NAME				"Name"
#define J2534REGISTRY_COMPANY_NAME		"Dearborn Electronics India Pvt Ltd. - Garuda"
#define J2534REGISTRY_COMPANY_NAME_USB		"Dearborn Electronics India Pvt Ltd. - GarudaUSB"
#define J2534REGISTRY_COMPANY_NAME_WIFI		"Dearborn Electronics India Pvt Ltd. - GarudaWiFi"
#define J2534REGISTRY_DOUBLE_BACKSLASH	"\\"
#define J2534REGISTRY_DEVICES			"Devices"
#define J2534REGISTRY_HYPHEN_SPACE		" - "
#define J2534REGISTRY_5000OEM_TOOL		"Garuda"
#define J2534REGISTRY_VENDOR			"Vendor"
#define J2534REGISTRY_PROTOCOLSSUPPORT	"ProtocolsSupported"
#define J2534REGISTRY_CONFIGAPP			"ConfigApplication"
#define J2534REGISTRY_FUNCLIB			"FunctionLibrary"
#define J2534REGISTRY_APIVERSION		"APIVersion"
#define J2534REGISTRY_PRODUCTVERSION	"ProductVersion"
#define J2534REGISTRY_LOGGING			"Logging"
#define J2534REGISTRY_LOGGINGDIRECTORY	"LoggingDirectory"
#define J2534REGISTRY_CAN				"CAN"
#define J2534REGISTRY_CAN_CH1			"CAN_CH1"
#define J2534REGISTRY_ISO15765			"ISO15765"
#define J2534REGISTRY_ISO15765_CH1		"ISO15765_CH1"
#define J2534REGISTRY_ISO14230			"ISO14230"


#define J2534REGISTRY_MAX_STRING_LENGTH		1024

/*Variable Declaration*/
char chFuncLib[MAX_PATH];
char chConfigApp[MAX_PATH];
char chName[MAX_PATH];
char chVendor[MAX_PATH];
char chProductVer[MAX_PATH];
char chProtSupp[MAX_PATH];
char g_chDhfpIpAddress[MAX_PATH];
char g_chGarudaIpAddress[MAX_PATH];

/*USB Device Related Variable Declaration*/
BOOL HidAttached;					// Used by member functions to make sure device enumerated
HANDLE HidDevHandle;				// Handle for HID Device
HANDLE ReadHandle;						
HANDLE WriteHandle;	
GUID HidGuid;						// holds GUID of device
PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
OVERLAPPED HIDOverlapped;
DWORD dwError;
ULONG Length;
LPOVERLAPPED lpOverLap;
DWORD NumberOfBytesRead;
ULONG Required;
HIDP_CAPS Capabilities;				// holds enumeration info
HANDLE								hEventObject;
UCHAR								InputReport[INPUTREPORTMAX];
UCHAR								OutputReport[OUTPUTREPORTMAX];

/*User defined functions*/
bool FindJ2534Entry(char* pchCurText);
HANDLE Single_Instance(char *name);
BOOL WriteRegistry();
void UpdateINSTALLLOG();
int AutoDetectGaruda(int nMode);

/*Garuda OEM TOOL USB Device Interface Functions Declaration*/
BOOL bOpenHidDevice();	// Open the HID Device based on VID and PID
//Reads the newest report from the device
void  ReadInputReport();
//Get Output Report size
int GetOutputReportSize(void); 
int GetInputReportSize(void);
int GetFeatureReportByteLength(void);
//Writes the newest report from the device based on report number
BOOL WriteOutputReport(unsigned char*ucReport,DWORD dwLength);
void CloseHandles();
BOOL GetDeviceDetected() {return (HidAttached);}
void DisplayInputReport();
void PrepareForOverlappedTransfer();
// gets the device capabilites and puts it in Capabilities
void GetDeviceCapabilities(void);

/*CALLBACK Functions*/
LRESULT CALLBACK MainDlg(HWND,UINT,WPARAM,LPARAM);

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	if(Single_Instance("Garuda Config App") == NULL)
		return 0;
	//WriteRegistry();
	UpdateINSTALLLOG();

	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG_CFG), NULL, (DLGPROC)MainDlg);
	return 0;
}

HANDLE Single_Instance(char *name) 
{
	HANDLE ret = NULL; //create a null handle for return
	HANDLE hMutex = ::CreateMutex( NULL, FALSE, _T(name)); //attempt to create MuteX
	bool Running = ( ::GetLastError() == ERROR_ALREADY_EXISTS ||
	::GetLastError() == ERROR_ACCESS_DENIED); //See if it was successful
	if(Running) 
	{
		ret = NULL; //Set return to NULL (should already be set to NULL
	}
	
	else 
	{
		ret = hMutex; //set to the Handle
	}
	
	if (hMutex != NULL) 
	{
		
		::ReleaseMutex(hMutex);
	}
	return ret;
}

LRESULT CALLBACK MainDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	RECT rt, rt2;
	switch (message)
	{
	case WM_INITDIALOG:
		{
			memset(&chFuncLib,0,MAX_PATH);
			memset(&chConfigApp,0,MAX_PATH);
			memset(&chName,0,MAX_PATH);
			memset(&chVendor,0,MAX_PATH);
			memset(&chProductVer,0,MAX_PATH);
			memset(&chProtSupp,0,MAX_PATH);
			HidDevHandle = NULL;
			ReadHandle = NULL;						
			WriteHandle = NULL;
			HidAttached = FALSE;
			hEventObject = NULL;

			GetWindowRect(GetDesktopWindow(), &rt);
			GetWindowRect(hDlg, &rt2);
			SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
				(rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, 
				SWP_NOZORDER | SWP_NOSIZE);

			if (!FindJ2534Entry(J2534REGISTRY_COMPANY_NAME) && 
				!FindJ2534Entry(J2534REGISTRY_COMPANY_NAME_WIFI))

			{
				MessageBox(hDlg,"Garuda Drivers not Installed","Error",MB_ICONERROR | MB_OK);
				CloseHandles();
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
				//return FALSE;		
			}
			else
			{
				SetDlgItemText(hDlg, IDC_EDIT1,chVendor);
				SetDlgItemText(hDlg, IDC_EDIT2,chName);
				SetDlgItemText(hDlg, IDC_EDIT3,chProtSupp);
				SetDlgItemText(hDlg, IDC_EDIT4,chConfigApp);
				SetDlgItemText(hDlg, IDC_EDIT5,chFuncLib);
				SetDlgItemText(hDlg, IDC_EDIT6,chProductVer);
				SetDlgItemText(hDlg, IDC_EDIT7,"USB");
				
				ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_INTERFACE),"USB");
				ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_INTERFACE),"WiFi");
				ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_INTERFACE),0);
			}
			return TRUE;
		}
	case WM_CLOSE:
		CloseHandles();
		EndDialog(hDlg, LOWORD(wParam));
		return TRUE;
		
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDCANCEL:
				HidDevHandle = NULL;
				ReadHandle = NULL;						
				WriteHandle = NULL;
				HidAttached = FALSE;
				hEventObject = NULL;
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;

			case IDAUTODETECT:

				int nCurSel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_INTERFACE));
				int nResult;
				
				
				if(nCurSel == 0) //USB
				{
					nResult = MessageBox(hDlg,"Please make sure the Garuda OEM TOOL device\nis connected to the PC USB port","Information",IDOK);
					
					if(nResult == 1 && AutoDetectGaruda(0))
						MessageBox(hDlg,"Garuda OEM TOOL device is detected","Information",IDOK);
					else
						MessageBox(hDlg,"Could not find Garuda OEM TOOL device.\nPlease be sure:\n\n1) Garuda OEM TOOL Device is connected to PC USB port.\n2) Be sure the USB drivers are installed properly.\n3) Libraries are installed correctly.\n4) No other programs that use USB ports are open.","Error!",IDOK);
					
				}
				else
				{
					nResult = MessageBox(hDlg,"Please make sure the config application is running in adminstrator mode\nGaruda OEM TOOL device is connected to PC through WiFi","Information",IDOK);
					
					if(nResult == 1 && AutoDetectGaruda(1))
						MessageBox(hDlg,"Garuda OEM TOOL device is detected","Information",IDOK);
					else
						MessageBox(hDlg,"Could not find Garuda OEM TOOL device.\nPlease be sure:\n\n1) Garuda OEM TOOL Device is connected to PC through WiFi.\n2) Be sure the WiFi drivers are installed properly.\n3) Libraries are installed correctly.\n4) No other programs that use WiFi are open.","Error!",IDOK);

				}

				AutoDetectGaruda(1);

				return TRUE;
			}
		}
	default:
		return FALSE;
	}
}

int AutoDetectGaruda(int nMode)
{
	int nResult = 1;
	
	memset(g_chGarudaIpAddress,0,sizeof(g_chGarudaIpAddress));
	strcpy(g_chGarudaIpAddress,"172.31.0.1");
	//strcpy(g_chGarudaIpAddress,"0.0.0.1");

	if(nMode == 0) //USB
	{
		nResult = bOpenHidDevice();
	}
	else //WiFi
	{
		//Check Whether DHFP entry for Garuda
		//System->CurrentControlSet->Services->tcpip->Parameters->interfaces->DhcpIpAddress
		
		DWORD rc;
		DWORD dwNumDev = 0, dwNumDevInfo = 0;
		DWORD dwBufSize, dwDataSize, dwSubKeySize, dwIndex = 0;
		HKEY  hKey, hSubKey;
		TCHAR szObject[J2534REGISTRY_MAX_STRING_LENGTH], szSubKey[255];
		char  szData[J2534REGISTRY_MAX_STRING_LENGTH];
		BOOL  status = TRUE;
		
		/* set the memory to zero */
		ZeroMemory(szObject, J2534REGISTRY_MAX_STRING_LENGTH);
		memset(szData, 0, J2534REGISTRY_MAX_STRING_LENGTH);
		
		/* read the registry key for the PassThruSupport entry */
		rc = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
			_T("System\\CurrentControlSet\\services\\Tcpip\\Parameters\\Interfaces"), 0, KEY_READ, &hKey);
		if (rc != ERROR_SUCCESS)
		{
			return 0;
		}

		dwDataSize = dwBufSize = dwSubKeySize = J2534REGISTRY_MAX_STRING_LENGTH;
		nResult = 0;
		//Enumerating all the devices
		while((rc = RegEnumKey(hKey, dwNumDev, szSubKey, dwSubKeySize)) == ERROR_SUCCESS)
		{			
			rc = RegOpenKeyEx(hKey, szSubKey, 0, KEY_READ| KEY_SET_VALUE, &hSubKey);                    
			if ( rc != ERROR_SUCCESS ) 
			{
				nResult = 0;
				break;
			}

			//Check for the DhfpIpAddress for the Interface
			//Check for the TcpAckFrequnecy Enabled or not
			bool bTCKFreqPresent = false;
			int bTCKFreq = 0;

			memset(g_chDhfpIpAddress,0,sizeof(g_chDhfpIpAddress));
			while ((rc = RegEnumValue(hSubKey, dwIndex++, szObject,
					&dwBufSize, NULL, NULL, 
					(LPBYTE)szData, &dwDataSize))== ERROR_SUCCESS) 
			{
				if(rc != ERROR_SUCCESS)
				{
					nResult = 0;
					break;
				}
				
				if ( rc == ERROR_SUCCESS) 
				{
					if (!(_tcscmp(szObject, _T("DhcpDefaultGateway")))) 
					{
						strcpy(g_chDhfpIpAddress, szData);
						dwNumDevInfo++;
					}					
					else if (!(_tcscmp(szObject, _T("TcpAckFrequency")))) 
					{
						bTCKFreqPresent = 1;
						if (strcmp(szData, "0") != 0)
						{
							bTCKFreq = 1;
						}
					}

					dwDataSize = dwBufSize = MAX_PATH;
				} 
			}

			//Check the interface is Garuda or not
			if(strcmp(g_chDhfpIpAddress,g_chGarudaIpAddress) == 0)
			{
				LPCTSTR value = TEXT("TcpAckFrequency");
				DWORD data = 1;
				DWORD d1 = sizeof(data);

				LONG setRes = RegSetValueEx (hSubKey, value, 0, REG_DWORD, (const BYTE*)&data,sizeof(DWORD) );


				//Check whether TCP Frequency Exists or not
				if(!bTCKFreqPresent)
				{
					//Create TcpAckFrequency
				}
				else
				{
					if(bTCKFreq ==0)
					{
						//Update TckAckFrequency to 1
					}
				}

				nResult = 1;

				break;
			}
			
			// close the handle to the opened registry key
            RegCloseKey(hSubKey);

			dwNumDevInfo = 0;
            dwNumDev++;
			dwIndex = 0;
		}	
		
	}

	return nResult;
}

//-----------------------------------------------------------------------------
//	Function Name	: FindJ2534Entry()
//	Input Params	: 
//	Output Params	: 
//	Return			: 
//	Description		: This is a function to find the J2534 device entry in
//					  the registry.
//-----------------------------------------------------------------------------
bool FindJ2534Entry(char* pchCurText)
{
	long			lSuccess;
	char			chTempstr[J2534REGISTRY_MAX_STRING_LENGTH]; 
	DWORD			dwDatasize;  	
	unsigned char	ucValueread[J2534REGISTRY_MAX_STRING_LENGTH];
	DWORD			dwDword, dwString; 
	HKEY			hMainkey;
	HKEY			hTempkey;
	HKEY			*phTempkey;
	dwDword = REG_DWORD, dwString = REG_SZ;
	hTempkey = NULL;
	phTempkey = NULL;
	strcpy(chTempstr, J2534REGISTRY_KEY_PATH);
	lSuccess = RegOpenKeyEx(HKEY_LOCAL_MACHINE, chTempstr, 0,KEY_READ,&hMainkey);
	if(lSuccess==ERROR_SUCCESS) 
	{
		dwDatasize=J2534REGISTRY_MAX_STRING_LENGTH;
		lSuccess = RegOpenKeyEx(hMainkey, pchCurText,0, KEY_READ, &hTempkey);
		if (lSuccess==ERROR_SUCCESS)
		{
			dwDatasize = sizeof(ucValueread);
			lSuccess = RegQueryValueEx(hTempkey, "ConfigApplication", NULL, 
				&dwString, ucValueread, &dwDatasize);
			
			if(lSuccess==ERROR_SUCCESS)
			{
				// Found Config application to load
				sprintf(chConfigApp, "%s", ucValueread);
			}
			dwDatasize = sizeof(ucValueread);
			lSuccess = RegQueryValueEx(hTempkey, "FunctionLibrary", NULL, 
				&dwString, ucValueread, &dwDatasize);
		
			if(lSuccess==ERROR_SUCCESS)
			{
				// Found DLL to load
				sprintf(chFuncLib, "%s", ucValueread);
			}

			lSuccess = RegQueryValueEx(hTempkey, "Name", NULL, 
				&dwString, ucValueread, &dwDatasize);
		
			if(lSuccess==ERROR_SUCCESS)
			{
				// Found Name to load
				sprintf(chName, "%s", ucValueread);
			}

			dwDatasize = sizeof(ucValueread);
			
			lSuccess = RegQueryValueEx(hTempkey, "ProductVersion", NULL, 
				&dwString, ucValueread, &dwDatasize);
			
			if(lSuccess==ERROR_SUCCESS)
			{
				// Found ProductVersion to load
				sprintf(chProductVer, "%s", ucValueread);
			}
			dwDatasize = sizeof(ucValueread);
			lSuccess = RegQueryValueEx(hTempkey, "ProtocolsSupported", NULL, 
				&dwString, ucValueread, &dwDatasize);
		
			if(lSuccess==ERROR_SUCCESS)
			{
				// Found ProtocolsSupported to load
				sprintf(chProtSupp, "%s", ucValueread);
			}
			dwDatasize = sizeof(ucValueread);
			lSuccess = RegQueryValueEx(hTempkey, "Vendor", NULL, 
				&dwString, ucValueread, &dwDatasize);
		
			if(lSuccess==ERROR_SUCCESS)
			{
				// Found Vendor to load
				sprintf(chVendor, "%s", ucValueread);
			}

			RegCloseKey(hTempkey);
			hTempkey = NULL;
		}
		else
		{
			RegCloseKey(hMainkey);
			return FALSE;
		}
		RegCloseKey(hMainkey);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
	
	//return true;
	/*if (phTempkey != NULL)
	{
		RegCloseKey(*phTempkey);
		return TRUE;
	}
	else
	{
		return FALSE;
	}*/
}

/*************************************************************************************
			Garuda OEM TOOL USB Device Interface Implementations
______________________________________________________________________________________
	
	BOOL bOpenHidDevice();	// Open the HID Device based on VID and PID
	//Reads the newest report from the device
	void  ReadInputReport();
	//Get Output Report size
	int GetOutputReportSize(void); 
	int GetInputReportSize(void);
	int GetFeatureReportByteLength(void);
	//Writes the newest report from the device based on report number
	BOOL WriteOutputReport(unsigned char*ucReport,DWORD dwLength);
	void CloseHandles();
	BOOL GetDeviceDetected() {return (HidAttached);}
	void DisplayInputReport();
	void PrepareForOverlappedTransfer();
	// gets the device capabilites and puts it in Capabilities
	void GetDeviceCapabilities(void);
************************************************************************************/

/************************************************************************************
*
*	Function: bOpenHidDevice
*	Purpose: tries to open a HID device based on VID and PID
*	Parameters: vid - HID device's vendor ID
*				pid - HID device's product ID
			
*	Returns: TRUE, if device is found
*			 FALSE, if device is not found
*
*************************************************************************************/
BOOL bOpenHidDevice()
{
	static GUID HidGuid;						/* HID Globally Unique ID: windows supplies us with this value */
	HDEVINFO HidDevInfo;						/* handle to structure containing all attached HID Device information */
	SP_DEVICE_INTERFACE_DATA devInfoData;		/* Information structure for HID devices */
	BOOLEAN Result;								/* result of getting next device information structure */
	HIDD_ATTRIBUTES	 HIDAttrib;					/* HID device HIDAttrib */
	BOOL								LastDevice = FALSE;
	int									MemberIndex = 0;
	Length = 0;
	detailData = NULL;
	/*
	API function: HidD_GetHidGuid
	Get the GUID for all system HIDs.
	Returns: the GUID in HidGuid.
	*/
	
	HidD_GetHidGuid(&HidGuid);	
	
	/*
	API function: SetupDiGetClassDevs
	Returns: a handle to a device information set for all installed devices.
	Requires: the GUID returned by GetHidGuid.
	*/
	
	HidDevInfo=SetupDiGetClassDevs 
								(&HidGuid, 
								NULL, 
								NULL, 
								DIGCF_PRESENT|DIGCF_INTERFACEDEVICE);
	
	devInfoData.cbSize = sizeof(devInfoData);
	
	//Step through the available devices looking for the one we want. 
	//Quit on detecting the desired device or checking all available devices without success.
	
	MemberIndex = 0;
	LastDevice = FALSE;
	do
	{
	/*
	API function: SetupDiEnumDeviceInterfaces
	On return, MyDeviceInterfaceData contains the handle to a
	SP_DEVICE_INTERFACE_DATA structure for a detected device.
	Requires:
	The DeviceInfoSet returned in SetupDiGetClassDevs.
	The HidGuid returned in GetHidGuid.
	An index to specify a device.
		*/
		
		Result=SetupDiEnumDeviceInterfaces (HidDevInfo, 
			0, 
			&HidGuid, 
			MemberIndex, 
			&devInfoData);
		
		if (Result != 0)
		{
			//A device has been detected, so get more information about it.
			
			/*
			API function: SetupDiGetDeviceInterfaceDetail
			Returns: an SP_DEVICE_INTERFACE_DETAIL_DATA structure
			containing information about a device.
			To retrieve the information, call this function twice.
			The first time returns the size of the structure in Length.
			The second time returns a pointer to the data in DeviceInfoSet.
			Requires:
			A DeviceInfoSet returned by SetupDiGetClassDevs
			The SP_DEVICE_INTERFACE_DATA structure returned by SetupDiEnumDeviceInterfaces.
			
			  The final parameter is an optional pointer to an SP_DEV_INFO_DATA structure.
			  This application doesn't retrieve or use the structure.			
			  If retrieving the structure, set 
			  MyDeviceInfoData.cbSize = length of MyDeviceInfoData.
			  and pass the structure's address.
			*/
			
			//Get the Length value.
			//The call will return with a "buffer too small" error which can be ignored.
			
			Result = SetupDiGetDeviceInterfaceDetail(HidDevInfo, 
				&devInfoData, 
				NULL, 
				0, 
				&Length, 
				NULL);
			
			//Allocate memory for the HidDevHandle structure, using the returned Length.
			
			detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(Length);
			
			//Set cbSize in the detailData structure.
			
			detailData -> cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
			
			//Call the function again, this time passing it the returned buffer size.
			
			Result = SetupDiGetDeviceInterfaceDetail (HidDevInfo, 
				&devInfoData, 
				detailData, 
				Length, 
				&Required, 
				NULL);
			
				/*
				API function: CreateFile
				Returns: a handle that enables reading and writing to the device.
				Requires:
				The DevicePath in the detailData structure
				returned by SetupDiGetDeviceInterfaceDetail.
			*/
			
			HidDevHandle=CreateFile (detailData->DevicePath, 
				0, 
				FILE_SHARE_READ|FILE_SHARE_WRITE, 
				(LPSECURITY_ATTRIBUTES)NULL,
				OPEN_EXISTING, 
				0, 
				NULL);
			
			
				/*
				API function: HidD_GetHIDAttrib
				Requests information from the device.
				Requires: the handle returned by CreateFile.
				Returns: a HIDD_HIDAttrib structure containing
				the Vendor ID, Product ID, and Product Version Number.
				Use this information to decide if the detected device is
				the one we're looking for.
			*/
			
			//Set the Size to the number of bytes in the structure.
			
			HIDAttrib.Size = sizeof(HIDAttrib);
			
			Result = HidD_GetAttributes (HidDevHandle, 
				&HIDAttrib);
			//Is it the desired device?
			HidAttached = FALSE;
			if (HIDAttrib.VendorID == VID_1X)
			{
				if (HIDAttrib.ProductID == PID_1X)
				{
					//Both the Vendor ID and Product ID match.
					HidAttached = TRUE;
					//Get the device's capablities.
					GetDeviceCapabilities();
					// Get a handle for writing Output reports.
					WriteHandle=CreateFile 
						(detailData->DevicePath, 
						GENERIC_WRITE, 
						FILE_SHARE_READ|FILE_SHARE_WRITE, 
						(LPSECURITY_ATTRIBUTES)NULL,
						OPEN_EXISTING, 
						0, 
						NULL);
					// Prepare to read reports using Overlapped I/O.
					PrepareForOverlappedTransfer();
					
				} //if (HIDAttrib.ProductID == ProductID)
				
				else
					//The Product ID doesn't match.
					CloseHandle(HidDevHandle);
				
			} //if (HIDAttrib.VendorID == VendorID)
			else if (HIDAttrib.VendorID == VID_2X)
			{
				if (HIDAttrib.ProductID == PID_2X)
				{
					//Both the Vendor ID and Product ID match.
					HidAttached = TRUE;
					//Get the device's capablities.
					GetDeviceCapabilities();
					// Get a handle for writing Output reports.
					WriteHandle=CreateFile 
						(detailData->DevicePath, 
						GENERIC_WRITE, 
						FILE_SHARE_READ|FILE_SHARE_WRITE, 
						(LPSECURITY_ATTRIBUTES)NULL,
						OPEN_EXISTING, 
						0, 
						NULL);
					// Prepare to read reports using Overlapped I/O.
					PrepareForOverlappedTransfer();
					
				} //if (HIDAttrib.ProductID == ProductID)
				
				else
					//The Product ID doesn't match.
					CloseHandle(HidDevHandle);
				
			} //if (HIDAttrib.VendorID == VendorID)
			
			else
				CloseHandle(HidDevHandle);
			
			//Free the memory used by the detailData structure (no longer needed).
			free(detailData);
		}  
		else
			//SetupDiEnumDeviceInterfaces returned 0, so there are no more devices to check.
			LastDevice=TRUE;
		//If we haven't found the device yet, and haven't tried every available device,
		//try the next one.
		MemberIndex = MemberIndex + 1;
	} //do
	while ((LastDevice == FALSE) && (HidAttached == FALSE));
	SetupDiDestroyDeviceInfoList(HidDevHandle);
	return HidAttached;
}

/************************************************************************************
*	Function: GetDeviceCapabilities
*	Purpose: Gets the devices specific capabilites
*	Parameters: Void
*	Returns: Void 
*************************************************************************************/
void GetDeviceCapabilities(void)
{
	//Get the Capabilities structure for the device.
	PHIDP_PREPARSED_DATA	PreparsedData;

	/*
	API function: HidD_GetPreparsedData
	Returns: a pointer to a buffer containing the information about the device's 
	capabilities.
	Requires: A handle returned by CreateFile.
	There's no need to access the buffer directly,
	but HidP_GetCaps and other API functions require a pointer to the buffer.
	*/

	HidD_GetPreparsedData (HidDevHandle, &PreparsedData);

	/*
	API function: HidP_GetCaps
	Learn the device's capabilities.
	For standard devices such as joysticks, you can find out the specific
	capabilities of the device.
	For a custom device, the software will probably know what the device is
	capable of,and the call only verifies the information.
	Requires: the pointer to the buffer returned by HidD_GetPreparsedData.
	Returns: a Capabilities structure containing the information.
	*/
	
	HidP_GetCaps (PreparsedData, &Capabilities);

	//No need for PreparsedData any more, so free the memory it's using.
	HidD_FreePreparsedData(PreparsedData);
}

/************************************************************************************
*	Function: GetInputReportSize 
*	Purpose:  Returns the info from capablities
*	Parameters: Void
*	Returns: Input Report size for device	 
*************************************************************************************/

int GetInputReportSize(void)
{
	return(Capabilities.InputReportByteLength);
}
/************************************************************************************
*	Function: GetOutputReportSize 
*	Purpose:  Returns the info from capablities
*	Parameters: Void
*	Returns: Input Report size for device	 
*************************************************************************************/

int GetOutputReportSize(void)
{
	return(Capabilities.OutputReportByteLength);
}
/************************************************************************************
*	Function: GetFeatureReportByteLength 
*	Purpose:  Returns the info from capablities
*	Parameters: Void
*	Returns: Feature Report size for device	 
*************************************************************************************/

int GetFeatureReportByteLength(void)
{
	return(Capabilities.FeatureReportByteLength);
}

/************************************************************************************
*	Function: ReadReport 
*	Purpose:  returns a report
*	Parameters: 
*	Returns																			
*************************************************************************************/
void ReadInputReport()
{
	// Retrieve an Input report from the device.
	DWORD	Result;

	//The first byte is the report number.
	InputReport[0]=0;
	
	/*API call:ReadFile
	'Returns: the report in InputReport.
	'Requires: a device handle returned by CreateFile
	'(for overlapped I/O, CreateFile must be called with FILE_FLAG_OVERLAPPED),
	'the Input report length in bytes returned by HidP_GetCaps,
	'and an overlapped structure whose hEvent member is set to an event object.
	*/
	
	if (ReadHandle != INVALID_HANDLE_VALUE)
	{
		Result = ReadFile (ReadHandle, 
							InputReport, 
							Capabilities.InputReportByteLength, 
							&NumberOfBytesRead,
							(LPOVERLAPPED) &HIDOverlapped); 
	}
	
	/*API call:WaitForSingleObject 'Used with overlapped ReadFile.
	'Returns when ReadFile has received the requested amount of data or on timeout.
	'Requires an event object created with CreateEvent and a timeout value in milliseconds.*/
	
	Result = WaitForSingleObject (hEventObject, 8);
	
	switch (Result)
	{
	case WAIT_OBJECT_0:
		{
			break;
		}
	case WAIT_TIMEOUT:
		{
			/*API call: CancelIo Cancels the ReadFile Requires the device handle.
			Returns non-zero on success.*/
			Result = CancelIo(ReadHandle);
			//A timeout may mean that the device has been removed. 
			//Close the device handles and set HidAttached = False 
			//so the next access attempt will search for the device.
			break;
		}
	default:
		{
			//Close the device handles and set HidAttached = False 
			break;
		}
	}
	
	/*
	API call: ResetEvent Sets the event object to non-signaled.Requires a handle to the 
	event object.Returns non-zero on success.*/
	
	ResetEvent(hEventObject);
	
	//Display the report data.
	//DisplayInputReport();
}

/************************************************************************************
*	Function: WriteOutputReport 
*	Purpose:  -- calls the API which writes a report to endpoint1
*	Parameters																	
*		*OutputReport -- the report to be written								
*		ReportNumber -- 
*					 0 : Exchange Input and Output reports
*					 1 : Exchange Feature reports.
*	Returns :
*			zero if the write failed		
*************************************************************************************/

BOOL WriteOutputReport(unsigned char*ucReport,DWORD dwLength) 
{ 
	DWORD	BytesWritten = 0;
	INT		Index =0;
	ULONG	Result;
	
	//The first byte is the report number.
	OutputReport[0] = 0;
	memcpy(&OutputReport[1],ucReport,dwLength);
	
	/*
	API Function: WriteFile
	Sends a report to the device.
	Returns: success or failure.
	Requires:
	A device handle returned by CreateFile.
	A buffer that holds the report.
	The Output Report length returned by HidP_GetCaps,
	A variable to hold the number of bytes written.
	*/
	if (WriteHandle != INVALID_HANDLE_VALUE)
	{
		Result = WriteFile 	(WriteHandle, 
							 OutputReport, 
							 Capabilities.OutputReportByteLength, 
							 &BytesWritten, 
							 NULL);
	}

	if (!Result)
	{
		//The WriteFile failed, so close the handles 
		return TRUE;
	}
	else
	{
		/*Data has been written to the device*/
		return FALSE;
	}
}

/*******************************************************************************/
/*	Function: PrepareForOverlappedTransfer									   */
/*	Purpose:																   */
/*	Parameters: None														   */
/*	Returns : None															   */
/*******************************************************************************/
void PrepareForOverlappedTransfer()
{
	//Get a handle to the device for the overlapped ReadFiles.
	
	ReadHandle=CreateFile 
		(detailData->DevicePath,
		GENERIC_READ, 
		FILE_SHARE_READ|FILE_SHARE_WRITE,
		(LPSECURITY_ATTRIBUTES)NULL, 
		OPEN_EXISTING, 
		FILE_FLAG_OVERLAPPED, 
		NULL);

	/*API function: CreateEvent
	Requires:
	  Security HIDAttrib or Null
	  Manual reset (true). Use ResetEvent to set the event object's state to non-signaled.
	  Initial state (true = signaled) 
	  Event object name (optional)
	Returns: a handle to the event object
	*/

	if (hEventObject == 0)
	{
		hEventObject = CreateEvent(NULL,TRUE,TRUE,"");
		HIDOverlapped.hEvent = hEventObject;
		HIDOverlapped.Offset = 0;
		HIDOverlapped.OffsetHigh = 0;
	}
}
/******************************************************************************/
/*	Function: CloseHandles													  */
/*	Purpose:  Close Read, Write and device handles							  */
/*	Parameters: None														  */
/*	Returns :																  */
/******************************************************************************/
void CloseHandles() 
{
	if (HidDevHandle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(HidDevHandle);
	}
	
	if (ReadHandle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(ReadHandle);
	}
	
	if (WriteHandle != INVALID_HANDLE_VALUE)
	{
		CloseHandle(WriteHandle);
	}
}
void UpdateINSTALLLOG()
{

	char DirectoryPath[500];
	unsigned char*dataBuf;
	BOOL success;
	GetCurrentDirectory(  300, DirectoryPath );  
	strcat(DirectoryPath,"\\");
	strcat(DirectoryPath,"INSTALL.LOG");

	FILE *tempFile;//Nikhil added
//	CString filedata;
	success = SetFileAttributes(DirectoryPath,FILE_ATTRIBUTE_NORMAL);

	if((tempFile = fopen(DirectoryPath,"r+b"))!= NULL)
	{
		fseek (tempFile , 0 , SEEK_END);
		int ulSize = ftell (tempFile);
		rewind (tempFile);
		dataBuf = (unsigned char*)malloc(ulSize ); 
		fread(dataBuf, sizeof( unsigned char), ulSize , tempFile);
//		filedata = dataBuf;
		fclose(tempFile);
	}

		/*	token = strtok( dataBuf, tokens );
			file_rowindex = atoi(token);

			if(file_rowindex == ref_rowindex)
			{
				memset(datainChar,0,PASSTHRU_MSG_DATA_SIZE);
				token = strtok( NULL, tokens );
				file_datacount = atoi(token);
				for(i=0;i<file_datacount;i++)
				{
					token = strtok( NULL, tokens );
					strcpy(onebytedata,token);
					dataconverted = atoi(onebytedata);
					datainChar[i] = (char)dataconverted;
				}
				success = 1;
				break;
			}
		}
		fclose(tempFile);
	}
	return(success);*/





}

/******************************************************************************/
/*	Function: WriteRegistry													  */
/*	Purpose:  Used to write the J2534 Registry values into the registry.	  */
/*	Parameters: None														  */
/*	Returns : TRUE or FALSE																  */
/******************************************************************************/
BOOL WriteRegistry()
{
	long			lSuccess;
	DWORD			dwDword;
	HKEY			hMainkey, hTempkey;
	
	lSuccess = RegCreateKey(HKEY_LOCAL_MACHINE,J2534REGISTRY_KEY_PATH,&hMainkey);

	if(lSuccess == ERROR_SUCCESS)
	{
		lSuccess = RegCreateKey(hMainkey,J2534REGISTRY_COMPANY_NAME,&hTempkey);
		if(lSuccess == ERROR_SUCCESS)
		{	
			int n=strlen("04.04")+1;
			RegSetValueEx(hTempkey,J2534REGISTRY_APIVERSION,0,REG_SZ,(BYTE*)"04.04",n);
			

			dwDword=0x1;
	

			/***********  Supported for 1st release 29/12/2008 Nikhilesh Sawarkar//nikhileshps@deindia.com*/
			RegSetValueEx(hTempkey,J2534REGISTRY_ISO15765,0,REG_DWORD,(unsigned char*)&dwDword,4);		
			//RegSetValueEx(hTempkey,J2534REGISTRY_ISO15765_CH1,0,REG_DWORD,(unsigned char*)&dwDword,4);
			RegSetValueEx(hTempkey,J2534REGISTRY_ISO14230,0,REG_DWORD,(unsigned char*)&dwDword,4);
			RegSetValueEx(hTempkey,J2534REGISTRY_CAN,0,REG_DWORD,(unsigned char*)&dwDword,4);
			//RegSetValueEx(hTempkey,J2534REGISTRY_CAN_CH1,0,REG_DWORD,(unsigned char*)&dwDword,4);
		
			/*********** Logging Not supported for 1st release 29/12/2008 Nikhilesh Sawarkar*/
		/*	dwDword=0x00;
			RegSetValueEx(hTempkey,J2534REGISTRY_LOGGING,0,REG_DWORD,(unsigned char*)&dwDword,4);
			n = strlen("C:\\") + 1;
			RegSetValueEx(hTempkey,J2534REGISTRY_LOGGINGDIRECTORY,0,REG_SZ,(BYTE*)"C:\\",n);*/
			/***********  Supported for 1st release 29/12/2008 Nikhilesh Sawarkar//nikhileshps@deindia.com*/

			char * system2;
			system2=new char[100];
			GetSystemDirectory(system2,25);
			char *config;
			config=new char[100];
			config="\\GarudaConfig.exe";
			strcat(system2,config);


			n=strlen(system2)+1;
			RegSetValueEx(hTempkey,J2534REGISTRY_CONFIGAPP,0,REG_SZ,(BYTE*)system2,n);	
			
			//no need to disply device id refered cardaq device registry
			//dwDword=0x0;
			//RegSetValueEx(hTempkey,J2534REGISTRY_DEVICE_ID,0,REG_DWORD,(unsigned char*)&dwDword,4);

			char * system1;
			system1=new char[100];
			GetSystemDirectory(system1,25);
			char *Garuda;
			Garuda=new char[100];
			Garuda="\\Garuda40432.dll";
			strcat(system1,Garuda);
			n=strlen(system1)+1;
			RegSetValueEx(hTempkey,J2534REGISTRY_FUNCLIB,0,REG_SZ,(BYTE*)system1,n);

			n= strlen(J2534REGISTRY_5000OEM_TOOL)+1;
			RegSetValueEx(hTempkey,J2534REGISTRY_NAME,0,REG_SZ,(BYTE*)J2534REGISTRY_5000OEM_TOOL,n);
			
			n= strlen("1.0.0.1")+1;
			RegSetValueEx(hTempkey,J2534REGISTRY_PRODUCTVERSION,0,REG_SZ,(BYTE*)"1.0.0.1",n);

			//n= strlen("CAN:1, ISO14230:1, ISO15765:1, CAN_CH1:1, ISO15765_CH1:1") + 1;
			n= strlen("CAN:1, ISO14230:1, ISO15765:1") + 1;
			RegSetValueEx(hTempkey,J2534REGISTRY_PROTOCOLSSUPPORT,0,REG_SZ,(BYTE*)"CAN:1, ISO14230:1, ISO15765:1",n);	
			
			n= strlen("Dearborn Electronics India Pvt Ltd.")+1;
			RegSetValueEx(hTempkey,J2534REGISTRY_VENDOR,0,REG_SZ,(BYTE*)"Dearborn Electronics India Pvt Ltd.",n);			

			RegCloseKey(hTempkey);
		}
		RegCloseKey(hMainkey);
	}
	return 1;
}

