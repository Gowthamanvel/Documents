#ifndef __J2534_H
#define __J2534_H

/* Protocol definitions */
#define J1850VPW							1
#define J1850PWM							2
#define ISO9141								3
#define ISO14230							4
#define CAN									5
#define ISO15765							6
#define SCI_A_ENGINE						7
#define SCI_A_TRANS							8
#define SCI_B_ENGINE						9
#define SCI_B_TRANS							10
#define	SWCAN_ISO15765_PS					11				// Single Wire CAN ISO 15765 as per J2534 -2
#define SWCAN_CAN_PS						12				// Single Wire CAN Raw CAN as per J2534 -2
#define CCD									13				// CCD as per J2534 - 2
#define CAN_CH1								14		//J25354 specs fpr multiple channels
#define CAN_CH1_PROTOCOL_ID					0x9000		//J25354 specs fpr multiple channels
#define ISO15765_CH1						15
#define ISO15765_CH1_PROTOCOL_ID		   	0x9400		//J25354 specs fpr multiple channels
#define J1939								16
#define J1939_PROTOCOL_ID					0xC6 //0x800C - For Standard//0xC6 - Garuda			
#define J1939_CH1							17
#define J1939_CH1_PROTOCOL_ID				0xC7				




/* IOCTL IDs */
#define GET_CONFIG							1
#define SET_CONFIG							2
#define READ_VBATT							3
#define FIVE_BAUD_INIT						4
#define FAST_INIT							5
#define SET_PIN_USE							6
#define CLEAR_TX_BUFFERS					7
#define CLEAR_TX_BUFFER						7
#define CLEAR_RX_BUFFERS					8
#define CLEAR_RX_BUFFER 					8
#define CLEAR_PERIODIC_MSGS					9
#define CLEAR_MSG_FILTERS					10
#define CLEAR_FUNCT_MSG_LOOKUP_TABLE		11
#define ADD_TO_FUNCT_MSG_LOOKUP_TABLE		12
#define DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE	13
#define READ_PROG_VOLTAGE					14
#define SWCAN_HS							15
#define SWCAN_NS							16
#define	PROTECT_J1939_ADDR					17
#define	PROTECT_J1939_ADDR_ID				0x00008009


/* Configuration Parameter IDs */
#define DATA_RATE							1
#define LOOPBACK							3
#define NODE_ADDRESS						4
#define NETWORK_LINE						5
#define P1_MIN								6
#define P1_MAX								7
#define P2_MIN								8
#define P2_MAX								9
#define P3_MIN								10
#define P3_MAX								11
#define P4_MIN								12
#define P4_MAX								13
#define W1									14
#define W2									15
#define W3									16
#define W4									17
#define W5									18
#define TIDLE								19
#define TINIL								20
#define TWUP								21
#define PARITY								22
#define BIT_SAMPLE_POINT					23
#define SYNC_JUMP_WIDTH 					24
#define T1_MAX								26
#define T2_MAX								27
#define T4_MAX								28
#define T5_MAX								29
#define ISO15765_BS							30
#define ISO15765_STMIN						31
#define DATA_BITS							32
#define FIVE_BAUD_MOD						33
#define BS_TX								34
#define STMIN_TX							35
#define T3_MAX								36
#define ISO15765_WFT_MAX					37
#define	CAN_MIXED_FORMAT					38
#define J1962_PINS							39
#define SWCAN_HS_DATA_RATE					40
#define SWCAN_SPEEDCHANGE_ENABLE			41
#define SWCAN_RES_SWITCH				    42
#define J1939_T1							43
#define J1939_T2							44
#define J1939_T3							45
#define J1939_T4							46
#define J1939_BRDCST_MIN_DELAY				47
#define J1939_T1_ID							0x0000803F
#define J1939_T2_ID							0x00008040
#define J1939_T3_ID							0x00008041
#define J1939_T4_ID							0x00008042
#define J1939_BRDCST_MIN_DELAY_ID			0x00008043

/*Jayasheela-added macro for W0 parameter */
#define W0									43

/* Error IDs */
#define STATUS_NOERROR						0
#define ERR_NOT_SUPPORTED					1
#define ERR_INVALID_CHANNEL_ID				2
#define ERR_INVALID_PROTOCOL_ID				3
#define ERR_NULL_PARAMETER					4
#define ERR_INVALID_IOCTL					5
#define ERR_INVALID_FLAGS					6
#define ERR_FAILED							7
#define ERR_DEVICE_NOT_CONNECTED			8
#define ERR_TIMEOUT							9
#define ERR_INVALID_MSG						10
#define ERR_INVALID_TIME_INTERVAL			11
#define ERR_EXCEEDED_LIMIT					12
#define ERR_INVALID_MSG_ID					13
#define ERR_INVALID_ERROR_ID				14
#define ERR_INVALID_IOCTL_ID				15
#define ERR_BUFFER_EMPTY					16
#define ERR_BUFFER_FULL						17
#define ERR_BUFFER_OVERFLOW					18
#define ERR_PIN_INVALID						19
#define ERR_CHANNEL_IN_USE					20
#define ERR_MSG_PROTOCOL_ID					21
#define ERR_ADDRESS_NOT_CLAIMED				0x00010000

/* Miscellaneous definitions */
#define SHORT_TO_GROUND						0xFFFFFFFE
#define VOLTAGE_OFF							0xFFFFFFFF

/* RxStatus definitions */
#define TX_MSG_TYPE							0x00000001
#define ISO15765_FIRST_FRAME				0x00000002
#define RX_BREAK							0x00000004
#define	ISO15765_TX_DONE					0x00000008


#define PASSTHRU_MSG_DATA_SIZE				4128	

/* TxFlags definitions */
#define TX_NORMAL_TRANSMIT					0x00000000
#define ISO15765_FRAME_PAD					0x00000040
#define ISO15765_EXT_ADDR					0x00000080
#ifndef CAN_29BIT_ID
#define CAN_29BIT_ID						0x00000100
#endif
#define CAN_EXTENDED_ID						0x00000100
#define TX_BLOCKING							0x00010000
#define SCI_TX_VOLTAGE						0x00800000

/* Filter definitions */
#define PASS_FILTER							0x00000001
#define BLOCK_FILTER						0x00000002
#define FLOW_CONTROL_FILTER					0x00000003

/* Message Structure */
typedef struct
{
	unsigned long ProtocolID;
	unsigned long RxStatus;
	unsigned long TxFlags;
	unsigned long Timestamp;
	unsigned long DataSize;
	unsigned long ExtraDataIndex;
	unsigned char Data[PASSTHRU_MSG_DATA_SIZE];
} PASSTHRU_MSG;

/* IOCTL Structures */
typedef struct
{
	unsigned long Parameter;
	unsigned long Value;
} SCONFIG;

typedef struct
{
	unsigned long NumOfParams;
	SCONFIG *ConfigPtr;
} SCONFIG_LIST;

typedef struct
{
	unsigned long NumOfBytes;
	unsigned char *BytePtr;
} SBYTE_ARRAY;

typedef struct
{
	unsigned long NumOfPins;
	unsigned char *PinUsePtr;
} SPIN_CONTROL;

typedef struct
{
	unsigned long PinNumber;
	unsigned long PinUse;
	unsigned long Parameter;
} SPIN_USE;

#endif /* __J2534_H */

