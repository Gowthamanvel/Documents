/*Exported Function Pointers*/
typedef long (CALLBACK* PTOPEN)(void *, unsigned long *);
typedef long (CALLBACK* PTCLOSE)(unsigned long);
typedef long (CALLBACK* PTCONNECT)(unsigned long, unsigned long, unsigned long, 
								   unsigned long, unsigned long *);
typedef long (CALLBACK* PTDISCONNECT)(unsigned long);
typedef long (CALLBACK* PTREADMSGS)(unsigned long, void *, unsigned long *, unsigned long);
typedef long (CALLBACK* PTWRITEMSGS)(unsigned long, void *, unsigned long *, unsigned long);
typedef long (CALLBACK* PTSTARTPERIODICMSG)(unsigned long, void *, unsigned long *, 
											unsigned long);
typedef long (CALLBACK* PTSTOPPERIODICMSG)(unsigned long, unsigned long);
typedef long (CALLBACK* PTSTARTMSGFILTER)(unsigned long, unsigned long, void *, void *, void *,
										  unsigned long *);
typedef long (CALLBACK* PTSTOPMSGFILTER)(unsigned long, unsigned long);
typedef long (CALLBACK* PTSETPROGRAMMINGVOLTAGE)(unsigned long, unsigned long, unsigned long);
typedef long (CALLBACK* PTREADVERSION)(unsigned long, char *, char *, char *);
typedef long (CALLBACK* PTGETLASTERROR)(char *);
typedef long (CALLBACK* PTIOCTL)(unsigned long, unsigned long, void *, void *);
typedef long (CALLBACK* PTLOADFIRMWARE)(void);
typedef long (CALLBACK* PTRECOVERFIRMWARE)(void);
typedef long (CALLBACK* PTREADIPSETUP)(char *, char *, char *, char *, char *);
typedef long (CALLBACK* PTWRITEIPSETUP)(char *, char *, char *, char *, char *);
typedef long (CALLBACK* PTREADPCSETUP)(char *, char *);
typedef long (CALLBACK* LOGGINGSTATUS)(unsigned long,unsigned long,SYSTEMTIME *);

PTOPEN	PassThruOpen;
PTCLOSE	PassThruClose;
PTCONNECT PassThruConnect;
PTDISCONNECT PassThruDisconnect;
PTREADMSGS PassThruReadMsgs;
PTWRITEMSGS PassThruWriteMsgs;
PTSTARTPERIODICMSG PassThruStartPeriodicMsg;
PTSTOPPERIODICMSG PassThruStopPeriodicMsg;
PTSTARTMSGFILTER PassThruStartMsgFilter;
PTSTOPMSGFILTER PassThruStopMsgFilter;
PTSETPROGRAMMINGVOLTAGE PassThruSetProgrammingVoltage;
PTREADVERSION PassThruReadVersion;
PTGETLASTERROR PassThruGetLastError;
PTIOCTL PassThruIoctl;
PTLOADFIRMWARE PassThruLoadFirmware;
PTRECOVERFIRMWARE PassThruRecoverFirmware;
PTREADIPSETUP PassThruReadIPSetup;
PTWRITEIPSETUP PassThruWriteIPSetup;
PTREADPCSETUP PassThruReadPCSetup;
LOGGINGSTATUS LoggingStatus;

char* ErrorList[] = {"STATUS_NOERROR",
					"ERR_NOT_SUPPORTED",
					"ERR_INVALID_CHANNEL_ID",
					"ERR_INVALID_PROTOCOL_ID",
					"ERR_NULL_PARAMETER",
					"ERR_INVALID_IOCTL",
					"ERR_INVALID_FLAGS",
					"ERR_FAILED",
					"ERR_INVALID_DEVICE_ID",
					"ERR_TIMEOUT",
					"ERR_INVALID_MSG",
					"ERR_INVALID_TIME_INTERVAL",
					"ERR_EXCEEDED_LIMIT",
					"ERR_INVALID_MSG_ID",
					"ERR_DEVICE_IN_USE",
					"ERR_INVALID_IOCTL_ID",
					"ERR_BUFFER_EMPTY",
					"ERR_BUFFER_FULL",
					"ERR_BUFFER_OVERFLOW",
					"ERR_PIN_INVALID",
					"ERR_CHANNEL_IN_USE",
					"ERR_MSG_PROTOCOL_ID",
					"ERR_INVALID_FILTER_ID",
					"ERROR_NO_FLOW_CONTROL",
					"ERR_NOT_UNIQUE",
					"ERR_INVALID_BAUDRATE",
					"ERR_ADDRESS_NOT_CLAIMED",
					"",
					"",
					"",
					"",
					"",
					"ERR_DEVICE_NOT_CONNECTED"};

/*vikaschar* ProtocolList[5][2] = {	"ISO14230","4",
								"CAN","5",
								"ISO15765","6",
								"CAN_CH1","14",
								"ISO15765_CH1","15"
							};*/
char* ProtocolList[8][2] = {	"ISO9141", "3",
								"ISO14230","4",
								"CAN","5",
								"ISO15765","6",
								"CAN_CH1","14",
								"ISO15765_CH1","15",
								"J1939","16",
								"J1939_CH1","17"
							};


/*char* ProtocolList[5][2] = {	"ISO14230","4",
								"CAN","5",
								"ISO15765","6",
								"CAN_CH1","14",
								"ISO15765_CH1","15"
							};*/

/*char* ProtocolList[] = {	"J1850VPW",
							"J1850PWM",
							"ISO9141",
							"ISO14230",
							"CAN",
							"ISO15765",
							"SCI_A_ENGINE",
							"SCI_A_TRANS",
							"SCI_B_ENGINE",
							"SCI_B_TRANS",
							"SWCAN_ISO15765_PS",
							"SWCAN_PS",
							"CCD",
							"CAN_CH1",
							"ISO15765_CH1",
						};
						*/

char* IoctlParamList[] = {	"",
							"DATA_RATE",
							"LOOPBACK",
							"NODE_ADDRESS",
							"NETWORK_LINE",
							"P1_MIN",
							"P1_MAX",
							"P2_MIN",
							"P2_MAX",
							"P3_MIN",
							"P3_MAX",
							"P4_MIN",
							"P4_MAX",
							"W1",
							"W2",
							"W3",
							"W4",
							"W5",
							"TIDLE",
							"TINIL",
							"TWUP",
							"PARITY",
							"BIT_SAMPLE_POINT",
							"SYNC_JUMP_WIDTH",
							"W0",
							"T1_MAX",
							"T2_MAX",
							"T4_MAX",
							"T5_MAX",
							"ISO15765_BS",
							"ISO15765_STMIN",
							"DATA_BITS",
							"FIVE_BAUD_MOD",
                            "BS_TX",
                            "STMIN_TX",
                            "T3_MAX",
                            "ISO15765_WFT_MAX",
							"CAN_MIXED_FORMAT",
							"J1962_PINS",							
							"SWCAN_HS_DATA_RATE",					
							"SWCAN_SPEEDCHANGE_ENABLE",
							"SWCAN_RES_SWITCH",
							"J1939_T1",
							"J1939_T2",
							"J1939_T3",
							"J1939_T4",
							"J1939_BRDCST_MIN_DELAY",
};
