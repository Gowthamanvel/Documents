/*********************************************************************************
                    Dearborn Electronics India Pvt Ltd.,
**********************************************************************************
 Project Name           : InnovaJ2534SDK Software - SDK Version 1.0
 File Name              : InnovaJ2534SDK.cpp
 Description            : Implementation of the InnovaJ2534S SDK 
                          application
 Date                   : March 25, 2009
 Version                : 1.2
 Author                 : Chakravarthy
 Revision               : 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File        Date           Author                      Description
 Version
_____________________________________________________________________________
 
  1.0        Dec 07, 2007   Chakravarthy                Initial Version

  1.1        Feb 05, 2008   Chakravarthy                Added Header column to 
                                                        the main list control.
  1.2        Mar 25, 2009   Nikhilesh Sawarkar          Added Multichannel support
_____________________________________________________________________________
*********************************************************************************/
#include "stdafx.h"
#include <stdlib.h>
#include "windows.h"
#include <process.h>
#include "resource.h"
#include "Defines.h"
#include "windowsx.h"
#include "stdio.h"
#include "J2534.h"
#include "shellapi.h"
#include "commctrl.h"
#include <tchar.h>
#include "Commdlg.h"
#include  <math.h>

// Constants
#define J2534REGISTRY_KEY_PATH          "Software\\PassThruSupport.04.04"
#define J2534REGISTRY_DEVICE_ID         "DeviceId"
#define J2534REGISTRY_NAME              "Name"
#define J2534REGISTRY_DEARBORN_GROUP    "Innova."
#define J2534REGISTRY_DEVICES           "Devices"
#define J2534REGISTRY_DOUBLE_BACKSLASH  "\\"
#define J2534REGISTRY_HYPHEN_SPACE      " - "
#define J2534REGISTRY_CAYMAN            "5000OEMTOOL"
#define J2534REGISTRY_VENDOR            "Vendor"
#define J2534REGISTRY_NAME              "Name"
#define J2534REGISTRY_PROTOCOLSSUPPORT  "ProtocolsSupported"
#define J2534REGISTRY_CONFIGAPP         "ConfigApplication"
#define J2534REGISTRY_FUNCLIB           "FunctionLibrary"
#define J2534REGISTRY_APIVERSION        "APIVersion"
#define J2534REGISTRY_PRODUCTVERSION    "ProductVersion"
#define J2534REGISTRY_LOGGING           "Logging"
#define J2534REGISTRY_LOGGINGDIRECTORY  "LoggingDirectory"
#define J2534REGISTRY_CAN               "CAN"
#define J2534REGISTRY_ISO15765          "ISO15765"
#define J2534REGISTRY_J1850PWM          "J1850PWM"
#define J2534REGISTRY_J1850VPW          "J1850VPW"
#define J2534REGISTRY_ISO9141           "ISO9141"
#define J2534REGISTRY_ISO14230          "ISO14230"
#define J2534REGISTRY_SCI_A_ENGINE      "SCI_A_ENGINE"
#define J2534REGISTRY_SCI_A_TRANS       "SCI_A_TRANS"
#define J2534REGISTRY_SCI_B_ENGINE      "SCI_B_ENGINE"
#define J2534REGISTRY_SCI_B_TRANS       "SCI_B_TRANS"
#define J2534REGISTRY_SWCAN_ISO15765_PS "SWCAN_ISO15765_PS"
#define J2534REGISTRY_SWCAN_PS          "SWCAN_PS"
#define J2534REGISTRY_CCD               "CCD"
/*VIKAS*/#define J2534REGISTRY_CAN_CH1           "CAN_CH1"


#define J2534REGISTRY_MAX_STRING_LENGTH     1024
#define J2534REGISTRY_MINI_STRING_LENGTH    128
#define MAX_PX_SIZE 5

#define MAX_COLUMN  10
#define MAX_COLUMN_WRT 5
#define TEMPSTREAM  "InnovaDtStream.ini"//Nikhil added
#define DELEMETER  "#"
#define NEWLINE    "\n"
#define ENCRYPTLIMIT  20000
#define SIZE_0x  2
#define READ_ON  0
#define READ_OFF 1
/*Function Declaration*/
int  LoadJ2534Library();
int  InitFunctionPointers();
void EraseFunctionPointers();
void AddToScreen(HWND,char *msg);
void EnableAllControls(BOOL bEnable);
void EnableDeviceControls(BOOL bEnable);
void EnableProtocolControls(BOOL bEnable);
int  CheckAndConvertMsg(unsigned char *, unsigned char *);
/* Added one more parameter for messageid for periodicMSG by venkatesh in 29-july-08*/
void StartPeriodicMessage(HWND,int,int,int,int,int,unsigned long *);
void StopPeriodicMessage(HWND,int,int,int,int,int,unsigned long);
void StartMsgFilter(HWND,int,int,int,int,int,int,int,unsigned long *);
void StopMsgFilter(HWND ,int,int,int,int,int,int,int,unsigned long);

DWORD WINAPI ReadMessages (LPVOID lpVoid);
void ClearAllPXMessages(HWND hDlg);
void ClearAllMsgFilters(HWND hDlg);
HANDLE Single_Instance(char *name);

/*Save List Control Data*/
void SaveListControlDataToFile();
void DrawLine(FILE *pFile);
/***********************************Nikhilesh added*********************************************/
void CreateFileHeader(FILE *pFile);
void AddFrameInfoToFile(FILE *pFile,TCHAR *szColumnData,int nColumnIndex,int nRowIndex);
void FileCreateTempStream();
void FileDeleteTempStream();
void FileCopyDatatoStream(int,char*,int );
int  FileReadDataFrmStream(TCHAR*,char*);
void FileEncryptData(int,char*,char*);
void FileSaveDataFrmStream(TCHAR *szColumnData,int nRowIndex);
unsigned long hexToint(char *string);
char* removeheader(char *val);
BOOL varifyString(char *val);
void ResetGUIStatus(BOOL Filter, BOOL PeriodicMessages);
void ReadPeoridicStatus(char* profileBuffer,HWND hDlg);
void WritePeoridicStatus(char* profileBuffer,HWND hDlg);
void ReadFilterStatus(char* profileBuffer,HWND hDlg);
void WriteFilterStatus(char* profileBuffer,HWND hDlg);
void sortBuffer(int * connections, unsigned long ActiveConnections);
void UpdateConnectDisconnectList(HWND hDlg, BOOL button);

/***********************************************************************************************/



/*API Functions*/
void DO_PassThruOpen();
void DO_PassThruConnect();
void Do_PassThruPeoridicMsg();
void Do_PassThruFilterMsg();
void Do_PassThruIOCTL();
void DO_PassThruDisConnect();
void Do_PassThruClose();
void Do_PassThruReadVersion();
void Do_PassThruGetLastError();
void Do_PassThruWrtMsg();
void Do_PassThruSetProgramVoltage();
void Do_PassThruStopPeoridicMsg();
void Do_PassThruStopFilterMsg();

/*CALLBACK Function Dclaration*/
LRESULT CALLBACK MainDlg(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK ConnectProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK PeoridicProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK FilterProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK IOCTLProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK SetProgrammingVoltageProc(HWND,UINT,WPARAM,LPARAM);

/*Variable Decalration*/
HINSTANCE hModule,hInst;
HANDLE hExitThread=NULL;
HWND hMainDlg,hLogWindow,hStatus,hRxWindow,hPxDlg,hDeviceDataLstHnd,hWriteList;
unsigned int iListboxCharWidth, iListboxCurrentWidth;
char chFuncLib[MAX_PATH];
char chConfigApp[MAX_PATH];
char tempbuf[PASSTHRU_MSG_DATA_SIZE];
unsigned long ulDeviceID,iFilId,iPeriodId;
unsigned long ulChannelID;
unsigned long ulPeriodicID[MAX_PX_SIZE];
unsigned long ulFilterID[MAX_PX_SIZE];
unsigned char tempstr[16384], tempmsg[16384], tempmsg2[16384],pxmessages[16384];
char lastmsgs[10][16384],path[1024];
char buttonstate[50];
int iCurProtocol,nFilId;
unsigned long ulChannelID_Count = 0;

/*********************************Nikhilesh added***********************************************************************************************************/
// Two Dimensional buffer  |String location of protocol |Protocol ID | Channel ID | Read Enable Status(used to desable reading while disconnecting and       
// iProtocolsConnected[]   |as per ProtocolList         |            |            | desable reading while disconnecting and deleting Protocol object
unsigned long iProtocolsConnected[10][4];
char DirectoryPath[MAX_PATH];
										/* | number of msg | protocol ID |*/
unsigned long ulMessageRecords[5][2] = {	0,ISO14230,
											0,CAN,
											0,ISO15765,
											0,CAN_CH1_PROTOCOL_ID,
											0,ISO15765_CH1_PROTOCOL_ID
										};


/************************************************************************************************************************************************************/

BOOL bCanExtended,hCanIdBoth;
HANDLE hReadThread = NULL;
bool bReceiveThread = TRUE;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{

    if(Single_Instance("Innova Class") == NULL)
        return 0;
    hExitThread=CreateEvent(NULL, TRUE, FALSE, NULL);
    hInst=hInstance;
    DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainDlg);
    return 0;
}
//-----------------------------------------------------------------------------
//  Function Name   : FindJ2534Entry()
//  Input Params    : 
//  Output Params   : 
//  Return          : 
//  Description     : This is a function to find the J2534 device entry in
//                    the registry.
//-----------------------------------------------------------------------------
bool FindJ2534Entry(char* pchCurText)
{
    long            lSuccess;
    char            chTempstr[J2534REGISTRY_MAX_STRING_LENGTH]; 
    DWORD           dwDatasize;     
    unsigned char   ucValueread[J2534REGISTRY_MAX_STRING_LENGTH];
    DWORD           dwDword, dwString; 
    HKEY            hMainkey;
    HKEY            hTempkey;
    HKEY            *phTempkey;
    dwDword = REG_DWORD, dwString = REG_SZ;
    hTempkey = NULL;
    phTempkey = NULL;
    strcpy(chTempstr, J2534REGISTRY_KEY_PATH);
    lSuccess = RegOpenKeyEx(HKEY_LOCAL_MACHINE, chTempstr, 0,KEY_READ,&hMainkey);
    if(lSuccess==ERROR_SUCCESS) 
    {
        dwDatasize=J2534REGISTRY_MAX_STRING_LENGTH;
        lSuccess = RegOpenKeyEx(hMainkey, pchCurText,0, KEY_READ, &hTempkey);
        if (lSuccess==ERROR_SUCCESS)
        {
            dwDatasize = sizeof(ucValueread);
            lSuccess = RegQueryValueEx(hTempkey, "ConfigApplication", NULL, 
                &dwString, ucValueread, &dwDatasize);
            
            if(lSuccess==ERROR_SUCCESS)
            {
                // Found Config application to load
                sprintf(chConfigApp, "%s", ucValueread);
            }

            dwDatasize = sizeof(ucValueread);
            lSuccess = RegQueryValueEx(hTempkey, "FunctionLibrary", NULL, 
                &dwString, ucValueread, &dwDatasize);
        
            if(lSuccess==ERROR_SUCCESS)
            {
                // Found DLL to load
                sprintf(chFuncLib, "%s", ucValueread);
            }
            RegCloseKey(hTempkey);
            hTempkey = NULL;
        }
    }
    RegCloseKey(hMainkey);
    return true;
    if (phTempkey != NULL)
    {
        RegCloseKey(*phTempkey);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

HANDLE Single_Instance(char *name) 
{
    HANDLE ret = NULL; //create a null handle for return
    HANDLE hMutex = ::CreateMutex( NULL, FALSE, _T(name)); //attempt to create MuteX
    bool Running = ( ::GetLastError() == ERROR_ALREADY_EXISTS ||
    ::GetLastError() == ERROR_ACCESS_DENIED); //See if it was successful
    if(Running) 
    {
        ret = NULL; //Set return to NULL (should already be set to NULL
    }
    
    else 
    {
        ret = hMutex; //set to the Handle
    }
    
    if (hMutex != NULL) 
    {
        
        ::ReleaseMutex(hMutex);
    }
    return ret;
}

LRESULT CALLBACK MainDlg(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT rt, rt2;
    long lSuccess;
    DWORD           dwDatasize;     
    HKEY            hMainkey;
    bool            bDeviceExist;
    char chTempstr1[J2534REGISTRY_MAX_STRING_LENGTH]; 
    int nOpen =0;
	char _text[20];
	unsigned long protocolCount;
	int nsel,i;
	int error =0;
	char profileBuffer[100];
	char lastprotocolmsgs[10][16384];

    switch (message)
    {
    case WM_INITDIALOG:
        {
            memset(tempbuf, 0, PASSTHRU_MSG_DATA_SIZE);
            memset(chTempstr1, 0, J2534REGISTRY_MAX_STRING_LENGTH);
            memset(chFuncLib, 0, MAX_PATH);
            memset(chConfigApp, 0, MAX_PATH);
			GetCurrentDirectory(  300, DirectoryPath );     
			strcat(DirectoryPath,"\\");
			strcat(DirectoryPath,TEMPSTREAM);
			FileCreateTempStream();//Nikhil added
            
            GetWindowRect(GetDesktopWindow(), &rt);
            GetWindowRect(hDlg, &rt2);
            SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
                (rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, 
                SWP_NOZORDER | SWP_NOSIZE);

            hMainDlg=hDlg;
			hDeviceDataLstHnd = GetDlgItem(hMainDlg, IDC_EDIT_RXDATA);//Nikhil
			SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, "");
            hLogWindow = GetDlgItem(hDlg,IDC_LISTLOG);
            hRxWindow = GetDlgItem(hDlg,IDC_LIST_RX);
			//Nikhil added
			hWriteList = GetDlgItem(hDlg,IDC_MSGLIST);
			LVCOLUMN listCol;
			
/***************************/
			memset(&listCol, 0, sizeof(LVCOLUMN));
            listCol.mask = LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;
			listCol.pszText = "Select";
            listCol.cx = 0x30;
            SendMessage(hWriteList,LVM_INSERTCOLUMN,0,(LPARAM)&listCol); 
            listCol.pszText = "Protocol";
            listCol.cx = 0x50;
            SendMessage(hWriteList,LVM_INSERTCOLUMN,1,(LPARAM)&listCol); 
			listCol.cx = 0x50;
            listCol.pszText="Tx Flag";                            
            SendMessage(hWriteList,LVM_INSERTCOLUMN,2,(LPARAM)&listCol);
			listCol.cx = 0x100;
            listCol.pszText="Message";                            
            SendMessage(hWriteList,LVM_INSERTCOLUMN,3,(LPARAM)&listCol);
			ListView_SetExtendedListViewStyle(hWriteList, LVS_EX_GRIDLINES | LVS_EX_CHECKBOXES  );

/*****************************/

			/*jayasheela-added one more control for Tx flags */
			SetDlgItemText(hDlg, IDC_TXFLAGS, "0x00000000");
            /*Fill the Rx Window*/
           
            memset(&listCol, 0, sizeof(LVCOLUMN));
            listCol.mask = LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;
            listCol.pszText = "Sl No";
            listCol.cx = 0x28;
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,0,(LPARAM)&listCol); 
            listCol.cx = 0x42;
            listCol.pszText="Timestamp";                            
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,1,(LPARAM)&listCol);
            listCol.cx = 0x34;
            listCol.pszText="Protocol";                            
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,2,(LPARAM)&listCol); 
            listCol.cx = 0x30;
            listCol.pszText="Tx/Rx";                            
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,3,(LPARAM)&listCol);
			listCol.cx = 0x56;
            listCol.pszText="ExtraDataIndex";                            
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,4,(LPARAM)&listCol);
            listCol.cx = 0x38;
            listCol.pszText="RxStatus";                            
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,5,(LPARAM)&listCol);
            listCol.cx = 0x32;
            listCol.pszText="TxFlags";                            
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,6,(LPARAM)&listCol);
			listCol.cx = 0x38;
            listCol.pszText="DataSize";                           
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,7,(LPARAM)&listCol);
            listCol.cx = 0x100;
            listCol.pszText="Data Bytes";                           
            SendMessage(hRxWindow,LVM_INSERTCOLUMN,8,(LPARAM)&listCol); 
            ListView_SetExtendedListViewStyle(hRxWindow, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);
 
            /*Find the list of devices from the registry*/
            bDeviceExist = FALSE;
            strcpy(chTempstr1, J2534REGISTRY_KEY_PATH);
            lSuccess = RegOpenKeyEx(HKEY_LOCAL_MACHINE, chTempstr1,0, KEY_READ, &hMainkey);
            if(lSuccess==ERROR_SUCCESS) 
            {
                i=0;
                while (lSuccess==ERROR_SUCCESS) 
                {
                    dwDatasize=J2534REGISTRY_MAX_STRING_LENGTH;
                    lSuccess = RegEnumKey(hMainkey, i, chTempstr1, dwDatasize);
                    if(lSuccess==ERROR_SUCCESS)
                    {
                        /*Fill the  List of J2534 Device Information*/
						ComboBox_AddString(GetDlgItem(hMainDlg, IDC_COMBO_DEVICEDLL),chTempstr1);
						ComboBox_SetCurSel(GetDlgItem(hMainDlg, IDC_COMBO_DEVICEDLL),0);
                        bDeviceExist = TRUE;
                        i++;
                    }
                }
                RegCloseKey(hMainkey);
            }
            if(bDeviceExist == TRUE)
            {
                hStatus = GetDlgItem(hDlg,IDC_OPEN);
                EnableWindow(hStatus,1);
                hStatus = GetDlgItem(hDlg,IDC_CFG_DEVICE);
                EnableWindow(hStatus,1);
                EnableAllControls(FALSE);
            }
            else
            {
                hStatus = GetDlgItem(hDlg,IDC_OPEN);
                EnableWindow(hStatus,0);
                hStatus = GetDlgItem(hDlg,IDC_CFG_DEVICE);
                EnableWindow(hStatus,0);
                EnableAllControls(FALSE);
                AddToScreen(hLogWindow,"There is currently no J2534 device installed.");
            }
            GetWindowsDirectory((LPSTR)path, sizeof(path) - 13);
            if (path[strlen(path)-1] != '\\')
                strcat(path, "\\");
            strcat(path, "InnovaJ2534SDK.ini");
            
            /*Load the Bitmap*/
            hStatus = GetDlgItem(hDlg,IDC_STATIC_LOGO);
            ResetGUIStatus(TRUE,TRUE);
            return TRUE;
        }
        break;

    case WM_CLOSE:
		FileDeleteTempStream();
        SetEvent(hExitThread);
        TerminateThread(hReadThread,0);
        if(hModule)
        {
            Do_PassThruClose();
            EraseFunctionPointers();
        }
		CloseHandle(hExitThread);
        EndDialog(hDlg, LOWORD(wParam));
        return TRUE;

    case WM_NOTIFY:
        {
			if(((LPNMLVKEYDOWN)lParam)->hdr.code  == LVN_KEYDOWN  )
				{
					if((((LPNMLVKEYDOWN)lParam)->wVKey == VK_UP) || (((LPNMLVKEYDOWN)lParam)->wVKey == VK_DOWN))
					{
						int iSlected=0;
						int iItemCount = 0;
						char Text[255]={0}; 
						TCHAR datainChar[PASSTHRU_MSG_DATA_SIZE];
						iSlected=SendMessage(hRxWindow,LVM_GETNEXTITEM,(unsigned int)-1,LVNI_FOCUSED);  //LVNI_FOCUSED 
						if(iSlected == 0 && ((LPNMLVKEYDOWN)lParam)->wVKey == VK_UP)
						{
							return FALSE;
						}
						iItemCount = SendMessage(hRxWindow,LVM_GETITEMCOUNT,(unsigned int)-1,LVNI_FOCUSED);  //LVNI_FOCUSED 
						
						 
						LV_ITEM LvItem;
						memset(&LvItem,0,sizeof(LvItem));
						LvItem.mask=LVIF_TEXT;
						LvItem.iSubItem=0;
						LvItem.pszText=Text;
						LvItem.cchTextMax=256;
						LvItem.iItem=iSlected;
						if((((LPNMLVKEYDOWN)lParam)->wVKey == VK_DOWN))
							iSlected++;
						if((((LPNMLVKEYDOWN)lParam)->wVKey == VK_UP))
							iSlected--;

						if(iSlected >= iItemCount && ((LPNMLVKEYDOWN)lParam)->wVKey == VK_DOWN)
						{
							return FALSE;
						}
						SendMessage(hRxWindow,LVM_GETITEMTEXT, iSlected, (LPARAM)&LvItem);
						//Read and parse from temp file.
						if(FileReadDataFrmStream(datainChar,Text))
							SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, datainChar);//Nikhil
						else
							SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, "");//Nikhil

					}
					return TRUE;
				}
            switch (((LPNMHDR)lParam)->code)
            {
            case LVN_COLUMNCLICK:
                if (((LPNMHDR)lParam)->idFrom == IDC_LIST_RX)
                {
                    /*Here Just i captured the click event of List cotrol. If any
                    thing needs to be done in feature, it can be used*/
                }
                break; 
				case NM_CLICK:
				 if (((LPNMHDR)lParam)->idFrom == IDC_LIST_RX)
                {
                    /*Here,upon user clicks list item, corresponding data is displayed on edit box*/
					int iSlected=0;
					char Text[255]={0}; 
					TCHAR datainChar[PASSTHRU_MSG_DATA_SIZE];
					iSlected=(int)SendMessage(hRxWindow,LVM_GETNEXTITEM,(unsigned int)-1,LVNI_FOCUSED);  //LVNI_FOCUSED 
					if(iSlected==-1)
					{
						break;
					}
					LV_ITEM LvItem;
					memset(&LvItem,0,sizeof(LvItem));
					LvItem.mask=LVIF_TEXT;
					LvItem.iSubItem=0;
					LvItem.pszText=Text;
					LvItem.cchTextMax=256;
					LvItem.iItem=iSlected;
				    SendMessage(hRxWindow,LVM_GETITEMTEXT, iSlected, (LPARAM)&LvItem);
					//Read and parse from temp file.
					if(FileReadDataFrmStream(datainChar,Text))
						SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, datainChar);//Nikhil
					else
						SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, "");//Nikhil
				 
				 }
				if (((LPNMHDR)lParam)->idFrom == IDC_MSGLIST)
                {
					int iSlected=0;
					iSlected=SendMessage(hWriteList,LVM_GETNEXTITEM,(unsigned int)-1,LVNI_FOCUSED);  //LVNI_FOCUSED 
					ListView_SetItemState(hMainDlg,iSlected,LVNI_FOCUSED ,LVIS_OVERLAYMASK );
					
				}
			break;
	           default:
                break;
            }
        }
        return TRUE;

    case WM_COMMAND:
        {
            if(HIWORD(wParam)==LBN_SELCHANGE)
            {
                if(ListBox_GetCount(GetDlgItem(hDlg, IDC_MSGLIST)))
                    EnableWindow(GetDlgItem(hDlg, IDC_WRITEMESSAGE), TRUE);
            }
            else
            {
                switch (LOWORD(wParam))
                {
                case IDEXIT:
                    SetEvent(hExitThread);
                    TerminateThread(hReadThread,0);
					ResetGUIStatus(TRUE,TRUE);
                    if(hModule)
                    {
                        Do_PassThruClose();
                        EraseFunctionPointers();
                    }
					CloseHandle(hExitThread);
                    EndDialog(hDlg, LOWORD(wParam));
                    return TRUE;
                case IDC_OPEN:
					GetDlgItemText(hDlg,IDC_OPEN,_text,14);
					if( strcmp(_text,"&Open Device") == 0)
						{
							DO_PassThruOpen();
						}
					else if( strcmp(_text,"&Close Device") == 0)
						{
							 SetEvent(hExitThread);
							 Sleep(50);
							 TerminateThread(hReadThread,0);
							 if(hModule)
							 {
								Do_PassThruClose();
								EraseFunctionPointers();
							 }

						}
                    break;
                case IDC_CONNECT:
                    DO_PassThruConnect();
                    break;
                case IDC_STARTPEORIDIC:
                    Do_PassThruPeoridicMsg();
                    break;
                case IDC_STARTMSG_FILTER:
                    Do_PassThruFilterMsg();
                    break;
                case IDC_IOCTL:
                    Do_PassThruIOCTL();
                    break;
                case IDC_DISCONNECT:
                    DO_PassThruDisConnect();
                    break;
                case IDC_CLOSE: 
					 /*Jayasheela-added this code to handle the exceptions */
					 SetEvent(hExitThread);
					 TerminateThread(hReadThread,0);
					 if(hModule)
					 {
						Do_PassThruClose();
						EraseFunctionPointers();
					 }
                    break;
                case IDC_READVERSION:
                    Do_PassThruReadVersion();
                    break;
                case IDC_GETLAST_ERROR:
                    Do_PassThruGetLastError();
                    break;
                case IDC_ADDTOLIST:
                    if(GetDlgItemText(hDlg, IDC_MSG, (char*)tempstr, 16384))
                    {
                        SetDlgItemText(hDlg, IDC_MSG, NULL);
                        if(CheckAndConvertMsg(tempstr, tempmsg)!=-1)
                        {
                            if(tempstr[strlen((char*)tempstr)-1]==' ')
                                tempstr[strlen((char*)tempstr)-1]=0;
                            
                            WritePrivateProfileString("Previous Msgs", NULL, NULL, path);
                            for(i=0; i<10; i++)
                            {
                                if(!strcmp((char*)tempstr, lastmsgs[i]))
                                    break;
                            }
                            if(i==10)
                            {
                                for(i=9; i>0; i--)
                                {
                                    memset(lastmsgs[i], 0, 16384);
                                    strcpy((char*)lastmsgs[i], (char*)lastmsgs[i-1]);
                                }
                                
                                memset(lastmsgs[0], 0, 16384);
                                strcpy((char*)lastmsgs[0], (char*)tempstr);
                                ComboBox_InsertString(GetDlgItem(hDlg, IDC_MSG), 0, (char*)lastmsgs[0]);
                                ComboBox_DeleteString(GetDlgItem(hDlg, IDC_MSG), 10);
                            }
                            for(i=0; i<10; i++)
                            {
                                sprintf((char*)tempbuf, "Msg%d", i); 
                                WritePrivateProfileString("Previous Msgs", (char*)tempbuf, (char*)lastmsgs[i], path);
                            }
                           //Add message to list control
/***************************/
							LV_ITEM lvitem;
							lvitem.iSubItem = 0;
							lvitem.pszText = "";  
							lvitem.mask = LVIF_IMAGE | LVIF_TEXT;
							lvitem.state =  LVIS_STATEIMAGEMASK ;
							lvitem.stateMask = LVIS_STATEIMAGEMASK ;
							lvitem.iImage = 0;	
							int nItemCount = ListView_GetItemCount(hWriteList);
							lvitem.iItem = nItemCount;
							ListView_InsertItem(hWriteList,&lvitem);
							ComboBox_GetText(GetDlgItem(hMainDlg, IDC_COMBO_CHN),_text,20);
							ListView_SetItemText(hWriteList,nItemCount,1,_text);
							GetDlgItemText(hMainDlg, IDC_TXFLAGS, (char*)_text, 20);
							ListView_SetItemText(hWriteList,nItemCount,2,(char*)_text);
							ListView_SetItemText(hWriteList,nItemCount,3,(char*)tempstr);
//							ListView_SetCheckState(hWriteList,nItemCount,TRUE);

/****************************/

/****************************************************************/
								strcat((char *)tempstr," - ");
								strcat((char *)tempstr,_text);
								ComboBox_GetText(GetDlgItem(hMainDlg, IDC_COMBO_CHN),_text,20);
								sprintf((char*)profileBuffer,"%s", _text);   
								strcat(profileBuffer," - Previous Msgs");

								for(int i=0; i<10; i++)
								{
									sprintf((char *)tempbuf, "Msg%d", i);
									GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)lastprotocolmsgs[i], 16384, path);
								}
								for(i=0; i<10; i++)
								{
									if(!strcmp((char*)tempstr, lastprotocolmsgs[i]))
										break;
								}
								if(i==10)
								{
									for(i=9; i>0; i--)
									{
										memset(lastprotocolmsgs[i], 0, 16384);
										strcpy((char*)lastprotocolmsgs[i], (char*)lastprotocolmsgs[i-1]);
									}
                                
									memset(lastprotocolmsgs[0], 0, 16384);
									strcpy((char*)lastprotocolmsgs[0], (char*)tempstr);
								}
								for(i=0; i<10; i++)
								{
									sprintf((char*)tempbuf, "Msg%d", i); 
									WritePrivateProfileString(profileBuffer, (char*)tempbuf, (char*)lastprotocolmsgs[i], path);
								}
								
						
/*****************************************************************/

                        }
						    ComboBox_SetCurSel(GetDlgItem(hMainDlg, IDC_MSG),0);

                    }
                    break;
                case IDC_RMV_LIST:
					{
					int nsel=0;
					int msgcount = 0;
				/*	iSlected=SendMessage(hWriteList,LVM_GETNEXTITEM,-1,LVNI_SELECTED);  //LVNI_FOCUSED 
					ListView_DeleteItem(hWriteList,iSlected);
					if(ListView_GetItemCount(hWriteList)==0)
                            EnableWindow(GetDlgItem(hMainDlg, IDC_WRITEMESSAGE), FALSE);*/
						nsel = ListView_GetItemCount(hWriteList);
						for(msgcount = 0; msgcount<nsel; msgcount++)
						{
							if(ListView_GetCheckState(hWriteList,msgcount))
							{
								ListView_DeleteItem(hWriteList,msgcount);
								msgcount = -1;
								nsel--;
							}
						}	
					}
                    break;
                case IDC_WRITEMESSAGE:
                    Do_PassThruWrtMsg();
                    break;
                case IDC_TRANS_FILE:
                    {
					
                        PASSTHRU_MSG *ptrMsg;
                        OPENFILENAME     OpenFileName;    
                        // Structure for common dialog File/Open      
                        TCHAR            szFilter[]=__TEXT("*.bin"); 
                        TCHAR            szFile[MAX_PATH] = __TEXT("*.bin"); 
                        
                        // Initialize variables      
                        szFile[0] = __TEXT('\0'); 
                        OpenFileName.lStructSize           = sizeof(OPENFILENAME); 
                        OpenFileName.hwndOwner             = NULL; 
                        OpenFileName.hInstance             = NULL; 
                        OpenFileName.lpstrFilter           = szFilter; 
                        OpenFileName.lpstrCustomFilter     = (LPTSTR) NULL; 
                        OpenFileName.nMaxCustFilter        = 0L; 
                        OpenFileName.nFilterIndex          = 1L; 
                        OpenFileName.lpstrFile             = szFile; 
                        OpenFileName.nMaxFile              = sizeof(szFile); 
                        OpenFileName.lpstrFileTitle        = NULL; 
                        OpenFileName.nMaxFileTitle         = 0; 
                        OpenFileName.lpstrInitialDir       = NULL; 
                        OpenFileName.lpstrTitle            = __TEXT("File Browser"); 
                        OpenFileName.nFileOffset           = 0;
                        OpenFileName.nFileExtension        = 0;
                        OpenFileName.lpstrDefExt           = NULL;
                        // No default extension      
                        OpenFileName.lCustData             = 0;
                        OpenFileName.Flags = OFN_SHOWHELP      | 
                            OFN_PATHMUSTEXIST | 
                            OFN_FILEMUSTEXIST | 
                            OFN_HIDEREADONLY  | 
                            OFN_EXPLORER       | 
                            OFN_LONGNAMES; 
                        
                        // Create File Dialog Box 
						ComboBox_GetText(GetDlgItem(hMainDlg, IDC_COMBO_CHN),_text,20);
						for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
						{
							if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
							{
								for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
								{	
									if(protocolCount == iProtocolsConnected[nsel][0])
										break;
								}
								iCurProtocol = iProtocolsConnected[nsel][1];
								ulChannelID = iProtocolsConnected[nsel][2];
								break;
							}
						}
                        if (GetOpenFileName(&OpenFileName)) 
                        { 
                            FILE *pSaveFile = fopen( OpenFileName.lpstrFile,"r+b");
                            if(pSaveFile != NULL)
                            {
                                ptrMsg=new PASSTHRU_MSG;
                                unsigned long ulNumMsgs = 0;
                                while(fread(tempstr, sizeof( unsigned char), PASSTHRU_MSG_DATA_SIZE, pSaveFile))
                                {
                                    memcpy(ptrMsg->Data,tempstr,PASSTHRU_MSG_DATA_SIZE);
                                    ptrMsg->DataSize=PASSTHRU_MSG_DATA_SIZE;
                                    ptrMsg->ExtraDataIndex=0;
                                    ptrMsg->ProtocolID=iCurProtocol;
                                    if(bCanExtended)
                                        ptrMsg->TxFlags=0x100;
                                    else
                                        ptrMsg->TxFlags=0x00;
                                    ulNumMsgs = 1;
                                    error=PassThruWriteMsgs(ulChannelID, ptrMsg, &ulNumMsgs, 1000);
                                    if(error)
                                    {
                                        sprintf(tempbuf, "PassThruWriteMsgs returned: %s", ErrorList[error]);
                                        AddToScreen(hLogWindow,tempbuf);
                                        break;
                                    }
                                }
                                AddToScreen(hLogWindow,"Closing File: Transfer data Succesfull.");
                                fclose(pSaveFile);
								delete [] ptrMsg;
                            }
                            
                        }
                    }
                    break;
                case IDC_CFG_DEVICE:
                    char chDeviceName[J2534REGISTRY_MAX_STRING_LENGTH];
                    memset(chDeviceName,0,J2534REGISTRY_MAX_STRING_LENGTH);

					ComboBox_GetText(GetDlgItem(hMainDlg, IDC_COMBO_DEVICEDLL),chDeviceName,J2534REGISTRY_MAX_STRING_LENGTH);
                    if (!FindJ2534Entry(chDeviceName))
                    {
                        return -1;
                    }
                    nOpen = (int) ShellExecute(NULL, "open", chConfigApp, NULL, NULL, SW_SHOWNORMAL);
                    if((nOpen == ERROR_FILE_NOT_FOUND) ||(nOpen == ERROR_PATH_NOT_FOUND)) 
                    {
                        MessageBox(hDlg,"Configuration application is not found under the path","Error",MB_OK);
                    }
                    break;
                case IDC_PROG_VOLTAGE:
                    Do_PassThruSetProgramVoltage();
                    break;
                case IDC_ADD_CLEAR_LOG:
                    ListBox_ResetContent(hLogWindow);
                    break;
                case IDC_ADD_CLEARMSG_MONITOR:
                    ListView_DeleteAllItems(hRxWindow);
					SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, "");
					//+ Deleate the tempdata file.
					FileCreateTempStream();
                    break;
                case IDC_CLEARRX:
                    lSuccess = PassThruIoctl(ulChannelID, CLEAR_RX_BUFFER, (void *)NULL, (void *)NULL);
                    if(lSuccess == STATUS_NOERROR)
                        AddToScreen(hLogWindow,"Clear RX Buffer Successful");
                    break;
                case IDC_CLEARTX:
                    lSuccess = PassThruIoctl(ulChannelID, CLEAR_TX_BUFFER, (void *)NULL, (void *)NULL);
                    if(lSuccess == STATUS_NOERROR)
                        AddToScreen(hLogWindow,"Clear TX Buffer Successful");
                    break;
                case IDC_SAVE:
                    SaveListControlDataToFile();
                    break;
                case IDC_APPHELP:
                    break;
                case IDC_ABOUT:
                    sprintf(tempbuf, "Innova J2534  - SDK Version 1.0.1.2");
                    AddToScreen(hLogWindow,tempbuf);
                    break;
                default:
                    return FALSE;
                }
            }
        }
    default:
        return FALSE;
    }
}
void AddToScreen(HWND handle , char *msg)
{
    int height, numitems, numonscreen;
    RECT rt;
    if(strlen(msg)>iListboxCurrentWidth)
    {
        iListboxCurrentWidth=strlen(msg);
        ListBox_SetHorizontalExtent(handle, iListboxCurrentWidth*iListboxCharWidth);
    }
    ListBox_AddString(handle, msg);
    height=ListBox_GetItemHeight(handle, 0);
    GetClientRect(handle, &rt);
    numonscreen=(rt.bottom-rt.top)/height;
    numitems=ListBox_GetCount(handle);
    ListBox_SetTopIndex(handle, numitems-numonscreen);
}
void EnableAllControls(BOOL bEnable)
{
    hStatus = GetDlgItem(hMainDlg,IDC_CONNECT);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_DISCONNECT);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_CLOSE);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STARTPEORIDIC);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STOPEORIDIC);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STARTMSG_FILTER);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STOPMSG_FILTER);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_ADDTOLIST);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_WRITEMESSAGE);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_RMV_LIST);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_IOCTL);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_PROG_VOLTAGE);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_READVERSION);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_MSG);
    EnableWindow(hStatus,bEnable);
	hStatus = GetDlgItem(hMainDlg,IDC_COMBO_CHN);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_GETLAST_ERROR);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_CLEARRX);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_CLEARTX);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_TRANS_FILE);
    EnableWindow(hStatus,bEnable);
	/*jayasheela-added one more control for Tx flags */
	hStatus = GetDlgItem(hMainDlg,IDC_TXFLAGS);
    EnableWindow(hStatus,bEnable);
}
void EnableDeviceControls(BOOL bEnable)
{
    hStatus = GetDlgItem(hMainDlg,IDC_CONNECT);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_CLOSE);
    EnableWindow(hStatus,bEnable);
}
void EnableProtocolControls(BOOL bEnable)
{
    hStatus = GetDlgItem(hMainDlg,IDC_DISCONNECT);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STARTPEORIDIC);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STOPEORIDIC);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STARTMSG_FILTER);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_STOPMSG_FILTER);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_ADDTOLIST);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_WRITEMESSAGE);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_RMV_LIST);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_IOCTL);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_PROG_VOLTAGE);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_READVERSION);
    EnableWindow(hStatus,bEnable);
	hStatus = GetDlgItem(hMainDlg,IDC_COMBO_CHN);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_MSG);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_GETLAST_ERROR);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_CLEARRX);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_CLEARTX);
    EnableWindow(hStatus,bEnable);
    hStatus = GetDlgItem(hMainDlg,IDC_TRANS_FILE);
    EnableWindow(hStatus,bEnable);
	/*jayasheela-added one more control for Tx flags */
	hStatus = GetDlgItem(hMainDlg,IDC_TXFLAGS);
    EnableWindow(hStatus,bEnable);
}
void DO_PassThruOpen()
{
    int error =0;
    if(!LoadJ2534Library())
    {
        error = PassThruOpen(NULL, &ulDeviceID);
        sprintf(tempbuf, "PassThruOpen returned: %s", ErrorList[error]);
        AddToScreen(hLogWindow,tempbuf);
        if(error == 0) 
        {
            SetDlgItemText(hMainDlg,IDC_OPEN,"&Close Device");
			EnableDeviceControls(1);
            for(int i=0; i<10; i++)
            {
                sprintf((char *)tempbuf, "Msg%d", i);
                GetPrivateProfileString("Previous Msgs", tempbuf, NULL, (char*)lastmsgs[i], 16384, path);
                ComboBox_AddString(GetDlgItem(hMainDlg, IDC_MSG), (char*)lastmsgs[i]);
                sprintf((char*)tempbuf, "Msg%d", i); 
            }
            ComboBox_SetCurSel(GetDlgItem(hMainDlg, IDC_MSG),0);
        }
    }
    else
    {
        MessageBox(NULL, "Couldn't load J2534 functions Library. You may need (re)install the J2534 libraries.", "Error:", MB_OK);
    }
}
void DO_PassThruConnect()
{
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DLG_CONNECT), hMainDlg, (DLGPROC)ConnectProc);
    return;
}
void DO_PassThruDisConnect()
{
	DialogBox(hInst, MAKEINTRESOURCE(IDD_DLG_CONNECT), hMainDlg, (DLGPROC)ConnectProc);
	return;
}
void Do_PassThruPeoridicMsg()
{
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG_PER_MSG), hMainDlg, (DLGPROC)PeoridicProc);
}
void Do_PassThruFilterMsg()
{
    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG_FILTER_MSG), hMainDlg, (DLGPROC)FilterProc);
}
void Do_PassThruIOCTL()
{
    DialogBox(hInst, MAKEINTRESOURCE(IDD_IOCTL_DLG), hMainDlg, (DLGPROC)IOCTLProc);
}
void Do_PassThruClose()
{
    int nIndex =0; 
    nIndex = PassThruClose(ulDeviceID);
	if(nIndex == STATUS_NOERROR)
	{
		SetDlgItemText(hMainDlg,IDC_OPEN,"&Open Device");
		EnableAllControls(0);
		sprintf(tempbuf, "PassThruClose returned: %s", ErrorList[nIndex]);
		AddToScreen(hLogWindow,tempbuf);
	    ListView_DeleteAllItems(hWriteList);
		ulChannelID_Count = 0;
		ComboBox_ResetContent(GetDlgItem(hMainDlg, IDC_COMBO_CHN));
		ResetGUIStatus(TRUE, TRUE);
		ZeroMemory(iProtocolsConnected,60);
    }
}

void Do_PassThruReadVersion()
{
    char firmware[80], dll[80], api[80];
    int error;
    error=PassThruReadVersion(ulDeviceID, firmware, dll, api);
    if(error==STATUS_NOERROR)
    {
        sprintf(tempbuf, "Firmware Version: %s", firmware);
        AddToScreen(hLogWindow,tempbuf);
        sprintf(tempbuf, "DLL Version: %s", dll);
        AddToScreen(hLogWindow,tempbuf);
        sprintf(tempbuf, "API Version: %s", api);
        AddToScreen(hLogWindow,tempbuf);
    }
    sprintf(tempbuf, "PassThruReadVersion returned: %s", ErrorList[error]);
    AddToScreen(hLogWindow,tempbuf);
    return;
}
void Do_PassThruGetLastError()
{
    char errorstr[1024];
    int error;
    error=PassThruGetLastError(errorstr);
    if(error==STATUS_NOERROR)
    {
        sprintf(tempbuf, "Last Error: %s", errorstr);
        AddToScreen(hLogWindow,tempbuf);
    }
    sprintf(tempbuf, "PassThruGetLastError returned: %s", ErrorList[error]);
    AddToScreen(hLogWindow,tempbuf);
    return;
}

void Do_PassThruWrtMsg()
{
    PASSTHRU_MSG *ptrMsg;
    int  size, error,Txflags;
    unsigned long ulNumMsgs;
	unsigned long nsel = 0;
	char _text[25];
	char _text_protocol[25];
	unsigned long protocolCount;
	/***************/
	unsigned long msgtype,msgcount,msgsel;
	unsigned long j;
	unsigned long msgLocation[100];
	unsigned long iCurProtocol_loc,ulChannelID_loc;

	/***************************Construct ulMessageRecords ***************/
	for( j=0; j<MAX_PX_SIZE; j++)
		ulMessageRecords[j][0] = 0;
	msgtype = msgcount = msgsel = 0;
	nsel = ListView_GetItemCount(hWriteList);
	for(msgtype = 0;msgtype<MAX_PX_SIZE;msgtype++)
	{
		for(msgcount = 0,msgsel = 0; msgcount<nsel; msgcount++)
		{
			if(ListView_GetCheckState(hWriteList,msgcount))
			{
				//read protocol of message
				ListView_GetItemText(hWriteList,msgcount,1,_text,MAX_PATH);
				if(strcmp(_text,ProtocolList[msgtype][0]) == 0)
				{
					strcpy(_text_protocol,_text);
					msgLocation[msgsel++] = msgcount;
					ulMessageRecords[msgtype][0] = msgsel;
				}
			}
		}
		/*************Send messages***********/	
		ulNumMsgs = ulMessageRecords[msgtype][0];
		iCurProtocol_loc = ulChannelID_loc = 0;
		//Read message channel and protocol Id's
		for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
		{
			if(ulMessageRecords[msgtype][1] == iProtocolsConnected[protocolCount][1])
			{
				iCurProtocol_loc = iProtocolsConnected[protocolCount][1];
				ulChannelID_loc = iProtocolsConnected[protocolCount][2];
				break;
			}
		}
		if((ulNumMsgs != 0) && (ulChannelID_loc != 0) && (iCurProtocol_loc !=0))
		{
				ptrMsg=new PASSTHRU_MSG[ulNumMsgs];
				for( j=0; j<ulNumMsgs; j++)
				{
					//Read data from message
					ListView_GetItemText(hWriteList,msgLocation[j],3,(char*)tempstr,MAX_PATH);
					size=CheckAndConvertMsg(tempstr, tempmsg);
					memset(ptrMsg+j, 0, sizeof(PASSTHRU_MSG));
					memcpy(ptrMsg[j].Data, tempmsg, size);
					ptrMsg[j].DataSize=size;
					ptrMsg[j].ExtraDataIndex=size;
					ptrMsg[j].ProtocolID= iCurProtocol_loc;
					ptrMsg[j].Timestamp = GetCurrentTime();
					
					ListView_GetItemText(hWriteList,msgLocation[j],2,(char*)tempbuf,1024);
						sscanf(tempbuf, "%X", &Txflags);
					/*jayasheela CanIDboth bit check 11 bit*/
					if(hCanIdBoth)
					{
						ptrMsg[j].TxFlags=Txflags;
					}
					else
					{
						if(bCanExtended)
						{
							Txflags|=0x100;
							ptrMsg[j].TxFlags=Txflags;
						}
						else
						{
							Txflags&=~(0x100);
							ptrMsg[j].TxFlags=Txflags;
						}
					}
			}
			error=PassThruWriteMsgs(ulChannelID_loc, ptrMsg, &ulNumMsgs, 10000);
			sprintf(tempbuf, "( %s )PassThruWrtMsg returned: %s", _text_protocol,ErrorList[error]);
			AddToScreen(hLogWindow,tempbuf);
			delete [] ptrMsg;
			
		}
		
	}
	return;
}

void Do_PassThruSetProgramVoltage()
{
    DialogBox(hInst, MAKEINTRESOURCE(IDD_SETPROGRAMMINGVOLTAGE), hMainDlg, (DLGPROC)SetProgrammingVoltageProc);
    return;
}

//==========================================================================================
// Name        : LoadJ2534Library
// Author      : Chakravarthy
// Version     : 0.1
// Copyright   : None
// Description : Load J2534 Function Library
// Return      : Returns 0 if the library is loaded successfully and -1 if it 
//               Fails to load.
//==========================================================================================
int LoadJ2534Library()
{
    char chDeviceName[J2534REGISTRY_MAX_STRING_LENGTH];
    memset(chDeviceName,0,J2534REGISTRY_MAX_STRING_LENGTH);
//    ListBox_GetText(hDeviceLstHnd, ListBox_GetCurSel(hDeviceLstHnd),chDeviceName);
	ComboBox_GetText(GetDlgItem(hMainDlg, IDC_COMBO_DEVICEDLL),chDeviceName,J2534REGISTRY_MAX_STRING_LENGTH);

    
    if (!FindJ2534Entry(chDeviceName))
    {
        return -1;
    }
    
    hModule = LoadLibrary(chFuncLib);
    if (hModule == NULL)
    {
        DWORD errorCode = GetLastError();
		sprintf(tempbuf, "PassThruConnect returned: %s", errorCode);
        AddToScreen(hLogWindow,tempbuf);
	    return -1;
    }
    else
    {
        if (InitFunctionPointers() != 0)
            return -1;
    }
    return 0;
}
//==========================================================================================
// Name        : InitFunctionPointers
// Author      : Chakravarthy
// Version     : 0.1
// Copyright   : None
// Description : Initialize the function pointers from the DLL.
// Return      : Returns 0 if the function is loaded successfully and -1 if it 
//               Fails to load.
//==========================================================================================
int InitFunctionPointers()
{
    if ((PassThruOpen = (PTOPEN)GetProcAddress(hModule, "PassThruOpen")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruClose = (PTCLOSE)GetProcAddress(hModule, "PassThruClose")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruConnect = (PTCONNECT)GetProcAddress(hModule, "PassThruConnect")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruDisconnect = (PTDISCONNECT)GetProcAddress(hModule, 
                                                            "PassThruDisconnect")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruReadMsgs = (PTREADMSGS)GetProcAddress(hModule, "PassThruReadMsgs")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruWriteMsgs = (PTWRITEMSGS)GetProcAddress(hModule, "PassThruWriteMsgs")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruStartPeriodicMsg = (PTSTARTPERIODICMSG)GetProcAddress(hModule,
                                                "PassThruStartPeriodicMsg")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruStopPeriodicMsg = (PTSTOPPERIODICMSG)GetProcAddress(hModule,
                                        "PassThruStopPeriodicMsg")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruStartMsgFilter = (PTSTARTMSGFILTER)GetProcAddress(hModule,
                                        "PassThruStartMsgFilter")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruStopMsgFilter = (PTSTOPMSGFILTER)GetProcAddress(hModule, 
                                "PassThruStopMsgFilter")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruSetProgrammingVoltage = (PTSETPROGRAMMINGVOLTAGE)GetProcAddress(hModule, 
                                         "PassThruSetProgrammingVoltage")) == NULL)
    {
        return(FALSE);
    }
    if ((PassThruReadVersion = (PTREADVERSION)GetProcAddress(hModule, "PassThruReadVersion"))
                                                                        == NULL)
    {
        return(FALSE);
    }
    if ((PassThruGetLastError = (PTGETLASTERROR)GetProcAddress(hModule, "PassThruGetLastError"))
                                                                                == NULL)
    {
        return(FALSE);
    }
    if ((PassThruIoctl = (PTIOCTL)GetProcAddress(hModule, "PassThruIoctl")) == NULL)
    {
        return(FALSE);
    }
    return 0;
}
//==========================================================================================
// Name        : EraseFunctionPointers
// Author      : Chakravarthy
// Version     : 0.1
// Copyright   : None
// Description : DeInitialize the function pointers to NULL.
// Return      : NONE
//==========================================================================================
void EraseFunctionPointers()
{
    FreeLibrary(hModule);
    hModule = NULL;
    PassThruOpen = NULL;
    PassThruClose = NULL;
    PassThruConnect = NULL;
    PassThruDisconnect = NULL;
    PassThruReadMsgs = NULL;
    PassThruWriteMsgs = NULL;
    PassThruStartPeriodicMsg = NULL;
    PassThruStopPeriodicMsg = NULL;
    PassThruStartPeriodicMsg = NULL;
    PassThruStopMsgFilter = NULL;
    PassThruSetProgrammingVoltage = NULL;
    PassThruReadVersion = NULL;
    PassThruGetLastError = NULL;
    PassThruIoctl = NULL;
}

DWORD WINAPI ReadMessages (LPVOID lpVoid)
{
    PASSTHRU_MSG *ptrMsg;
	char recvBuf[PASSTHRU_MSG_DATA_SIZE];
	char dataBuf[PASSTHRU_MSG_DATA_SIZE];
    unsigned long ulNum;
    unsigned long ulTimeout;
    int error;
    int nItemCount;
	int dataBufsize = 0;
    ptrMsg=(PASSTHRU_MSG*) new PASSTHRU_MSG;
	unsigned long ulChannelID_Loc;
    
    LV_ITEM lvitem;
    lvitem.iSubItem = 0;
    lvitem.pszText = recvBuf;  
    lvitem.mask = LVIF_IMAGE | LVIF_TEXT;
    lvitem.state =  LVIS_STATEIMAGEMASK ;
    lvitem.stateMask = LVIS_STATEIMAGEMASK ;
    lvitem.iImage = 0;
    
    while(true)
    {
        
            ulNum = 1;
            ulTimeout = 10;
			
		for(unsigned long iProtocol_Count = 0;iProtocol_Count < MAX_PX_SIZE;iProtocol_Count++)
		{
			if (WaitForSingleObject(hExitThread, 0)==WAIT_OBJECT_0)
				 ExitThread(0);
			if((iProtocolsConnected[iProtocol_Count][2] == 0 ) || (iProtocolsConnected[iProtocol_Count][3] == READ_OFF))
				 continue;
			ulChannelID_Loc = iProtocolsConnected[iProtocol_Count][2];
			error=PassThruReadMsgs(ulChannelID_Loc, ptrMsg, &ulNum, ulTimeout);
            if(error == 0)
            {
                nItemCount = ListView_GetItemCount(GetDlgItem(hMainDlg,IDC_LIST_RX));
                lvitem.iItem = nItemCount;
                
                /*Serial Number Col 0*/
                sprintf(recvBuf,"%d",nItemCount+1);
                ListView_InsertItem(GetDlgItem(hMainDlg,IDC_LIST_RX),&lvitem);
            
                /*Update Timestamp Col 1*/
                sprintf(recvBuf,"%u",ptrMsg->Timestamp);
                ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,1,recvBuf);

				memset(recvBuf,0,2);
				sprintf(recvBuf,"%02X",ptrMsg->DataSize);
				ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
				ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);    
				ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
				memset(dataBuf,0,2);
                /*Update Potocol Col 2*/
                if(ptrMsg->ProtocolID ==2 || ptrMsg->ProtocolID == 1)
                {
                    if(ptrMsg->ProtocolID ==1)
                        ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"J1850VPWM");
                    
                    if(ptrMsg->ProtocolID ==2)
                        ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"J1850PWM");
					
					if(ptrMsg->DataSize!=0)
                    {

						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize - 3);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
						/*update Header+data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
							sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex -3);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}
				}

                else if(ptrMsg->ProtocolID == 3)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"ISO9141");

                    /*Update Header Col 4*/
					/* no header for 9141 */
					if(ptrMsg->DataSize!=0)
                    {

						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                
						/*update Data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
							sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}

					}
				}
                else if(ptrMsg->ProtocolID == 4)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"ISO14230");
					/*jayasheela- added if(ptrMsg->DataSize!=0) to 
					handle the read ack's without data */
					if(ptrMsg->DataSize!=0)
                    {
						/*Jayasheela-removed some code not required to extract header */ 
                
						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize );
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                
							/*Update Header+data Col 4*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
                	}
				}
                                
                else if (ptrMsg->ProtocolID == 5)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"CAN");
                    
                    /*Update DataSize Col 5*/
					/* Jayasheela-replaced ptrMsg->DataSize-4 with ptrMsg->DataSize below
					   bcz: not required */
					if(ptrMsg->DataSize!=0)
                    {

						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
						/*update Header+data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						/* Jayasheela-replaced ptrMsg->ExtraDataIndex-4 with ptrMsg->ExtraDataIndex below
						   bcz: not required */
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex );
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}
                }
                else if (ptrMsg->ProtocolID == 6)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"IS015765");
					if(ptrMsg->DataSize!=0)
                    {

						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
						/*update Header+data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                                       
						sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex );
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
					}
                }
                else if (ptrMsg->ProtocolID == 7)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SCI_A_ENGINE");
					if(ptrMsg->DataSize!=0)
                    {

						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                
						/*update Data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}
                }
                else if (ptrMsg->ProtocolID == 8)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SCI_A_TRANS");

					if(ptrMsg->DataSize!=0)
                    {

						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                
						/*update Data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}

                }
                else if (ptrMsg->ProtocolID == 9)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SCI_B_ENGINE");
					
					if(ptrMsg->DataSize!=0)
                    {

						/*Update Header Col 4*/
                
						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                
						/*update Data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}
                }
                else if (ptrMsg->ProtocolID == 10)
                {
                    
					ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SCI_B_TRANS");

					if(ptrMsg->DataSize!=0)
                    {

						/*Update DataSize Col 5*/
						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                
						/*update Data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}

                }
                else if (ptrMsg->ProtocolID == 11)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SWCAN_ISO15765_PS");
                }
                else if (ptrMsg->ProtocolID == 12)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SWCAN_CAN_PS");
                }
                else if (ptrMsg->ProtocolID == 13)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"CCD");
                }
				else if (ptrMsg->ProtocolID == 0x8008)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SWCAN");
                    
                    /*Update DataSize Col 5*/
					/* Jayasheela-replaced ptrMsg->DataSize-4 with ptrMsg->DataSize below
					   bcz: not required */
					if(ptrMsg->DataSize!=0)
                    {

						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
						/*update Header+data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						/* Jayasheela-replaced ptrMsg->ExtraDataIndex-4 with ptrMsg->ExtraDataIndex below
						   bcz: not required */
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex );
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}
                }
				else if (ptrMsg->ProtocolID == 0x8007)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"SWCAN_ISO15765_PS");
                    
                    /*Update DataSize Col 5*/
					/* Jayasheela-replaced ptrMsg->DataSize-4 with ptrMsg->DataSize below
					   bcz: not required */
					if(ptrMsg->DataSize!=0)
                    {

						sprintf(recvBuf,"%02X",ptrMsg->DataSize);
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
						/*update Header+data Col 6*/
						memset(recvBuf,0,ptrMsg->DataSize);
						memset(dataBuf,0,ptrMsg->DataSize);
						for(unsigned long j=0; j<ptrMsg->DataSize; j++)
						{
							sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    		sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
						}
						dataBufsize = ptrMsg->DataSize;
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
						/*Update ExtradataIndex Col 7*/
						/* Jayasheela-replaced ptrMsg->ExtraDataIndex-4 with ptrMsg->ExtraDataIndex below
						   bcz: not required */
						if(ptrMsg->ExtraDataIndex!=0)
						{
							sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex );
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
						}
					}
                }
				else if (ptrMsg->ProtocolID == 0x94)
					{
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"IS015765_CH1");
						if(ptrMsg->DataSize!=0)
						{

							sprintf(recvBuf,"%02X",ptrMsg->DataSize);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
							/*update Header+data Col 6*/
							memset(recvBuf,0,ptrMsg->DataSize);
							memset(dataBuf,0,ptrMsg->DataSize);
							for(unsigned long j=0; j<ptrMsg->DataSize; j++)
							{
								sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    			sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
							}
							dataBufsize = ptrMsg->DataSize;
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
                   
							if(ptrMsg->ExtraDataIndex!=0)
							{
								sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex );
								ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
							}
						}
					}
					else if (ptrMsg->ProtocolID == 0x90)
					{
						ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,2,"CAN_CH1");
                    
						/*Update DataSize Col 5*/
						/* Jayasheela-replaced ptrMsg->DataSize-4 with ptrMsg->DataSize below
						   bcz: not required */
						if(ptrMsg->DataSize!=0)
						{

							sprintf(recvBuf,"%02X",ptrMsg->DataSize);
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,7,recvBuf);
                    
							/*update Header+data Col 6*/
							memset(recvBuf,0,ptrMsg->DataSize);
							memset(dataBuf,0,ptrMsg->DataSize);
							for(unsigned long j=0; j<ptrMsg->DataSize; j++)
							{
								sprintf(recvBuf+strlen(recvBuf), " %02X", ptrMsg->Data[j]);
                    			sprintf(dataBuf+strlen(dataBuf), " %02X", ptrMsg->Data[j]);
							}
							dataBufsize = ptrMsg->DataSize;
							ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,8,recvBuf);
                    
							/*Update ExtradataIndex Col 7*/
							/* Jayasheela-replaced ptrMsg->ExtraDataIndex-4 with ptrMsg->ExtraDataIndex below
							   bcz: not required */
							if(ptrMsg->ExtraDataIndex!=0)
							{
								sprintf(recvBuf,"%02X",ptrMsg->ExtraDataIndex );
								ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,4,recvBuf);
							}
						}
					}
					

                /*Update Tx/ Rx Col 3*/
                if(ptrMsg->RxStatus & TX_MSG_TYPE)
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,3,"Tx");
                }
                else
                {
                    ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,3,"Rx");
                }

                /*Update TxFlags col 9*/
                sprintf(recvBuf,"%02X",ptrMsg->TxFlags);
                ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,6,recvBuf);
                                
                /*update rx status col 8*/
				/*jayasheela-removed the code need to display RX status as it is */
                sprintf(recvBuf,"%02X",ptrMsg->RxStatus);
                ListView_SetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nItemCount,5,recvBuf);
				if(BST_CHECKED == IsDlgButtonChecked(hMainDlg,IDC_CHECK_CURRENT))
					SetDlgItemText(hMainDlg, IDC_EDIT_RXDATA, dataBuf);
				/*Copy received data to temp file ..Nikhilesh*/
				FileCopyDatatoStream(dataBufsize,dataBuf,nItemCount);

            }
        }
    }
    ptrMsg = NULL;
    return 0;
}
void sortBuffer(int* connections, unsigned long ActiveConnections)
{
	unsigned long i,j;
	unsigned long bound = ActiveConnections-1;
	unsigned long last_swap;
	if(ActiveConnections == 0)
		return;
	while (bound) 
	{
		last_swap = 0;
		for(i=0;i<bound;i++)
		{
			if(connections[i] < connections[i+1])
			{
				//////////Swapig higher value First////////////////
				j = connections[i];
				connections[i] = connections[i+1];
				connections[i+1] = j;
				last_swap = i;
			}

		}
		bound=last_swap; 
	}

}
void UpdateConnectDisconnectList(HWND hDlg,BOOL button)
{
	unsigned long protocolCount;
	int nsel = 0;
    char _text[100];
	unsigned long ActiveConnections = 0;
//	int connections[5] = {0};
	int connections[5] = {'X','X','X','X','X'};
	ListBox_ResetContent(GetDlgItem(hDlg, IDC_LIST_CONNECT));
	ListBox_ResetContent(GetDlgItem(hDlg, IDC_LIST_DISCONNECT));
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
	{
		if(iProtocolsConnected[protocolCount][1] != 0)
		{
			ListBox_AddString(GetDlgItem(hDlg, IDC_LIST_DISCONNECT),ProtocolList[iProtocolsConnected[protocolCount][0]][0]);
		}
		ListBox_AddString(GetDlgItem(hDlg, IDC_LIST_CONNECT),ProtocolList[protocolCount][0]);
	}
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
	{
		if(iProtocolsConnected[protocolCount][1] != 0)
		{
			ActiveConnections++;
			nsel = iProtocolsConnected[protocolCount][0];
			connections[protocolCount] = nsel;
		}
	}
	sortBuffer(connections,ActiveConnections);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
	{
		if(connections[protocolCount] == 'X')
			continue;
		ListBox_DeleteString( GetDlgItem(hDlg, IDC_LIST_CONNECT),connections[protocolCount]);
	}

    SetDlgItemText(hDlg, IDC_FLAGS, "0x00000000");
    ListBox_SetCurSel(GetDlgItem(hDlg, IDC_LIST_CONNECT),0);
	nsel = ListBox_GetCurSel(GetDlgItem(hDlg, IDC_LIST_CONNECT));
	ListBox_GetText(GetDlgItem(hDlg, IDC_LIST_CONNECT), nsel,_text);
	ComboBox_ResetContent(GetDlgItem(hDlg, IDC_COMBO_BAUD));

	if(strcmp(_text,"ISO14230") == 0)
	{
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"4800");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"9600");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"9615");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"9800");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"10400");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"10870");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"11905");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"12500");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"13158");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"13889");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"14706");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"15625");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"19200");
		ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_BAUD),0);
	}
	else
	{
		//Added support for 10,20,50,100,125,250,500,800,1000 kbps
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"10000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"20000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"50000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"100000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"125000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"250000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"500000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"800000");
		ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"1000000");
		ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_BAUD),6);

		//ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"500000");
		//ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"250000");
		//ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"125000");		
		//ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_BAUD),5);
	}
	if(button)
	{
		hStatus = GetDlgItem(hDlg,IDC_COMBO_BAUD);
		EnableWindow(GetDlgItem(hDlg,IDC_COMBO_BAUD),TRUE);
		hStatus = GetDlgItem(hDlg,IDC_FLAGS);
		EnableWindow(GetDlgItem(hDlg,IDC_FLAGS),TRUE);
		SetDlgItemText(hDlg,IDCONNECT,"&Connect");
		ListBox_SetCurSel(GetDlgItem(hDlg, IDC_LIST_DISCONNECT),-1);
	}

	return;
}
LRESULT CALLBACK ConnectProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND hProtList, hProtDisconnectList, hControl,hChannelCtrl;
    RECT rt, rt2;
	unsigned long protocolCount;
	unsigned int nsel = 0;
    int nProtocol =1, flags = 0, error;
	int nProtocolStringVal = 1;
    unsigned long nBaudRate =0;
    char _text[100];
	char _text1[100];
	int iProtocol_Count = 0;
	int sel = 0;
//	int connections[5] = {0};
	unsigned long msgcount, msgsel;
	int msgLocation[100];
	unsigned long ulMessageRecords = 0;
	char profileBuffer[100];
	char lastprotocolmsgs[10][16384];
	char *token;





	hProtList=GetDlgItem(hDlg, IDC_LIST_CONNECT);
	hProtDisconnectList = GetDlgItem(hDlg, IDC_LIST_DISCONNECT);



    switch (message)
    {
        case WM_INITDIALOG:
            
            GetWindowRect(GetDesktopWindow(), &rt);
            GetWindowRect(hDlg, &rt2);
            SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
                        (rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, SWP_NOZORDER | SWP_NOSIZE);

			UpdateConnectDisconnectList(hDlg, FALSE);
            return TRUE;
        
        case WM_COMMAND:
            {       

				if(HIWORD(wParam)==LBN_SELCHANGE && (HWND)lParam == GetDlgItem(hDlg, IDC_LIST_DISCONNECT))
                {  
					 hStatus = GetDlgItem(hDlg,IDC_COMBO_BAUD);
					 EnableWindow(hStatus,FALSE);
					 hStatus = GetDlgItem(hDlg,IDC_FLAGS);
					 EnableWindow(hStatus,FALSE);
					 SetDlgItemText(hDlg,IDCONNECT,"&Disconnect");
					 ListBox_SetCurSel(hProtList,-1);
				}
                if(HIWORD(wParam)==LBN_SELCHANGE && (HWND)lParam == GetDlgItem(hDlg, IDC_LIST_CONNECT))
                {   

					 hStatus = GetDlgItem(hDlg,IDC_COMBO_BAUD);
					 EnableWindow(hStatus,TRUE);
					 hStatus = GetDlgItem(hDlg,IDC_FLAGS);
					 EnableWindow(hStatus,TRUE);
					 SetDlgItemText(hDlg,IDCONNECT,"&Connect");
					 ListBox_SetCurSel(hProtDisconnectList,-1);

						ComboBox_ResetContent(GetDlgItem(hDlg, IDC_COMBO_BAUD));
						nsel = ListBox_GetCurSel(hProtList);
						ListBox_GetText(hProtList, nsel,_text);
						if(strcmp(_text,"ISO14230") == 0)
						{
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"4800");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"9600");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"9615");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"9800");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"10400");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"10870");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"11905");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"12500");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"13158");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"13889");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"14706");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"15625");
                            ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"19200");
                            ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_BAUD),0);
                        }
						else 
                        {
							//Added support for 10,20,50,100,125,250,500,800,1000 kbps
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"10000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"20000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"50000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"100000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"125000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"250000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"500000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"800000");
							ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"1000000");
							ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_BAUD),6);
							
							//ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"500000");
							//ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"250000");
							//ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_BAUD),"125000");		
							//ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_BAUD),5);
                        }
                        printf("%02X",ListBox_GetCurSel(hProtList));
	               }
                else
                {
                    switch (LOWORD(wParam))
                    {
                    case IDCANCEL:
                        EndDialog(hDlg, LOWORD(wParam));
                        return TRUE;
                        break;

                    case IDCONNECT:

						GetDlgItemText(hDlg,IDCONNECT,_text,14);

						if( strcmp(_text,"&Connect") == 0)
						{
                        bCanExtended=FALSE;
						hCanIdBoth=FALSE;
                        hControl=GetDlgItem(hDlg, IDC_COMBO_BAUD);
						/*jayasheela-added editable combo box for baudrate selection */
                       //nsel = ComboBox_GetCurSel(hControl);
                       //ComboBox_GetLBText(hControl,nsel,_text);
						ComboBox_GetText(hControl,_text,8);
                        sscanf((char *)_text,"%ul",&nBaudRate);                     
							/**********************************/
							nsel = ListBox_GetCurSel(hProtList);
							ListBox_GetText(hProtList, nsel,_text);
							for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
							{
								if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
								{
									nProtocolStringVal = protocolCount;
									nProtocol = atoi(ProtocolList[protocolCount][1]);
									break;
								}
							}
							/****************************************/
							if((ListBox_GetCurSel(hProtList))==-1)
							{
								MessageBox(hDlg, "You must first select a protocol", "Error:", MB_OK);
							}
							else
							{
								
								if(GetDlgItemText(hDlg, IDC_FLAGS, (char*)tempbuf, 1024))
									sscanf(tempbuf, "%X", &flags);
                            
								if(nProtocol==CAN || nProtocol==CAN_CH1 || nProtocol==ISO15765 || nProtocol==ISO15765_CH1 ||nProtocol== SWCAN_ISO15765_PS || 
									nProtocol==SWCAN_CAN_PS) 
								{
								if((flags >> 11) & 0x01)
									hCanIdBoth=TRUE;
								else
								{
									hCanIdBoth=FALSE;
									if((flags >> 8) & 0x01)
									bCanExtended=TRUE;
									else
									bCanExtended=FALSE;
								}								
                                if(nProtocol==SWCAN_CAN_PS)
                                    nProtocol = 0x00008008; // Single Wire CAN as per J2534-2 Spec 
									//nProtocol = 0x000088;
                                if(nProtocol==SWCAN_ISO15765_PS)
                                    nProtocol = 0x00008007; // Single Wire CAN as per J2534-2 Spec 
                            }
								if(nProtocol==CAN_CH1)
									nProtocol = CAN_CH1_PROTOCOL_ID;
								if(nProtocol==ISO15765_CH1)
									nProtocol = ISO15765_CH1_PROTOCOL_ID;
                        
                            error=PassThruConnect(ulDeviceID, nProtocol, flags, nBaudRate, &ulChannelID);
                            sprintf(tempbuf, "PassThruConnect returned: %s", ErrorList[error]);
                            AddToScreen(hLogWindow,tempbuf);
                            if(error == STATUS_NOERROR)
                            {
								EnableProtocolControls(1);
                                iCurProtocol=nProtocol;
									for (iProtocol_Count = 0; iProtocol_Count < MAX_PX_SIZE; iProtocol_Count++)
									{
										if (iProtocolsConnected[iProtocol_Count][1] == 0)
										{
											iProtocolsConnected[iProtocol_Count][0] = nProtocolStringVal;
											iProtocolsConnected[iProtocol_Count][1] = nProtocol;
											iProtocolsConnected[iProtocol_Count][2] = ulChannelID;
											iProtocolsConnected[iProtocol_Count][3] = READ_ON;
											break;
										}
									}
									//Fill data structare foe channels
									ComboBox_AddString(GetDlgItem(hMainDlg, IDC_COMBO_CHN),ProtocolList[nProtocolStringVal][0]);
									ComboBox_SetCurSel(GetDlgItem(hMainDlg, IDC_COMBO_CHN),0);
									ResetEvent(hExitThread);
									DWORD dwID = 0;
									ulChannelID_Count++;
									if(ulChannelID_Count != ulChannelID)
										MessageBox(NULL,"Invalid Channel set","Test Trigger",NULL);
									if(ulChannelID_Count == 1)
										 hReadThread = ::CreateThread(NULL, 0, ReadMessages, NULL, 0, &dwID);
									/******************Put approprate message in list**/
									ListBox_GetText(hProtList, ListBox_GetCurSel(hProtList),_text);
									sprintf((char*)profileBuffer,"%s", _text);   
									strcat(profileBuffer," - Previous Msgs");

									for(int i=0; i<10; i++)
									{
										sprintf((char *)tempbuf, "Msg%d", i);
										GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)lastprotocolmsgs[i], 16384, path);
										token = strtok( lastprotocolmsgs[i], "-" );
										if(token != NULL)
										{
											LV_ITEM lvitem;
											lvitem.iSubItem = 0;
											lvitem.pszText = "";  
											lvitem.mask = LVIF_IMAGE | LVIF_TEXT;
											lvitem.state =  LVIS_STATEIMAGEMASK ;
											lvitem.stateMask = LVIS_STATEIMAGEMASK ;
											lvitem.iImage = 0;	
											int nItemCount = ListView_GetItemCount(hWriteList);
											lvitem.iItem = nItemCount;
											ListView_InsertItem(hWriteList,&lvitem);
											ListView_SetItemText(hWriteList,nItemCount,1,_text);
											ListView_SetItemText(hWriteList,nItemCount,3,token);
											token = strtok( NULL, "-" );
											ListView_SetItemText(hWriteList,nItemCount,2,token);
											sprintf((char*)tempbuf, "Msg%d", i); 
										}
									
									}
                
								}
							if(error == ERR_INVALID_PROTOCOL_ID)
                            {
								nsel = ListBox_GetCurSel(hProtList);
								ListBox_GetText(hProtList, nsel,_text);
								if( strcmp(_text,"ISO15765") == 0)
									MessageBox(NULL,"Channel is Already Engaged with CAN Protocol","Information", MB_ICONASTERISK | MB_OK);
								if( strcmp(_text,"ISO15765_CH1") == 0)
									MessageBox(NULL,"Channel is Already Engaged with CAN_CH1 Protocol","Information", MB_ICONASTERISK | MB_OK);
								if( strcmp(_text,"CAN") == 0)
									MessageBox(NULL,"Channel is Already Engaged with ISO15765 Protocol","Information", MB_ICONASTERISK | MB_OK);
								if( strcmp(_text,"CAN_CH1") == 0)
									MessageBox(NULL,"Channel is Already Engaged with ISO15765_CH1 Protocol","Information", MB_ICONASTERISK | MB_OK);
							}
							
						}
							
//						EndDialog(hDlg, LOWORD(wParam));
				/**************************************************************/
			
				UpdateConnectDisconnectList(hDlg, FALSE);

				/*****************************************************************/
               }
				else
					if( strcmp(_text,"&Disconnect") == 0)
					{
						
						//Test Nikhil to select channel
						nsel = ListBox_GetCurSel(hProtDisconnectList);
						if(nsel >= 4)
							return FALSE;
						ListBox_GetText(hProtDisconnectList, nsel,_text);
						for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
							{
								if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
								{
									for(sel = 0;sel<MAX_PX_SIZE;sel++)
									{	
										if(protocolCount == iProtocolsConnected[sel][0] && iProtocolsConnected[sel][1] != 0)
											break;
									}
									iCurProtocol = iProtocolsConnected[sel][1];
									ulChannelID = iProtocolsConnected[sel][2];
									iProtocolsConnected[sel][3] = READ_OFF;
									break;
								}
							}
						Sleep(100);
						/* Another way to get Channel and Protocol ids but unstable..Nikhilesh
						nsel = ListBox_GetCurSel(hProtDisconnectList);
						ulChannelID = nsel;
						ulChannelID++;*/
						error=PassThruDisconnect(ulChannelID);
						if(error == STATUS_NOERROR)
						{
							ListBox_DeleteString( hProtDisconnectList,nsel);
							ComboBox_DeleteString( GetDlgItem(hMainDlg, IDC_COMBO_CHN),nsel);
							ComboBox_SetCurSel(GetDlgItem(hMainDlg, IDC_COMBO_CHN),0);

							//Delete corresponding msgs from write message list
							/**************************************************************/
							msgcount = msgsel = 0;
							ulMessageRecords = 0;
							nsel = ListView_GetItemCount(hWriteList);
							for(msgcount = 0,msgsel = 0; msgcount<nsel; msgcount++)
							{
									//read protocol from message
									ListView_GetItemText(hWriteList,msgcount,1,_text1,MAX_PATH);
									if(strcmp(_text1,_text) == 0)
									{
										msgLocation[msgsel++] = msgcount;
										ulMessageRecords = msgsel;
										
									}
							}
							
							sortBuffer(msgLocation,ulMessageRecords);
							for(unsigned long j = 0;j<ulMessageRecords;j++)
									ListView_DeleteItem(hWriteList,msgLocation[j]);
							/*Clear the all Periodic and message filter states. here i ahve taken the 
							variable for error as index, since i dont want to create one more variable
							for index.*/
							ResetGUIStatus(TRUE,TRUE);
							/***************************************************************/

							iProtocolsConnected[sel][0] = 0;
							iProtocolsConnected[sel][1] = 0;
							iProtocolsConnected[sel][2] = 0;
							ulChannelID_Count--;
						}
						iProtocolsConnected[sel][3] = READ_ON;
						sprintf(tempbuf, "PassThruDisConnect returned: %s", ErrorList[error]);
						AddToScreen(hLogWindow,tempbuf);
					
						/*jayasheela-commented to handle the exceptions */
						//CloseHandle(hExitThread);	
						if(ulChannelID_Count < 1)
						{
							EnableProtocolControls(0);
							SetEvent(hExitThread);
							TerminateThread(hReadThread,0);
						}
						//CloseHandle(hReadThread);

					

					
//						EndDialog(hDlg, LOWORD(wParam));
						/******************************************************/
						UpdateConnectDisconnectList(hDlg, TRUE);
						/**************************************************/
					}
                        break;
                    }
                }
				
                break;
        default:
            return FALSE;
            }
    }
    return TRUE;
}

LRESULT CALLBACK PeoridicProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT rt, rt2;
    char _text[100];
	int protocolCount = 0;
	int nsel = 0;
	char profileBuffer[100];
    switch (message)
    {
    case WM_INITDIALOG:
        {
            hPxDlg = hDlg;
            GetWindowRect(GetDesktopWindow(), &rt);
            GetWindowRect(hDlg, &rt2);
            SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
                (rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, 
                    SWP_NOZORDER | SWP_NOSIZE);
			for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)//nikhiltest_added
			{
				if(iProtocolsConnected[protocolCount][1] != 0)
					ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_PPC),ProtocolList[iProtocolsConnected[protocolCount][0]][0]);
			}
			ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC),0);
			nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC));
					iCurProtocol = iProtocolsConnected[nsel][1];
					sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
					strcat(profileBuffer," - Periodic Msgs");

			ReadPeoridicStatus(profileBuffer,hDlg);
			
            return TRUE;
        }
        break;
    case WM_COMMAND:
        {
			if(HIWORD(wParam)==CBN_SETFOCUS && (HWND)lParam == GetDlgItem(hDlg, IDC_COMBO_PPC))
            {
					nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC));
					iCurProtocol = iProtocolsConnected[nsel][1];
					sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
					strcat(profileBuffer," - Periodic Msgs");
					WritePeoridicStatus(profileBuffer,hDlg);
                
			}
			if((HIWORD(wParam)==CBN_SELCHANGE)  && ((HWND)lParam == GetDlgItem(hDlg, IDC_COMBO_PPC)))
            {
				    nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC));
					iCurProtocol = iProtocolsConnected[nsel][1];
					sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
					strcat(profileBuffer," - Periodic Msgs");
					ReadPeoridicStatus(profileBuffer,hDlg);
         
			}

            switch (LOWORD(wParam))
            {
            case IDC_CLEARPX:
                ClearAllPXMessages(hDlg);
                break;
            case IDCANCEL:
				nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC));
				iCurProtocol = iProtocolsConnected[nsel][1];
				sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
				strcat(profileBuffer," - Periodic Msgs");   
				WritePeoridicStatus(profileBuffer,hDlg);
                EndDialog(hDlg, LOWORD(wParam));
                return TRUE;
            case IDC_BUTTON_TP1:
                GetDlgItemText(hDlg,IDC_BUTTON_TP1,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P1,IDC_EDIT_TX1,IDC_EDIT_TI1,IDC_BUTTON_TP1,IDC_COMBO_PPC,&iPeriodId);
					/*jayasheela-store periodic id */
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC1,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					/*jayasheela-get filter id */
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC1,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P1,IDC_EDIT_TX1,IDC_EDIT_TI1,IDC_BUTTON_TP1,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC1,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP2:
                GetDlgItemText(hDlg,IDC_BUTTON_TP2,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P2,IDC_EDIT_TX2,IDC_EDIT_TI2,IDC_BUTTON_TP2,IDC_COMBO_PPC, &iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC2,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					/*jayasheela-get filter id */
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC2,NULL,1);
					StopPeriodicMessage(hDlg,IDC_EDIT_P2,IDC_EDIT_TX2,IDC_EDIT_TI2,IDC_BUTTON_TP2,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC2,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP3:
                GetDlgItemText(hDlg,IDC_BUTTON_TP3,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P3,IDC_EDIT_TX3,IDC_EDIT_TI3,IDC_BUTTON_TP3,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC3,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC3,NULL,1);
					StopPeriodicMessage(hDlg,IDC_EDIT_P3,IDC_EDIT_TX3,IDC_EDIT_TI3,IDC_BUTTON_TP3,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC3,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP4:
                GetDlgItemText(hDlg,IDC_BUTTON_TP4,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P4,IDC_EDIT_TX4,IDC_EDIT_TI4,IDC_BUTTON_TP4,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC4,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC4,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P4,IDC_EDIT_TX4,IDC_EDIT_TI4,IDC_BUTTON_TP4,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC4,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP5:
                GetDlgItemText(hDlg,IDC_BUTTON_TP5,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P5,IDC_EDIT_TX5,IDC_EDIT_TI5,IDC_BUTTON_TP5,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC5,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC5,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P5,IDC_EDIT_TX5,IDC_EDIT_TI5,IDC_BUTTON_TP5,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC5,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP6:
                GetDlgItemText(hDlg,IDC_BUTTON_TP6,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P6,IDC_EDIT_TX6,IDC_EDIT_TI6,IDC_BUTTON_TP6,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC6,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC6,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P6,IDC_EDIT_TX6,IDC_EDIT_TI6,IDC_BUTTON_TP6,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC6,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP7:
                GetDlgItemText(hDlg,IDC_BUTTON_TP7,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P7,IDC_EDIT_TX7,IDC_EDIT_TI7,IDC_BUTTON_TP7,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC7,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC7,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P7,IDC_EDIT_TX7,IDC_EDIT_TI7,IDC_BUTTON_TP7,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC7,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP8:
                GetDlgItemText(hDlg,IDC_BUTTON_TP8,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P8,IDC_EDIT_TX8,IDC_EDIT_TI8,IDC_BUTTON_TP8,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC8,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC8,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P8,IDC_EDIT_TX8,IDC_EDIT_TI8,IDC_BUTTON_TP8,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC8,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP9:
                GetDlgItemText(hDlg,IDC_BUTTON_TP9,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P9,IDC_EDIT_TX9,IDC_EDIT_TI9,IDC_BUTTON_TP9,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC9,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC9,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P9,IDC_EDIT_TX9,IDC_EDIT_TI9,IDC_BUTTON_TP9,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC9,0,0);
				}
                return TRUE;
                break;
            case IDC_BUTTON_TP10:
                GetDlgItemText(hDlg,IDC_BUTTON_TP10,_text,10);
                if(strcmp(_text ,"&Start") ==0)
				{
					iPeriodId=0;
                    StartPeriodicMessage(hDlg,IDC_EDIT_P10,IDC_EDIT_TX10,IDC_EDIT_TI10,IDC_BUTTON_TP10,IDC_COMBO_PPC,&iPeriodId);
					if(iPeriodId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC10,iPeriodId,0);
				}
                else if(strcmp(_text ,"&Stop") ==0)
				{
					iPeriodId=GetDlgItemInt(hDlg,IDC_STATIC10,NULL,1);
                    StopPeriodicMessage(hDlg,IDC_EDIT_P10,IDC_EDIT_TX10,IDC_EDIT_TI10,IDC_BUTTON_TP10,IDC_COMBO_PPC,iPeriodId);
					SetDlgItemInt(hDlg,IDC_STATIC10,0,0);
				}
                return TRUE;
                break;

            default:
                return FALSE;
            }
        }
    default:
        return FALSE;
    }
}

LRESULT CALLBACK FilterProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT rt, rt2;
    int i;
    char _text[100];
	int protocolCount = 0;
	int nsel = 0;
	char profileBuffer[100];


    switch (message)
    {
    case WM_INITDIALOG:
        {
            GetWindowRect(GetDesktopWindow(), &rt);
            GetWindowRect(hDlg, &rt2);
            SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
                (rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, 
                    SWP_NOZORDER | SWP_NOSIZE);

			for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)//nikhiltest_added
			{
				if(iProtocolsConnected[protocolCount][1] != 0)
					ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_FPC),ProtocolList[iProtocolsConnected[protocolCount][0]][0]);
			}
			ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC),0);

			nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC));
					iCurProtocol = iProtocolsConnected[nsel][1];
					sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
					strcat(profileBuffer," - Filter Msgs");
			ReadFilterStatus( profileBuffer,hDlg);
                
            return TRUE;
        }
        break;
    case WM_COMMAND:
        {

			if(HIWORD(wParam)==CBN_SETFOCUS && (HWND)lParam == GetDlgItem(hDlg, IDC_COMBO_FPC))
            {
					nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC));
					iCurProtocol = iProtocolsConnected[nsel][1];
					sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
					strcat(profileBuffer," - Filter Msgs");
					WriteFilterStatus( profileBuffer,hDlg);
                    

			}
		    if(HIWORD(wParam)==CBN_SELCHANGE )
			{
				for (i=0;i<10;i++)
				{
					nsel = ComboBox_GetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i));
					nsel = lParam ;
					if(ComboBox_GetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i))==3)
						EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), TRUE);
					else
						EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), FALSE);
				}
				
				if((HWND)lParam == GetDlgItem(hDlg, IDC_COMBO_FPC))
				{
						nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC));
						iCurProtocol = iProtocolsConnected[nsel][1];
						sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
						strcat(profileBuffer," - Filter Msgs");
						ReadFilterStatus( profileBuffer,hDlg);
				}
            }
            else
            {
                switch (LOWORD(wParam))
                {
                case IDCANCEL:
					//Nikhiltest WritePrivateProfileString w.r.to protocol selected 
					nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC));
					iCurProtocol = iProtocolsConnected[nsel][1];
					sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[nsel][0]][0]);   
					strcat(profileBuffer," - Filter Msgs");
					WriteFilterStatus( profileBuffer,hDlg);
                    EndDialog(hDlg, LOWORD(wParam));
                    return TRUE;
                case IDCLEAR:
                    ClearAllMsgFilters(hDlg);
                    break;
                case IDC_BUTTON_TP11:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP11,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{	iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P1,IDC_EDIT_P11,IDC_EDIT_P21,IDC_EDIT_TX1,
                        IDC_BUTTON_TP11,IDC_COMBO1,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC1,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC1,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P1,IDC_EDIT_P11,IDC_EDIT_P21,IDC_EDIT_TX1,
                        IDC_BUTTON_TP11,IDC_COMBO1,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC1,0,0);
					}
                    break;
                case IDC_BUTTON_TP12:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP12,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{	iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P2,IDC_EDIT_P12,IDC_EDIT_P22,IDC_EDIT_TX2,
                        IDC_BUTTON_TP12,IDC_COMBO2,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC2,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC2,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P2,IDC_EDIT_P12,IDC_EDIT_P22,IDC_EDIT_TX2,
                        IDC_BUTTON_TP12,IDC_COMBO2,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC2,0,0);
					}
                    break;
                case IDC_BUTTON_TP13:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP13,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P3,IDC_EDIT_P13,IDC_EDIT_P23,IDC_EDIT_TX3,
                        IDC_BUTTON_TP13,IDC_COMBO3,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC3,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC3,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P3,IDC_EDIT_P13,IDC_EDIT_P23,IDC_EDIT_TX3,
                        IDC_BUTTON_TP13,IDC_COMBO3,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC3,0,0);
					}
                    break;
                case IDC_BUTTON_TP14:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP14,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P4,IDC_EDIT_P14,IDC_EDIT_P24,IDC_EDIT_TX4,
                        IDC_BUTTON_TP14,IDC_COMBO4,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC4,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC4,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P4,IDC_EDIT_P14,IDC_EDIT_P24,IDC_EDIT_TX4,
                        IDC_BUTTON_TP14,IDC_COMBO4,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC4,0,0);
					}
                    break;
                case IDC_BUTTON_TP15:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP15,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P5,IDC_EDIT_P15,IDC_EDIT_P25,IDC_EDIT_TX5,
                        IDC_BUTTON_TP15,IDC_COMBO5,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC5,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC5,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P5,IDC_EDIT_P15,IDC_EDIT_P25,IDC_EDIT_TX5,
                        IDC_BUTTON_TP15,IDC_COMBO5,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC5,0,0);
					}
                    break;
                case IDC_BUTTON_TP16:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP16,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P6,IDC_EDIT_P16,IDC_EDIT_P26,IDC_EDIT_TX6,
                        IDC_BUTTON_TP16,IDC_COMBO6,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC6,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC6,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P6,IDC_EDIT_P16,IDC_EDIT_P26,IDC_EDIT_TX6,
                        IDC_BUTTON_TP16,IDC_COMBO6,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC6,0,0);
					}
                    break;
                case IDC_BUTTON_TP17:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP17,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P7,IDC_EDIT_P17,IDC_EDIT_P27,IDC_EDIT_TX7,
                        IDC_BUTTON_TP17,IDC_COMBO7,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC7,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC7,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P7,IDC_EDIT_P17,IDC_EDIT_P27,IDC_EDIT_TX7,
                        IDC_BUTTON_TP17,IDC_COMBO7,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC7,0,0);
					}
                    break;
                case IDC_BUTTON_TP18:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP18,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P8,IDC_EDIT_P18,IDC_EDIT_P28,IDC_EDIT_TX8,
                        IDC_BUTTON_TP18,IDC_COMBO8,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC8,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC8,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P8,IDC_EDIT_P18,IDC_EDIT_P28,IDC_EDIT_TX8,
                        IDC_BUTTON_TP18,IDC_COMBO8,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC8,0,0);
					}
                    break;
                case IDC_BUTTON_TP19:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP19,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P9,IDC_EDIT_P19,IDC_EDIT_P29,IDC_EDIT_TX9,
                        IDC_BUTTON_TP19,IDC_COMBO9,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC9,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC9,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P9,IDC_EDIT_P19,IDC_EDIT_P29,IDC_EDIT_TX9,
                        IDC_BUTTON_TP19,IDC_COMBO9,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC9,0,0);
					}
                    break;
                case IDC_BUTTON_TP20:
                    GetDlgItemText(hDlg,IDC_BUTTON_TP20,_text,10);
                    if(strcmp(_text ,"&Start") ==0)
					{
						iFilId=0;
                        StartMsgFilter(hDlg,IDC_EDIT_P10,IDC_EDIT_P20,IDC_EDIT_P30,IDC_EDIT_TX10,
                        IDC_BUTTON_TP20,IDC_COMBO10,IDC_COMBO_FPC,&iFilId);
						/*jayasheela-store filter id */
						if(iFilId!=0)
						SetDlgItemInt(hDlg,IDC_STATIC10,iFilId,0);
					}
                    else if(strcmp(_text ,"&Stop") ==0)
					{
						/*jayasheela-get filter id */
						iFilId=GetDlgItemInt(hDlg,IDC_STATIC10,NULL,1);
                        StopMsgFilter(hDlg,IDC_EDIT_P10,IDC_EDIT_P20,IDC_EDIT_P30,IDC_EDIT_TX10,
                        IDC_BUTTON_TP20,IDC_COMBO10,IDC_COMBO_FPC,iFilId);
						SetDlgItemInt(hDlg,IDC_STATIC10,0,0);
					}
                    break;
                default:
                    return FALSE;
                }
            }
        }
    default:
        return FALSE;
    }
}

LRESULT CALLBACK IOCTLProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    RECT rt, rt2;
    static HWND hIOCTLList, hParamList;
    int sel, sel2, error, size, param;
    unsigned long longparam, ulVBattVoltage,ulProgVoltage;
    unsigned char address, Keybytes[2];
    SBYTE_ARRAY InputParam, OutputParam;
    PASSTHRU_MSG PassThruTempMsg, ResultMsg;
    SCONFIG_LIST ConfigList;
    SCONFIG Config;
	int cParameter = 1;
	unsigned long protocolCount;
	int nsel = 0;
	char _text[25];
    
    switch (message)
    {
    case WM_INITDIALOG:
        {
            GetWindowRect(GetDesktopWindow(), &rt);
            GetWindowRect(hDlg, &rt2);
            SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
                (rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, 
                    SWP_NOZORDER | SWP_NOSIZE);
            
			for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)//nikhiltest_added
			{
				if(iProtocolsConnected[protocolCount][1] != 0)
					ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_IPC),ProtocolList[iProtocolsConnected[protocolCount][0]][0]);
			}
			ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_IPC),0);
            
            hIOCTLList = GetDlgItem(hDlg, IDC_IOCTL_LIST);
            
            ListBox_AddString(hIOCTLList, "GET_CONFIG");
            ListBox_AddString(hIOCTLList, "SET_CONFIG");
            ListBox_AddString(hIOCTLList, "READ_VBATT");
            ListBox_AddString(hIOCTLList, "FIVE_BAUD_INIT");
            ListBox_AddString(hIOCTLList, "FAST_INIT");
            ListBox_AddString(hIOCTLList, "CLEAR_TX_BUFFER");
            ListBox_AddString(hIOCTLList, "CLEAR_RX_BUFFER");
            ListBox_AddString(hIOCTLList, "CLEAR_PERIODIC_MSGS");
            ListBox_AddString(hIOCTLList, "CLEAR_MSG_FILTERS");
            ListBox_AddString(hIOCTLList, "CLEAR_FUNCT_MSG_LOOKUP_TABLE");
            ListBox_AddString(hIOCTLList, "ADD_TO_FUNCT_MSG_LOOKUP_TABLE");
            ListBox_AddString(hIOCTLList, "DELETE_FROM_FUNCT_MSG_LOOKUP_TABLE");
            ListBox_AddString(hIOCTLList, "READ_PROG_VOLTAGE");
            ListBox_AddString(hIOCTLList, "SWCAN_HS");
            ListBox_AddString(hIOCTLList, "SWCAN_NS");

            ListBox_SetCurSel(hIOCTLList, 1);
            hParamList=GetDlgItem(hDlg, IDC_PARAM_LIST);
            ListBox_AddString(hParamList, "DATA_RATE");
            ListBox_AddString(hParamList, "LOOPBACK");
            ListBox_AddString(hParamList, "NODE_ADDRESS");
            ListBox_AddString(hParamList, "NETWORK_LINE");
            ListBox_AddString(hParamList, "P1_MIN");
            ListBox_AddString(hParamList, "P1_MAX");
            ListBox_AddString(hParamList, "P2_MIN");
            ListBox_AddString(hParamList, "P2_MAX");
            ListBox_AddString(hParamList, "P3_MIN");
            ListBox_AddString(hParamList, "P3_MAX");
            ListBox_AddString(hParamList, "P4_MIN");
            ListBox_AddString(hParamList, "P4_MAX");
            ListBox_AddString(hParamList, "W1");
            ListBox_AddString(hParamList, "W2");
            ListBox_AddString(hParamList, "W3");
            ListBox_AddString(hParamList, "W4");
            ListBox_AddString(hParamList, "W5");
            ListBox_AddString(hParamList, "TIDLE");
            ListBox_AddString(hParamList, "TINIL");
            ListBox_AddString(hParamList, "TWUP");
            ListBox_AddString(hParamList, "PARITY");
            ListBox_AddString(hParamList, "BIT_SAMPLE_POINT");
            ListBox_AddString(hParamList, "SYNC_JUMP_WIDTH");
            ListBox_AddString(hParamList, "W0");
            ListBox_AddString(hParamList, "T1_MAX");
            ListBox_AddString(hParamList, "T2_MAX");
            ListBox_AddString(hParamList, "T4_MAX");
            ListBox_AddString(hParamList, "T5_MAX");
            ListBox_AddString(hParamList, "ISO15765_BS");
            ListBox_AddString(hParamList, "ISO15765_STMIN");
            ListBox_AddString(hParamList, "DATA_BITS");
            ListBox_AddString(hParamList, "FIVE_BAUD_MOD");
            ListBox_AddString(hParamList, "BS_TX");
            ListBox_AddString(hParamList, "STMIN_TX");
            ListBox_AddString(hParamList, "T3_MAX");
            ListBox_AddString(hParamList, "ISO15765_WFT_MAX");
            ListBox_AddString(hParamList, "CAN_MIXED_FORMAT");
            ListBox_AddString(hParamList, "J1962_PINS");
            ListBox_AddString(hParamList, "SWCAN_HS_DATA_RATE");
            ListBox_AddString(hParamList, "SWCAN_SPEEDCHANGE_ENABLE");
            ListBox_AddString(hParamList, "SWCAN_RES_SWITCH");
            ListBox_SetCurSel(hParamList, 0);
            SetDlgItemText(hDlg, IDC_PARAM, "Enter parameter: (Be sure to enter all data in decimal except NODE_ADDRESS and J1962_PINS)");
            ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
            return TRUE;
        }
        break;

    case WM_COMMAND:


        if(HIWORD(wParam)==LBN_SELCHANGE && (HWND)lParam != GetDlgItem(hDlg, IDC_COMBO_IPC))
        {
            if(LOWORD(wParam)==IDC_IOCTL_LIST)
            {
                ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                SetDlgItemText(hDlg, IDC_PARAM, "");
                
                if(ListBox_GetCurSel(hIOCTLList)==0 ||
                    ListBox_GetCurSel(hIOCTLList)==1)
                {
                    EnableWindow(hParamList, TRUE);
                    ComboBox_SetCurSel(hParamList, -1);
					 if(ListBox_GetCurSel(hIOCTLList)==1)
					 {
						SetDlgItemText(hDlg, IDC_INIT, "");
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_SHOW);
                        SetDlgItemText(hDlg, IDC_PARAM, "Enter parameter: (Be sure to enter all data in decimal except NODE_ADDRESS and J1962_PINS)");
       
					 }
                }
                else
                {
                    EnableWindow(hParamList, FALSE);
                    if(ListBox_GetCurSel(hIOCTLList)==3 ||
                        ListBox_GetCurSel(hIOCTLList)==4 ||
                        ListBox_GetCurSel(hIOCTLList)==10 ||
                        ListBox_GetCurSel(hIOCTLList)==11)
                    {
                        SetDlgItemText(hDlg, IDC_INIT, "");
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_SHOW);
                        SetDlgItemText(hDlg, IDC_PARAM, "Enter parameter: (Be sure to enter all data in decimal except NODE_ADDRESS and J1962_PINS)");
                        
                    }
                    else
                    {
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                        SetDlgItemText(hDlg, IDC_PARAM, "");
                    }
                }
            }
            else if(LOWORD(wParam)==IDC_PARAM_LIST)
            {
                ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                SetDlgItemText(hDlg, IDC_PARAM, "");
                switch(ListBox_GetCurSel(hParamList)+2)
                {
                case LOOPBACK:
                    if(ListBox_GetCurSel(hIOCTLList)==1)
                    {
                        ComboBox_ResetContent(GetDlgItem(hDlg, IDC_CHOICE));
                        ComboBox_AddString(GetDlgItem(hDlg, IDC_CHOICE), "0 (OFF)");
                        ComboBox_AddString(GetDlgItem(hDlg, IDC_CHOICE), "1 (ON)");
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_SHOW);
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_CHOICE), 0);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                        SetDlgItemText(hDlg, IDC_PARAM, "Please select a parameter:");
                    }
                    else
                    {
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                        SetDlgItemText(hDlg, IDC_PARAM, "");
                    }
                    break;
                case NETWORK_LINE:
                    if(ListBox_GetCurSel(hIOCTLList)==1)
                    {
                        ComboBox_ResetContent(GetDlgItem(hDlg, IDC_CHOICE));
                        ComboBox_AddString(GetDlgItem(hDlg, IDC_CHOICE), "0 (BUS_NORMAL)");
                        ComboBox_AddString(GetDlgItem(hDlg, IDC_CHOICE), "1 (BUS_PLUS)");
                        ComboBox_AddString(GetDlgItem(hDlg, IDC_CHOICE), "2 (BUS_MINUS)");
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_CHOICE),0);
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_SHOW);
                        ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_CHOICE), 0);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                        SetDlgItemText(hDlg, IDC_PARAM, "Please select a parameter:");
                    }
                    else
                    {
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                        SetDlgItemText(hDlg, IDC_PARAM, "");
                    }
                    break;
                default:
                    if(ListBox_GetCurSel(hIOCTLList)==1)
                    {
                        SetDlgItemText(hDlg, IDC_INIT, "");
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_SHOW);
                        SetDlgItemText(hDlg, IDC_PARAM, "Enter parameter: (Be sure to enter all data in decimal except NODE_ADDRESS and J1962_PINS)");
                    }
                    else
                    {
                        ShowWindow(GetDlgItem(hDlg, IDC_CHOICE), SW_HIDE);
                        ShowWindow(GetDlgItem(hDlg, IDC_INIT), SW_HIDE);
                        SetDlgItemText(hDlg, IDC_PARAM, "");
                    }
                    break;
                }
            }
            break;
        }
        switch (LOWORD(wParam))
        {
        case IDCANCEL:
            EndDialog(hDlg, LOWORD(wParam));
            return TRUE;
            break;

        case ID_ISSUE_BTN:
		
			
			//Test Nikhil to select channel
			ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_IPC),_text,20);
			for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
				{
					if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
					{
						for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
						{	
							if(protocolCount == iProtocolsConnected[nsel][0])
								break;
						}
						iCurProtocol = iProtocolsConnected[nsel][1];
						ulChannelID = iProtocolsConnected[nsel][2];
						break;
					}
				}
			/* Another way to get Channel and Protocol ids but unstable..Nikhilesh
			/*nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_IPC));
			iCurProtocol = iProtocolsConnected[nsel++][1];
			ulChannelID = nsel;*/
            sel=ListBox_GetCurSel(hIOCTLList);
            switch(sel)
            {
            case 0: 
            case 1:
                param=ListBox_GetCurSel(hParamList);
                param++;
                if(param>=2)
                    param++;
                
                ConfigList.NumOfParams=1;
                ConfigList.ConfigPtr=&Config;
                Config.Parameter=param;
                Config.Value=0;
                if(param==LOOPBACK || param==NETWORK_LINE)
                {
                    if(sel==1)
                    {
                        sel2=ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_CHOICE));
                        Config.Value=sel2;
                        sprintf(tempbuf, "Config.Value=%d;", sel2);
                        AddToScreen(hLogWindow,tempbuf);
                    }                               
                }
                else
                {
                    if(sel==1)
                    {
                        if(!GetDlgItemText(hDlg, IDC_INIT, (char*)tempstr, 1024))
                            break;
                        /*jayasheela-changed always was entring if*/
						/*Jayasheela-all data will take it as decimal except NODE_ADDRESS and 
						  J1962_PINS*/
                        if(param==NODE_ADDRESS || param==J1962_PINS)
                        {
                            sscanf((char*)tempstr, "%X", &longparam);
                            Config.Value=longparam;
                            sprintf(tempbuf, "Config.Value=0x%X;", longparam);
                            AddToScreen(hLogWindow,tempbuf);
                        }
                        else
                        {
							sscanf((char*)tempstr, "%d", &longparam);
                            Config.Value=longparam;
                            sprintf(tempbuf, "Config.Value=%d;", longparam);
                            AddToScreen(hLogWindow,tempbuf);
                        }
                    }       
                }
				/*Jayasheela-Added to handle single wire Ioctl commands */
			 cParameter = ConfigList.ConfigPtr->Parameter;

				switch(ConfigList.ConfigPtr->Parameter)
				{
					case CAN_MIXED_FORMAT:
										ConfigList.ConfigPtr->Parameter=0x00008000;
										//ConfigList.ConfigPtr->Parameter=0x00000080;
										break;
					case J1962_PINS:
										ConfigList.ConfigPtr->Parameter=0x00008001;
										//ConfigList.ConfigPtr->Parameter=0x00000081;
										break;
					case SWCAN_HS_DATA_RATE:
										ConfigList.ConfigPtr->Parameter=0x00008010;
										//ConfigList.ConfigPtr->Parameter=0x00000090;
										break;
					case SWCAN_SPEEDCHANGE_ENABLE:
										ConfigList.ConfigPtr->Parameter=0x00008011;
										//ConfigList.ConfigPtr->Parameter=0x00000091;
										break;
					case SWCAN_RES_SWITCH:
										ConfigList.ConfigPtr->Parameter=0x00008012;
										//ConfigList.ConfigPtr->Parameter=0x00000092;
										break;
				}
                error=PassThruIoctl(ulChannelID, sel+1, &ConfigList, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                
                if(error==STATUS_NOERROR && sel==0)
                {
                    if(cParameter>=3)
						cParameter--;
                    /*Jayasheela-changed to display data in decimal except NODE_ADDRESS and J1962_PINS */
                    if(cParameter==0x00000003 ||cParameter==0x00000026)
                        sprintf(tempbuf, "%s = 0x%X", IoctlParamList[cParameter], Config.Value);
                    else
                        sprintf(tempbuf, "%s = %d", IoctlParamList[cParameter], Config.Value);
                    AddToScreen(hLogWindow,tempbuf);
                }
                
                break;
            case 2:
                sel+=1;
                GetDlgItemText(hDlg, IDC_INIT, (char*)tempstr, 1024);
                error=PassThruIoctl(ulDeviceID, sel, NULL, &ulVBattVoltage);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                if(error==STATUS_NOERROR)
                {
                    sprintf(tempbuf, "Voltage Read: %lu mV", ulVBattVoltage);
                    AddToScreen(hLogWindow,tempbuf);
                }
                break;
				/*Jayasheela -added case to handle read progvoltage command*/
			case 12:
                sel+=2;
                error=PassThruIoctl(ulDeviceID, sel, NULL, &ulProgVoltage);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                if(error==STATUS_NOERROR)
                {
                    sprintf(tempbuf, "Progm Voltage Read: %lu mV", ulProgVoltage);
                    AddToScreen(hLogWindow,tempbuf);
                }
                break;

            case 3:
                sel+=1;
                GetDlgItemText(hDlg, IDC_INIT, (char*)tempstr, 1024);
                sscanf((char*)tempstr, "%02X", &address);           
              //  AddToScreen(hLogWindow,tempstr);
                InputParam.NumOfBytes=1;
                InputParam.BytePtr=&address;
                OutputParam.BytePtr=Keybytes;
                OutputParam.NumOfBytes=2;
                error=PassThruIoctl(ulChannelID, sel, &InputParam, &OutputParam);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                if(error==STATUS_NOERROR)
                {
                    sprintf(tempbuf, "Keybyte 1: 0x%02X   Keybyte 2: 0x%02X", Keybytes[0], Keybytes[1]);
                    AddToScreen(hLogWindow,tempbuf);
                }
                break;
            case 4:
                sel+=1;
                GetDlgItemText(hDlg, IDC_INIT, (char*)tempstr, 1024);
                size=CheckAndConvertMsg(tempstr, tempmsg);
                if(size>0)
                {
                    memset(&PassThruTempMsg, 0, sizeof(PASSTHRU_MSG));
                    memcpy(PassThruTempMsg.Data, tempmsg, size);
                    PassThruTempMsg.DataSize=size;
                    PassThruTempMsg.ExtraDataIndex=0;
                    PassThruTempMsg.ProtocolID=iCurProtocol;
                    error=PassThruIoctl(ulChannelID, sel, &PassThruTempMsg, &ResultMsg);
                    sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                    AddToScreen(hLogWindow,tempbuf);
                    if(error==STATUS_NOERROR)
                    {
                        strcpy((char*)tempstr, "Fast Init Response: ");
                        for (unsigned int i=0; i<ResultMsg.DataSize; i++)
                        {
                            sprintf((char*)tempstr+strlen((char*)tempstr), "%02X ", ResultMsg.Data[i]);
                        }
                        AddToScreen(hLogWindow,(char*)tempstr);
                        sprintf((char*)tempstr, "Fast Init Response Length: %d", ResultMsg.DataSize);
                        AddToScreen(hLogWindow,(char*)tempstr);
                    }
                }
                break;
            case 10:
            case 11:
                sel+=2;
                GetDlgItemText(hDlg, IDC_INIT, (char*)tempstr, 1024);
                sscanf((char*)tempstr, "%02X", &address);           
                InputParam.NumOfBytes=1;
                InputParam.BytePtr=&address;
                error=PassThruIoctl(ulChannelID, sel, &InputParam, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                break;

            case 13:
                sel+=2;
                //GetDlgItemText(hDlg, IDC_INIT, (char *)tempstr, 1024);
                //sscanf((char*)tempstr, "%02X %02X", Keybytes, Keybytes+1);          
                //sprintf(tempbuf, "szTempbuf[0]=0x%02X;", Keybytes[0]);
                //AddToScreen(hLogWindow,tempbuf);
                //sprintf(tempbuf, "szTempbuf[1]=0x%02X;", Keybytes[1]);
                //AddToScreen(hLogWindow,tempbuf);
				/*Jaaysheela -removed passing of 0x00001000 value as 2ndparameter*/
                error=PassThruIoctl(ulChannelID, 0x00008000, Keybytes, NULL);
                //error=PassThruIoctl(ulChannelID, 0x00000080, Keybytes, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                break;
				/*jayasheela-added to handle SWCAN_NS IOCTL command */
			case 14:
                sel+=2;
                GetDlgItemText(hDlg, IDC_INIT, (char *)tempstr, 1024);
                sscanf((char*)tempstr, "%02X %02X", Keybytes, Keybytes+1);          
            /*    sprintf(tempbuf, "szTempbuf[0]=0x%02X;", Keybytes[0]);
                AddToScreen(hLogWindow,tempbuf);
                sprintf(tempbuf, "szTempbuf[1]=0x%02X;", Keybytes[1]);
                AddToScreen(hLogWindow,tempbuf);*/
                error=PassThruIoctl(ulChannelID,0x00008001, Keybytes, NULL);
                //error=PassThruIoctl(ulChannelID,0x00000081, Keybytes, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                break;
				/*Jayasheela-Added cases to handle CLEAR_PERIODIC_MSGS and CLEAR_MSG_FILTERS*/
				/*CLEAR_PERIODIC_MSGS*/
			case 7:
				sel+=2;
                error=PassThruIoctl(ulChannelID, sel, NULL, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
				ResetGUIStatus(TRUE,FALSE);
				break;
				/*Jayasheela-Added cases to handle CLEAR_PERIODIC_MSGS and CLEAR_MSG_FILTERS*/
				/*CLEAR_FILTER_MSGS*/
			case 8:
				sel+=2;
                error=PassThruIoctl(ulChannelID, sel, NULL, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
				ResetGUIStatus(FALSE,TRUE);
				break;
            default:
                sel+=2;
                error=PassThruIoctl(ulChannelID, sel, NULL, NULL);
                sprintf(tempbuf, "PassThruIoctl returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                break;
        }
        EndDialog(hDlg, LOWORD(wParam));
        default:
            return FALSE;
        }
        return TRUE;
        break;
        default:
            return FALSE;
    }
    return TRUE;
}

LRESULT CALLBACK SetProgrammingVoltageProc(HWND hDlg, UINT message, WPARAM wParam, 
                                           LPARAM lParam)
{
    RECT rt, rt2;
    BOOL retval;
    unsigned long iPinNum, voltage = 0, error;
	char _text[20];

    switch (message)
    {
        case WM_INITDIALOG:
            GetWindowRect(GetDesktopWindow(), &rt);
            GetWindowRect(hDlg, &rt2);
            SetWindowPos(hDlg, hDlg, (rt.right-rt.left)/2-(rt2.right-rt2.left)/2,
                        (rt.bottom-rt.top)/2-(rt2.bottom-rt2.top)/2, 0, 0, SWP_NOZORDER | SWP_NOSIZE);

			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"0");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"6");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"9");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"11");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"12");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"13");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"14");
			ComboBox_AddString(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),"15");
			ComboBox_SetCurSel(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),0);

			CheckRadioButton(hDlg,IDC_RADIO_VALUES,IDC_RADIO_STG,IDC_RADIO_VALUES);
	         return TRUE;
        case WM_COMMAND:
            switch (LOWORD(wParam))
            {
				case IDC_RADIO_VALUES:
				       EnableWindow(GetDlgItem(hDlg,IDC_VOLTAGE),TRUE);
					break;

			    case IDC_RADIO_VOFF:
				       EnableWindow(GetDlgItem(hDlg,IDC_VOLTAGE),FALSE);
					break;

				case IDC_RADIO_STG:
				       EnableWindow(GetDlgItem(hDlg,IDC_VOLTAGE),FALSE);
					break;

                case IDOK:
					//Read Pin number
                    iPinNum=GetDlgItemInt(hDlg, IDC_COMBO_VOLTAGE, &retval, FALSE);
                    if(!retval)
                        break;
					ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_VOLTAGE),_text,3);
                    sscanf((char *)_text,"%ul",&iPinNum); 

					//Read Radio button and get Voltage value accordingly
					if(BST_CHECKED == IsDlgButtonChecked(hDlg,IDC_RADIO_VALUES))
					{

						voltage=GetDlgItemInt(hDlg, IDC_VOLTAGE, &retval, FALSE);
						sprintf(tempbuf,"PassThruSetProgrammingVoltage(%lu, %lu);", iPinNum, voltage);
						if(!retval)
							break;
					}
					else
						if(BST_CHECKED == IsDlgButtonChecked(hDlg,IDC_RADIO_VOFF))
						{
							voltage = VOLTAGE_OFF;
							sprintf(tempbuf,"PassThruSetProgrammingVoltage(%lu, %X);", iPinNum, VOLTAGE_OFF);
						}
						else
							if(BST_CHECKED == IsDlgButtonChecked(hDlg,IDC_RADIO_STG))
							{
								voltage = SHORT_TO_GROUND;
								sprintf(tempbuf,"PassThruSetProgrammingVoltage(%lu, %X);", iPinNum, SHORT_TO_GROUND);
							}
 
                    AddToScreen(hLogWindow,tempbuf);
                    error=PassThruSetProgrammingVoltage(ulDeviceID, iPinNum, voltage);
                    sprintf(tempbuf, "PassThruSetProgrammingVoltage returned: %s", ErrorList[error]);
                    AddToScreen(hLogWindow,tempbuf);
                case IDCANCEL:
                    EndDialog(hDlg, LOWORD(wParam));
                break;
            }
            return TRUE;
            break;
        default:
            return FALSE;
    }
    return TRUE;
}

char* removeheader(char *val)
{
	return(val + SIZE_0x);
}
BOOL varifyString(char *val)
{
	BOOL status = 0;
	val = removeheader(val);
	for(unsigned int i =0;i<strlen(val);i++)
	{
		status = 0;
		if(val[i] >= '0' && val[i] <= '9')
			status = 1;
		if(val[i] >= 'A' && val[i] <= 'F')
			status = 1;
		if(val[i] >= 'a' && val[i] <= 'f')
			status = 1;
		if(status == 0)
			break;
	}
return status;

}
unsigned long hexToint(char *val) //Nikhilesh
{
	unsigned long value=0;
	unsigned long i,j = 0;
	val = removeheader(val);
	
	unsigned long val_len = strlen(val);
	for(i=0;i<val_len;i++)
	{
		if((val[i] >= '0') && (val[i] <= '9'))
		{
			j=(val[i] - '0');
		}
		if((val[i] >= 'A') && (val[i] <= 'F'))
		{
			j=(val[i] - 'A'+10);
		}
		if((val[i] >= 'a') && (val[i] <= 'f'))
		{
			j=(val[i] - 'a'+10);
		}
		value = value + j * (unsigned long)pow(16.0,(val_len - 1 - i));
	}

	return (int)value;
}

void StartPeriodicMessage(HWND hDlg, int nDlgMsgID,int nDlgTxFlags,int nDlgTimerDelay,
                                                                        int ndlgButton,int nProtocolSelected,unsigned long *ulPID)
{
    unsigned long ulTimerDelay,nTxFlags;
    BOOL retval;
    PASSTHRU_MSG ptrMsg;
    int error, size;
	char Txstring[15];
	int nsel;
	char _text[25];
	unsigned long protocolCount;

	//Test Nikhil to select channel
	ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_PPC),_text,20);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
	{
		if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
		{
			for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
			{	
				if(protocolCount == iProtocolsConnected[nsel][0])
					break;
			}
			iCurProtocol = iProtocolsConnected[nsel][1];
			ulChannelID = iProtocolsConnected[nsel][2];
			break;
		}
	}
	/* Another way to get Channel and Protocol ids but unstable..Nikhilesh
	/*nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC));
	iCurProtocol = iProtocolsConnected[nsel++][1];
	ulChannelID = nsel;*/
    if(GetDlgItemText(hDlg, nDlgMsgID, tempbuf, 16384))
    {
        ulTimerDelay=GetDlgItemInt(hDlg, nDlgTimerDelay, &retval, FALSE);
        if(retval)
        {
            if((size=CheckAndConvertMsg((unsigned char *)tempbuf, tempmsg)) != 0)
            {
                memset(&ptrMsg, 0, sizeof(PASSTHRU_MSG));
                memcpy(ptrMsg.Data, tempmsg, size);
                ptrMsg.DataSize=size;
                ptrMsg.ExtraDataIndex=0;
                ptrMsg.ProtocolID=iCurProtocol;
				nTxFlags = GetDlgItemText(hDlg, nDlgTxFlags, Txstring, 12);
				if(varifyString(Txstring))
				{
					nTxFlags = hexToint(Txstring);
				}
				else
				{
					MessageBox(NULL,"Invalid Data","Error",NULL);
					return;
				}

			    if(bCanExtended)
                    ptrMsg.TxFlags=0x100;
                else
                    ptrMsg.TxFlags=nTxFlags;
                
                error=PassThruStartPeriodicMsg(ulChannelID, &ptrMsg,ulPID, ulTimerDelay);
                sprintf(tempbuf, "PassThruStartPeriodicMsg returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                if(error==STATUS_NOERROR)
                {
                    ulPeriodicID[ndlgButton - IDC_BUTTON_TP1] = *ulPID;
                    EnableWindow(GetDlgItem(hDlg,nDlgMsgID),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nDlgTxFlags),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nDlgTimerDelay),FALSE);
                    SetDlgItemText(hDlg,ndlgButton,"&Stop");
                }
            }
        }
    }
}

void StopPeriodicMessage(HWND hDlg, int nDlgMsgID,int nDlgTxFlags,int nDlgTimerDelay,
                                                                  int ndlgButton,int nProtocolSelected, unsigned long nMSGID)
{
    int error =0;
	int nsel = 0;
	unsigned long protocolCount;
	char _text[25];

	ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_PPC),_text,20);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
		{
			if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
			{
				for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
				{	
					if(protocolCount == iProtocolsConnected[nsel][0])
						break;
				}
				iCurProtocol = iProtocolsConnected[nsel][1];
				ulChannelID = iProtocolsConnected[nsel][2];
				break;
			}
		}
	/* Another way to get Channel and Protocol ids but unstable..Nikhilesh
	/*	nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_PPC));
	iCurProtocol = iProtocolsConnected[nsel++][1];
	ulChannelID = nsel;*/
    error=PassThruStopPeriodicMsg(ulChannelID, nMSGID);
    if(error==STATUS_NOERROR)
    {
        EnableWindow(GetDlgItem(hDlg,nDlgMsgID),TRUE);
        EnableWindow(GetDlgItem(hDlg,nDlgTxFlags),TRUE);
        EnableWindow(GetDlgItem(hDlg,nDlgTimerDelay),TRUE);
        SetDlgItemText(hDlg,ndlgButton,"&Start");
    }
    sprintf(tempbuf, "PassThruStopPeriodicMsg returned: %s", ErrorList[error]);
    AddToScreen(hLogWindow,tempbuf);
}

void StopMsgFilter(HWND hDlg, int nDlgMMsgID,int nDlgPMsgID,int nDlgFCMsgID,
                              int nDlgTxFlags,int nDlgButton,int nFilterType,int nProtocolSelected, unsigned long nFILTERID)
{
    int error =0;
	unsigned long protocolCount;
	char _text[25];
	int nsel = 0;

	//Test Nikhil to select channel
	ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_FPC),_text,20);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
		{
			if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
			{
				for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
				{	
					if(protocolCount == iProtocolsConnected[nsel][0])
						break;
				}
				iCurProtocol = iProtocolsConnected[nsel][1];
				ulChannelID = iProtocolsConnected[nsel][2];
				break;
			}
		}
	/* Another way to ger Channel and Protocol ids but unstable..Nikhilesh
	nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC));
	iCurProtocol = iProtocolsConnected[nsel++][1];
	ulChannelID = nsel;*/
	/*Jayasheela -below replaced nFILTERID+1 to nFILTERID.*/
    error=PassThruStopMsgFilter(ulChannelID, nFILTERID);
    if(error==STATUS_NOERROR)
    {
        EnableWindow(GetDlgItem(hDlg,nDlgMMsgID),TRUE);
        EnableWindow(GetDlgItem(hDlg,nDlgPMsgID),TRUE);
        EnableWindow(GetDlgItem(hDlg,nDlgTxFlags),TRUE);
        if(ComboBox_GetCurSel(GetDlgItem(hDlg,nFilterType)) == 3)
            EnableWindow(GetDlgItem(hDlg,nDlgFCMsgID),TRUE);
        else
            EnableWindow(GetDlgItem(hDlg,nDlgFCMsgID),FALSE);
        
        EnableWindow(GetDlgItem(hDlg,nFilterType),TRUE);
        SetDlgItemText(hDlg,nDlgButton,"&Start");
    }
    sprintf(tempbuf, "PassThruStopMsgFilter returned: %s", ErrorList[error]);
    AddToScreen(hLogWindow,tempbuf);
}

void ClearAllPXMessages(HWND hDlg)
{
    int error =0;
	char _text[25];
	unsigned long protocolCount;
	int nsel;
	ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_PPC),_text,20);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
		{
			if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
			{
				for(nsel = 0;nsel<MAX_COLUMN;nsel++)
				{	
					if(protocolCount == iProtocolsConnected[nsel][0])
						break;
				}
				iCurProtocol = iProtocolsConnected[nsel][1];
				ulChannelID = iProtocolsConnected[nsel][2];
				break;
			}
		}
		for(int i = 0; i< MAX_COLUMN;i++)
		{
			if(ulPeriodicID[i] !=0)
			{
				error=PassThruStopPeriodicMsg(ulChannelID, ulPeriodicID[i]);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P1+i),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TX1+i),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TI1+i),TRUE);
				SetDlgItemText(hDlg,IDC_BUTTON_TP1 +i,"&Start");
				ulPeriodicID[i] = 0;
				SetDlgItemInt(hDlg,IDC_STATIC1+i,0,0);
			}
		}
   
}
/*Jayasheela -interchanged the nDlgMMsgID and nDlgPMsgID */
void StartMsgFilter(HWND hDlg, int nDlgMMsgID,int nDlgPMsgID,int nDlgFMsgID,
                    int nDlgTxFlags,int ndlgButton,int nFiltType, int nProtocolSelected, unsigned long *nFILTERID)
{
    PASSTHRU_MSG ptrMask, ptrPattern, ptrFC;
    unsigned long size;
    static HWND hCombo;
    int error =0;
    static int i = 0;
	char _text[25];
	unsigned long protocolCount;
	int nsel = 0;


	//Test Nikhil to select channel
	ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_FPC),_text,20);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
		{
			if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
			{
				for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
				{	
					if(protocolCount == iProtocolsConnected[nsel][0])
						break;
				}
				iCurProtocol = iProtocolsConnected[nsel][1];
				ulChannelID = iProtocolsConnected[nsel][2];
				break;
			}
		}
//This another way of selecting protocol but very unstable and dependent.. So deactivated

/*	nsel = ComboBox_GetCurSel(GetDlgItem(hDlg, IDC_COMBO_FPC));
	iCurProtocol = iProtocolsConnected[nsel++][1];
	ulChannelID = nsel;*/

    if(GetDlgItemText(hDlg, nDlgPMsgID, (char*)tempmsg, 16384))
    {
        if(GetDlgItemText(hDlg, nDlgMMsgID, (char*)tempmsg2, 16384))
        {
            
            size=CheckAndConvertMsg(tempmsg2, tempstr);
            memset(&ptrMask, 0, sizeof(PASSTHRU_MSG));
            memcpy(ptrMask.Data, tempstr, size);
            ptrMask.DataSize=size;
            ptrMask.ExtraDataIndex=0;
            ptrMask.ProtocolID=iCurProtocol;

            size=CheckAndConvertMsg(tempmsg, tempstr);
            memset(&ptrPattern, 0, sizeof(PASSTHRU_MSG));
            memcpy(ptrPattern.Data, tempstr, size);
            ptrPattern.DataSize=size;
            ptrPattern.ExtraDataIndex=0;
            ptrPattern.ProtocolID=iCurProtocol;

			/* Jayasheela- storing Txflags in pattern and mask*/
			GetDlgItemText(hDlg, nDlgTxFlags, (char*)tempbuf, 16384);               
            sscanf(tempbuf, "%X", &ptrPattern.TxFlags);
			sscanf(tempbuf, "%X", &ptrMask.TxFlags);

            hCombo = GetDlgItem(hDlg,nFiltType);
            
            if(ComboBox_GetCurSel(hCombo)==3)
            {
                if(GetDlgItemText(hDlg, nDlgFMsgID, (char*)tempmsg, 16384))
                {
                    size=CheckAndConvertMsg(tempmsg, tempstr);
                    memset(&ptrFC, 0, sizeof(PASSTHRU_MSG));
                    memcpy(ptrFC.Data, tempstr, size);
                    ptrFC.DataSize=size;
                    ptrFC.ExtraDataIndex=0;
                    ptrFC.ProtocolID=iCurProtocol;
					/* Jayasheela- storing Txflags in Flowcontrol*/
					sscanf(tempbuf, "%X", &ptrFC.TxFlags);
                    error=PassThruStartMsgFilter(ulChannelID, ComboBox_GetCurSel(hCombo), &ptrMask, &ptrPattern, &ptrFC,nFILTERID);
				
                    sprintf(tempbuf, "PassThruStartMsgFilter returned: %s", ErrorList[error]);
                    AddToScreen(hLogWindow,tempbuf);
                    if(error==STATUS_NOERROR)
                    {
                        ulFilterID[ndlgButton - IDC_BUTTON_TP11] = *nFILTERID;
                        EnableWindow(GetDlgItem(hDlg,nDlgPMsgID),FALSE);
                        EnableWindow(GetDlgItem(hDlg,nDlgMMsgID),FALSE);
                        EnableWindow(GetDlgItem(hDlg,nDlgFMsgID),FALSE);
                        EnableWindow(GetDlgItem(hDlg,nDlgTxFlags),FALSE);
                        EnableWindow(GetDlgItem(hDlg,nFiltType),FALSE);
                        SetDlgItemText(hDlg,ndlgButton,"&Stop");
                    }
                }
            }
            else if(ComboBox_GetCurSel(hCombo)==1)
            {
                error=PassThruStartMsgFilter(ulChannelID, ComboBox_GetCurSel(hCombo), &ptrMask, &ptrPattern, NULL, nFILTERID);
				
                sprintf(tempbuf, "PassThruStartMsgFilter returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                if(error==STATUS_NOERROR)
                {
                    ulFilterID[ndlgButton - IDC_BUTTON_TP11] = *nFILTERID;
                    EnableWindow(GetDlgItem(hDlg,nDlgPMsgID),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nDlgMMsgID),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nDlgTxFlags),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nFiltType),FALSE);
                    SetDlgItemText(hDlg,ndlgButton,"&Stop");
                }
            }
            else if(ComboBox_GetCurSel(hCombo)==2)
            {
                error=PassThruStartMsgFilter(ulChannelID, ComboBox_GetCurSel(hCombo), &ptrMask, &ptrPattern, NULL, nFILTERID);
                sprintf(tempbuf, "PassThruStartMsgFilter returned: %s", ErrorList[error]);
                AddToScreen(hLogWindow,tempbuf);
                if(error==STATUS_NOERROR)
                {
                    ulFilterID[ndlgButton - IDC_BUTTON_TP11] = *nFILTERID;
                    EnableWindow(GetDlgItem(hDlg,nDlgPMsgID),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nDlgMMsgID),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nDlgTxFlags),FALSE);
                    EnableWindow(GetDlgItem(hDlg,nFiltType),FALSE);
                    SetDlgItemText(hDlg,ndlgButton,"&Stop");
                }
            }
        }
    }
}

void ClearAllMsgFilters(HWND hDlg)
{
    int error =0;
    int nsel = 0;
	char _text[25];
	unsigned long protocolCount;
	ComboBox_GetText(GetDlgItem(hDlg, IDC_COMBO_FPC),_text,20);
	for(protocolCount = 0;protocolCount<MAX_PX_SIZE;protocolCount++)
		{
			if(strcmp(_text,ProtocolList[protocolCount][0]) == 0)
			{
				for(nsel = 0;nsel<MAX_PX_SIZE;nsel++)
				{	
					if(protocolCount == iProtocolsConnected[nsel][0])
						break;
				}
				iCurProtocol = iProtocolsConnected[nsel][1];
				ulChannelID = iProtocolsConnected[nsel][2];
				break;
			 }
		}
		for(int i = 0; i< MAX_COLUMN;i++)
		{
			if(ulFilterID[i] !=0)
			{
				error=PassThruStopMsgFilter(ulChannelID, ulFilterID[i]);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P1+i),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P11+i),TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TX1+i),TRUE);
				nsel = ComboBox_GetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i));
				if(nsel == 3)
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i),TRUE);
				else
					EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i),FALSE);                
				ComboBox_SetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i),nsel);
				EnableWindow(GetDlgItem(hDlg,IDC_COMBO1+i),TRUE);
				SetDlgItemText(hDlg,IDC_BUTTON_TP11 +i,"&Start");
				ulFilterID[i] = 0;
				SetDlgItemInt(hDlg,IDC_STATIC1+i,0,0);
			}
		}

    
}

int CheckAndConvertMsg(unsigned char *in, unsigned char *out)
{
    unsigned int i,j=0;

    if(strlen((char*)in)<=0)
        return -1;

    for(i=0; i<strlen((char*)in);)
    {
        while(in[i]==' ')
            i++;

        if(i>=strlen((char*)in))
            break;

        if(in[i]<='9' && in[i]>='0')
            out[j]=unsigned char (in[i]-'0');
        else if (toupper(in[i])>='A' && toupper(in[i])<='F')
            out[j]=unsigned char (toupper(in[i])-'A'+10);
        else
            out[j]=0;

        i++;
        if(in[i]<='9' && in[i]>='0')
        {
            out[j]=unsigned char(out[j]<<4);
            out[j] = unsigned char (out[j] + (in[i]-'0'));
        }
        else if (toupper(in[i])>='A' && toupper(in[i])<='F')
        {
            out[j]=unsigned char(out[j]<<4);
            out[j]=unsigned char(out[j] + (toupper(in[i]-'A'+10)));
        }
        j++;
        i++;
    }

    in[0]=0;
    for(i=0; i<j; i++)
    {
        sprintf((char*)in+strlen((char*)in), "%02X ", out[i]);
    }
    return j;
}

void FileCreateTempStream()
{
	int success = 0;
	FILE *tempFile;//Nikhil added
	success = SetFileAttributes(DirectoryPath,FILE_ATTRIBUTE_NORMAL);

	if((tempFile = fopen(DirectoryPath,"w"))!= NULL)//Temp_Stream.ini //TEMPSTREAM
	{
		success = SetFileAttributes(DirectoryPath,FILE_ATTRIBUTE_TEMPORARY);//FILE_ATTRIBUTE_READONLY FILE_ATTRIBUTE_HIDDEN FILE_ATTRIBUTE_TEMPORARY
		fclose(tempFile);
	}

}
void FileDeleteTempStream()
{
	int success = 0;
	DWORD err;
	_fcloseall();
	success = SetFileAttributes(DirectoryPath,FILE_ATTRIBUTE_NORMAL);
	success =  DeleteFile(DirectoryPath); // file name
	if(success == 0)
		err =  GetLastError();


}
void FileCopyDatatoStream(int datasize,char *data,int nitemCount)
{
	int success = 0;
	char encryptedData[ENCRYPTLIMIT];
	FILE *tempFile;//Nikhil added
	//FILE_ATTRIBUTE_READONLY FILE_ATTRIBUTE_HIDDEN FILE_ATTRIBUTE_TEMPORARY
	success = SetFileAttributes(DirectoryPath,FILE_ATTRIBUTE_NORMAL);
	if((tempFile = fopen(DirectoryPath,"a"))!= NULL)//Temp_Stream.ini //TEMPSTREAM
	{
		nitemCount++;
		//Encrypt here
		FileEncryptData(nitemCount,data,encryptedData);
		fprintf(tempFile,encryptedData);
		fclose(tempFile);
	}
//
//	MessageBox(NULL,"ALTER","ALTEERR",MB_OK);//test
}
void FileEncryptData(int rowcount,char* lData,char* lEncryptedData)
{
	char convertData[10];
	int intvalueofdata = 0;
	int i;

	int dataSize = strlen(lData);
	memset(lEncryptedData,0,ENCRYPTLIMIT);

	strcat(lEncryptedData,DELEMETER);
	_itoa(rowcount,convertData,10);
	strcat(lEncryptedData,convertData);
	strcat(lEncryptedData,DELEMETER);
	_itoa(dataSize,convertData,10);
	strcat(lEncryptedData,convertData);
	for(i=0;i<dataSize;i++)
	{
		strcat(lEncryptedData,DELEMETER);
		intvalueofdata = (int)lData[i];//(int)
		_itoa(intvalueofdata,convertData,10);
		strcat(lEncryptedData,convertData);

	}
	strcat(lEncryptedData,DELEMETER);
	strcat(lEncryptedData,NEWLINE);



}

int FileReadDataFrmStream(TCHAR *datainChar,char *irowindex)
{
	int success = 0;
	char dataBuf[ENCRYPTLIMIT];
	char onebytedata[10]={0};
	int dataconverted = 0;
	char tokens[] = DELEMETER;
	char *token;
	int ref_rowindex = atoi(irowindex);
	int file_rowindex = 0;
	int file_datacount = 0;
	int i = 0;


	FILE *tempFile;		//Nikhil added
	//FILE_ATTRIBUTE_READONLY FILE_ATTRIBUTE_HIDDEN FILE_ATTRIBUTE_TEMPORARY
	success = SetFileAttributes(DirectoryPath,FILE_ATTRIBUTE_NORMAL);


	if((tempFile = fopen(DirectoryPath,"r"))!= NULL)//Temp_Stream.ini //TEMPSTREAM
	{
		success = 0;
		memset(dataBuf,0,ENCRYPTLIMIT);
		while( !feof( tempFile ) )
		{
			fscanf(tempFile,"%s",dataBuf); 
			token = strtok( dataBuf, tokens );
			file_rowindex = atoi(token);

			if(file_rowindex == ref_rowindex)
			{
				memset(datainChar,0,PASSTHRU_MSG_DATA_SIZE);
				token = strtok( NULL, tokens );
				file_datacount = atoi(token);
				for(i=0;i<file_datacount;i++)
				{
					token = strtok( NULL, tokens );
					strcpy(onebytedata,token);
					dataconverted = atoi(onebytedata);
					datainChar[i] = (char)dataconverted;
				}
				success = 1;
				break;
			}
		}
		fclose(tempFile);
	}
	return(success);


}

void FileSaveDataFrmStream(TCHAR * szColumnData,int nRowIndex)
{
	char charRowIndex[10] = {0};
	nRowIndex++;
	itoa(nRowIndex,charRowIndex,10);
	FileReadDataFrmStream(szColumnData,charRowIndex);
	return;
}
void SaveListControlDataToFile()
{
    OPENFILENAME     SaveFileName; 
    TCHAR            szFilter[]=__TEXT("*.txt"); 
    TCHAR            szFile[MAX_PATH] = __TEXT("txt"); 
    
    // Initialize variables      
    SaveFileName.lStructSize           = sizeof(OPENFILENAME); 
    SaveFileName.hwndOwner             = NULL; 
    SaveFileName.hInstance             = NULL; 
    SaveFileName.lpstrFilter           = szFilter; 
    SaveFileName.lpstrCustomFilter     = (LPTSTR) NULL; 
    SaveFileName.nMaxCustFilter        = 0L; 
    SaveFileName.nFilterIndex          = 1L; 
    SaveFileName.lpstrFile             = szFile; 
    SaveFileName.nMaxFile              = sizeof(szFile); 
    SaveFileName.lpstrFileTitle        = NULL; 
    SaveFileName.nMaxFileTitle         = 0; 
    SaveFileName.lpstrInitialDir       = NULL; 
    SaveFileName.lpstrTitle            = __TEXT("Save As"); 
    SaveFileName.nFileOffset           = 0;
    SaveFileName.nFileExtension        = 0;
    SaveFileName.lpstrDefExt           = __TEXT("txt");
    // No default extension      
    SaveFileName.lCustData             = 0;
    SaveFileName.Flags = OFN_SHOWHELP      | 
                         OFN_PATHMUSTEXIST | 
                         OFN_FILEMUSTEXIST | 
                         OFN_HIDEREADONLY  | 
                         OFN_EXPLORER      | 
                         OFN_LONGNAMES; 
    
    // Create File Dialog Box 
    if (GetSaveFileName(&SaveFileName)) 
        
    { 
        FILE *pSaveFile = fopen( SaveFileName.lpstrFile,"wt");
        int nFrmCnt = 0;
        TCHAR szColumnData[ENCRYPTLIMIT];
        /**To create the file header.*/
        CreateFileHeader(pSaveFile);
        nFrmCnt = ListView_GetItemCount(GetDlgItem(hMainDlg,IDC_LIST_RX));
        for(int nRowIndex = 0; nRowIndex < nFrmCnt;nRowIndex++)
        {
            for(int nColumnIndex = 0;nColumnIndex < MAX_COLUMN;nColumnIndex++)
            {
                ListView_GetItemText(GetDlgItem(hMainDlg,IDC_LIST_RX),nRowIndex,nColumnIndex,szColumnData,MAX_PATH);
                AddFrameInfoToFile(pSaveFile,szColumnData,nColumnIndex,nRowIndex);
            }
        }
        DrawLine(pSaveFile);
        fclose(pSaveFile);
    }
}

void CreateFileHeader(FILE *pFile)
{
    TCHAR szHeader[MAX_PATH];
    fputs("Innova J2534 SDK Log File",pFile);
    DrawLine(pFile);
    sprintf(szHeader,"\n%-10s|%-15s|%-15s|%-10s|%-15s|%-10s|%-10s|%-15s|%-42s|","Sl No","Timestamp","Protocol","Tx/Rx","ExtraDataIndex","RxStatus","TxFlags","DataSize","Data");
    fputs(szHeader,pFile);
    DrawLine(pFile);
}

void AddFrameInfoToFile(FILE *pFile,TCHAR *szColumnData,int nColumnIndex,int nRowIndex)

{
    TCHAR szFormatedData[ENCRYPTLIMIT];
    switch(nColumnIndex)
    {
        
    case 0:
        sprintf(szFormatedData,"\n%-10s|",szColumnData);
        break;
        
    case 1:
        sprintf(szFormatedData,"%-15s|",szColumnData);
        break;
        
    case 2:           
        sprintf(szFormatedData,"%-15s|",szColumnData);
        break;
        
    case 3:
        sprintf(szFormatedData,"%-10s|",szColumnData);
        break;

	case 4:
        sprintf(szFormatedData,"%-15s|",szColumnData);
        break;
        
    case 5:
        sprintf(szFormatedData,"%-10s|",szColumnData);
        break;
        
    case 6:
        sprintf(szFormatedData,"%-10s|",szColumnData);
        break;
        
    case 7:
        sprintf(szFormatedData,"%-15s|",szColumnData);
        break;
        
    case 8:
		FileSaveDataFrmStream(szColumnData,nRowIndex);
        sprintf(szFormatedData,"%-30s",szColumnData);
        break;
        
    case 9:
        sprintf(szFormatedData,"%-5s",szColumnData);
        break;
    }
    
    fputs(szFormatedData,pFile);
}

void DrawLine(FILE *pFile)
{
    fputs("\n",pFile);
    for(int nDrawIndex = 0;nDrawIndex < 150;nDrawIndex++)
    {
        fputs("-",pFile);
    }
}
void ResetGUIStatus(BOOL Filter, BOOL PeriodicMessages)
{
	int i,j;
	char profileBuffer[100];
	
	if(Filter == TRUE)
	{
            for (i=0;i<MAX_PX_SIZE;i++)
            {
				if(iProtocolsConnected[i][1] != 0)
					{
						sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[i][0]][0]);   
						strcat(profileBuffer," - Filter Msgs");
						for (j = 0;j<MAX_COLUMN;j++)
						{
							sprintf((char*)buttonstate, "ButtonState%d", j); 
							WritePrivateProfileString(profileBuffer, (char*)buttonstate,"&Start", path);
							ulFilterID[j] = 0;
						}	
					}
            }
	}
	if(PeriodicMessages == TRUE)
	{
			for (i=0;i<MAX_PX_SIZE;i++)
            {
				if(iProtocolsConnected[i][1] != 0)
					{
						sprintf((char*)profileBuffer,"%s", ProtocolList[iProtocolsConnected[i][0]][0]);   
						strcat(profileBuffer," - Periodic Msgs");
						for (j = 0;j<MAX_COLUMN;j++)
						{
							sprintf((char*)buttonstate, "ButtonState%d", j); 
							WritePrivateProfileString(profileBuffer, (char*)buttonstate,"&Start", path);
							ulPeriodicID[i] =0;
						}	
					}
            }
	}
}


void ReadPeoridicStatus(char *profileBuffer, HWND hDlg)
{
	char _text[100];
    char txflags[50];char cinterval[50];
	
    for(int i=0; i<MAX_COLUMN; i++)
    {
        sprintf((char *)tempbuf, "Msg%d", i);
        sprintf((char *)buttonstate, "ButtonState%d", i);
        sprintf((char *)txflags, "TxFlags%d", i);
        sprintf((char *)cinterval,"Interval%d", i);
        GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)pxmessages, 16384, path);
        GetPrivateProfileString(profileBuffer, (char*)txflags, NULL, (char*)_text, 100, path);
        
        if(strlen(_text))
            SetDlgItemText(hDlg,IDC_EDIT_TX1+i,(char*)_text);
        else
            SetDlgItemText(hDlg,IDC_EDIT_TX1+i,"0x00000000");

        GetPrivateProfileString(profileBuffer, (char*)cinterval, NULL, (char*)_text, 100, path);
        
        if(strlen(_text))
            SetDlgItemText(hDlg,IDC_EDIT_TI1+i,(char*)_text);
        else
            SetDlgItemText(hDlg,IDC_EDIT_TI1+i,"0");

        GetPrivateProfileString(profileBuffer, (char*)buttonstate, NULL, (char*)_text, 100, path);
        
        SetDlgItemText(hDlg,IDC_EDIT_P1+i,(char*)pxmessages);
    
        if(strcmp(_text ,"&Start") ==0)
        {
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P1+i),TRUE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TX1+i),TRUE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TI1+i),TRUE);
            SetDlgItemText(hDlg,IDC_BUTTON_TP1+i,"&Start");
        }
        else if(strcmp(_text ,"&Stop") ==0)
        {
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P1+i),FALSE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TX1+i),FALSE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TI1+i),FALSE);
            SetDlgItemText(hDlg,IDC_BUTTON_TP1+i,"&Stop");
        }
		/*jayasheela-get the periodicid's stored in a file */
		sprintf((char*)tempbuf, "PeriodicId%d", i); 
        GetPrivateProfileString(profileBuffer, (char*)tempbuf, NULL,(char*)_text, 100, path);
		SetDlgItemText(hDlg,IDC_STATIC1+i,_text);
    }

}

void WritePeoridicStatus(char *profileBuffer, HWND hDlg)
{
	char _text[100];
    char txflags[50];char cinterval[50];
	int i;

	WritePrivateProfileString(profileBuffer, NULL,NULL, path);    
	for (i=0;i<MAX_COLUMN;i++)
    {
        if(GetDlgItemText(hDlg, IDC_EDIT_P1+i, (char*)pxmessages, 16384))
        {
            sprintf((char*)tempbuf, "Msg%d", i); 
            sprintf((char *)txflags, "TxFlags%d", i);
            sprintf((char *)cinterval,"Interval%d", i);
            sprintf((char*)buttonstate, "ButtonState%d", i); 
            CheckAndConvertMsg((unsigned char *)pxmessages, tempmsg);
            WritePrivateProfileString(profileBuffer, (char*)tempbuf,(char*)pxmessages, path);
            GetDlgItemText(hDlg,IDC_EDIT_TX1+i,_text,10);
            WritePrivateProfileString(profileBuffer, (char*)txflags,(char*)_text, path);  
            GetDlgItemText(hDlg,IDC_EDIT_TI1+i,_text,10);
            WritePrivateProfileString(profileBuffer, (char*)cinterval,(char*)_text, path);
            GetDlgItemText(hDlg,IDC_BUTTON_TP1+i,_text,10);
            WritePrivateProfileString(profileBuffer, (char*)buttonstate,(char*)_text, path);  
			/*Jayasheela -store the filter id */
            sprintf((char *)tempbuf, "PeriodicId%d", i);
            GetDlgItemText(hDlg, IDC_STATIC1+i,_text,100);
            WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)_text,path);
        }
    }
}
void ReadFilterStatus(char* profileBuffer,HWND hDlg)
{
	int nFilType =0;
    char _text[100];
	for(int i=0; i<MAX_COLUMN; i++)
    {
        ComboBox_AddString(GetDlgItem(hDlg,IDC_COMBO1+i), "None");
        ComboBox_AddString(GetDlgItem(hDlg,IDC_COMBO1+i), "Pass");
        ComboBox_AddString(GetDlgItem(hDlg,IDC_COMBO1+i), "Block");
        ComboBox_AddString(GetDlgItem(hDlg,IDC_COMBO1+i), "Flow Control");
        ComboBox_SetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i),0);
        
        sprintf((char*)tempbuf, "MaskMsg%d", i); 
        GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)pxmessages, 16384, path);
        SetDlgItemText(hDlg,IDC_EDIT_P1+i,(char*)pxmessages);
        sprintf((char*)tempbuf, "PatternMsg%d", i); 
        GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)pxmessages, 16384, path);
		SetDlgItemText(hDlg,IDC_EDIT_P11+i,(char*)pxmessages);
		/*sprintf((char*)tempbuf, "FCMsg%d", i); 
		GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)pxmessages, 16384, path);
        SetDlgItemText(hDlg,IDC_EDIT_P11+i,(char*)pxmessages);*/
        sprintf((char*)tempbuf, "FilterType%d", i); 
        GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)_text, 100, path);
        
        if(strlen((char*)_text))
        {
            sscanf((char*)_text,"%d",&nFilType);
            ComboBox_SetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i),nFilType);
        }
        else
        {
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), FALSE);
        }
                    
        sprintf((char*)tempbuf, "FCMsg%d", i); 
        GetPrivateProfileString(profileBuffer, tempbuf, NULL, (char*)pxmessages, 16384, path);
        
        if(strlen((char*)pxmessages))
        {
            SetDlgItemText(hDlg,IDC_EDIT_P21+i,(char*)pxmessages);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), TRUE);
        }
        else
        {
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), FALSE);
        }
        
        sprintf((char *)tempbuf, "TxFlags%d", i);
        GetPrivateProfileString(profileBuffer, (char*)tempbuf, NULL, (char*)_text, 100, path);
        
        if(strlen(_text))
            SetDlgItemText(hDlg,IDC_EDIT_TX1+i,(char*)_text);
        else
            SetDlgItemText(hDlg,IDC_EDIT_TX1+i,"0x00000000");

        sprintf((char*)tempbuf, "ButtonState%d", i);

        GetPrivateProfileString(profileBuffer, (char*)tempbuf, NULL, (char*)_text, 100, path);
        
        if(strcmp(_text ,"&Start") ==0)
        {
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P1+i),TRUE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P11+i),TRUE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TX1+i),TRUE);
            EnableWindow(GetDlgItem(hDlg,IDC_COMBO1+i),TRUE);
			if(ComboBox_GetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i)) == 3)
				EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), TRUE);
            SetDlgItemText(hDlg,IDC_BUTTON_TP11 +i,"&Start");
        }
        else if(strcmp(_text ,"&Stop") ==0)
        {
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P1+i),FALSE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P11+i),FALSE);
            EnableWindow(GetDlgItem(hDlg,IDC_EDIT_TX1+i),FALSE);
            EnableWindow(GetDlgItem(hDlg,IDC_COMBO1+i),FALSE);
			EnableWindow(GetDlgItem(hDlg,IDC_EDIT_P21+i), FALSE);
            SetDlgItemText(hDlg,IDC_BUTTON_TP11 +i,"&Stop");
        }
		/*jayasheela-get the filterid's stored in a file */
		sprintf((char*)tempbuf, "FilterId%d", i); 
        GetPrivateProfileString(profileBuffer, (char*)tempbuf, NULL,(char*)_text, 100, path);
		SetDlgItemText(hDlg,IDC_STATIC1+i,_text);
    }

}

void WriteFilterStatus(char* profileBuffer,HWND hDlg)
{
	int nFilType =0;
    char _text[100];
	int i;
	
	WritePrivateProfileString(profileBuffer, NULL,NULL, path);  
	for (i=0;i<MAX_COLUMN;i++)
	{
		if(GetDlgItemText(hDlg, IDC_EDIT_P1+i,(char*)tempmsg, 16384))
		{
			if(GetDlgItemText(hDlg, IDC_EDIT_P11+i,(char*)tempmsg2, 16384))
			{
				CheckAndConvertMsg(tempmsg, tempstr);
				sprintf((char*)tempbuf, "MaskMsg%d", i); 
				WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)tempmsg, path);
				CheckAndConvertMsg(tempmsg2, tempstr);
				sprintf((char*)tempbuf, "PatternMsg%d", i); 
				WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)tempmsg2, path);
				nFilType = ComboBox_GetCurSel(GetDlgItem(hDlg,IDC_COMBO1+i));
				if(nFilType == 3)
				{
					if(GetDlgItemText(hDlg, IDC_EDIT_P21+i, (char*)tempmsg, 16384))
					{
						CheckAndConvertMsg(tempmsg, tempstr);
						sprintf((char*)tempbuf, "FCMsg%d", i); 
						WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)tempmsg, path);
					}
				}
				sprintf((char *)tempbuf, "TxFlags%d", i);
				GetDlgItemText(hDlg, IDC_EDIT_TX1+i,(char*)_text, 100);
				WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)_text,path);
				sprintf((char *)tempbuf, "FilterType%d", i);
				sprintf((char*)_text, "%d",nFilType);
				WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)_text, path);
				GetDlgItemText(hDlg,IDC_BUTTON_TP11+i,_text,100);
				sprintf((char*)tempbuf, "ButtonState%d", i);
				WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)_text, path);
				/*Jayasheela -store the filter id */
				sprintf((char *)tempbuf, "FilterId%d", i);
				GetDlgItemText(hDlg, IDC_STATIC1+i,_text,100);
				WritePrivateProfileString(profileBuffer,(char*)tempbuf,(char*)_text,path);
			}
		}
	}
	
	
}
