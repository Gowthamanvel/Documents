#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <dbus/dbus-glib-lowlevel.h>
#include <data_logger.h>
#include "bt_spp.h"
#include	"hfcp.h"
#include	"g3d.h"
#define PROFILE_PATH "/garuda3/bluetooth/spp"
#define PROFILE_UUID "00001101-0000-1000-8000-00805F9B34FB"
#define AGENT_PATH "/garuda3/bluetooth/agent"
#define AGENT_CAPABILITY "NoInputNoOutput"
#define INTERFACE "org.bluez.Agent1"

struct bt_spp_ctx *spp_ctx = NULL;
DBusConnection *conn = NULL;

static void dbus_check_and_log_error(DBusError *error)
{
	if (dbus_error_is_set(error))
	{
	//	fprintf(stderr, "D-Bus Error: %s\n", error->message);
		dbus_error_free(error);
	}
}

static DBusHandlerResult agent_method_handler(DBusConnection *conn,
		DBusMessage *msg,
		void *user_data)
{
	const char *iface = INTERFACE;

	if (dbus_message_is_method_call(msg, iface, "AuthorizeService"))
	{
		const char *device;
		const char *uuid;

		if (!dbus_message_get_args(msg, NULL,
					DBUS_TYPE_OBJECT_PATH, &device,
					DBUS_TYPE_STRING, &uuid,
					DBUS_TYPE_INVALID))
		{
			return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
		}

		DBG("Agent: AuthorizeService UUID=%s\n", uuid);

		/* Accept ONLY SPP */
		if (!strcasecmp(uuid, PROFILE_UUID))
		{
			DBG("Agent: SPP service authorized\n");
			DBusMessage *reply = dbus_message_new_method_return(msg);
			dbus_connection_send(conn, reply, NULL);
			dbus_message_unref(reply);
		}
		else
		{
			DBG("Agent: Rejecting non-SPP service\n");
			DBusMessage *err =
				dbus_message_new_error(msg,
						"org.bluez.Error.Rejected",
						"Service not allowed");
			dbus_connection_send(conn, err, NULL);
			dbus_message_unref(err);
		}

		return DBUS_HANDLER_RESULT_HANDLED;
	}

	/* -------- Pairing confirmation (NoInputNoOutput) -------- */
	if (dbus_message_is_method_call(msg, iface, "RequestConfirmation") ||
			dbus_message_is_method_call(msg, iface, "RequestAuthorization"))
	{
		DBG("Agent: Pairing confirmation accepted\n");

		DBusMessage *reply = dbus_message_new_method_return(msg);
		dbus_connection_send(conn, reply, NULL);
		dbus_message_unref(reply);
		return DBUS_HANDLER_RESULT_HANDLED;
	}

	if (dbus_message_is_method_call(msg, iface, "Cancel") ||
			dbus_message_is_method_call(msg, iface, "Release"))
	{
		DBusMessage *reply = dbus_message_new_method_return(msg);
		dbus_connection_send(conn, reply, NULL);
		dbus_message_unref(reply);
		return DBUS_HANDLER_RESULT_HANDLED;
	}

	return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

static const DBusObjectPathVTable agent_vtable = {
	.message_function = agent_method_handler,
};

static void register_agent_path(DBusConnection *conn)
{
	dbus_connection_register_object_path(conn, AGENT_PATH, &agent_vtable, NULL);
}

static int bt_register_agent(DBusConnection *conn)
{
	DBusMessage *msg;
	DBusError error;
	const char *path = AGENT_PATH;
	const char *cap = AGENT_CAPABILITY;
	dbus_error_init(&error);

	/* RegisterAgent */
	msg = dbus_message_new_method_call(
			"org.bluez",
			"/org/bluez",
			"org.bluez.AgentManager1",
			"RegisterAgent");

	dbus_message_append_args(msg,
			DBUS_TYPE_OBJECT_PATH, &path,
			DBUS_TYPE_STRING, &cap,
			DBUS_TYPE_INVALID);

	DBusMessage *reply = dbus_connection_send_with_reply_and_block(conn, msg, -1, &error);
	dbus_message_unref(msg);
	if (!reply)
		return -1;
	dbus_message_unref(reply);

	/* RequestDefaultAgent */
	msg = dbus_message_new_method_call(
			"org.bluez",
			"/org/bluez",
			"org.bluez.AgentManager1",
			"RequestDefaultAgent");

	dbus_message_append_args(msg,
			DBUS_TYPE_OBJECT_PATH, &path,
			DBUS_TYPE_INVALID);

	reply = dbus_connection_send_with_reply_and_block(conn, msg, -1, &error);
	dbus_message_unref(msg);
	if (!reply)
		return -1;
	dbus_message_unref(reply);

	DBG("Agent registered (NoInputNoOutput)\n");
	return 0;
}

/* Handles RFCOMM socket I/O events and forwards received data to the RX callback */
static gboolean spp_rfcomm_io_handler(GIOChannel *source,
		GIOCondition condition,
		gpointer user_data)
{
	struct bt_spp_ctx *ctx = user_data;

	if (condition & G_IO_IN)
	{
		char buf[1024];
		gsize bytes_read = 0;
		GError *error = NULL;

		GIOStatus status = g_io_channel_read_chars(
				source,
				buf,
				sizeof(buf),
				&bytes_read,
				&error);

		if (status == G_IO_STATUS_NORMAL && bytes_read > 0)
		{
			buf[bytes_read] = '\0';
			if (ctx->rx_cb)
				ctx->rx_cb(buf, bytes_read);
		}
		else if (status == G_IO_STATUS_EOF)
		{
			DBG("SPP disconnected (EOF)\n");
			ctx->fd = -1;
			ctx->watch_id = 0;
			g_io_channel_shutdown(spp_ctx->channel, TRUE, NULL);
			spp_ctx->channel = NULL;
			return FALSE;
		}
		else if (status == G_IO_STATUS_ERROR)
		{
		//	DBG("GIOChannel error: %s\n", error->message);
			g_error_free(error);
			ctx->fd = -1;
			ctx->watch_id = 0;
			g_io_channel_shutdown(spp_ctx->channel, TRUE, NULL);
			spp_ctx->channel = NULL;
			return FALSE;
		}
	}

	if (condition & (G_IO_HUP | G_IO_ERR))
	{
		DBG("SPP disconnected (HUP/ERR)\n");
		ctx->fd = -1;
		ctx->watch_id = 0;
		return FALSE;
	}

	return TRUE;
}

/* ================= DBus method handling ================= */
static DBusHandlerResult spp_profile_method_handler(DBusConnection *conn,
		DBusMessage *msg, void *user_data)
{
	DBusMessageIter args;
	int fd = -1;

	if (dbus_message_is_method_call(msg, "org.bluez.Profile1", "Release"))
	{
		DBG("Profile Release called. Cleaning up...\n");
		DBusMessage *reply = dbus_message_new_method_return(msg);
		dbus_connection_send(conn, reply, NULL);
		dbus_message_unref(reply);
		spp_ctx->fd = -1;
		g_io_channel_shutdown(spp_ctx->channel, TRUE, NULL);
		g_io_channel_unref(spp_ctx->channel);
		spp_ctx->channel = NULL;
		return DBUS_HANDLER_RESULT_HANDLED;
	}
	else if (dbus_message_is_method_call(msg, "org.bluez.Profile1", "NewConnection"))
	{
		// Extract args: device, fd, properties
		dbus_message_iter_init(msg, &args);

		const char *device_path;
		dbus_message_iter_get_basic(&args, &device_path);

		// Move to next arg (fd)
		dbus_message_iter_next(&args);

		if (dbus_message_iter_get_arg_type(&args) == DBUS_TYPE_UNIX_FD)
		{
			dbus_message_iter_get_basic(&args, &fd);
		}
		else
		{
			DBG("Expected UNIX_FD but got %d\n", dbus_message_iter_get_arg_type(&args));
			return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
		}
		if (!spp_ctx)
		{
			DBG("Error: SPP is not initialized\n");
			return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
		}

		spp_ctx->fd = fd;

		// Reply OK
		DBusMessage *reply = dbus_message_new_method_return(msg);
		dbus_connection_send(conn, reply, NULL);
		dbus_message_unref(reply);

		if (spp_ctx->fd >= 0)
		{
			DBG("\nNew Connection established %d\n", spp_ctx->fd);
			spp_ctx->channel = g_io_channel_unix_new(spp_ctx->fd);
			g_io_channel_set_encoding(spp_ctx->channel, NULL, NULL);
			g_io_channel_set_buffered(spp_ctx->channel, FALSE);
	 		HFCP_setApplicationMode(GARUDA_IN_BT_MODE);
			spp_ctx->watch_id = g_io_add_watch(
					spp_ctx->channel,
					G_IO_IN | G_IO_HUP | G_IO_ERR,
					spp_rfcomm_io_handler,
					spp_ctx);
		}
		return DBUS_HANDLER_RESULT_HANDLED;
	}
	return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
}

static const DBusObjectPathVTable spp_profile_vtable = {
	.message_function = spp_profile_method_handler,
};

/* Registers the SPP profile object path on the system DBus */
void register_spp_profile_path(DBusConnection *conn)
{
	dbus_connection_register_object_path(conn, PROFILE_PATH, &spp_profile_vtable, NULL);
}

/* Registers the Serial Port Profile (SPP) with BlueZ */
static int bt_register_spp_profile(DBusConnection *conn)
{
//	DBusError error;
	DBusMessage *msg;
	DBusMessageIter args, dict, entry, variant;
	const char *path = PROFILE_PATH;
	const char *uuid = PROFILE_UUID;

	//dbus_error_init(&error);

	msg = dbus_message_new_method_call(
			"org.bluez",
			"/org/bluez",
			"org.bluez.ProfileManager1",
			"RegisterProfile");

	if (!msg)
	{
		DBG("Error: Failed to create message.\n");
		return 1;
	}

	dbus_message_iter_init_append(msg, &args);
	dbus_message_iter_append_basic(&args, DBUS_TYPE_OBJECT_PATH, &path);
	dbus_message_iter_append_basic(&args, DBUS_TYPE_STRING, &uuid);

	/* a{sv} container */
	dbus_message_iter_open_container(&args, DBUS_TYPE_ARRAY, "{sv}", &dict);

	/* Channel */
	dbus_message_iter_open_container(&dict, DBUS_TYPE_DICT_ENTRY, NULL, &entry);
	const char *k_channel = "Channel";
	dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &k_channel);
	dbus_message_iter_open_container(&entry, DBUS_TYPE_VARIANT, "q", &variant);
	dbus_uint16_t channel = 22;
	dbus_message_iter_append_basic(&variant, DBUS_TYPE_UINT16, &channel);
	dbus_message_iter_close_container(&entry, &variant);
	dbus_message_iter_close_container(&dict, &entry);

	/* Name */
	dbus_message_iter_open_container(&dict, DBUS_TYPE_DICT_ENTRY, NULL, &entry);
	const char *k_name = "Name";
	dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &k_name);
	dbus_message_iter_open_container(&entry, DBUS_TYPE_VARIANT, "s", &variant);
	const char *name = "Serial Port";
	dbus_message_iter_append_basic(&variant, DBUS_TYPE_STRING, &name);
	dbus_message_iter_close_container(&entry, &variant);
	dbus_message_iter_close_container(&dict, &entry);

	/* Role = server */
	dbus_message_iter_open_container(&dict, DBUS_TYPE_DICT_ENTRY, NULL, &entry);
	const char *k_role = "Role";
	dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &k_role);
	dbus_message_iter_open_container(&entry, DBUS_TYPE_VARIANT, "s", &variant);
	const char *role = "server";
	dbus_message_iter_append_basic(&variant, DBUS_TYPE_STRING, &role);
	dbus_message_iter_close_container(&entry, &variant);
	dbus_message_iter_close_container(&dict, &entry);

	/* Service (UUID) */
	dbus_message_iter_open_container(&dict, DBUS_TYPE_DICT_ENTRY, NULL, &entry);
	const char *k_service = "Service";
	dbus_message_iter_append_basic(&entry, DBUS_TYPE_STRING, &k_service);
	dbus_message_iter_open_container(&entry, DBUS_TYPE_VARIANT, "s", &variant);
	dbus_message_iter_append_basic(&variant, DBUS_TYPE_STRING, &uuid);
	dbus_message_iter_close_container(&entry, &variant);
	dbus_message_iter_close_container(&dict, &entry);

	dbus_message_iter_close_container(&args, &dict);

	DBusMessage *reply = dbus_connection_send_with_reply_and_block(conn, msg, -1, NULL);
	if (reply)
	{
		DBG("Profile registered successfully.\n");
		dbus_message_unref(reply);
	}
//	dbus_check_and_log_error(&error);

	return 0;
}

/* Writes data to the active SPP RFCOMM connection */
ssize_t bt_spp_write(const void *data, size_t len)
{
	if (!spp_ctx || spp_ctx->fd < 0)
	{
		DBG("Error: Write failed no active connection\n");
		return -1;
	}

	ssize_t ret = write(spp_ctx->fd, data, len);

	hexdump("bt_spp_write:",data,len,1);

	if (ret < 0)
		DBG("write:");
	return ret;
}

#define	SPP_RECVBUF_SIZE		512

static int recvd_len = 0;
int count =1;
int length =0;
/* Default application callback for processing received SPP data */
static void spp_rx_data_callback(const char *data, int len)
{
	static uint8_t recvbuf[SPP_RECVBUF_SIZE]={0};

	DBG("%d %s\n", len, data);
	
	// printf("Length :%d\n",len);

	if (len >= 256 && count == 1) {
		memcpy(recvbuf, data, 256);
		count=2;
	} else if(len > 0 && count == 2) 	{
		memcpy(recvbuf + 256, data, len);
		hexdump("BT-RD", recvbuf, len+256, 1);
		handle_hfcp_rx((uint8_t*)recvbuf,len+256);
		memset(recvbuf, 0x00, len+256);
		count=1;
		goto done;
	}

	if (len < 256 && count==1) {
		hexdump("Under BT-RD", data, len, 1);
		DBG("hfcp entered in rx pipeline!\n");
		handle_hfcp_rx((const uint8_t*)data,len);
	}
	

	done:
	fflush(stdout);
}

/* Initializes DBus, registers the SPP profile, and starts the GLib main loop */
int bt_spp_init(void)
{
//	DBusError error;

//	dbus_error_init(&error);
	conn = dbus_bus_get(DBUS_BUS_SYSTEM, NULL);

	if (!conn)
	{
	//	DBG("Failed to connect to system bus: %s\n", error.message);
		return 1;
	}
	dbus_connection_setup_with_g_main(conn, NULL);

	register_agent_path(conn);
	if (bt_register_agent(conn) != 0) {
		DBG("Failed to register agent\n");
		return 1;
	}

	register_spp_profile_path(conn);

	if (!spp_ctx)
	{
		spp_ctx = malloc(sizeof(struct bt_spp_ctx));
		if (!spp_ctx)
 		{
			DBG("ERROR: failed to allocate memory spp_ctx\n");
			return 1;
		}
		spp_ctx->fd = -1;
		spp_ctx->rx_cb = spp_rx_data_callback;
		DBG("spp_rx handle passed!\n");
	}
	if (bt_register_spp_profile(conn) != 0)
		{
			DBG("bt register failed!\n");
			return 1;
		}
	return 0;

}

/* Cleans up SPP resources, and closes connections */
void bt_spp_deinit(void)
{
	if (spp_ctx)
	{
		if (spp_ctx->watch_id > 0)
		{
			g_source_remove(spp_ctx->watch_id);
			spp_ctx->watch_id = 0;
		}

		if (spp_ctx->channel)
		{
			g_io_channel_shutdown(spp_ctx->channel, TRUE, NULL);
			g_io_channel_unref(spp_ctx->channel);
			spp_ctx->channel = NULL;
		}

		if (spp_ctx->fd >= 0)
		{
			close(spp_ctx->fd);
			spp_ctx->fd = -1;
		}

		free(spp_ctx);
		spp_ctx = NULL;
	}

	if (conn)
	{
		dbus_connection_unref(conn);
		conn = NULL;
	}

	DBG("SPP deinitialized\n");
}

/* Returns whether an SPP connection is currently active */
uint8_t bt_spp_is_connected(void)
{
	return (spp_ctx->fd > 0) ? 1u : 0u;
}

int bt_deinit()
{
	bt_spp_deinit();
   return 0;
}

int bt_init()
{
	if (bt_spp_init() != 0)
	{
		DBG("Failed to register SPP profile\n");
		 HFCP_setApplicationMode(GARUDA_IN_DEFAULT_MODE);
	}
	else
		{
			DBG("SPP profile registered successfully.\n");
			// HFCP_setApplicationMode(GARUDA_IN_BT_MODE);
		}
	return 0;
}

