#ifndef BT_SPP_H
#define BT_SPP_H

#include <stddef.h>
#include <stdint.h>
#include <dbus/dbus.h>

typedef void (*data_callback_t)(const char *data, int len);

static GMainLoop *glib_main_loop = NULL;

struct bt_spp_ctx {
	int fd;
	GIOChannel *channel;
	guint watch_id;
	void (*rx_cb)(const char *data, int len);
};

int bt_spp_init(void);
void bt_spp_handle_profile_messages(DBusConnection *conn);
void bt_spp_deinit(void);

/* Write data to the connected SPP device */
ssize_t bt_spp_write(const void *data, size_t len);

/* checks if connection exists */
uint8_t bt_spp_is_connected(void);

int bt_init();
int bt_deinit();

#endif
