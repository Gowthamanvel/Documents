#!/bin/sh

GPIO=30
GPIONAME=PA30
ETHIF=eth0
CANIF=can0

if [ ! -d /sys/class/gpio/${GPIONAME} ]; then
    echo $GPIO > /sys/class/gpio/export
fi

# Set as input
echo in > /sys/class/gpio/${GPIONAME}/direction

# Read initial state
# $(cat /sys/class/gpio/${GPIONAME}/value)
prev_obdpowered=0

while true; do
    obdpowered=$(cat /sys/class/gpio/${GPIONAME}/value)
    if [ ${obdpowered} != ${prev_obdpowered} ]; then
    	# OBD power changed state
    	if [ ${obdpowered} == 1 ]; then
	        echo "OBD Power (PA30) went from 0 to 1 → restarting ${ETHIF}"
    		ifconfig ${ETHIF} down
		rmmod macb micrel
	        modprobe macb micrel
		ip link set ${CANIF} up type can bitrate 500000 sample-point 0.875 restart 200ms
    		ifconfig ${ETHIF} up
    	else
	        echo "OBD Power (PA30) went from 1 to 0 → downing ${ETHIF}"
		ip link set ${CANIF} down
    		ifconfig ${ETHIF} down
    		rmmod macb micrel
    	fi
    	prev_obdpowered=${obdpowered}
    fi
    sleep 1
done

