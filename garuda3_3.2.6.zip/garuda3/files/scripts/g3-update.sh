#!/bin/sh
#
# Copyright (c) 2023, Capgemini - Intelligent Devices
#
NEW_ITB=/boot/sama5d29_garuda3.itb.new
RUN_ITB=/boot/sama5d29_garuda3.itb

echo "Running g3-update"

if [ ! -f ${RUN_ITB} ]; then
	echo "No running LINUX ITB image file present"
	exit 1
fi

if [ ! -f ${NEW_ITB} ]; then
	echo "No update available"
	exit 0
fi
sync

mv "${RUN_ITB}" "${RUN_ITB}.prev"
mv "${NEW_ITB}" "${RUN_ITB}"

sync

reboot

exit 0

