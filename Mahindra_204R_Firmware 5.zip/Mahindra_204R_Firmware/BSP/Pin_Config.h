/**
******************************************************************************
* @file    iar_stm32f407zg_sk.h
* @brief   This file contains definitions for Leds, push-buttons
*          and COM ports hardware resources.
******************************************************************************
* @copy
*
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
* TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
* DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*
* <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
*/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __PIN_CONFIG_H
#define __PIN_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif
  
  /* Includes ------------------------------------------------------------------*/
  
  typedef enum
  {
    WIFI = 0,
    DL_MODE = 1,
    LINK = 2,
    TEST = 3
  } Led_TypeDef;
  
  
  typedef enum
  {
    CAN_CH1 = 0,
    CAN_CH2 = 1
  } CAN_CH_TypeDef;
  
  typedef enum
  {
    /*UART 1 and 6 are on APB 2 - Changes to be done in UART_MidInit*/
    DEBUG_UART_CH = 0,
    GPRS_UART_CH,
    KWP_UART_CH
  } UART_CH_TypeDef;
  
#define LEDn                             4
  
#define LED1_PIN                         GPIO_Pin_12
#define LED1_GPIO_PORT                   GPIOD
#define LED1_GPIO_CLK                    RCC_AHB1Periph_GPIOD
  
#define LED2_PIN                         GPIO_Pin_13
#define LED2_GPIO_PORT                   GPIOD
#define LED2_GPIO_CLK                    RCC_AHB1Periph_GPIOD
  
#define LED3_PIN                         GPIO_Pin_14
#define LED3_GPIO_PORT                   GPIOD
#define LED3_GPIO_CLK                    RCC_AHB1Periph_GPIOD
  
#define LED4_PIN                         GPIO_Pin_15
#define LED4_GPIO_PORT                   GPIOD
#define LED4_GPIO_CLK                    RCC_AHB1Periph_GPIOD
  /*
  
#define SPIx                           SPI1
#define SPIx_CLK                       RCC_APB2Periph_SPI1
#define SPIx_CLK_INIT                  RCC_APB2PeriphClockCmd
  
#define SPIx_SCK_PIN                   GPIO_Pin_5
#define SPIx_SCK_GPIO_PORT             GPIOA
#define SPIx_SCK_GPIO_CLK              RCC_AHB1Periph_GPIOA
#define SPIx_SCK_SOURCE                GPIO_PinSource5
#define SPIx_SCK_AF                    GPIO_AF_SPI1
  
#define SPIx_MISO_PIN                  GPIO_Pin_6
#define SPIx_MISO_GPIO_PORT            GPIOA
#define SPIx_MISO_GPIO_CLK             RCC_AHB1Periph_GPIOA
#define SPIx_MISO_SOURCE               GPIO_PinSource6
#define SPIx_MISO_AF                   GPIO_AF_SPI1
  
#define SPIx_MOSI_PIN                  GPIO_Pin_7
#define SPIx_MOSI_GPIO_PORT            GPIOA
#define SPIx_MOSI_GPIO_CLK             RCC_AHB1Periph_GPIOA
#define SPIx_MOSI_SOURCE               GPIO_PinSource7
#define SPIx_MOSI_AF                   GPIO_AF_SPI1
  
#define SPIx_CS_PIN                    GPIO_Pin_4
#define SPIx_CS_GPIO_PORT              GPIOA
#define SPIx_CS_GPIO_CLK               RCC_AHB1Periph_GPIOA
#define SPIx_CS_SOURCE                 GPIO_PinSource4
#define SPIx_CS_AF                     GPIO_AF_SPI1  
  
#define SPIx_DMA                       DMA2
#define SPIx_DMA_CLK                   RCC_AHB1Periph_DMA2
#define SPIx_TX_DMA_CHANNEL            DMA_Channel_3
#define SPIx_TX_DMA_STREAM             DMA2_Stream5
#define SPIx_TX_DMA_IT_TCIF            DMA_IT_TCIF5
#define SPIx_RX_DMA_CHANNEL            DMA_Channel_3
#define SPIx_RX_DMA_STREAM             DMA2_Stream2
#define SPIx_RX_DMA_IT_TCIF            DMA_IT_TCIF2
#define SPIx_TX_DMA_IRQ_CH             DMA2_Stream5_IRQn
#define SPIx_RX_DMA_IRQ_CH             DMA2_Stream2_IRQn
  
  
#define SPIx_TX_DMA_IRQ             DMA2_Stream5_IRQHandler
#define SPIx_RX_DMA_IRQ             DMA2_Stream2_IRQHandler
  */
  
#define SPI_SN8200                      LPC_SSP1                  
#define SPI_CLK_PORT                    0x3                     
#define SPI_CLK_PIN                     3 
#define SPI_CLK_SCU_MODE_FUNC           (SCU_PINIO_FAST | SCU_MODE_FUNC2)
#define SPI_MOSI_PORT                   0x3                                   
#define SPI_MOSI_PIN                    7  
#define SPI_MOSI_SCU_MODE_FUNC          (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC5)        
#define SPI_MISO_PORT                   0x3                
#define SPI_MISO_PIN                    6  
#define SPI_MISO_SCU_MODE_FUNC          (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC5)        
#define SPI_CSEL_PORT                   0x3
#define SPI_CSEL_PIN                    8 
#define SPI_CSEL_SCU_MODE_FUNC          (SCU_PINIO_FAST | SCU_MODE_FUNC5)
  
#define EXT_INT_SN8200_PORT             0x02//0x03  //P3_5 GPIO1[15]
#define EXT_INT_SN8200_PIN              2   
#define EXT_INT_PORT                    0x05  //P3_5 GPIO1[15]
#define EXT_INT_PIN                     2
    
#define EXT_INT_SN8200_SCU_MODE_FUNC    (SCU_PINIO_FAST | SCU_MODE_FUNC4)
#define EXT_INT_SN8200_CH               5
#define EXT_INT_IRQ_CH                  PIN_INT5_IRQn
#define EXT_INT_IRQ                     GPIO5_IRQHandler
  
#define SN8200_RESET_PORT               6//0x04  //( P6_9 GPIO3[5]
#define SN8200_RESET_PIN                9//3 

#define SN8200_RESET_GPIO_PORT          3//0x04  //( P6_9 GPIO3[5]
#define SN8200_RESET_GPIO_PIN           5  
  
#define SN8200_RESET_SCU_MODE_FUNC    (SCU_PINIO_FAST | SCU_MODE_FUNC0)
  
#define SPI_TX_DMA_CH                   2//10  
#define SPI_TX_DMA_PERIPH_CONN_ID       GPDMA_CONN_SSP1_Tx
#define SPI_RX_DMA_CH                   3//9    
#define SPI_RX_DMA_PERIPH_CONN_ID       GPDMA_CONN_SSP1_Rx
//  
//#define SPIx                           SPI2
//#define SPIx_CLK                       RCC_APB1Periph_SPI2
//#define SPIx_CLK_INIT                  RCC_APB1PeriphClockCmd
//#define SPIx_IRQn                      SPI2_IRQn
//#define SPIx_IRQHANDLER                SPI2_IRQHandler
//  
//#define SPIx_SCK_PIN                   GPIO_Pin_13
//#define SPIx_SCK_GPIO_PORT             GPIOB
//#define SPIx_SCK_GPIO_CLK              RCC_AHB1Periph_GPIOB
//#define SPIx_SCK_SOURCE                GPIO_PinSource13
//#define SPIx_SCK_AF                    GPIO_AF_SPI2
//  
//#define SPIx_MISO_PIN                  GPIO_Pin_14
//#define SPIx_MISO_GPIO_PORT            GPIOB
//#define SPIx_MISO_GPIO_CLK             RCC_AHB1Periph_GPIOB
//#define SPIx_MISO_SOURCE               GPIO_PinSource14
//#define SPIx_MISO_AF                   GPIO_AF_SPI2
//  
//#define SPIx_MOSI_PIN                  GPIO_Pin_15
//#define SPIx_MOSI_GPIO_PORT            GPIOB
//#define SPIx_MOSI_GPIO_CLK             RCC_AHB1Periph_GPIOB
//#define SPIx_MOSI_SOURCE               GPIO_PinSource15
//#define SPIx_MOSI_AF                   GPIO_AF_SPI2
//  
//#define SPIx_CS_PIN                    GPIO_Pin_12
//#define SPIx_CS_GPIO_PORT              GPIOB 
//#define SPIx_CS_GPIO_CLK               RCC_AHB1Periph_GPIOB
//#define SPIx_CS_SOURCE                 GPIO_PinSource12
//#define SPIx_CS_AF                     GPIO_AF_SPI2       
//  
//#define SPIx_DMA                       DMA1
//#define SPIx_DMA_CLK                   RCC_AHB1Periph_DMA1
//#define SPIx_TX_DMA_CHANNEL            DMA_Channel_0
//#define SPIx_TX_DMA_STREAM             DMA1_Stream4
//#define SPIx_TX_DMA_IT_TCIF            DMA_IT_TCIF4
//#define SPIx_TX_DMA_FLAG_TCIF          DMA_FLAG_TCIF4
//#define SPIx_RX_DMA_CHANNEL            DMA_Channel_0
//#define SPIx_RX_DMA_STREAM             DMA1_Stream3
//#define SPIx_RX_DMA_IT_TCIF            DMA_IT_TCIF3
//  
//  
//#define SPIx_TX_DMA_IRQ_CH             DMA1_Stream4_IRQn
//#define SPIx_RX_DMA_IRQ_CH             DMA1_Stream3_IRQn
//  
//  
//#define SPIx_TX_DMA_IRQ                DMA1_Stream4_IRQHandler
//#define SPIx_RX_DMA_IRQ                DMA1_Stream3_IRQHandler
//  
//  
//#define EXT_INT_GPIO                   GPIO_Pin_0
//#define EXT_INT_PORT                   GPIOB
//#define EXT_INT_CLK                    RCC_AHB1Periph_GPIOB
//#define EXT_INT_PIN_SOURCE             EXTI_PortSourceGPIOB
//#define EXT_INT_PIN                    EXTI_PinSource0
//#define EXT_INT_LINE                   EXTI_Line0  
//#define EXT_INT_IRQ                    EXTI0_IRQHandler
//#define EXT_INT_IRQ_CH                 EXTI0_IRQn
#if  ST32F4_PLATFORM
/*----------------------------------------------------------------------------*/  
  
  /** @addtogroup IAR_STM32F407ZG_SK_LOW_LEVEL_COM
  * @{
  */
#define UARTn                            6
 
  
  
  /**
  * @brief Definition for COM port1, connected to USART6
  */
#define DEBUG_UART                        USART6
#define DEBUG_UART_CLK                    RCC_APB2Periph_USART6
#define DEBUG_UART_TX_PIN                 GPIO_Pin_6
#define DEBUG_UART_TX_GPIO_PORT           GPIOC
#define DEBUG_UART_TX_GPIO_CLK            RCC_AHB1Periph_GPIOC
#define DEBUG_UART_TX_SOURCE              GPIO_PinSource6
#define DEBUG_UART_TX_AF                  GPIO_AF_USART6
#define DEBUG_UART_RX_PIN                 GPIO_Pin_7
#define DEBUG_UART_RX_GPIO_PORT           GPIOC
#define DEBUG_UART_RX_GPIO_CLK            RCC_AHB1Periph_GPIOC
#define DEBUG_UART_RX_SOURCE              GPIO_PinSource7
#define DEBUG_UART_RX_AF                  GPIO_AF_USART6
#define DEBUG_UART_IRQn                   USART6_IRQn
  
  /**
  * @brief Definition for COM port2, connected to USART3
  */
#define GPRS_UART                        USART3
#define GPRS_UART_CLK                    RCC_APB1Periph_USART3
#define GPRS_UART_TX_PIN                 GPIO_Pin_8
#define GPRS_UART_TX_GPIO_PORT           GPIOD
#define GPRS_UART_TX_GPIO_CLK            RCC_AHB1Periph_GPIOD
#define GPRS_UART_TX_SOURCE              GPIO_PinSource8
#define GPRS_UART_TX_AF                  GPIO_AF_USART3
#define GPRS_UART_RX_PIN                 GPIO_Pin_9
#define GPRS_UART_RX_GPIO_PORT           GPIOD
#define GPRS_UART_RX_GPIO_CLK            RCC_AHB1Periph_GPIOD
#define GPRS_UART_RX_SOURCE              GPIO_PinSource9
#define GPRS_UART_RX_AF                  GPIO_AF_USART3
#define GPRS_UART_RTS_PIN                GPIO_Pin_12
#define GPRS_UART_RTS_GPIO_PORT          GPIOD
#define GPRS_UART_RTS_GPIO_CLK           RCC_AHB1Periph_GPIOD
#define GPRS_UART_RTS_SOURCE             GPIO_PinSource12
#define GPRS_UART_RTS_AF                 GPIO_AF_USART3
#define GPRS_UART_CTS_PIN                GPIO_Pin_11
#define GPRS_UART_CTS_GPIO_PORT          GPIOD
#define GPRS_UART_CTS_GPIO_CLK           RCC_AHB1Periph_GPIOD
#define GPRS_UART_CTS_SOURCE             GPIO_PinSource11
#define GPRS_UART_CTS_AF                 GPIO_AF_USART3
#define GPRS_UART_IRQn                   USART3_IRQn
 
/*----------------------------------------------------------------------------*/  
#endif
  

#define UARTn                            4

#define DEBUG_UART                        LPC_USART0
#define DEBUG_UART_TX_PIN                 4//5//4
#define DEBUG_UART_TX_PORT                6//9//6 
#define DEBUG_UART_TX_MODE_FUNC           (SCU_MODE_PULLDOWN | SCU_MODE_FUNC2) // SCU_MODE_FUNC7)  //SCU_MODE_FUNC2

#define DEBUG_UART_RX_PIN                 5//6//5
#define DEBUG_UART_RX_PORT                6//9//6 
#define DEBUG_UART_RX_MODE_FUNC           (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC2)//SCU_MODE_FUNC7) //SCU_MODE_FUNC2
#define DEBUG_UART_IRQn                   USART0_IRQn  
  
#define GPRS_UART                        LPC_USART2
#define GPRS_UART_TX_PIN                 1
#define GPRS_UART_TX_PORT                7 
#define GPRS_UART_TX_MODE_FUNC           (SCU_MODE_PULLDOWN | SCU_MODE_FUNC2)

#define GPRS_UART_RX_PIN                 2
#define GPRS_UART_RX_PORT                7
#define GPRS_UART_RX_MODE_FUNC           (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_ZIF_DIS | SCU_MODE_FUNC2)
#define GPRS_UART_IRQn                   USART2_IRQn  
  
  /**
  * @BUZZER
  */
#define BUZZER_GPIO_PIN                  GPIO_Pin_10
#define BUZZER_GPIO_PORT                 GPIOA
#define BUZZER_GPIO_CLK                  RCC_AHB1Periph_GPIOA
#define BUZZER_PIN_SOURCE                GPIO_PinSource10
#define BUZZER_TIM                       TIM1
#define RCC_APB2PERIPH_BUZZER_TIM        RCC_APB2Periph_TIM1
#define BUZZER_PIN_AF                    GPIO_AF_TIM1
  
  /**
  * @USB OTG
  */
#define OTG_FS_VBUS_PIN                    GPIO_Pin_9
#define OTG_FS_VBUS_PORT                   GPIOA
#define OTG_FS_VBUS_CLK                    RCC_AHB1Periph_GPIOA
#define OTG_FS_VBUS_SOURCE                 GPIO_PinSource9
  
#define USB_FS_VBUSON_PIN                  GPIO_Pin_2
#define USB_FS_VBUSON_PORT                 GPIOC
#define USB_FS_VBUSON_CLK                  RCC_AHB1Periph_GPIOC
#define USB_FS_VBUSON_SOURCE               GPIO_PinSource2
  
#define USB_FS_FAULT_PIN                   GPIO_Pin_10
#define USB_FS_FAULT_PORT                  GPIOB
#define USB_FS_FAULT_CLK                   RCC_AHB1Periph_GPIOB
#define USB_FS_FAULT_SOURCE                GPIO_PinSource10
  
  /**
  * @USB HOST
  */
#define OTG_HS_VBUS_PIN                    GPIO_Pin_13
#define OTG_HS_VBUS_PORT                   GPIOB
#define OTG_HS_VBUS_CLK                    RCC_AHB1Periph_GPIOB
#define OTG_HS_VBUS_SOURCE                 GPIO_PinSource13
  
#define USB_HS_VBUSON_PIN                  GPIO_Pin_3
#define USB_HS_VBUSON_PORT                 GPIOE
#define USB_HS_VBUSON_CLK                  RCC_AHB1Periph_GPIOE
#define USB_HS_VBUSON_SOURCE               GPIO_PinSource3
  
#define USB_HS_FAULT_PIN                   GPIO_Pin_13
#define USB_HS_FAULT_PORT                  GPIOD
#define USB_HS_FAULT_CLK                   RCC_AHB1Periph_GPIOD
#define USB_HS_FAULT_SOURCE                GPIO_PinSource13
  
#define OTG_HS_ID_PIN                      GPIO_Pin_12
#define OTG_HS_ID_PORT                     GPIOB
#define OTG_HS_ID_CLK                      RCC_AHB1Periph_GPIOB
#define OTG_HS_ID_SOURCE                   GPIO_PinSource12
  
  /**
  * @TRIMER
  */
#define TRIMER_PIN                      GPIO_Pin_0
#define TRIMER_PORT                     GPIOC
#define TRIMER_CLK                      RCC_AHB1Periph_GPIOC
#define TRIMER_SOURCE                   GPIO_PinSource0
#define TRIMER_CHANNEL                  ADC_Channel_10
  
  /** @addtogroup IAR_STM32F407ZG_SK_LOW_LEVEL_SD_FLASH
  * @{
  */
  /**
  * @SD
  */
#define SD_CP_PIN                       GPIO_Pin_3
#define SD_CP_PORT                      GPIOD
#define SD_CP_CLK                       RCC_AHB1Periph_GPIOD
#define SD_CP_SOURCE                    GPIO_PinSource3
  
#define SD_WP_PIN                       GPIO_Pin_4
#define SD_WP_PORT                      GPIOE
#define SD_WP_CLK                       RCC_AHB1Periph_GPIOE
#define SD_WP_SOURCE                    GPIO_PinSource4
  
#define SD_CMD_PIN                      GPIO_Pin_2
#define SD_CMD_PORT                     GPIOD
#define SD_CMD_CLK                      RCC_AHB1Periph_GPIOD
#define SD_CMD_SOURCE                   GPIO_PinSource2
  
#define SD_D0_PIN                       GPIO_Pin_8
#define SD_D0_PORT                      GPIOC
#define SD_D0_CLK                       RCC_AHB1Periph_GPIOC
#define SD_D0_SOURCE                    GPIO_PinSource8
  
#define SD_D1_PIN                       GPIO_Pin_9
#define SD_D1_PORT                      GPIOC
#define SD_D1_CLK                       RCC_AHB1Periph_GPIOC
#define SD_D1_SOURCE                    GPIO_PinSource9
  
#define SD_D2_PIN                       GPIO_Pin_10
#define SD_D2_PORT                      GPIOC
#define SD_D2_CLK                       RCC_AHB1Periph_GPIOC
#define SD_D2_SOURCE                    GPIO_PinSource10
  
#define SD_D3_PIN                       GPIO_Pin_11
#define SD_D3_PORT                      GPIOC
#define SD_D3_CLK                       RCC_AHB1Periph_GPIOC
#define SD_D3_SOURCE                    GPIO_PinSource11
  
#define SD_CLK_PIN                      GPIO_Pin_12
#define SD_CLK_PORT                     GPIOC
#define SD_CLK_CLK                      RCC_AHB1Periph_GPIOC
#define SD_CLK_SOURCE                   GPIO_PinSource12
  /**
  * @brief  SD FLASH SDIO Interface
  */
#define SD_SDIO_DMA_STREAM3	          3
  //#define SD_SDIO_DMA_STREAM6           6
  
#ifdef SD_SDIO_DMA_STREAM3
#define SD_SDIO_DMA_STREAM            DMA2_Stream3
#define SD_SDIO_DMA_CHANNEL           DMA_Channel_4
#define SD_SDIO_DMA_FLAG_FEIF         DMA_FLAG_FEIF3
#define SD_SDIO_DMA_FLAG_DMEIF        DMA_FLAG_DMEIF3
#define SD_SDIO_DMA_FLAG_TEIF         DMA_FLAG_TEIF3
#define SD_SDIO_DMA_FLAG_HTIF         DMA_FLAG_HTIF3
#define SD_SDIO_DMA_FLAG_TCIF         DMA_FLAG_TCIF3
#elif defined SD_SDIO_DMA_STREAM6
#define SD_SDIO_DMA_STREAM            DMA2_Stream6
#define SD_SDIO_DMA_CHANNEL           DMA_Channel_4
#define SD_SDIO_DMA_FLAG_FEIF         DMA_FLAG_FEIF6
#define SD_SDIO_DMA_FLAG_DMEIF        DMA_FLAG_DMEIF6
#define SD_SDIO_DMA_FLAG_TEIF         DMA_FLAG_TEIF6
#define SD_SDIO_DMA_FLAG_HTIF         DMA_FLAG_HTIF6
#define SD_SDIO_DMA_FLAG_TCIF         DMA_FLAG_TCIF6
#endif /* SD_SDIO_DMA_STREAM3 */
  
 /**
  * @}
  */
  
  /**
  * @CAN
  */
  
    
#if  ST32F4_PLATFORM
/*----------------------------------------------------------------------------*/  
#define CANn                             2 
#define CAN1_INTERFACE              CAN1
#define CAN1_CLK                    RCC_APB1Periph_CAN1
#define CAN1_TX_PIN                 GPIO_Pin_1
#define CAN1_TX_GPIO_PORT           GPIOD
#define CAN1_TX_GPIO_CLK            RCC_AHB1Periph_GPIOD
#define CAN1_TX_SOURCE              GPIO_PinSource1
#define CAN1_TX_AF                  GPIO_AF_CAN1
#define CAN1_RX_PIN                 GPIO_Pin_0
#define CAN1_RX_GPIO_PORT           GPIOD
#define CAN1_RX_GPIO_CLK            RCC_AHB1Periph_GPIOD
#define CAN1_RX_SOURCE              GPIO_PinSource0
#define CAN1_RX_AF                  GPIO_AF_CAN1
#define CAN1_TX_ISR                 CAN1_TX_IRQn
#define CAN1_RX0_ISR                CAN1_RX0_IRQn
#define CAN1_RX1_ISR                CAN1_RX1_IRQn
  
#define CAN2_INTERFACE              CAN2
#define CAN2_CLK                    RCC_APB1Periph_CAN2
#define CAN2_TX_PIN                 GPIO_Pin_6
#define CAN2_TX_GPIO_PORT           GPIOB
#define CAN2_TX_GPIO_CLK            RCC_AHB1Periph_GPIOB
#define CAN2_TX_SOURCE              GPIO_PinSource6
#define CAN2_TX_AF                  GPIO_AF_CAN2
#define CAN2_RX_PIN                 GPIO_Pin_5
#define CAN2_RX_GPIO_PORT           GPIOB
#define CAN2_RX_GPIO_CLK            RCC_AHB1Periph_GPIOB
#define CAN2_RX_SOURCE              GPIO_PinSource5
#define CAN2_RX_AF                  GPIO_AF_CAN2
#define CAN2_TX_ISR                 CAN2_TX_IRQn
#define CAN2_RX0_ISR                CAN2_RX0_IRQn
#define CAN2_RX1_ISR                CAN2_RX1_IRQn
/*----------------------------------------------------------------------------*/  
#endif

  
#define CANn                        2
  
#define CAN1_INTERFACE              LPC_C_CAN0
#define CAN1_TX_GPIO_PORT           0x01 //0x0E//0x0E//0x03 
#define CAN1_RX_GPIO_PORT           0x01 //0x0E//0x0E//0x03  
#define CAN1_TX_PIN                 17   
#define CAN1_RX_PIN                 18     
#define CAN1_CLK                    CLK_BASE_APB3  
#define CAN1_ISR                    C_CAN0_IRQn  
#define CAN1_TX_MODE_FUNC           (SCU_MODE_INACT | SCU_MODE_FUNC5)    //SCU_MODE_FUNC1)    
#define CAN1_RX_MODE_FUNC           (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC5)    //SCU_MODE_FUNC1)
    
#define CAN2_INTERFACE              LPC_C_CAN1
#define CAN2_TX_GPIO_PORT           0x01 //0x0E  //TBD  
#define CAN2_RX_GPIO_PORT           0x01 //0x0E  //TBD      
#define CAN2_TX_PIN                 17  //0x00  //TBD
#define CAN2_RX_PIN                 18  //0x01  //TBD
#define CAN2_CLK                    CLK_BASE_APB1  
#define CAN2_ISR                    C_CAN1_IRQn  
#define CAN2_TX_MODE_FUNC           (SCU_MODE_INACT | SCU_MODE_FUNC5)    
#define CAN2_RX_MODE_FUNC           (SCU_MODE_INACT | SCU_MODE_INBUFF_EN | SCU_MODE_FUNC5)
    
    
  /**
  * @}
  */
  /**
  * @}
  */
  
  /** @defgroup IAR_STM32F407ZG_SK_LOW_LEVEL_Exported_Macros
  * @{
  */
  /**
  * @}
  */
  
  
  /**
  * @}
  */
  
#ifdef __cplusplus
}
#endif

#endif /* __IAR_STM32F407ZG_SK_H */
/**
* @}
*/

/**
* @}
*/

/**
* @}
*/

/**
* @}
*/

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/

