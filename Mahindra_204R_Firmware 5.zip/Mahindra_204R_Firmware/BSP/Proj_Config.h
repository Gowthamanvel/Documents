/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.0>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements CAN middle level application interfaces
*******************************************************************************/
#ifndef __PROJ_CONFIG_H
#define __PROJ_CONFIG_H
#include <stdbool.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#if 1
//#include <stdbool.h>
//#include <stdint.h>
//#include <string.h>
//#include <stdio.h>
#if NXP_LPC_43XX
//#include <lpc_types.h>
#endif

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
typedef enum
{
    MID_FAIL,
    MID_PASS
}Mid_API_Status_t;

//typedef struct
//{
  //uint8_t *address; 
  //uint16_t len;
//}Dynamic_QStruct_t;

typedef struct
{
  uint8_t *address; 
  uint16_t len;
  uint8_t  freeAddress;
}Dynamic_QStruct_t;



typedef struct
{
    uint8_t *address;
    uint16_t len;
    uint8_t  freeAddress;
}Dynamic_QFreeStruct_t;

typedef struct
{
    uint32_t  sector;
    uint16_t len;
    uint8_t *address;
}Dynamic_SD_Write_Struct_t;


/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
#define     USE_FREERTOS					1
#define		DATALOG_DEBUG					1
#define		HFCP_DEBUG						1
#define     COUNT_MONITER					1
#define		CAN_DEBUG						1
//#define     SPITX_DMA_INT_MODE
//#define     CAN_2ND_FIFO_USAGE


#define HFCP_MAX_USB_SINGLE				64
#define HFCP_MAX_USB_RESP_SIZE			64


#define HFCP_TX_BUFFER_SIZE             64
#define HFCP_MAX_IN_SINGLE_FRAME        1*HFCP_TX_BUFFER_SIZE
#define DATALOG_MAX_IN_SINGLE_FRAME     1*HFCP_TX_BUFFER_SIZE 
#define MAX_HFCP_RESP_SIZE              20*HFCP_MAX_IN_SINGLE_FRAME
#define SPI_DMA_TX_MAX_SIZE             MAX_HFCP_RESP_SIZE+12
#define HFCP_RX_BUFFER_SIZE             64


/* Interrupt Priorities */
//#define     CAN1_TX_IRQ_PRIORITY        configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
//#define     CAN1_RX0_IRQ_PRIORITY       configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
//#define     CAN1_RX1_IRQ_PRIORITY       configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
//#define     CAN2_TX_IRQ_PRIORITY        configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
//#define     CAN2_RX0_IRQ_PRIORITY       configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
//#ifdef CAN_2ND_FIFO_USAGE
//#define     CAN2_RX1_IRQ_PRIORITY       configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
//#endif
#define		CAN2_IRQ_PRIORITY		    configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2

/* SPI Tx DMA Interrupt */
#define     SPI_DMA_TX_IRQ_PRIORITY     configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
/* SPI Rx DMA Interrupt */
#define     SPI_DMA_RX_IRQ_PRIORITY     configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
/* SPI External Interrupt */
#define     EXT_INT_IRQ_PRIORITY        configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
#define     SDIO_IRQ_PRIORITY           configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
#define     SDIO_DMA_IRQ_PRIORITY       configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
/* USB Interrupt */
#define     USB_HS_IRQ_PRIORITY			configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2

#define TIMER_ISR_PRIORITY              configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
#define STMIN_TIMER_ISR_PRIORITY		configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2
#define UART_ISR_PRIORITY               configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2


/* Task Priorities */
#define CAN1_TX_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define CAN2_TX_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define CAN1_RX_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define CAN2_RX_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define HFCP_RX_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define HFCP_TX_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define WIFI_TASK_PRIORITY      tskIDLE_PRIORITY+1
#define USB_TX_TASK_PRIORITY	tskIDLE_PRIORITY+1
#define GENERAL_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define DATALOG_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define GARUDA_MAIN_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define PERIODIC_MSG_TASK_PRIORITY  tskIDLE_PRIORITY+1
#define KWP_TASK_PRIORITY   tskIDLE_PRIORITY+1
#define LED_TASK_PRIORITY       tskIDLE_PRIORITY+1
#define MSD_TASK_PRIORITY   tskIDLE_PRIORITY+1


/* Task Stack Size */
#define CAN1_TX_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*8
#define CAN2_TX_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*8
#define CAN1_RX_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*8
#define CAN2_RX_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*8
#define HFCP_RX_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*3//6
#define HFCP_TX_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*6
#define WIFI_TASK_STACK_SIZE            configMINIMAL_STACK_SIZE*6
#define WIFI_INTR_TASK_STACK_SIZE		configMINIMAL_STACK_SIZE
#define USB_TASK_STACK_SIZE             configMINIMAL_STACK_SIZE*3//6
#define DATALOG_TASK_STACK_SIZE         configMINIMAL_STACK_SIZE*12//8,12
#define GARUDA_MAIN_TASK_STACK_SIZE     configMINIMAL_STACK_SIZE*6
#define PERIODIC_MSG_TASK_STACK_SIZE    configMINIMAL_STACK_SIZE*6
#define KWP_TASK_STACK_SIZE             configMINIMAL_STACK_SIZE//*6
#define LED_TASK_STACK_SIZE             configMINIMAL_STACK_SIZE*2
#define SD_CARD_WRITE_TASK_STACK_SIZE   configMINIMAL_STACK_SIZE*3
#define MSD_TASK_STACK_SIZE             configMINIMAL_STACK_SIZE*2

/* Transmit and Receive status Flags  */
#define CAN_STD_MSG                                         0x00000000
#define CAN_EXT_MSG                                         0x00000100
#define TX_MSG_TYPE_LOOPBACK                                0x00000001
#define J1939_ADDRESS_CLAIMED								0x00010000
#define J1939_ADDRESS_LOST									0x00020000 


#define SWAP_UINT32(x) (((x) >> 24) | (((x) & 0x00FF0000) >> 8) | (((x) & 0x0000FF00) << 8) | ((x) << 24))
/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
//extern uint32_t SystemCoreClock;

#endif
/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
#endif /* __CAN_MID_H */

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* 1.1                    Sanjeeva                                     08-Aug-08
* Added support for Time stamps
*******************************************************************************/
