/*
 * USB_Mid.h
 *
 * Created: 5/12/2015 12:16:54 PM
 *  Author: amit
 */ 


#ifndef USB_MID_H_
#define USB_MID_H_

#include "FreeRTOS.h"
#include "Proj_Config.h"
#include "Pin_Config.h"
#include "chip.h"
#include "board.h"
#include "HIDDFunction.h"
#include "HIDDTransferDriver.h"
/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void USB_Mid_Init (void);
void USB_Mid_Transmit (uint8_t *, uint16_t, uint8_t ); //ADDED relese variable for KWp
//Mid_API_Status_t SPI_Mid_Recieve (Dynamic_QStruct_t *, TickType_t);
//void SPID_Rx_Cb(uint32_t channel, Spid* pArg);
void USBFreeRTOS_Init (void);

uint8_t USB_Mid_IsConnected (uint32_t waitPeriod);
uint8_t USB_Mid_Get_State (uint32_t waitPeriod);

void USB_Mid_pauseTask (void);
void USB_Mid_startTask (void);
void USB_Mid_Reset (void);

#endif /* USB_MID_H_ */
/*****************************************************************************
**                            End Of File
******************************************************************************/
