/******************************************************************************
*
* Copyright                                                  Template Version
* 2015 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * UART_Mid.h
 *
 * Created: 7/15/2015 6:43:09 PM
 *  Author: amit
 */ 

/******************************************************************************
* P U R P O S E: This module implements UART Mid level application interfaces
*******************************************************************************/

#ifndef UART_MID_H_
#define UART_MID_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
#define nUART       4

#define UART0_PINS  {PIO_PA10A_UTXD0 | PIO_PA9A_URXD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_DEFAULT}    

/*mode determines from where the API(Uart_clear_Rx_Q(),Uart_clear_Tx_Q()) are called, 
whether from ISR or not */

#define NORMAL_MODE		0
#define ISR_MODE		1
    
/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
typedef enum
{   
    KWP_UART_CHAN   = 0,
    DEBUG_UART_CHAN       
} UART_chId_t;

typedef enum
{
    UART_PARITY_DISABLE,
    UART_PARITY_ODD,
    UART_PARITY_EVEN,
    UART_PARITY_FORCED_HIGH,
    UART_PARITY_FORCED_LOW
} UART_Parity_t;

typedef enum
{
    UART_STOPBIT_0_5,
    UART_STOPBIT_1,
    UART_STOPBIT_1_5,
    UART_STOPBIT_2
} UART_Stopbits_t;

typedef enum
{
    UART_FLOWCONTROL_NONE,
    UART_FLOWCONTROL_HARDWARE,
    UART_FLOWCONTROL_SOFTWARE
} UART_Flowcontrol_t;

typedef struct
{
    uint32_t              baudrate;
    uint8_t               dataLen;
    UART_Stopbits_t       stopbits;
    UART_Parity_t         parity;
    uint8_t               use_fifo;
    UART_Flowcontrol_t    flowcontrol;
    uint16_t              txQueueSz;
    uint16_t              rxQueueSz;
    uint32_t              timeGuard;
    uint32_t              rxTimeout;
}UART_InitTypeDef;

typedef struct
{
    uint8_t      UART_enabled;             /* UART Status : Enable/Disable */
    uint32_t  Set_baudrate;             /* TimeOUT is Enable or Disable*/
    uint16_t  timeguard_localcount;     /* TimeGaurd localCount in terms of ISR Rate(Constant) */
    uint16_t  timeguard_count;          /* TimeGaurd Count (Increments for each ISR Exec) */
    uint8_t      timeguard_enabled;        /* Timeguard is Enable or Disable */
    uint16_t  timeout_localcount;       /* TimeOUT localCount in terms of ISR Rate(Constant) */
    uint16_t  timeout_count;            /* TimeOUT Count (Increments for each ISR Exec) */
    uint8_t      timeout_enabled;          /* TimeOUT is Enable or Disable*/
} UART_Set_Param_t;

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*
******************************************************************************/
void Timer_Init(void);
void Timer_Stop( void );
void UART_timeguard_handler(void);
void UART_RXtimeout_handler(void);
void UART_MidEnable(UART_chId_t uartCh);
void UART_MidDisable(UART_chId_t uartCh);
void Uart_Clear_Tx_Q(UART_chId_t uartCh,uint8_t mode);
void Uart_Clear_Rx_Q(UART_chId_t uartCh,uint8_t mode);
Mid_API_Status_t Q_To_Uart(UART_chId_t uartCh);
Mid_API_Status_t UART_MidDeInit(UART_chId_t uartCh);
void UART_Change_RxTimeOut(UART_chId_t uartCh, uint32_t rxTimeOut);
void UART_Restart_RxTimeOut(UART_chId_t uartCh);
void UART_Change_TimeGuard(UART_chId_t uartCh, uint32_t timeGuard);
void UART_Set_Baudrate(UART_chId_t uartCh, uint32_t baudrate);
void UART_Set_Parity(UART_chId_t uartCh, UART_Parity_t parity);
void UART_Set_DataLength(UART_chId_t uartCh,uint8_t dataLength);
void UART_Set_Stopbits(UART_chId_t uartCh, UART_Stopbits_t stopbits);
Mid_API_Status_t UART_MidSendFirstByte (UART_chId_t uartCh, uint8_t p_buf);
uint16_t UART_MidRecv (UART_chId_t uartCh, uint8_t *p_buf, uint16_t len);
Mid_API_Status_t UART_MidSend (UART_chId_t uartCh, uint8_t *p_buf, uint16_t len);
Mid_API_Status_t UART_MidInit(UART_chId_t uartCh, UART_InitTypeDef Uart_InitData);
uint16_t UART_MidRecvWait (UART_chId_t uartCh, uint8_t *p_buf, uint16_t len, int16_t maxTimeout);
uint16_t ISO9141_14230_Get_Data_Length( uint8_t recvdData, uint16_t* lengthIndex);

#endif /* UART_MID_H_ */