/******************************************************************************
*
* Copyright                                                  Template Version
* 2015 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * HSMCI_Mid.h
 *
 * Created: 11/5/2015 12:15:23 PM
 *  Author: amit
 */ 

/******************************************************************************
* P U R P O S E: This module implements HSMCI Mid level application interfaces
*******************************************************************************/

#ifndef HSMCI_MID_H_
#define HSMCI_MID_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*
******************************************************************************/
void HSMCI_ConfigurePIOs(void);
void CardDetectConfigure(void);
FRESULT scan_files (char* path);
uint8_t formatdisk(const TCHAR *pDrv);
uint8_t AnyCardIsConnected(void);
uint8_t SD_Card_Init(sSdCard *pSd);
uint8_t CardIsConnected(uint8_t iMci);
void Initialize_HSMCI_Drivers(uint8_t interface);

#endif /* HSMCI_MID_H_ */
