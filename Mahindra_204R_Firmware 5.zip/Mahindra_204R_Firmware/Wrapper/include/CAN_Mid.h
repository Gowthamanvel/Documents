/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.0>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements CAN middle level application interfaces
*******************************************************************************/
#ifndef __CAN_MID_H
#define __CAN_MID_H


/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Pin_Config.h"
#include "Proj_Config.h"
#include "mcan_config.h"

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
#define RX_ONLY_STD_MSG         0x01
#define RX_ONLY_EXT_MSG         0x02
#define RX_BOTH_STD_EXT_MSG     0x03
#define BAUDRATE_100K           100000
#define BAUDRATE_125K           125000
#define BAUDRATE_250K           250000
#define BAUDRATE_500K           500000
#define BAUDRATE_800K           800000
#define BAUDRATE_1000K          1000000

#define CAN_FIXED_PACKET_LENGTH			6       /*< (2 (Rx Flags) + 4 (Timestamp) ) */
#define DATALOG_FIXED_PACKET_LENGTH     7       /*< (2 (Rx Flags) + 5 (Timestamp) ) */
#define CAN_PACKET_COPY_LENGTH			4		/*<  4 (Timestamp) */
#define DATALOG_PACKET_COPY_LENGTH      5		/*<  5 (Timestamp) */
#define MAX_CAN_FRAMES					3       /*< Maximum no of CAN Frames in to be framed/ sent to HFCP */
#define MODE							0x40    /*< Mode 01 for MultiFrames functionality */
#define MAX_CAN_FRAME_SIZE				19
#define MAX_DATALOG_FRAME_SIZE			20		/*< ( 1 (Message Length) + 2 (Rx Flags) + 5 (Timestamp) + 4 (Msg ID) + 8 ( Data ) */
#define MAX_USB_BUFFER_SIZE				64


/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
typedef struct
{
    uint8_t     dlc;             /* DLC */
    uint8_t     ide;             /* IDE : STD = 0, EXT = 1 */
    uint8_t     rtr;             /* RTR : Data = 0, Remote = 1 */
    uint32_t    msg_id;         /* Message Identifier */
    uint8_t     data[8];         /* Message data */
}CAN_TX_Msg_t;

typedef struct
{
  uint32_t u32Baudrate;    
  uint8_t  u8SJW;  
  uint8_t  u8SamplingMode;
  uint8_t  u8LoopBackMode;
}CAN_Init_Info;

typedef enum
{
  CAN_Q_EMPTY,
  CAN_Q_FULL,
  CAN_Q_OK,
  CAN_Q_FAIL
} CAN_Mid_QStatus_t;

typedef enum
{
    CAN_BAUDRATE,
    CAN_SJW,
    CAN_SAMPLING_POINT
}CAN_Config_t;

typedef struct
{
	uint16_t     msgLen;        /* Total Length Including Header(Msg ID) */
	uint32_t     rxFlags;       /* IDE : STD or  EXT */
	uint32_t     timeStamp;     /* Timestamp */
	uint32_t     msgId;         /* Message Identifier */
	uint8_t      data[8];       /* Message data */
} __attribute__ ((packed)) CAN_Rx_Msg_t;

/* Added the Debug Messages, which will be sent on USB Packets */
typedef struct
{
	uint32_t CAN_Mid_Tx_Send;
	uint32_t CAN_Mid_Tx_Fail;
	uint32_t CAN_Tx_Complete;
	uint32_t CAN_Tx_Queue_Fail;
	uint32_t CAN_Rx_Count;
	uint8_t CAN_Tx_Progress;
	uint8_t CAN_Last_Tx_Data;
	uint8_t reserved_1;
	uint8_t reserved_2;
} __attribute__ ((packed)) Garuda_Debug_Info;

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void CAN_Power_Off(void);
bool Is_DataLog_Active(void);
void CAN_FreeRTOSInit(void);
void Enq_CAN1_Remaining_Data(void);
void Enq_CAN2_Remaining_Data(void);
void CAN_Mid_DeInit (uint8_t p_channel);
uint8_t CAN_Mid_Disable(uint8_t p_channel);
Mid_API_Status_t CAN_ClearQ(uint8_t QUEUE);
uint8_t CAN_Mid_Init (CAN_CH_TypeDef p_ch, uint32_t p_baudrate);
uint8_t  LowLevel_CAN_enable_loopback( uint8_t p_channel_no_U8);
uint8_t LowLevel_CAN_disable_loopback( uint8_t p_channel_no_U8);
uint8_t LowLevel_CAN_get_current_SJW(uint8_t p_channel_no_U8);
uint32_t CAN_Mid_get_current_baudrate(uint8_t p_channel_no_U8);
uint8_t LowLevel_CAN_get_loopback_status( uint8_t p_channel_no_U8);
uint8_t CAN_Mid_Enable(uint8_t p_channel,uint8_t p_connection_flag_U8);
uint8_t LowLevel_CAN_get_current_sampling_mode(uint8_t p_channel_no_U8);
uint8_t CAN_Mid_set_baudrate(uint32_t p_baud_rate_U32, uint8_t p_channel_no_U8);
Mid_API_Status_t CAN_Mid_Transmit(CAN_CH_TypeDef p_ch , CAN_TX_Msg_t *p_tx_msg);
Mid_API_Status_t CAN_Mid_Transmit_ISR(CAN_CH_TypeDef p_ch , CAN_TX_Msg_t *p_tx_msg);
void CAN_Loopback_Tx( CAN_TX_Msg_t *p_tx_msg, CAN_CH_TypeDef p_ch, uint8_t release);
void CAN_Mid_Get_Config(uint8_t p_channel_no_U8, CAN_Config_t Config, uint32_t *value);
Mid_API_Status_t CAN_Mid_txData (CAN_CH_TypeDef p_ch, CAN_TX_Msg_t *pMsg, uint8_t callSrc);

#endif /* __CAN_MID_H */

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* 1.1                    Sanjeeva                                     08-Aug-08
* Added support for Time stamps
*******************************************************************************/
