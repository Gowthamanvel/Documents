/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * GPIO_Mid.h
 *
 * Created: 7/15/2015 6:08:36 PM
 *  Author: amit
 */ 

#ifndef GPIO_MID_H_
#define GPIO_MID_H_


/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#define GARUDA_USB          0x07
#define GARUDA_USB_WIFI     0x03 /*< To be Decided */


/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
/* GPIO PINS Used */
typedef enum
{
    KW_TXD,                                  /* GPIO Port A Pin 0 */
    KW_RXD,                                  /* GPIO Port A Pin 1 */
    KLINE_PULLUP_SLCT,                       /* GPIO Port D Pin 3 */
    KLINE_LLINE_SLCT,                        /* GPIO Port D Pin 4 */
    LLINE_ISO_SLCT,                          /* GPIO Port D Pin 5 */
    KLINE_ISO_SLCT,                          /* GPIO Port D Pin 6 */
    KW_TX_5BAUD                              /* GPIO Port D Pin 7 */
} KWP_GPIOs_t;

typedef enum
{
    BOARD_DETECT_0,                         /* GPIO Port A Pin 0 */
    BOARD_DETECT_1,                         /* GPIO Port A Pin 1 */
    BOARD_DETECT_2                          /* GPIO Port D Pin 3 */                          
} Board_Detect_GPIOs_t;

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
#define PIN_KWP_TXD_5BAUD            {PIO_PD17, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_DEFAULT} 
#define PIN_KLINE_PULLUP_SLCT        {PIO_PB13, PIOB, ID_PIOB, PIO_OUTPUT_0, PIO_DEFAULT} 
#define PIN_KLINE_LLINE_SLCT         {PIO_PD14, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_DEFAULT} 
#define PIN_KLINE_ISO_SLCT           {PIO_PD13, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_DEFAULT} 
#define PIN_LLINE_ISO_SLCT           {PIO_PA3,  PIOA, ID_PIOA, PIO_OUTPUT_0, PIO_DEFAULT} 

#define PIN_KWP_TXD                 {PIO_PA10A_UTXD0, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_PULLUP} /**< UART 4 TX Pins */
#define PIN_KWP_RXD                 {PIO_PA9A_URXD0, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_PULLUP} /**< UART 4 RX Pins */

#define BOARD_DETECT_PIN0           {PIO_PD30, PIOD, ID_PIOD, PIO_INPUT, PIO_PULLUP}   
#define BOARD_DETECT_PIN1           {PIO_PD26, PIOD, ID_PIOD, PIO_INPUT, PIO_PULLUP}
#define BOARD_DETECT_PIN2           {PIO_PD24, PIOD, ID_PIOD, PIO_INPUT, PIO_PULLUP}


/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*
******************************************************************************/
/*******************************************************************************
* Function Name  : Config_Pin_Output
* Description    : Configures the GPIO Pin As Output.
* Input          : p_GPIO_pin : The GPIO Pin which needs to configured
* Output         : None
* Return         : None
*******************************************************************************/
void Config_Pin_Output(KWP_GPIOs_t p_GPIO_pin);

/*******************************************************************************
* Function Name  : Set_Pin_High
* Description    : Sets GPIO Pin @ High Level.
* Input          : p_GPIO_pin : The GPIO Pin used
* Output         : None
* Return         : None
*******************************************************************************/
void Set_Pin_High(KWP_GPIOs_t p_GPIO_pin);

/*******************************************************************************
* Function Name  : Set_Pin_Low
* Description    : Sets GPIO Pin @ Low Level.
* Input          : p_GPIO_pin : The GPIO Pin used
* Output         : None
* Return         : None
*******************************************************************************/
void Set_Pin_Low(KWP_GPIOs_t p_GPIO_pin);

/*******************************************************************************
* Function Name  : Config_Pin_UART_Mode
* Description    : Configures Pin to UART Mode
* Input          : p_GPIO_pin : The GPIO Pin used
* Output         : None
* Return         : None
*******************************************************************************/
void Config_Pin_UART_Mode(KWP_GPIOs_t p_GPIO_pin);

uint8_t get_BoardDetect_Value(void);
void Initialise_Board_Detect_Pins(void);

#endif /* GPIO_MID_H_ */