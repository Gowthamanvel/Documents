/******************************************************************************
*
* Copyright                                                  Template Version
* 2015 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * USB_MSD_Mid.h
 *
 * Created: 11/17/2015 11:30:09 AM
 *  Author: amit
 */ 

/******************************************************************************
* P U R P O S E: This module implements USB MSD Mid level application interfaces
*******************************************************************************/
#ifndef USB_MSD_MID_H_
#define USB_MSD_MID_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "sdmmc_cmd.h"

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
/** Size of one block in bytes. */
#define BLOCK_SIZE          512
#define MSD_BUFFER_SIZE    ( 100 * BLOCK_SIZE  )  
/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*
******************************************************************************/
void USB_MSD_Mid_Init(void);
void SDDiskInit(sSdCard *pSd);
void _MemoriesInitialize(sSdCard *pSd);
void _MemoriesDeInitialize(sSdCard *pSd);
void MSDCallbacks_Data(uint8_t flowDirection, uint32_t  dataLength, 
                                uint32_t  fifoNullCount,uint32_t  fifoFullCount);

#endif /* USB_MSD_MID_H_ */