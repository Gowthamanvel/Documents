/******************************************************************************
*
* Copyright                                                  Template Version
* 2015 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * ADC_Mid.h
 *
 * Created: 7/29/2015 2:28:04 PM
 *  Author: amit
 */ 

/******************************************************************************
* P U R P O S E: This module implements ADC Mid level application interfaces
*******************************************************************************/

#ifndef ADC_MID_H_
#define ADC_MID_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#define ADC_CHANNEL     7
#define SAMPLES         100
#define AFE_CLK         20000000 //2200000//5000000//

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*
******************************************************************************/
void afe_adc_initialization(void); 
uint8_t Read_BatteryVoltage(uint32_t *BatVg);

#endif /* ADC_MID_H_ */