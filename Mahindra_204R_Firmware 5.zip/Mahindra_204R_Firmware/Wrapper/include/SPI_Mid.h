/******************************************************************************
*
* Copyright                                                  Template Version
* 2013 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/******************************************************************************
* P U R P O S E: This module implements SPI low level application interfaces
*******************************************************************************/
#ifndef __SPI_LOW_H
#define __SPI_LOW_H

#include "FreeRTOS.h"
#include "Proj_Config.h"
#include "Pin_Config.h"
#include "chip.h"
#include "board.h"
#include "projdefs.h"

#define SPI_RX_Queue_SIZE			50
#define SPI_DMA_RX_SIZE             40

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
Mid_API_Status_t SPI_Mid_Init(void);
Mid_API_Status_t SPI_Mid_Deinit(void);
void SN8200ConfigReset(void);
void SN8200HoldReset(void);
void SN8200ReleaseReset(void);
void Start_SPI_Rx_DMA (void);
void Stop_SPI_Rx_DMA (void);
bool Is_Ext_Int_Line_Low(void);
bool Is_Ext_Int_Line_High(void);
void SPIFreeRTOS_Init (void);
void WiFI_Mid_Reset (void);
void SPID_Rx_Cb(uint32_t channel, Spid* pArg);
void SPI_Mid_Transmit (uint8_t *, uint16_t );
Mid_API_Status_t SPI_Mid_Recieve (Dynamic_QStruct_t *, TickType_t);
void SPI_Dummy_Transmit (uint8_t *SPIDmaPacket, uint16_t SPIDmaTxLen);

#endif
/*****************************************************************************
**                            End Of File
******************************************************************************/
