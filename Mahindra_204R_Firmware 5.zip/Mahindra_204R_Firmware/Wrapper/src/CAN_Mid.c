/******************************************************************************
*
* Copyright
* 2014 Dearborn Electronics India                            <Ver 1.0>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements CAN middle level application interfaces
*******************************************************************************/
/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "chip.h"
#include "CAN_Mid.h"
#include "HFCP.h"
#include "j2534_filter.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"
#include "mcan.h"
#include "time_stamps.h"
#include "Data_Logger.h"
#include "Led_Handler.h"
#include "same70n20.h"
/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define MSD_ID_ALL_PASS				0x00
#define MSG_ID_ALL_PASS_MASK		0x00  

#define TX_BUFFER_0                 0
#define TX_BUFFER_1                 1
#define TX_BUFFER_2                 2

#define RX_BUFFER_0                 0
#define RX_BUFFER_1                 1
#define RX_BUFFER_2                 2

#define FILTER_0                    0
#define FILTER_1                    1
#define FILTER_2		            2

#define CAN_STANDARD                0
#define CAN_FD                      1


/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
static QueueHandle_t xCAN1_TX_Queue;
static QueueHandle_t xCAN1_RX_Queue;
SemaphoreHandle_t xCAN1StartTx;
static SemaphoreHandle_t xCAN1STMINStart;
SemaphoreHandle_t xCAN2StartTx;
static SemaphoreHandle_t xCAN2STMINStart;

#define CAN1_TX_Queue_SIZE   600 //500 Changed to 64 to support 1Mbps 4096 bytes data transfer
#define CAN1_RX_Queue_SIZE   800 

static QueueHandle_t xCAN2_TX_Queue;
static QueueHandle_t xCAN2_RX_Queue;
#define CAN2_TX_Queue_SIZE   600 //500 Changed to 64 to support 1Mbps 4096 bytes data transfer
#define CAN2_RX_Queue_SIZE   800

static uint8_t l_enable_CAN_Tx1_BOOL, l_enable_CAN_Tx2_BOOL;
static uint8_t l_CAN_Rx1_connection_flag_U8, l_CAN_Rx2_connection_flag_U8;

static Dynamic_QStruct_t can1BufInfo;
static Dynamic_QStruct_t can2BufInfo;
uint64_t CAN1DataLoggingExtendedTime=0;
uint64_t CAN2DataLoggingExtendedTime=0;

CAN_Init_Info gstrCANInitInfo[CANn];
uint8_t CAN1_MsgCount = 0;
uint8_t CAN2_MsgCount = 0;
extern uint8_t startLogging;

uint8_t CAN1TxProgress =0;
uint8_t CAN2TxProgress =0;

#if CAN_DEBUG

uint8_t txCatchIndex = 0;
uint8_t txCatchIndexFail = 0;
volatile uint8_t CANtXCheck = 0;
uint8_t CANMidTxBuffer[100][2];
uint8_t txCatchTransmit[100][2];
uint8_t txCatchFailedTransmit[100][2];
uint16_t CanMidIndex = 0;
uint32_t enQCount;
uint32_t enQFailCOunt;
uint32_t directSendCount;
uint32_t DqueueCount1 =0;
uint32_t DqueueCount2 =0;
uint32_t CAN1SendCount = 0;
uint32_t CAN2SendCount = 0;
uint32_t CAN1TXQueueFail=0;
uint32_t CAN2TXQueueFail=0;

#endif

#if COUNT_MONITER

uint32_t CANqfull;
uint32_t CAN2qfull;
uint32_t can1cnt;
uint32_t can2cnt;
uint32_t can1Rxcnt;
uint32_t can2Rxcnt;
uint32_t canErrCnt;
uint32_t can2ErrCnt;

uint32_t CAN1TXComplete=0;
uint32_t CAN2TXComplete=0;
uint32_t CAN1TXInComplete=0;

uint32_t can1RxIsrCount = 0;
uint32_t can2RxIsrCount = 0;

uint32_t LPCAN1qfull= 0;
uint32_t LPcan1cnt= 0;
uint32_t LPcan1ErrCnt= 0;
uint32_t LPCAN2qfull= 0;
uint32_t LPcan2cnt= 0;
uint32_t LPcan2ErrCnt= 0;

uint64_t CAN1AllocOk =0;
uint32_t CAN1TotalFrame =0;
uint32_t CAN1MallocFailCount =0;

uint64_t CAN2AllocOk = 0;
uint32_t CAN2TotalFrame=0;
uint32_t CAN2MallocFailCount=0;

#endif /*#if COUNT_MONITER*/

uint32_t     * txMailbox0;
uint32_t     * txMailbox1;
uint32_t     * txMailbox2;

Mailbox8Type   rxMailbox0;
Mailbox8Type   rxMailbox1;
Mailbox8Type   rxMailbox2;

extern uint8_t CAN1_Vehicle_STMinValue;
extern uint8_t CAN2_vehicle_STMinValue;

Garuda_Debug_Info Garuda_Debug;
Garuda_Debug_Info Garuda_Debug_CAN2;

/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/
void CAN1_RX_Task(void *PvParam);
void CAN2_RX_Task(void *PvParam);
void CAN1_TX_Task(void *PvParam);
void CAN2_TX_Task(void *PvParam);

void Init_STMin_Timer(CAN_CH_TypeDef p_ch);
void Stop_STMIN_Timer(CAN_CH_TypeDef p_ch);
void Start_STMIN_Timer(uint8_t timervalue,CAN_CH_TypeDef p_ch);

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
/////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct QueueDefinition
{
    int8_t *pcHead;					/*< Points to the beginning of the queue storage area. */
    int8_t *pcTail;					/*< Points to the byte at the end of the queue storage area.  Once more byte is allocated than necessary to store the queue items, this is used as a marker. */
    int8_t *pcWriteTo;				/*< Points to the free next place in the storage area. */

    union							/* Use of a union is an exception to the coding standard to ensure two mutually exclusive structure members don't appear simultaneously (wasting RAM). */
    {
        int8_t *pcReadFrom;			/*< Points to the last place that a queued item was read from when the structure is used as a queue. */
        UBaseType_t uxRecursiveCallCount;/*< Maintains a count of the number of times a recursive mutex has been recursively 'taken' when the structure is used as a mutex. */
    } u;

    List_t xTasksWaitingToSend;		/*< List of tasks that are blocked waiting to post onto this queue.  Stored in priority order. */
    List_t xTasksWaitingToReceive;	/*< List of tasks that are blocked waiting to read from this queue.  Stored in priority order. */

    volatile UBaseType_t uxMessagesWaiting;/*< The number of items currently in the queue. */
    UBaseType_t uxLength;			/*< The length of the queue defined as the number of items it will hold, not the number of bytes. */
    UBaseType_t uxItemSize;			/*< The size of each items that the queue will hold. */

    volatile BaseType_t xRxLock;	/*< Stores the number of items received from the queue (removed from the queue) while the queue was locked.  Set to queueUNLOCKED when the queue is not locked. */
    volatile BaseType_t xTxLock;	/*< Stores the number of items transmitted to the queue (added to the queue) while the queue was locked.  Set to queueUNLOCKED when the queue is not locked. */

    #if ( configUSE_TRACE_FACILITY == 1 )
    UBaseType_t uxQueueNumber;
    uint8_t ucQueueType;
    #endif

    #if ( configUSE_QUEUE_SETS == 1 )
    struct QueueDefinition *pxQueueSetContainer;
    #endif

} xQUEUE;

/* The old xQUEUE name is maintained above then typedef ed to the new Queue_t
name below to enable the use of older kernel aware debuggers. */
typedef xQUEUE Queue_t;
/////////////////////////////////////////////////////////////////////////////////////////////////////////

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
* Function name	: uint8_t CAN_Mid_Init(uint8_t, uint8_t)
* returns       : None
* parameters    : uint8_t p_channel - channel Number
                  uint32_t p_baudrate - Baudrate
* Description	: This function Initializes CAN.
* Notes		:
*******************************************************************************/
uint8_t CAN_Mid_Init (CAN_CH_TypeDef p_ch, uint32_t p_baudrate)
{
    uint8_t fl_init_status_U8 = MID_PASS;
    uint32_t MCANBitRate = 0;
    
    if(0 == p_baudrate)
    {
        return ERR_INVALID_BAUDRATE;
    }
    	
    memset(&gstrCANInitInfo[p_ch], 0, sizeof(CAN_Init_Info));        
    if( (CAN_CH1 == p_ch) )
    {		
        if(p_baudrate == BAUDRATE_800K)
        {
            MCANBitRate = ((uint32_t) (( (float) CAN_CLK_FREQ_HZ / ((float)( MCAN1_TSEG1 + 1 + MCAN1_TSEG2 + 3 ) * (float) p_baudrate )) - 1 ));
            mcan0Config.bitTiming = MCAN_BTP_BRP(MCANBitRate) | MCAN_BTP_TSEG1(MCAN1_TSEG1 + 1) | MCAN_BTP_TSEG2(MCAN1_TSEG2) | MCAN_BTP_SJW(MCAN1_SJW);
        }
        else
        {
            MCANBitRate = ((uint32_t) (( (float) CAN_CLK_FREQ_HZ / ((float)( MCAN1_TSEG1 + MCAN1_TSEG2 + 3 ) * (float) p_baudrate )) - 1 ));
            mcan0Config.bitTiming = MCAN_BTP_BRP(MCANBitRate) | MCAN_BTP_TSEG1(MCAN1_TSEG1) | MCAN_BTP_TSEG2(MCAN1_TSEG2) | MCAN_BTP_SJW(MCAN1_SJW);
        }
        
        MCAN_Init( &mcan0Config );
        MCAN_InitTxQueue( &mcan0Config );
        MCAN_Enable( &mcan0Config );

        MCAN_IEnableMessageStoredToRxDedBuffer( &mcan0Config, CAN_INTR_LINE_0 ); /* Check for the Interrupt Line */
        
        gstrCANInitInfo[p_ch].u32Baudrate = p_baudrate;
        MCAN_ConfigRxClassicFilter( &mcan0Config, CAN_FIFO_0, FILTER_1, MSD_ID_ALL_PASS, CAN_STD_ID, MSG_ID_ALL_PASS_MASK );
        /* MCAN_ConfigRxClassicFilter( &mcan0Config, CAN_FIFO_0, FILTER_1, MSD_ID_ALL_PASS, CAN_EXT_ID, MSG_ID_ALL_PASS_MASK ); */
        
        gstrCANInitInfo[p_ch].u32Baudrate = p_baudrate;
    }
    else if( (CAN_CH2 == p_ch) )
    {		
        if(p_baudrate == BAUDRATE_800K)
        {
            MCANBitRate = ((uint32_t) (( (float) CAN_CLK_FREQ_HZ / ((float)( MCAN1_TSEG1 + 1 + MCAN1_TSEG2 + 3 ) * (float) p_baudrate )) - 1 ));
            mcan1Config.bitTiming = MCAN_BTP_BRP(MCANBitRate) | MCAN_BTP_TSEG1(MCAN1_TSEG1 + 1) | MCAN_BTP_TSEG2(MCAN1_TSEG2) | MCAN_BTP_SJW(MCAN1_SJW);
        }
        else
        {
            MCANBitRate = ((uint32_t) (( (float) CAN_CLK_FREQ_HZ / ((float)( MCAN1_TSEG1 + MCAN1_TSEG2 + 3 ) * (float) p_baudrate )) - 1 ));
            mcan1Config.bitTiming = MCAN_BTP_BRP(MCANBitRate) | MCAN_BTP_TSEG1(MCAN1_TSEG1) | MCAN_BTP_TSEG2(MCAN1_TSEG2) | MCAN_BTP_SJW(MCAN1_SJW);
        }
        
        MCAN_Init( &mcan1Config );
        MCAN_InitTxQueue( &mcan1Config );
        MCAN_Enable( &mcan1Config );
        MCAN_IEnableMessageStoredToRxDedBuffer( &mcan1Config, CAN_INTR_LINE_0); /* CAN_INTR_LINE_1 - Check for the Interrupt Line */

        gstrCANInitInfo[p_ch].u32Baudrate = p_baudrate;
        
        MCAN_ConfigRxClassicFilter( &mcan1Config, CAN_FIFO_0, FILTER_1, MSD_ID_ALL_PASS, CAN_STD_ID, MSG_ID_ALL_PASS_MASK );
        /* MCAN_ConfigRxClassicFilter( &mcan1Config, CAN_FIFO_0, FILTER_1, MSD_ID_ALL_PASS, CAN_EXT_ID, MSG_ID_ALL_PASS_MASK ); */
    }
    else
    {
        fl_init_status_U8 = ERR_INVALID_CHANNEL_ID;
    }
    return ( fl_init_status_U8 );
}

/******************************************************************************
* Function name	: CAN_FreeRTOSInit
* returns       : None
* parameters    : None                 
* Description	: This function Initializes CAN FreeRTOS functionalities.
* Notes		:
*******************************************************************************/
void CAN_FreeRTOSInit(void)
{
  xCAN1_TX_Queue = xQueueCreate( CAN1_TX_Queue_SIZE, ( unsigned portBASE_TYPE ) sizeof(CAN_TX_Msg_t) );
  xCAN1_RX_Queue = xQueueCreate( CAN1_RX_Queue_SIZE, ( unsigned portBASE_TYPE ) sizeof(CAN_Rx_Msg_t) );    
  if(pdFAIL == xTaskCreate(CAN1_RX_Task, "CAN1RxTask", CAN1_RX_TASK_STACK_SIZE, (void *) NULL,
                           CAN1_RX_TASK_PRIORITY, (TaskHandle_t*)NULL))
  {
    printf("CAN 1 Rx Task Creation Failed");    
  }
  
  if(pdFAIL == xTaskCreate(CAN1_TX_Task, "CAN1TxTask", CAN1_TX_TASK_STACK_SIZE, (void *) NULL,
							CAN1_TX_TASK_PRIORITY, (TaskHandle_t*)NULL))
  {
	  printf("CAN 1 Tx Task Creation Failed");	  
  }
  
  xCAN1StartTx = xSemaphoreCreateBinary();
  xCAN1STMINStart = xSemaphoreCreateBinary();
  
  xCAN2_TX_Queue = xQueueCreate( CAN2_TX_Queue_SIZE, ( unsigned portBASE_TYPE ) sizeof(CAN_TX_Msg_t) );
  xCAN2_RX_Queue = xQueueCreate( CAN2_RX_Queue_SIZE, ( unsigned portBASE_TYPE ) sizeof(CAN_Rx_Msg_t) );    
  if(pdFAIL == xTaskCreate(CAN2_RX_Task, "CAN2RxTask",CAN2_RX_TASK_STACK_SIZE, (void *) NULL,
                          CAN1_RX_TASK_PRIORITY, (TaskHandle_t*)NULL))
  {
    printf("CAN 2 Rx Task Creation Failed");    
  }    

if(pdFAIL == xTaskCreate(CAN2_TX_Task, "CAN2TxTask", CAN2_TX_TASK_STACK_SIZE, (void *) NULL,
					CAN2_TX_TASK_PRIORITY, (TaskHandle_t*)NULL))
{
	printf("CAN 2 Tx Task Creation Failed");	
}

xCAN2StartTx = xSemaphoreCreateBinary();
xCAN2STMINStart = xSemaphoreCreateBinary();
  
  vQueueAddToRegistry(xCAN1_TX_Queue, "CAN1TxQ");  
  vQueueAddToRegistry(xCAN2_TX_Queue, "CAN2TxQ");
  vQueueAddToRegistry(xCAN1_RX_Queue, "CAN1RxQ");  
  vQueueAddToRegistry(xCAN2_RX_Queue, "CAN2RxQ");
}

/******************************************************************************
* Function name	: CAN_Mid_DeInit
* returns       : None
* parameters    : None
* Description	: This function DeInitializes CAN.
* Notes		:
*******************************************************************************/
void CAN_Mid_DeInit (uint8_t p_channel)
{
	/* CAN register deinit */
	if( CAN_CH1 == p_channel)
	{
		PMC_DisablePeripheral(ID_MCAN0);    
	}
	else if( CAN_CH2 == p_channel)
	{
		PMC_DisablePeripheral(ID_MCAN1);    
	}
	else
	{
		/*< Do Nothing */
	}      
}

/******************************************************************************
**	Function Name	: CAN_Mid_Enable
**	Input Params	: Channel no, p_connection_flag_U8
**	Output Params	: Init status TRUE/False
**	Description	: This function Enables CAN Tx and Rx
******************************************************************************/
uint8_t CAN_Mid_Enable(uint8_t p_channel,uint8_t p_connection_flag_U8)
{
  uint8_t fl_status_U8 = STATUS_NOERROR;
  
  if(CAN_CH1 == p_channel)
  {
    /* ------------------------- */
    /* -- ADD CAN ENABLE CODE -- */
    /* ------------------------- */
    l_CAN_Rx1_connection_flag_U8 = p_connection_flag_U8;
    l_enable_CAN_Tx1_BOOL = TRUE;
  }
  else if(CAN_CH2 == p_channel)
  {
    /* ------------------------- */
    /* -- ADD CAN ENABLE CODE -- */
    /* ------------------------- */
    l_CAN_Rx2_connection_flag_U8 = p_connection_flag_U8;
    l_enable_CAN_Tx2_BOOL = TRUE;
  }
  else
  {
    l_enable_CAN_Tx1_BOOL = FALSE;
    l_enable_CAN_Tx2_BOOL = FALSE;
    fl_status_U8 = ERR_FAILED;
  }
  return(fl_status_U8);
}

/******************************************************************************
**	Function Name	: CAN_Mid_Disable
**	Input Params	: Channel no
**	Output Params	: Init status TRUE/False
**	Description	: This function Disables CAN Tx and Rx
******************************************************************************/
uint8_t CAN_Mid_Disable(uint8_t p_channel)
{
    uint8_t fl_status_U8 = STATUS_NOERROR;
    
    if(CAN_CH1 == p_channel)
    {
        if (PMC_IsPeriphEnabled( ID_MCAN0 ))
        {
            MCAN_Disable_Test(&mcan0Config);
            l_enable_CAN_Tx1_BOOL = FALSE;
        }
    }
    else if(CAN_CH2 == p_channel)
    {
        if (PMC_IsPeriphEnabled( ID_MCAN1 ))
        {
            MCAN_Disable_Test(&mcan1Config);
            l_enable_CAN_Tx2_BOOL = FALSE;
        }
    }
    else
    {
        l_enable_CAN_Tx1_BOOL = TRUE;
        l_enable_CAN_Tx2_BOOL = TRUE;
        l_CAN_Rx1_connection_flag_U8 = RX_BOTH_STD_EXT_MSG;
        l_CAN_Rx2_connection_flag_U8 = RX_BOTH_STD_EXT_MSG;
        
        fl_status_U8 = ERR_FAILED;
    }
    return(fl_status_U8);
}

/******************************************************************************
**	Function Name	: CAN_Power_Off
**	Input Params	: none
**	Output Params	: none
**	Description	: This function Power Offs the CAN controller 
******************************************************************************/
void CAN_Power_Off(void)
{
	PMC->PMC_SCDR |= PMC_SCDR_PCK5;  /* disable PCK */ 
}

/******************************************************************************
**	Function Name	: CAN_Mid_Get_Config
**	Input Params	: uint8_t p_channel_no_U8, CAN_Config_t Config, uint32_t* value.
**	Output Params	: None
**	Description		: Returns the current baud rate on the requested channel
******************************************************************************/
void CAN_Mid_Get_Config(uint8_t p_channel_no_U8, CAN_Config_t Config, uint32_t* value)
{  
	if((1 == p_channel_no_U8) || (2 == p_channel_no_U8))
	{
		switch(Config)
		{
			case CAN_BAUDRATE:
			if(0 != gstrCANInitInfo[p_channel_no_U8 - 1].u32Baudrate)
			{
				*value = gstrCANInitInfo[p_channel_no_U8 - 1].u32Baudrate;
			}
			else
			{
				*value = 0xFFFFFFFF;
			}
			break;
			
			case CAN_SJW:
			if(0 != gstrCANInitInfo[p_channel_no_U8 - 1].u32Baudrate)
			{
				*value = gstrCANInitInfo[p_channel_no_U8 - 1].u8SJW;
			}
			else
			{
				*value = ERR_INVALID_CHANNEL_ID;
			}
			break;
			
			case CAN_SAMPLING_POINT:
			if(0 != gstrCANInitInfo[p_channel_no_U8 - 1].u32Baudrate)
			{
				*value = gstrCANInitInfo[p_channel_no_U8 - 1].u8SamplingMode;
			}
			else
			{
				*value = ERR_INVALID_CHANNEL_ID;
			}
			break;
			
			default :
			*value = ERR_INVALID_CHANNEL_ID;
			break;
		}
	}
	else
	{
		*value = ERR_INVALID_CHANNEL_ID;
	}
}

/******************************************************************************
**	Function Name	: CAN_Mid_get_current_baudrate
**	Input Params	: channel no.
**	Output Params	: Baud rate
**	Description		: Reurns the current baud rate on the requested channel
******************************************************************************/
uint32_t CAN_Mid_get_current_baudrate(uint8_t p_channel_no_U8)
{
	uint32_t fl_current_baud_rate_U32;
	
	if((p_channel_no_U8 == 1) && (0 != gstrCANInitInfo[0].u32Baudrate))
	{
		fl_current_baud_rate_U32 = gstrCANInitInfo[0].u32Baudrate;
	}
	else if((p_channel_no_U8 == 2) && (0 != gstrCANInitInfo[1].u32Baudrate))
	{
		fl_current_baud_rate_U32 = gstrCANInitInfo[1].u32Baudrate;
	}
	else
	{
		fl_current_baud_rate_U32 = 0xFFFFFFFF;
	}
	
	return(fl_current_baud_rate_U32);
}

/******************************************************************************
**	Function Name	: CAN_Mid_set_baudrate
**	Input Params	: Baud rate,channel no.
**	Output Params	: Error status
**	Description		: Sets CAN to requested Baud rate
******************************************************************************/
uint8_t CAN_Mid_set_baudrate(uint32_t p_baud_rate_U32, uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;
	
	if(1 == p_channel_no_U8)
	{
		gstrCANInitInfo[CAN_CH1].u32Baudrate = p_baud_rate_U32;
	}
	else if(2 == p_channel_no_U8)
	{
		gstrCANInitInfo[CAN_CH2].u32Baudrate = p_baud_rate_U32;
	}
	else
	{
		fl_error_status_U8 = ERR_INVALID_CHANNEL_ID;
	}
	return(fl_error_status_U8);  
}

/******************************************************************************
**	Function Name	: LowLevel_CAN_get_loopback_status
**	Input Params	: channel no.
**	Output Params	: Error status
**	Description		: Gives the loop back status of requested channel
******************************************************************************/
uint8_t LowLevel_CAN_get_loopback_status( uint8_t p_channel_no_U8)
{
	uint8_t fl_ret_status_U8 = ERR_INVALID_CHANNEL_ID;
	if(1 == p_channel_no_U8)
	{
		fl_ret_status_U8 = gstrCANInitInfo[CAN_CH1].u8LoopBackMode;
	}
	else if(2 == p_channel_no_U8)
	{
		fl_ret_status_U8 = gstrCANInitInfo[CAN_CH2].u8LoopBackMode;
	}
	else
	{
		/* Do Nothing */
	}
	return(fl_ret_status_U8);
}

/******************************************************************************
**	Function Name	: LowLevel_CAN_get_current_SJW
**	Input Params	: channel no.
**	Output Params	: SJW
**	Description		: Returns the current SJW on the requested channel
******************************************************************************/
uint8_t LowLevel_CAN_get_current_SJW(uint8_t p_channel_no_U8)
{
	uint8_t fl_current_SJW_U8 = 0;
	if((p_channel_no_U8 == 1) && (0 != gstrCANInitInfo[CAN_CH1].u32Baudrate))
	{
		fl_current_SJW_U8 = gstrCANInitInfo[CAN_CH1].u8SJW;
	}
	else if((p_channel_no_U8 == 2) && (0 != gstrCANInitInfo[CAN_CH2].u32Baudrate))
	{
		fl_current_SJW_U8 = gstrCANInitInfo[CAN_CH2].u8SJW;
	}
	else
	{
		fl_current_SJW_U8 = ERR_INVALID_CHANNEL_ID;
	}
	return(fl_current_SJW_U8);  
}


/******************************************************************************
**	Function Name	: LowLevel_CAN_enable_loopback
**	Input Params	: channel no.
**	Output Params	: Error status
**	Description		: Sets CAN to loopback mode
******************************************************************************/
uint8_t  LowLevel_CAN_enable_loopback( uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;

	if(1 == p_channel_no_U8)
	{
		gstrCANInitInfo[CAN_CH1].u8LoopBackMode = TRUE;
	}
	else if(2 == p_channel_no_U8)
	{
		gstrCANInitInfo[CAN_CH2].u8LoopBackMode = TRUE;
	}
	else
	{
		fl_error_status_U8 = ERR_INVALID_CHANNEL_ID;
	}
	return(fl_error_status_U8);
}

/******************************************************************************
**	Function Name	: LowLevel_CAN_disable_loopback
**	Input Params	: channel no.
**	Output Params	: Error status
**	Description		: Disables CAN to loop back mode
******************************************************************************/
uint8_t LowLevel_CAN_disable_loopback( uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;

	if(1 == p_channel_no_U8)
	{
		gstrCANInitInfo[CAN_CH1].u8LoopBackMode = FALSE;
	}
	else if(2 == p_channel_no_U8)
	{
		gstrCANInitInfo[CAN_CH2].u8LoopBackMode = FALSE;
	}
	else
	{
		fl_error_status_U8 = ERR_INVALID_CHANNEL_ID;
	}
	return(fl_error_status_U8);
}

/******************************************************************************
**	Function Name	: LowLevel_CAN_get_current_sampling_mode
**	Input Params	: channel no.
**	Output Params	: Sampling mode
**	Description		: Returns the current sampling mode on the requested channel
******************************************************************************/
uint8_t LowLevel_CAN_get_current_sampling_mode(uint8_t p_channel_no_U8)
{
	uint8_t fl_current_SAM_U8 = 0;
	
	if((p_channel_no_U8 == 1) && (0 != gstrCANInitInfo[CAN_CH1].u32Baudrate))
	{
		fl_current_SAM_U8 = gstrCANInitInfo[CAN_CH1].u8SamplingMode;
	}
	else if((p_channel_no_U8 == 2) && (0 != gstrCANInitInfo[CAN_CH2].u32Baudrate))
	{
		fl_current_SAM_U8 = gstrCANInitInfo[CAN_CH2].u8SamplingMode;
	}
	else
	{
		fl_current_SAM_U8 = ERR_INVALID_CHANNEL_ID;
	}	
	return(fl_current_SAM_U8);
}

#if OLD_LOGIC
uint32_t failCount=0;
/******************************************************************************
**	Function Name	: CAN_Mid_Transmit
**	Input Params	: channel no.
**	Output Params	: none
**	Description		: Returns the CAN Mid send status of the requested channel
Note                : Few Debug codes are yet to be cleaned up. 
******************************************************************************/
Mid_API_Status_t CAN_Mid_Transmit(CAN_CH_TypeDef p_ch , CAN_TX_Msg_t *p_tx_msg)
{
  Mid_API_Status_t fl_Status = MID_FAIL;  

    if(CAN_CH1 == p_ch)
    {
         //taskENTER_CRITICAL();
	    //if (((Queue_t*)xCAN1_TX_Queue)->uxMessagesWaiting)
	    if( uxQueueMessagesWaiting(xCAN1_TX_Queue) )
	    {
		    //taskEXIT_CRITICAL();
			#if CAN_DEBUG		
		    //DqueueCount1 = ((Queue_t*)xCAN1_TX_Queue)->uxMessagesWaiting;
			#endif
		    if( xQueueSend( xCAN1_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
		    {
				#if CAN_DEBUG
			    txCatchTransmit[txCatchIndex][0] = p_tx_msg->data[0];
			    txCatchTransmit[txCatchIndex++][1] = 0x88;
			    if (txCatchIndex == 100)
			    {
				    txCatchIndex = 0;
			    }
				enQCount++;
				#endif
			    fl_Status = MID_PASS;
			    
		    }
		    else
		    {
				#if CAN_DEBUG
			    txCatchFailedTransmit[txCatchIndexFail][0] = p_tx_msg->data[0];
			    txCatchFailedTransmit[txCatchIndexFail++][1] = 0x88;
			    if (txCatchIndexFail == 100)
			    {
				    txCatchIndexFail = 0;
			    }
			    enQFailCOunt++;
				#endif
			    fl_Status = MID_FAIL;
		    }
	    }
	    else {
		    //taskEXIT_CRITICAL();
			#if CAN_DEBUG		
		    CANtXCheck = 0xAA;
			#endif
		    fl_Status = CAN_Mid_txData(p_ch, p_tx_msg, 0xEE);
		    if (fl_Status == MID_FAIL) {
				#if CAN_DEBUG
			    //DqueueCount2 = ((Queue_t*)xCAN1_TX_Queue)->uxMessagesWaiting;
				#endif
			    if( xQueueSend( xCAN1_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
			    {
					#if CAN_DEBUG
				    txCatchTransmit[txCatchIndex][0] = p_tx_msg->data[0];
				    txCatchTransmit[txCatchIndex++][1] = 0x22;
				    if (txCatchIndex == 100)
				    {
					    txCatchIndex = 0;
				    }
				    enQCount++;
					#endif
				    fl_Status = MID_PASS;
			    }
			    else
			    {
					#if CAN_DEBUG
				    txCatchFailedTransmit[txCatchIndexFail][0] = p_tx_msg->data[0];
				    txCatchFailedTransmit[txCatchIndexFail++][1] = 0x88;
				    if (txCatchIndexFail == 100)
				    {
					    txCatchIndexFail = 0;
				    }
				    enQFailCOunt++;
					#endif
				    fl_Status = MID_FAIL;
			    }
		    }
	    }        
    }
    else if(CAN_CH2 == p_ch ) 
    {
	    //taskENTER_CRITICAL();
	    //if (((Queue_t*)xCAN2_TX_Queue)->uxMessagesWaiting)
	    if( uxQueueMessagesWaiting(xCAN2_TX_Queue) )
	    {
		    //taskEXIT_CRITICAL();	
			#if CAN_DEBUG	
		    //DqueueCount1 = ((Queue_t*)xCAN2_TX_Queue)->uxMessagesWaiting;
			#endif
		    if( xQueueSend( xCAN2_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
		    {
				#if CAN_DEBUG
			    txCatchTransmit[txCatchIndex][0] = p_tx_msg->data[0];
			    txCatchTransmit[txCatchIndex++][1] = 0x88;
			    if (txCatchIndex == 100)
			    {
				    txCatchIndex = 0;
			    }
				enQCount++;
				#endif
			    fl_Status = MID_PASS;			    
		    }
		    else
		    {
				#if CAN_DEBUG
			    txCatchFailedTransmit[txCatchIndexFail][0] = p_tx_msg->data[0];
			    txCatchFailedTransmit[txCatchIndexFail++][1] = 0x88;
			    if (txCatchIndexFail == 100)
			    {
				    txCatchIndexFail = 0;
			    }
			    enQFailCOunt++;
				#endif
			    fl_Status = MID_FAIL;
		    }
	    }
	    else {
		    //taskEXIT_CRITICAL();
			#if CAN_DEBUG		
		    CANtXCheck = 0xAA;
			#endif
		    fl_Status = CAN_Mid_txData(p_ch, p_tx_msg, 0xEE);
		    if (fl_Status == MID_FAIL) {
				#if CAN_DEBUG
			    //DqueueCount2 = ((Queue_t*)xCAN2_TX_Queue)->uxMessagesWaiting;
				#endif
			    if( xQueueSend( xCAN2_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
			    {
					#if CAN_DEBUG
				    txCatchTransmit[txCatchIndex][0] = p_tx_msg->data[0];
				    txCatchTransmit[txCatchIndex++][1] = 0x22;
				    if (txCatchIndex == 100)
				    {
					    txCatchIndex = 0;
				    }
				    enQCount++;
					#endif
				    fl_Status = MID_PASS;
			    }
			    else
			    {
					#if CAN_DEBUG
				    txCatchFailedTransmit[txCatchIndexFail][0] = p_tx_msg->data[0];
				    txCatchFailedTransmit[txCatchIndexFail++][1] = 0x88;
				    if (txCatchIndexFail == 100)
				    {
					    txCatchIndexFail = 0;
				    }
				    enQFailCOunt++;
					#endif
				    fl_Status = MID_FAIL;
			    }
		    }
	    }
    }
    
    if ( MID_PASS == fl_Status )
    {
        CAN_Loopback_Tx(p_tx_msg, p_ch, DONT_RELEASE);
    }

	if(MID_FAIL == fl_Status)  
	{
		failCount++;		
	}    
	return fl_Status;
}

#endif


/******************************************************************************
**	Function Name	: CAN_Mid_Transmit
**	Input Params	: channel no.
**	Output Params	: none
**	Description		: Returns the CAN Mid send status of the requested channel
Note                : Few Debug codes are yet to be cleaned up.
******************************************************************************/
Mid_API_Status_t CAN_Mid_Transmit(CAN_CH_TypeDef p_ch , CAN_TX_Msg_t *p_tx_msg)
{
	Mid_API_Status_t fl_Status = MID_FAIL;

	if(CAN_CH1 == p_ch)
	{		
		if( xQueueSend( xCAN1_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
		{				
			fl_Status = MID_PASS;				
		}
		else
		{
			Garuda_Debug.CAN_Tx_Queue_Fail++;
			fl_Status = MID_FAIL;
		}
	}
	else if(CAN_CH2 == p_ch )
	{
		if( xQueueSend( xCAN2_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
		{				
			fl_Status = MID_PASS;
		}
		else
		{	
			Garuda_Debug_CAN2.CAN_Tx_Queue_Fail++;			
			fl_Status = MID_FAIL;
		}
	}
	else
	{
		//Do nothing
	}

    if ( MID_PASS == fl_Status )
    {
	    CAN_Loopback_Tx(p_tx_msg, p_ch, DONT_RELEASE);
    }
	
	return fl_Status;
}

#if OLD_LOGIC
/******************************************************************************
**	Function Name	: CAN_Mid_Transmit_ISR
**	Input Params	: channel no, p_tx_msg
**	Output Params	: None
**	Description		: Returns the CAN Mid send from ISR status of the 
                      requested channel
                      Note : Included a separate function, since the periodic 
                             message functions are called from the Timer ISR,
                             So use FreeRTOS FROM_ISR calls.
******************************************************************************/
Mid_API_Status_t CAN_Mid_Transmit_ISR(CAN_CH_TypeDef p_ch , CAN_TX_Msg_t *p_tx_msg)
{
    Mid_API_Status_t fl_Status = MID_FAIL;    
    
    if(CAN_CH1 == p_ch)
    {                
        portDISABLE_INTERRUPTS();
		#if CAN_DEBUG
        CAN1SendCount++;
		#endif
        if (((Queue_t*)xCAN1_TX_Queue)->uxMessagesWaiting)
        {           
            portENABLE_INTERRUPTS();
            if( xQueueSendFromISR( xCAN1_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
            {
                fl_Status = MID_PASS;
            }
            else
            {
				#if CAN_DEBUG
                CAN1TXQueueFail++;
				#endif
                fl_Status = MID_FAIL;
            }
        }
        else {            
            portENABLE_INTERRUPTS();
            fl_Status = CAN_Mid_txData(p_ch, p_tx_msg, 0xEE);
            if (fl_Status == MID_FAIL) {
                if( xQueueSendFromISR( xCAN1_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
                {
                    fl_Status = MID_PASS;
                }
                else
                {
					#if CAN_DEBUG
                    CAN1TXQueueFail++;
					#endif
                    fl_Status = MID_FAIL;
                }
            }
        }
    }
    else if(CAN_CH2 == p_ch)
    {               
        portDISABLE_INTERRUPTS();
		#if CAN_DEBUG
        CAN2SendCount++;
		#endif
        if (((Queue_t*)xCAN2_TX_Queue)->uxMessagesWaiting)
        {            
            portENABLE_INTERRUPTS();
            if( xQueueSendFromISR( xCAN2_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
            {
                fl_Status = MID_PASS;
            }
            else
            {
				#if CAN_DEBUG
                CAN2TXQueueFail++;
				#endif
                fl_Status = MID_FAIL;
            }
        }
        else {
            portENABLE_INTERRUPTS();
            fl_Status = CAN_Mid_txData(p_ch, p_tx_msg, 0xEE);
            if (fl_Status == MID_FAIL) {
                if( xQueueSendFromISR( xCAN2_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
                {
                    fl_Status = MID_PASS;
                }
                else
                {
					#if CAN_DEBUG
                    CAN2TXQueueFail++;
					#endif
                    fl_Status = MID_FAIL;
                }
            }
        }
    }
    else
    {
        //Invalid Channel
    }
    
    if ( MID_PASS == fl_Status )
    {
        CAN_Loopback_Tx(p_tx_msg, p_ch, DONT_RELEASE_ISR);    
    }    
    return fl_Status;
}
#endif


/******************************************************************************
**	Function Name	: CAN_Mid_Transmit_ISR
**	Input Params	: channel no, p_tx_msg
**	Output Params	: None
**	Description		: Returns the CAN Mid send from ISR status of the 
                      requested channel
                      Note : Included a separate function, since the periodic 
                             message functions are called from the Timer ISR,
                             So use FreeRTOS FROM_ISR calls.
******************************************************************************/
Mid_API_Status_t CAN_Mid_Transmit_ISR(CAN_CH_TypeDef p_ch , CAN_TX_Msg_t *p_tx_msg)
{
    Mid_API_Status_t fl_Status = MID_FAIL;    
    
    if(CAN_CH1 == p_ch)
    {                                                   
        if( xQueueSendFromISR( xCAN1_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
        {
            fl_Status = MID_PASS;
        }
        else
        {
			#if CAN_DEBUG
            CAN1TXQueueFail++;
			#endif
			Garuda_Debug.CAN_Tx_Queue_Fail++;
            fl_Status = MID_FAIL;
        }        
    }
    else if(CAN_CH2 == p_ch)
    {                                               
        if( xQueueSendFromISR( xCAN2_TX_Queue , (void *) p_tx_msg, ( TickType_t ) 0 ) == pdPASS)
        {
	        fl_Status = MID_PASS;
        }
        else
        {
	        #if CAN_DEBUG
	        CAN2TXQueueFail++;
			Garuda_Debug_CAN2.CAN_Tx_Queue_Fail++;
	        #endif
	        fl_Status = MID_FAIL;
        }
     }        
    else
    {
        //Invalid Channel
    }
    
    if ( MID_PASS == fl_Status )
    {
        CAN_Loopback_Tx(p_tx_msg, p_ch, DONT_RELEASE_ISR);    
    }    
    return fl_Status;
}


uint32_t CANMidTxDataFailCount =0;
/******************************************************************************
**	Function Name	: CAN_Mid_txData
**	Input Params	: channel no, pMsg, callSrc
**	Output Params	: none
**	Description		: Returns the CAN Mid tx Send status.
******************************************************************************/
Mid_API_Status_t CAN_Mid_txData (CAN_CH_TypeDef p_ch, CAN_TX_Msg_t *pMsg, uint8_t callSrc)
{
    MCan_ConfigType *pChConfig;
    uint32_t		*pMailBox;
    Mid_API_Status_t fl_Status = MID_PASS;
    
    if (p_ch == CAN_CH1) {
        pChConfig = &mcan0Config;
    }
    else if (p_ch == CAN_CH2) {
        pChConfig = &mcan1Config;
    }
    else {
        return MID_FAIL;
    }
    
    if (pChConfig->pMCan->MCAN_TXBRP == 0) 
    {
        pMailBox = (uint32_t *) MCAN_ConfigTxDedBuffer(pChConfig, TX_BUFFER_0, pMsg->msg_id,
                                           ((pMsg->ide)? CAN_EXT_ID : CAN_STD_ID),pMsg->dlc );

        memcpy(pMailBox, pMsg->data, pMsg->dlc);
		#if CAN_DEBUG
        //CANMidTxBuffer[CanMidIndex][0]= pMsg->data[0];
        //CANMidTxBuffer[CanMidIndex++][1] = callSrc;
        //if(CanMidIndex== 100)
        //{
            //CanMidIndex = 0;	
        //}
		#endif
        MCAN_SendTxDedBuffer(pChConfig, TX_BUFFER_0 );
		#if CAN_DEBUG
        directSendCount++;
		if(p_ch == CAN_CH1)
		{
			Garuda_Debug.CAN_Last_Tx_Data = pMsg->data[0];
			Garuda_Debug.CAN_Mid_Tx_Send++;	
		}
		else
		{
			Garuda_Debug_CAN2.CAN_Last_Tx_Data = pMsg->data[0];
			Garuda_Debug_CAN2.CAN_Mid_Tx_Send++;
		}
		#endif
    }
    else 
    {
		CANMidTxDataFailCount++;
		if(p_ch == CAN_CH1)
		{
			Garuda_Debug.CAN_Mid_Tx_Fail++;
		}
		else
		{
			Garuda_Debug_CAN2.CAN_Mid_Tx_Fail++;
		}
        fl_Status = MID_FAIL;
    }	
    return fl_Status;
}


#if CAN_OLD_LOGIC
uint32_t dummycount =0;
uint32_t CANTotalCount = 0;
uint32_t Alloc = 0;
uint32_t Alloc1 =0;
uint32_t framecount = 0;
uint32_t canTaskTxLimit = 0;
uint32_t can2MaxTxPerSch = 0;

void CAN2_RX_Task(void *PvParam)
{ 
  CAN_Rx_Msg_t  CAN2RxMsg;
  uint32_t TimeToWaitForCAN2Q;

  for(;;)
  {
      AllocOk++;
      TimeToWaitForCAN2Q = portMAX_DELAY;
      if (can2MaxTxPerSch < canTaskTxLimit)
	  {
		  can2MaxTxPerSch = canTaskTxLimit;
	  }
	  canTaskTxLimit = 0;
      while(xQueueReceive(xCAN2_RX_Queue, &CAN2RxMsg, TimeToWaitForCAN2Q) == pdTRUE)
      {
		  Alloc++;
          TimeToWaitForCAN2Q = 0;
        if(J2534_PASS == J2534_checkFilter((uint8_t*)&CAN2RxMsg.msgId,CAN2RxMsg.msgLen,GARUDA_CAN_CH1))
        {
#if COUNT_MONITER        
          can2Rxcnt++;
#endif
          if(Is_DataLog_Active())
          {
            can2BufInfo.address[can2BufInfo.len] = get_CAN1_or_ISO1();
            memcpy(&can2BufInfo.address[can2BufInfo.len+1],(uint8_t*) &CAN2RxMsg,(sizeof(CAN_Rx_Msg_t)));
            can2BufInfo.len+=sizeof(CAN_Rx_Msg_t)+1;
            CANTotalCount += sizeof(CAN_Rx_Msg_t)+1;
            if((can2BufInfo.len + sizeof(CAN_Rx_Msg_t) + 1) > DATALOG_MAX_IN_SINGLE_FRAME)
            {
              framecount++;
              break;
            }
          }
          else
          {
			can2BufInfo.len = 0;
            can2BufInfo.address = pvPortMalloc(DATALOG_MAX_IN_SINGLE_FRAME);
            if (!can2BufInfo.address) {
                continue;
            }
            can2BufInfo.address[can2BufInfo.len+0] = get_CAN1_or_ISO1();
            can2BufInfo.address[can2BufInfo.len+1] = CAN_Receive_msg;
            can2BufInfo.address[can2BufInfo.len+2] = 0; /* Segment number */
            can2BufInfo.address[can2BufInfo.len+3] = STATUS_NOERROR;     
            /* LSB of length Header + Data */
            memcpy(&can2BufInfo.address[can2BufInfo.len+4],(uint8_t*) &CAN2RxMsg,(sizeof(CAN_Rx_Msg_t)));
			can2BufInfo.len += sizeof(CAN_Rx_Msg_t) + 4;
			dummycount++;
            (void)Garuda_Tx_data_on_USB(can2BufInfo.address, can2BufInfo.len,RELEASE);
          }
          if (++canTaskTxLimit >= 24) {
              break;
          }
        }
      }
	  portYIELD_WITHIN_API();
  }
}
#endif

/******************************************************************************
**	Function Name	: CAN2_RX_Task
**	Input Params	: None
**	Output Params	: None
**	Description	    : This is a FreeRTOS TAsk for Handling CAN
******************************************************************************/
void CAN2_RX_Task(void *PvParam)
{
	CAN_Rx_Msg_t  CAN2RxMsg;
	uint32_t TimeToWaitForCAN2Q;    
    
	for(;;)
	{
		CAN2_MsgCount = 0;
		TimeToWaitForCAN2Q = portMAX_DELAY;
		while(xQueueReceive(xCAN2_RX_Queue, &CAN2RxMsg, TimeToWaitForCAN2Q) == pdTRUE)
		{
			if(J2534_PASS == J2534_checkFilter((uint8_t*)&CAN2RxMsg.msgId,CAN2RxMsg.msgLen,
			((J1939_PROTOCOL_ID == get_CANCH1_or_ISO15756CH1_or_J1939CH1()) ? GARUDA_J1939_CH2 :  GARUDA_CAN_CH2)))
			{
				#if COUNT_MONITER 
				can2Rxcnt++;
				Garuda_Debug_CAN2.CAN_Rx_Count++;
				#endif
				
				if(0 == CAN2_MsgCount ) {
					can2BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
					
					if(Is_DataLog_Active())
					can2BufInfo.len = 2;
					else
					can2BufInfo.len = 4;
					
					#if COUNT_MONITER
					if(can2BufInfo.address){
					CAN2AllocOk++;						
					}
					#endif
				}
				if (!can2BufInfo.address) {
					#if COUNT_MONITER
					CAN2MallocFailCount++;
					//WiFi_Led_ON();
					#endif
					continue;
				}
				
				can2BufInfo.address[0] = get_CANCH1_or_ISO15756CH1_or_J1939CH1();	

				if(Is_DataLog_Active())
				{					
					/**< Manage the Packet Length */
					can2BufInfo.address[can2BufInfo.len++] = DATALOG_FIXED_PACKET_LENGTH + CAN2RxMsg.msgLen ;

					/**< Manage the Rx Flags */
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)(CAN2RxMsg.rxFlags & 0x000000FF);
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)((CAN2RxMsg.rxFlags >> 8) & 0x000000FF);					
															
					/**< Manage the Rx Timestamp */
					/* get_extended_data_logging_timestamp(&CAN2DataLoggingExtendedTime); */
					get_extended_32Bit_data_logging_timestamp(&CAN2DataLoggingExtendedTime);
										
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)(CAN2DataLoggingExtendedTime & 0x000000FF);
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)((CAN2DataLoggingExtendedTime >> 8) & 0x000000FF);
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)((CAN2DataLoggingExtendedTime >> 16) & 0x000000FF);
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)((CAN2DataLoggingExtendedTime >> 24) & 0x000000FF);
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)((CAN2DataLoggingExtendedTime >> 32) & 0x000000FF);
										
					memcpy(&can2BufInfo.address[can2BufInfo.len], &CAN2RxMsg.msgId, CAN2RxMsg.msgLen);
					can2BufInfo.len += CAN2RxMsg.msgLen;	
										
					CAN2_MsgCount++;
										
					if((can2BufInfo.len + MAX_DATALOG_FRAME_SIZE) >= MAX_USB_BUFFER_SIZE)
					{
						break;
					}					
				}
				else
				{						                					
					can2BufInfo.address[1] = CAN_Receive_msg;
					can2BufInfo.address[2] = 0; /* Segment number */
						                
					/**< Manage the Packet Length */
					can2BufInfo.address[can2BufInfo.len++] = CAN_FIXED_PACKET_LENGTH + CAN2RxMsg.msgLen ;
						                
					/**< Manage the Rx Flags */
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)(CAN2RxMsg.rxFlags & 0x000000FF);
					can2BufInfo.address[can2BufInfo.len++] = (uint8_t)((CAN2RxMsg.rxFlags >> 8) & 0x000000FF);
						                
					memcpy(&can2BufInfo.address[can2BufInfo.len], &CAN2RxMsg.timeStamp,  (CAN_PACKET_COPY_LENGTH + CAN2RxMsg.msgLen));
					can2BufInfo.len +=  (CAN_PACKET_COPY_LENGTH + CAN2RxMsg.msgLen);
						                
					CAN2_MsgCount++;
						                
					if((can2BufInfo.len + MAX_CAN_FRAME_SIZE) >= MAX_USB_BUFFER_SIZE)
					{
						break;
					}					
				}				
			}
			else
			{
				/*< Filter Fail, so Drop Frames */
			}
            
			if(Is_DataLog_Active())		    
			{
				TimeToWaitForCAN2Q = portMAX_DELAY;
			}
			else
			{
				TimeToWaitForCAN2Q = 1;
			}  
		}/**< End of while(xQueueReceive()) */
            
		if(CAN2_MsgCount)
		{
			#if COUNT_MONITER 
			CAN2TotalFrame += CAN2_MsgCount;
			#endif
                                
			if(Is_DataLog_Active() )//&& startLogging)				
			{
				can2BufInfo.address[1] = (MODE | CAN2_MsgCount);
				WriteToLog(can2BufInfo);                    
			}
			else
			{
				can2BufInfo.address[3] = (MODE | CAN2_MsgCount);
				(void)Garuda_Tx_data_on_USB(can2BufInfo.address, can2BufInfo.len, RELEASE);
			}                                
		}
	}
}   


#if CAN_OLD_LOGIC
uint8_t can1TaskTxLimit;
uint32_t can1RxCount;
uint32_t can1MaxTxPerSch = 0;
void CAN1_RX_Task(void *PvParam)
{ 
  CAN_Rx_Msg_t  CAN1RxMsg;
  uint32_t TimeToWaitForCAN2Q;
      
  for(;;)
  {
      TimeToWaitForCAN2Q = portMAX_DELAY;
      if (can1MaxTxPerSch < can1TaskTxLimit)
	  {
		  can1MaxTxPerSch = can1TaskTxLimit;
	  }
	  can1TaskTxLimit = 0;
      while(xQueueReceive(xCAN1_RX_Queue, &CAN1RxMsg, TimeToWaitForCAN2Q) == pdTRUE)
      {		  
         TimeToWaitForCAN2Q = 0;
        if(J2534_PASS == J2534_checkFilter((uint8_t*)&CAN1RxMsg.msgId,CAN1RxMsg.msgLen,GARUDA_CAN_CH1))
        {
#if COUNT_MONITER        
          can1RxCount++;
#endif
          if(Is_DataLog_Active())
          {
            can1BufInfo.address[can1BufInfo.len] = get_CAN_or_ISO();
            memcpy(&can1BufInfo.address[can1BufInfo.len+1],(uint8_t*) &CAN1RxMsg,(sizeof(CAN_Rx_Msg_t)));
            can1BufInfo.len+=sizeof(CAN_Rx_Msg_t)+1;            
            if((can1BufInfo.len + sizeof(CAN_Rx_Msg_t) + 1) > DATALOG_MAX_IN_SINGLE_FRAME)
            {
              break;
            }
          }
          else
          {
			can1BufInfo.len = 0;
            can1BufInfo.address = pvPortMalloc(DATALOG_MAX_IN_SINGLE_FRAME);
            if (!can1BufInfo.address) {
                continue;
            }
            can1BufInfo.address[can1BufInfo.len+0] = get_CAN_or_ISO();
            can1BufInfo.address[can1BufInfo.len+1] = CAN_Receive_msg;
            can1BufInfo.address[can1BufInfo.len+2] = 0; /* Segment number */
            can1BufInfo.address[can1BufInfo.len+3] = STATUS_NOERROR;     
            ///* LSB of length Header + Data */
            memcpy(&can1BufInfo.address[can1BufInfo.len+4],(uint8_t*) &CAN1RxMsg,(sizeof(CAN_Rx_Msg_t)));
			can1BufInfo.len += sizeof(CAN_Rx_Msg_t) + 4;
            (void)Garuda_Tx_data_on_USB(can1BufInfo.address, can1BufInfo.len,RELEASE);
          }
          if (++can1TaskTxLimit >= 24) {
              break;
          }
        }
      }	  
	  portYIELD_WITHIN_API();
  }
}
#endif

#if PACKET_TEST_CODE
/******************************************************************************
**	Function Name	: CAN1_RX_Task
**	Input Params	: None
**	Output Params	: None
**	Description	    : This is a FreeRTOS Task for Handling CAN
******************************************************************************/
void CAN1_RX_Task(void *PvParam)
{
    CAN_Rx_Msg_t  CAN1RxMsg;
    uint32_t TimeToWaitForCAN1Q;
    uint8_t CAN_MsgCount = 0;
    
    for(;;)
    {
        CAN_MsgCount = 0;
        TimeToWaitForCAN1Q = portMAX_DELAY;
        while(xQueueReceive(xCAN1_RX_Queue, &CAN1RxMsg, TimeToWaitForCAN1Q) == pdTRUE)
        {
            if(J2534_PASS == J2534_checkFilter((uint8_t*)&CAN1RxMsg.msgId,CAN1RxMsg.msgLen,
								((J1939_PROTOCOL_ID == get_CAN_or_ISO15756_or_J1939()) ? GARUDA_J1939_CH1 :  GARUDA_CAN_CH1)))
            {				
				#if COUNT_MONITER
				can1Rxcnt++;
				#endif
				
				if(1)//Is_DataLog_Active())
				{	
					
					#if 1				
					if(0 == CAN_MsgCount ) {
						can1BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
						can1BufInfo.len = 4;
						
						#if COUNT_MONITER
						if(can1BufInfo.address)
						{
							CAN1AllocOk++;
						}
						#endif
					}
					if (!can1BufInfo.address) {
						#if COUNT_MONITER
						CAN1MallocFailCount++;
						//WiFi_Led_ON();
						#endif
						continue;
					}
					
					can1BufInfo.address[0] = get_CAN_or_ISO15756_or_J1939();
					can1BufInfo.address[1] = CAN_Receive_msg;
					can1BufInfo.address[2] = 0; /* Segment number */
					
					/**< Manage the Packet Length */
					can1BufInfo.address[can1BufInfo.len++] = CAN_FIXED_PACKET_LENGTH + CAN1RxMsg.msgLen ;
					
					/**< Manage the Rx Flags */
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1RxMsg.rxFlags & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1RxMsg.rxFlags >> 8) & 0x000000FF);
					
					memcpy(&can1BufInfo.address[can1BufInfo.len], &CAN1RxMsg.timeStamp, (CAN_PACKET_COPY_LENGTH + CAN1RxMsg.msgLen));
					can1BufInfo.len += (CAN_PACKET_COPY_LENGTH + CAN1RxMsg.msgLen);
					
					CAN_MsgCount++;
					
					if((can1BufInfo.len + MAX_CAN_FRAME_SIZE) >= MAX_USB_BUFFER_SIZE)
					{
						break;
					}
					#endif
																	
					#if 0									
					if(0 == CAN_MsgCount ) {
						can1BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
						can1BufInfo.len = 2;
						
						#if COUNT_MONITER
						if(can1BufInfo.address)
						{
							CAN1AllocOk++;
						}
						#endif
					}
					if (!can1BufInfo.address) {
						#if COUNT_MONITER
						CAN1MallocFailCount++;
						//WiFi_Led_ON();
						#endif
						continue;
					}
					
					can1BufInfo.address[0] = get_CAN_or_ISO15756_or_J1939();					
										
					/**< Manage the Packet Length */
					can1BufInfo.address[can1BufInfo.len++] = DATALOG_FIXED_PACKET_LENGTH + CAN1RxMsg.msgLen;
										
					/**< Manage the Rx Flags */
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1RxMsg.rxFlags & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1RxMsg.rxFlags >> 8) & 0x000000FF);
					
					/**< Manage the Rx Timestamp */					
					get_extended_32Bit_data_logging_timestamp(&CAN1DataLoggingExtendedTime);
										
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1DataLoggingExtendedTime & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 8) & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 16) & 0x000000FF);	
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 24) & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 32) & 0x000000FF);
										
					memcpy(&can1BufInfo.address[can1BufInfo.len], &CAN1RxMsg.msgId, CAN1RxMsg.msgLen);
					can1BufInfo.len += CAN1RxMsg.msgLen;
										
					CAN_MsgCount++;
										
					if((can1BufInfo.len + MAX_DATALOG_FRAME_SIZE) >= MAX_USB_BUFFER_SIZE)
					{
						break;
					}
					#endif														
				}
				else								
				{	
					#if 0																					
					if(0 == CAN_MsgCount ) {
						can1BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
						can1BufInfo.len = 4;
					
						#if COUNT_MONITER
						if(can1BufInfo.address)
						{						 
							CAN1AllocOk++;						
						}
						#endif
					}
					if (!can1BufInfo.address) {
						#if COUNT_MONITER
						CAN1MallocFailCount++;
						//WiFi_Led_ON();
						#endif
						continue;
					}
                
					can1BufInfo.address[0] = get_CAN_or_ISO15756_or_J1939();
					can1BufInfo.address[1] = CAN_Receive_msg;
					can1BufInfo.address[2] = 0; /* Segment number */
                
					/**< Manage the Packet Length */
					can1BufInfo.address[can1BufInfo.len++] = CAN_FIXED_PACKET_LENGTH + CAN1RxMsg.msgLen ;
                
					/**< Manage the Rx Flags */
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1RxMsg.rxFlags & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1RxMsg.rxFlags >> 8) & 0x000000FF);
                
					memcpy(&can1BufInfo.address[can1BufInfo.len], &CAN1RxMsg.timeStamp, (CAN_PACKET_COPY_LENGTH + CAN1RxMsg.msgLen));
					can1BufInfo.len += (CAN_PACKET_COPY_LENGTH + CAN1RxMsg.msgLen);
                
					CAN_MsgCount++;
                
					if((can1BufInfo.len + MAX_CAN_FRAME_SIZE) >= MAX_USB_BUFFER_SIZE)
					{
						break;
					}
					#endif							
				}
            }
            else
            {
                /*< Filter Fail, so Drop Frames */
            }
            
            if(Is_DataLog_Active())
            {
                TimeToWaitForCAN1Q = portMAX_DELAY;
            }
            else
            {
                TimeToWaitForCAN1Q = 1;
            }
        }/**< End of while(xQueueReceive()) */

        if(CAN_MsgCount)
        {
			#if COUNT_MONITER
            CAN1TotalFrame += CAN_MsgCount;
			#endif
            			
						
            if(Is_DataLog_Active() )//&& startLogging)
            {
				can1BufInfo.address[1] = (MODE | CAN_MsgCount);
                WriteToLog(can1BufInfo);                
            }
            else
            {
				can1BufInfo.address[3] = (MODE | CAN_MsgCount);
                (void)Garuda_Tx_data_on_USB(can1BufInfo.address, can1BufInfo.len, RELEASE);
            }			
        }
    }
}
#endif

/******************************************************************************
**	Function Name	: CAN1_RX_Task
**	Input Params	: None
**	Output Params	: None
**	Description	    : This is a FreeRTOS Task for Handling CAN
******************************************************************************/
void CAN1_RX_Task(void *PvParam)
{
	CAN_Rx_Msg_t  CAN1RxMsg;
	uint32_t TimeToWaitForCAN1Q;	
	
	for(;;)
	{
		CAN1_MsgCount = 0;
		TimeToWaitForCAN1Q = portMAX_DELAY;
		while(xQueueReceive(xCAN1_RX_Queue, &CAN1RxMsg, TimeToWaitForCAN1Q) == pdTRUE)
		{
			if(J2534_PASS == J2534_checkFilter((uint8_t*)&CAN1RxMsg.msgId,CAN1RxMsg.msgLen,
			((J1939_PROTOCOL_ID == get_CAN_or_ISO15756_or_J1939()) ? GARUDA_J1939_CH1 :  GARUDA_CAN_CH1)))
			{
				#if COUNT_MONITER 
				can1Rxcnt++;
				Garuda_Debug.CAN_Rx_Count++;
				#endif
				
				if(0 == CAN1_MsgCount ) {
					can1BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
					if(Is_DataLog_Active())
					can1BufInfo.len = 2;
					else
					can1BufInfo.len = 4;
					 
					#if COUNT_MONITER
					if(can1BufInfo.address){
						CAN1AllocOk++;						
					}
					#endif					 	 					
				}
				if (!can1BufInfo.address) {
					#if COUNT_MONITER
					//WiFi_Led_ON();
					CAN1MallocFailCount++;
					#endif
					continue;
				}
				
				can1BufInfo.address[0] = get_CAN_or_ISO15756_or_J1939();
				
				if(Is_DataLog_Active())
				{
					/**< Manage the Packet Length */
					can1BufInfo.address[can1BufInfo.len++] = DATALOG_FIXED_PACKET_LENGTH + CAN1RxMsg.msgLen ;
									
					/**< Manage the Rx Flags */
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1RxMsg.rxFlags & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1RxMsg.rxFlags >> 8) & 0x000000FF);
					
					/**< Manage the Rx Timestamp */
					//get_extended_data_logging_timestamp(&CAN1DataLoggingExtendedTime);
					get_extended_32Bit_data_logging_timestamp(&CAN1DataLoggingExtendedTime);
					
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1DataLoggingExtendedTime & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 8) & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 16) & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 24) & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1DataLoggingExtendedTime >> 32) & 0x000000FF);
					
					memcpy(&can1BufInfo.address[can1BufInfo.len], &CAN1RxMsg.msgId, CAN1RxMsg.msgLen);
					can1BufInfo.len += CAN1RxMsg.msgLen;
					
					CAN1_MsgCount++;
					
					if((can1BufInfo.len + MAX_DATALOG_FRAME_SIZE) > MAX_USB_BUFFER_SIZE)
					{
						break;
					}
				}
				else
				{
					can1BufInfo.address[1] = CAN_Receive_msg;
					can1BufInfo.address[2] = 0; /* Segment number */
					
					/**< Manage the Packet Length */
					can1BufInfo.address[can1BufInfo.len++] = CAN_FIXED_PACKET_LENGTH + CAN1RxMsg.msgLen ;
					
					/**< Manage the Rx Flags */
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)(CAN1RxMsg.rxFlags & 0x000000FF);
					can1BufInfo.address[can1BufInfo.len++] = (uint8_t)((CAN1RxMsg.rxFlags >> 8) & 0x000000FF);	
					
					memcpy(&can1BufInfo.address[can1BufInfo.len], &CAN1RxMsg.timeStamp, (CAN_PACKET_COPY_LENGTH + CAN1RxMsg.msgLen));
					can1BufInfo.len += (CAN_PACKET_COPY_LENGTH + CAN1RxMsg.msgLen);
					
					CAN1_MsgCount++;
					
					if((can1BufInfo.len + MAX_CAN_FRAME_SIZE) >= MAX_USB_BUFFER_SIZE)
					{
						break;
					}									
				}
			}
			else
			{
				/*< Filter Fail, so Drop Frames */
			}
			
			if(Is_DataLog_Active())
			{
				TimeToWaitForCAN1Q = portMAX_DELAY;
			}
			else
			{
				TimeToWaitForCAN1Q = 1;
			}
		}/**< End of while(xQueueReceive()) */

		if(CAN1_MsgCount)
		{
			#if COUNT_MONITER
			CAN1TotalFrame += CAN1_MsgCount;
			#endif				
				
			if(Is_DataLog_Active() )//&& startLogging)
			{
				can1BufInfo.address[1] = (MODE | CAN1_MsgCount);
				WriteToLog(can1BufInfo);					
			}
			else
			{
				can1BufInfo.address[3] = (MODE | CAN1_MsgCount);
				(void)Garuda_Tx_data_on_USB(can1BufInfo.address, can1BufInfo.len, RELEASE);
			}
		}
	}
}


/******************************************************************************
**	Function Name	: Enq_CAN1_Remaining_Data
**	Input Params	: void
**	Output Params	: void
**	Description	: This function Yet to be decided
******************************************************************************/
void Enq_CAN1_Remaining_Data (void)
{
#if OLD_LOGIC
    WriteToLog(can1BufInfo);
    can1BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
    if(can1BufInfo.address)
    {
        can1BufInfo.len = 0;
    }
#endif
	if(CAN1_MsgCount)
	{
		can1BufInfo.address[1] = (MODE | CAN1_MsgCount);		
		WriteToLog(can1BufInfo);		
		CAN1_MsgCount = 0;
	}
}

/******************************************************************************
**	Function Name	: Enq_CAN2_Remaining_Data
**	Input Params	: void
**	Output Params	: void
**	Description	: This function Yet to be decided
******************************************************************************/
void Enq_CAN2_Remaining_Data (void)
{
#if 0
    WriteToLog(can2BufInfo);
    can2BufInfo.address = pvPortMalloc(HFCP_MAX_IN_SINGLE_FRAME);
    if(can2BufInfo.address)
    {
    can2BufInfo.len = 0;
    }
#endif

	if(CAN2_MsgCount)
	{
		can2BufInfo.address[1] = (MODE | CAN2_MsgCount);
		WriteToLog(can2BufInfo);
		CAN2_MsgCount=0;
	}
}

/******************************************************************************
**	Function Name	: Enq_CAN2_Remaining_Data
**	Input Params	: void
**	Output Params	: void
**	Description	: This function Yet to be decided
******************************************************************************/
Mid_API_Status_t CAN_ClearQ(uint8_t QUEUE)
{  
	Mid_API_Status_t fl_Status = MID_PASS;
	uint8_t u8Status;
  
	switch(QUEUE)
	{
	case CAN1_TX_QUEUE:
		u8Status = xQueueReset(xCAN1_TX_Queue);
	break;
    
	case CAN1_RX_QUEUE:
		u8Status = xQueueReset(xCAN1_RX_Queue);
	break;

	case CAN2_TX_QUEUE:
		u8Status = xQueueReset(xCAN2_TX_Queue);
	break;
  
	case CAN2_RX_QUEUE:
		u8Status = xQueueReset(xCAN2_RX_Queue);
	break;
    
	default:
	break;
	}
  
	if(pdFAIL == u8Status)
	{
		fl_Status = MID_FAIL;
		//printf("\r\nRTOS DEBUG : Failed to Clear CAN Queue\r\n");
	}
	return fl_Status;
}

/******************************************************************************
**	Function Name	: CAN1_TX_IRQHandler
**	Input Params	: void
**	Output Params	: void
**	Description	: This function is a CAN TX Handler
******************************************************************************/
void CAN1_TX_IRQHandler(void)
{
	CAN_TX_Msg_t TxMessage;
	
	#if USE_FREERTOS
	BaseType_t fl_TaskWokenByReceive = pdFALSE;
	
	if( xQueueReceiveFromISR( xCAN1_TX_Queue, &TxMessage, &fl_TaskWokenByReceive) == pdPASS )
	{
		#if CAN_DEBUG
		CANtXCheck = 0xBB;
		#endif
		if(MID_FAIL == CAN_Mid_txData(CAN_CH1, &TxMessage, 0xAA))
		{
			while(1);
		}
	}
	#endif
}

/******************************************************************************
**	Function Name	: MCAN0_Handler
**	Input Params	: void
**	Output Params	: void
**	Description	    : This CAN 1 ISR Handler 
**  Note            : Handler for MCAN0, Line 0
******************************************************************************/
CAN_Rx_Msg_t CAN1RxMsg;      
void MCAN0_Handler(void)
{
    uint8_t entries = 0;    
    BaseType_t xCAN1RxTaskWoken = pdFALSE;		    
    uint32_t currentTimeStamp = 0;
    BaseType_t result;
	BaseType_t xCANTxTaskWoken = pdFALSE;
		
    if ( MCAN_IsMessageStoredToRxFifo0( &mcan0Config ) )
    {		
        do 
        {			
            MCAN_ClearMessageStoredToRxFifo0(&mcan0Config);
            entries = MCAN_GetRxFifoBuffer( &mcan0Config, CAN_FIFO_0, (Mailbox64Type *) &rxMailbox0 );
            if ( entries > 0 )
            {    
				#if COUNT_MONITER
				can1RxIsrCount++;
				#endif            
                CAN1RxMsg.rxFlags   = rxMailbox0.info.rxflags;
                CAN1RxMsg.msgId		= swap_uint32(rxMailbox0.info.id);
                CAN1RxMsg.msgLen	= rxMailbox0.info.length + 4;
                CAN1RxMsg.timeStamp	= rxMailbox0.info.timestamp;
                                  
                get_time_stamp(&currentTimeStamp);
                CAN1RxMsg.timeStamp = currentTimeStamp;
                 
                memcpy(&CAN1RxMsg.data[0], &rxMailbox0.data[0],rxMailbox0.info.length);                 
                xCAN1RxTaskWoken = pdFALSE;
                result = xQueueSendFromISR(xCAN1_RX_Queue, &CAN1RxMsg, &xCAN1RxTaskWoken);
                if(errQUEUE_FULL == result)
                {
					 #if COUNT_MONITER
                    CANqfull++;
					//WiFi_Led_ON();
					#endif
                    //break;
                }
                else if (pdTRUE == result)
                {
                    #if COUNT_MONITER					
                    can1cnt++;
                    #endif
                }
                else {
                    #if COUNT_MONITER
                    canErrCnt++;
                    #endif
                }			 				 
            }
        } while (entries > 1);		
    }
    if(MCAN_IsRxFifo0_Full( &mcan0Config))
    {
        MCAN_ClearRxFifo0_Full(&mcan0Config);		 
    }		
	 
    if ( MCAN_IsTxComplete( &mcan0Config ) )
    {
        //MCAN_ClearTxComplete( &mcan0Config );		
        if ( MCAN_IsBufferTxd( &mcan0Config, TX_BUFFER_0 ) )
        {
			MCAN_ClearTxComplete( &mcan0Config );
			 #if COUNT_MONITER
            CAN1TXComplete++;
			Garuda_Debug.CAN_Tx_Complete++;
			#endif
            //CAN1_TX_IRQHandler();			 
			xSemaphoreGiveFromISR(xCAN1StartTx,&xCANTxTaskWoken);
        }
		else
		{
			#if COUNT_MONITER
			CAN1TXInComplete++;
			#endif
		}	
    }
	/*if(MCAN_IsStuffError( &mcan0Config))
	{
		MCAN_ClearStuffError(&mcan0Config);
		USB_MSD_Led_ON();
	}*/	
}

/******************************************************************************
**	Function Name	: CAN2_TX_IRQHandler
**	Input Params	: void
**	Output Params	: void
**	Description	: This function is a CAN TX Handler
******************************************************************************/
void CAN2_TX_IRQHandler(void)
{
    CAN_TX_Msg_t TxMessage;
    
    #if USE_FREERTOS
    BaseType_t fl_TaskWokenByReceive = pdFALSE;

    if( xQueueReceiveFromISR( xCAN2_TX_Queue, &TxMessage, &fl_TaskWokenByReceive) == pdPASS )
    {
		#if CAN_DEBUG
        CANtXCheck = 0xBB;
		#endif
        if(MID_FAIL == CAN_Mid_txData(CAN_CH2, &TxMessage, 0xAA))
        {
            while(1);
        }
    }
    #endif
}

/******************************************************************************
**	Function Name	: MCAN1_Handler
**	Input Params	: void
**	Output Params	: void
**	Description	    : This CAN 2 ISR Handler
**  Note            : Handler for MCAN1, Line 0
******************************************************************************/
CAN_Rx_Msg_t CANRxMsg;
void MCAN1_Handler(void)
{
    uint8_t entries = 0;    
    BaseType_t xCAN2RxTaskWoken = pdFALSE;        
    uint32_t currentTimeStamp = 0;
    BaseType_t result;
	BaseType_t xCANTxTaskWoken = pdFALSE;
    
    if ( MCAN_IsMessageStoredToRxFifo0( &mcan1Config ) )
    {		
        do 
        {			
            MCAN_ClearMessageStoredToRxFifo0(&mcan1Config);
            entries = MCAN_GetRxFifoBuffer( &mcan1Config, CAN_FIFO_0, (Mailbox64Type *) &rxMailbox1 );			
            if ( entries > 0 )
            {
				#if COUNT_MONITER
                can2RxIsrCount++;
				#endif
                CANRxMsg.rxFlags    = rxMailbox1.info.rxflags;
                CANRxMsg.msgId		= swap_uint32(rxMailbox1.info.id);
                CANRxMsg.msgLen	= rxMailbox1.info.length + 4;
                CANRxMsg.timeStamp	= rxMailbox1.info.timestamp;
                 
                get_time_stamp(&currentTimeStamp);
                CANRxMsg.timeStamp = currentTimeStamp;
                 
                memcpy(&CANRxMsg.data[0], &rxMailbox1.data[0],rxMailbox1.info.length);
                result = xQueueSendFromISR(xCAN2_RX_Queue, &CANRxMsg, &xCAN2RxTaskWoken);
                if(errQUEUE_FULL == result)
                {
					#if COUNT_MONITER
                    CAN2qfull++;
					//WiFi_Led_ON();
					#endif
                    //break;
                }
                else if (pdTRUE == result)
                {
                    #if COUNT_MONITER					 
                    can2cnt++;
                    #endif
                }
                else {
                    #if COUNT_MONITER
                    can2ErrCnt++;
                    #endif
                }
            }
        } while (entries > 1);
    }
    if(MCAN_IsRxFifo0_Full( &mcan1Config))
    {
        MCAN_ClearRxFifo0_Full(&mcan1Config);
    }
    
    if ( MCAN_IsTxComplete( &mcan1Config ) )
    {
        //MCAN_ClearTxComplete( &mcan1Config );

        if ( MCAN_IsBufferTxd( &mcan1Config, TX_BUFFER_0 ) )
        {
			MCAN_ClearTxComplete( &mcan1Config );
			#if COUNT_MONITER
            CAN2TXComplete++;
			Garuda_Debug_CAN2.CAN_Tx_Complete++;
			#endif
            //CAN2_TX_IRQHandler();
			xSemaphoreGiveFromISR(xCAN2StartTx,&xCANTxTaskWoken);
        }
        
    }
}

/******************************************************************************
**	Function Name	: CAN_Loopback_Tx
**	Input Params	: void
**	Output Params	: void
**	Description	    : Can Loop back Tx
**  Note            :
******************************************************************************/
CAN_Rx_Msg_t CAN_Msg;
void CAN_Loopback_Tx( CAN_TX_Msg_t *p_tx_msg, CAN_CH_TypeDef p_ch, uint8_t release )
{   
    BaseType_t result;
    uint32_t currentTimeStamp = 0;
    BaseType_t xCANRxTaskWoken = pdFALSE;
    
    #if 1
     uint32_t rx_flags = 0x00000000;
     if(LowLevel_CAN_get_loopback_status(p_ch + 1))
     {
            /* Determine the CAN frame type */
            if(p_tx_msg->ide != FALSE)
            {
                rx_flags |= CAN_EXT_MSG ;
            }
            else
            {
                rx_flags &= ~CAN_EXT_MSG ;
            }
            
            rx_flags |= TX_MSG_TYPE_LOOPBACK;
            
            CAN_Msg.rxFlags    = rx_flags;
            CAN_Msg.msgId      = swap_uint32(p_tx_msg->msg_id);
            CAN_Msg.msgLen     = p_tx_msg->dlc + 4;    
                 
            get_time_stamp(&currentTimeStamp);
            CAN_Msg.timeStamp = currentTimeStamp;
                 
            memcpy(&CAN_Msg.data[0], &p_tx_msg->data,p_tx_msg->dlc);                 
    
            xCANRxTaskWoken = pdFALSE;
    
            if(CAN_CH1 == p_ch)
            {   
                if(DONT_RELEASE_ISR == release)
                {
                    result = xQueueSendFromISR(xCAN1_RX_Queue, &CAN_Msg, &xCANRxTaskWoken);    
                }                             
                else
                {
                    result = xQueueSend(xCAN1_RX_Queue, &CAN_Msg, ( TickType_t ) 0);    
                }
    
                if(errQUEUE_FULL == result)
                {
					#if COUNT_MONITER
                    LPCAN1qfull++;   
					#endif 
                }
                else if (pdTRUE == result)
                {   
					#if COUNT_MONITER 
                    LPcan1cnt++;    
					#endif
                }
                else 
                {
					#if COUNT_MONITER    
                    LPcan1ErrCnt++; 
					#endif  
                }
            } 
            else if(CAN_CH2 == p_ch)
            {                
                if(DONT_RELEASE_ISR == release)
                {
                    result = xQueueSendFromISR(xCAN2_RX_Queue, &CAN_Msg, &xCANRxTaskWoken);
                }
                else
                {
                    result = xQueueSend(xCAN2_RX_Queue, &CAN_Msg, ( TickType_t ) 0);
                } 
                               
                if(errQUEUE_FULL == result)
                {
					#if COUNT_MONITER
                    LPCAN2qfull++;   
					#endif 
                }
                else if (pdTRUE == result)
                {   
					#if COUNT_MONITER 
                    LPcan2cnt++;    
					#endif
                }
                else 
                {   
					#if COUNT_MONITER 
                    LPcan2ErrCnt++;  
					#endif 
                }
            } 
            else
            {
                /**< Do Nothing */
            }      
      } 
      #endif   
      
    #if OLD_LOGIC
    uint8_t resp[64];
    uint32_t time_stamp = 0;
    uint32_t rx_flags = 0x00000000;
    
    if(LowLevel_CAN_get_loopback_status(p_ch + 1))
    {
        if(1)//tx_done_indication(1) == STATUS_NOERROR)
        {
            resp[0] = ( (CAN_CH1 == p_ch) ? get_CAN_or_ISO() : get_CAN1_or_ISO1() );
            resp[1] = CAN_Receive_msg;
            resp[2] = 0; /* Segment number */            
            
            resp[3] = MODE | 0x01;           /* UPDATE THE MODE AND No of frames field, which is 1 */
            
            resp[4] = CAN_FIXED_PACKET_LENGTH + 4 + p_tx_msg->dlc; //NEED TO CHECK
                       
            /* Determine the CAN frame type */
            if(p_tx_msg->ide != FALSE)
            {
                rx_flags |= CAN_EXT_MSG ;
            }
            else
            {
                rx_flags &= ~CAN_EXT_MSG ;
            }
            
            rx_flags |= TX_MSG_TYPE_LOOPBACK;
            
            resp[5] = (uint8_t)(rx_flags & 0x000000FF);            
            resp[6] = (uint8_t)((rx_flags >> 8) & 0x000000FF);            
            
            get_time_stamp(&time_stamp);
            resp[7] = (uint8_t) ( time_stamp & 0x000000FF);
            resp[8] = (uint8_t)((time_stamp >> 8) & 0x000000FF);
            resp[9] = (uint8_t)((time_stamp >> 16) & 0x000000FF);
            resp[10] = (uint8_t)((time_stamp >> 24) & 0x000000FF);
            
            resp[11] = (uint8_t)((p_tx_msg->msg_id  >> 24)  & 0x000000FF);
            resp[12] = (uint8_t)((p_tx_msg->msg_id   >> 16)  & 0x000000FF);
            resp[13] = (uint8_t)((p_tx_msg->msg_id  >> 8)   & 0x000000FF);
            resp[14] = (uint8_t)((p_tx_msg->msg_id)         & 0x000000FF);
            
            memcpy(&resp[15], &p_tx_msg->data, p_tx_msg->dlc);
            
            (void)Garuda_Tx_data_on_USB(&resp[0],  64, release);

        }
        else
        {
            /* It should never reach here */
        }
    }
    #endif
}    

/******************************************************************************
**	Function Name	: CAN1_TX_Task
**	Input Params	: None
**	Output Params	: None
**	Description	    : This is a FreeRTOS Task for Handling CAN Tx
******************************************************************************/
void CAN1_TX_Task(void *PvParam)
{	
	CAN_TX_Msg_t TxMessage;
	uint32_t TimeToWaitForCAN1Q;
	Mid_API_Status_t fl_Status = MID_FAIL;
	CAN_CH_TypeDef p_ch = CAN_CH1;
	Init_STMin_Timer(p_ch);
	for(;;)
	{
		TimeToWaitForCAN1Q = portMAX_DELAY;
		while(xQueueReceive(xCAN1_TX_Queue, &TxMessage, TimeToWaitForCAN1Q) == pdTRUE)
		{			
			fl_Status = CAN_Mid_txData(p_ch, &TxMessage, 0xEE);
			if(MID_PASS == fl_Status)
			{
				CAN1TxProgress = 1;
				if( xSemaphoreTake( xCAN1StartTx, portMAX_DELAY ) == pdTRUE )
				{
					CAN1TxProgress = 0;					
					if(CAN1_Vehicle_STMinValue)
					{											
						Start_STMIN_Timer(CAN1_Vehicle_STMinValue, p_ch);
						if(xSemaphoreTake( xCAN1STMINStart, portMAX_DELAY ) == pdTRUE )
						{						
							Stop_STMIN_Timer(p_ch);
						}
					}
				}
			}
		}				
	}	
}


/******************************************************************************
**	Function Name	: CAN2_TX_Task
**	Input Params	: None
**	Output Params	: None
**	Description	    : This is a FreeRTOS Task for Handling CAN Tx
******************************************************************************/
void CAN2_TX_Task(void *PvParam)
{
	CAN_TX_Msg_t TxMessage;
	uint32_t TimeToWaitForCAN2Q;
	Mid_API_Status_t fl_Status = MID_FAIL;
	CAN_CH_TypeDef p_ch = CAN_CH2;
	Init_STMin_Timer(p_ch);
	for(;;)
	{
		TimeToWaitForCAN2Q = portMAX_DELAY;
		while(xQueueReceive(xCAN2_TX_Queue, &TxMessage, TimeToWaitForCAN2Q) == pdTRUE)
		{
			fl_Status = CAN_Mid_txData(p_ch, &TxMessage, 0xEE);
			if(MID_PASS == fl_Status)
			{				
				CAN2TxProgress = 1;				
				if( xSemaphoreTake( xCAN2StartTx, portMAX_DELAY) == pdTRUE )
				{	
					CAN2TxProgress=0;									
					if(CAN2_vehicle_STMinValue)
					{
						Start_STMIN_Timer(CAN2_vehicle_STMinValue, p_ch);
						if(xSemaphoreTake( xCAN2STMINStart, portMAX_DELAY) == pdTRUE )
						{
							Stop_STMIN_Timer(p_ch);
						}
					}
				}
			}/* End of if(MID_PASS == fl_Status) */
		}
	}/* End of for(;;) */
}

/******************************************************************************
**	Function Name	: Init_STMin_Timer
**	Input Params	: p_ch
**	Output Params	: None
**	Description	    : Enables/Initialises the timer for handling the STMIN functionality.
******************************************************************************/
void Init_STMin_Timer(CAN_CH_TypeDef p_ch)
{
	if(CAN_CH1 == p_ch)
	{	
		PMC_EnablePeripheral(ID_TC9);
		TC_Configure( TC3, 0, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );
	 
		/* Configure and enable interrupt on RC compare */
		NVIC_ClearPendingIRQ(TC9_IRQn);
		NVIC_SetPriority( TC9_IRQn ,STMIN_TIMER_ISR_PRIORITY);
		NVIC_EnableIRQ(TC9_IRQn);
	 
		TC3->TC_CHANNEL[ 0 ].TC_IER = TC_IER_CPCS ;	
	}
	else if (CAN_CH2 == p_ch)
	{
		#if 0
		PMC_EnablePeripheral(ID_TC3);
		TC_Configure( TC1, 0, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );		
		/* Configure and enable interrupt on RC compare */
		NVIC_ClearPendingIRQ(TC3_IRQn);
		NVIC_SetPriority( TC3_IRQn ,STMIN_TIMER_ISR_PRIORITY);
		NVIC_EnableIRQ(TC3_IRQn);		
		TC1->TC_CHANNEL[ 0 ].TC_IER = TC_IER_CPCS ;
		#endif

		PMC_EnablePeripheral(ID_TC2);
		TC_Configure( TC0,2, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );
		/* Configure and enable interrupt on RC compare */
		NVIC_ClearPendingIRQ(TC2_IRQn);
		NVIC_SetPriority( TC2_IRQn ,STMIN_TIMER_ISR_PRIORITY);
		NVIC_EnableIRQ(TC2_IRQn);
		TC0->TC_CHANNEL[ 2 ].TC_IER = TC_IER_CPCS ;		
		
	}
	else
	{
		// Invalid Channel
	}
}

/******************************************************************************
**	Function Name	: Start_STMIN_Timer
**	Input Params	: p_ch,timervalue
**	Output Params	: None
**	Description	    : Starts the timer for handling the STMIN functionality.
					  timervalue shall be the STMin value in msecs(ex : 1*1000). 
******************************************************************************/
void Start_STMIN_Timer(uint8_t timervalue, CAN_CH_TypeDef p_ch)
{
	if(CAN_CH1 == p_ch)
	{
		/** Start the counter */
		TC3->TC_CHANNEL[ 0 ].TC_RC = timervalue*1000;
		TC_Start( TC3, 0 );	
	}
	else if(CAN_CH2 == p_ch)
	{
		/** Start the counter */
		//TC1->TC_CHANNEL[ 0 ].TC_RC = timervalue*1000;
		//TC_Start( TC1, 0 );
		TC0->TC_CHANNEL[ 2 ].TC_RC = timervalue*1000;
		TC_Start( TC0, 2 );
		
	}
	else
	{
		//Invalid Channel
	}
}

/******************************************************************************
**	Function Name	: Stop_STMIN_Timer
**	Input Params	: p_ch
**	Output Params	: None
**	Description	    : Stops the timer of STMIN.					  
******************************************************************************/
void Stop_STMIN_Timer(CAN_CH_TypeDef p_ch)
{
	if(CAN_CH1 == p_ch)
	{
		/** Start the counter */
		TC_Stop( TC3, 0 );	
	}
	else if (CAN_CH2 == p_ch)
	{
		/** Start the counter */
		//TC_Stop( TC1, 0 );
		TC_Stop( TC0, 2 );
	}
	else
	{
		//Invalid Channel
	}
}

/******************************************************************************
**	Function Name	: TC9_Handler
**	Input Params	: None
**	Output Params	: None
**	Description	    : Timer ISR Handler					  
******************************************************************************/
volatile uint32_t TC9Dummy_SR;
void TC9_Handler(void)
{
	BaseType_t xSTMINTaskWoken = pdFALSE;
	/* Clear status bit to acknowledge interrupt */
	TC9Dummy_SR = TC3->TC_CHANNEL[ 0 ].TC_SR;
	/*Posts the semaphore if STMin timer expires */
	xSemaphoreGiveFromISR(xCAN1STMINStart,&xSTMINTaskWoken);
}

#if 0
/* Notes : 1. This timer is not available in SAME70N series,
			  since its only 100 pin Microcontroller.
		   2. DataLogger Timestamp is being used for 
			  STMIN Handling for CAN2			  	  			   
*/
/******************************************************************************
**	Function Name	: TC3_Handler
**	Input Params	: None
**	Output Params	: None
**	Description	    : Timer ISR Handler					  
******************************************************************************/
volatile uint32_t TC3Dummy_SR;
void TC3_Handler(void)
{
	BaseType_t xSTMINTaskWoken = pdFALSE;
	/* Clear status bit to acknowledge interrupt */
	TC3Dummy_SR = TC1->TC_CHANNEL[ 0 ].TC_SR;
	/*Posts the semaphore if STMin timer expires */
	xSemaphoreGiveFromISR(xCAN2STMINStart,&xSTMINTaskWoken);
}
#endif
/******************************************************************************
**	Function Name	: TC3_Handler
**	Input Params	: None
**	Output Params	: None
**	Description	    : Timer ISR Handler
******************************************************************************/
volatile uint32_t TC0Dummy_SR;
void TC2_Handler(void)
{
	BaseType_t xSTMINTaskWoken = pdFALSE;
	/* Clear status bit to acknowledge interrupt */
	TC0Dummy_SR = TC0->TC_CHANNEL[ 2 ].TC_SR;
	/*Posts the semaphore if STMin timer expires */
	xSemaphoreGiveFromISR(xCAN2STMINStart,&xSTMINTaskWoken);
}

/******************************************************************************
**	Function Name	: getCAN1TXStatus
**	Input Params	: none
**	Output Params	: None
**	Description	    : Returns the flags for CAN1 Tx Complete.			  
******************************************************************************/
uint8_t getCAN1TXStatus(void)
{
	return CAN1TxProgress;	
}

/******************************************************************************
**	Function Name	: getCAN2TXStatus
**	Input Params	: none
**	Output Params	: None
**	Description	    : Returns the flags for CAN2 Tx Complete.			  
******************************************************************************/
uint8_t getCAN2TXStatus(void)
{
	return CAN2TxProgress;
}
