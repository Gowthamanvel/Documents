/******************************************************************************
*
* Copyright                                                  Template Version
* 2014 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * HSMCI_Mid.c
 *
 * Created: 11/5/2015 12:13:08 PM
 *  Author: amit
 */   

/******************************************************************************
* P U R P O S E: This module implements HSMCI_Mid level application interfaces
*******************************************************************************/


/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "chip.h"
#include "stdio.h"
#include "string.h"
#include "board.h"
#include "libsdmmc.h"
#include "fatfs_config.h"
#include "Media.h"
#include "MEDSdcard.h"
#include "libstoragemedia.h"
#include "libsdmmc.h"
#include "MSDDriver.h"
#include "MSDLun.h"
#include "HSMCI_Mid.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define USBHS_PRI                       3
#define HSMCI_PRI                       2
#define XDMAC_PRI                       1

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
extern  sSdCard sdDrv[BOARD_NUM_MCI];
extern sXdmad Dma;
/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
static const Pin pinsCd[] = {BOARD_MCI_PIN_CD}; /** SD card detection pin instance. */
static const Pin pinsSd[] = {BOARD_MCI_PINS_SLOTA, BOARD_MCI_PIN_CK}; /** SD card pins instance. */
/* static sXdmad dmaDrv; */                           /** DMA driver instance */
static sMcid mciDrv[BOARD_NUM_MCI];             /** MCI driver instance. */



/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
* Function name     : void HSMCI_ConfigurePIOs(void)
* returns           : None
* parameters        : None
* Description       : configures the port pins for HSMCI and also card detect 
                      port pin.
* Notes             :
*******************************************************************************/
void HSMCI_ConfigurePIOs(void)
{
    /* Configure SDcard pins */
    PIO_Configure(pinsSd, PIO_LISTSIZE(pinsSd));
    
    /* Configure SD card detection */
    CardDetectConfigure();
}

/******************************************************************************
* Function name     : void CardDetectConfigure(void)
* returns           : None
* parameters        : None
* Description       : Configure for SD detect pin
* Notes             :
*******************************************************************************/
void CardDetectConfigure(void)
{
    PIO_Configure(pinsCd, PIO_LISTSIZE(pinsCd));
}

/******************************************************************************
* Function name     : void Initialize_HSMCI_Drivers(void)
* returns           : None
* parameters        : None
* Description       : Initialize driver instances.
* Notes             :
*******************************************************************************/
void Initialize_HSMCI_Drivers(uint8_t interface)
{ 
	uint8_t priority;    
    Dma.pXdmacs = XDMAC;
    /* Initialize the DMA driver */
    //XDMAD_Initialize(&dmaDrv,0);
    XDMAD_Initialize(&Dma,0);

    /* Enable XDMA interrupt and give it priority over any other peripheral interrupt */
    NVIC_ClearPendingIRQ(XDMAC_IRQn);
    NVIC_SetPriority(XDMAC_IRQn, 6);//1,6
    NVIC_EnableIRQ( XDMAC_IRQn );

    /* Initialize the HSMCI driver */
    //MCID_Init(&mciDrv[0], HSMCI, ID_HSMCI, BOARD_MCK, &dmaDrv, 0 ) ;
    MCID_Init(&mciDrv[0], HSMCI, ID_HSMCI, BOARD_MCK, &Dma, 0 ) ;

    /* Enable MCI interrupt and give it priority lower than DMA*/
    NVIC_ClearPendingIRQ(HSMCI_IRQn);
	
	priority = 7 + interface;
    NVIC_SetPriority(HSMCI_IRQn, priority); //,3,7
    NVIC_EnableIRQ( HSMCI_IRQn );

    /* Initialize SD driver */
    for (uint8_t i = 0; i < BOARD_NUM_MCI; i ++) {
        SDD_InitializeSdmmcMode(&sdDrv[i], &mciDrv[i], 0);
    }
}

/******************************************************************************
* Function name     : void CardIsConnected(void)
* returns           : None
* parameters        : None
* Description       : Return 1 if card is inserted.
* Notes             :
*******************************************************************************/
uint8_t CardIsConnected(uint8_t iMci)
{
    return PIO_Get(&pinsCd[iMci]) ? 0 : 1;
}


/******************************************************************************
* Function name     : void LoopDelay(void)
* returns           : None
* parameters        : None
* Description       : Delay some loop
* Notes             :
*******************************************************************************/
void LoopDelay(volatile unsigned int loop)
{
	for(;loop > 0; loop --);
}

/******************************************************************************
* Function name     : void AnyCardIsConnected(void)
* returns           : None
* parameters        : None
* Description       : Return 1 if card is inserted.
* Notes             :
*******************************************************************************/
uint8_t AnyCardIsConnected(void)
{
    uint32_t i;
    for (i = 0; i < BOARD_NUM_MCI; i ++) {
        if ( CardIsConnected(i) ) {
            return 1;
        }
    }
    return 0;
}

/******************************************************************************
* Function name     : void SD_Card_Init(void)
* returns           : return SDMMC status
* parameters        : sSdCard *pSd
* Description       : Initialises the SD Card Inserted
* Notes             :
*******************************************************************************/
uint8_t SD_Card_Init(sSdCard *pSd)
{
    uint8_t error;
    uint8_t retry = 2;
    
    while(retry --) {
        error = SD_Init(pSd);
        if (error == SDMMC_OK) break;
    }
    return error;
}

/******************************************************************************
* Function name     : void scan_files (char* path)
* returns           : scan result, 1: success
* parameters        : folder path
* Description       : Scan files under a certain path
* Notes             :
*******************************************************************************/
FRESULT scan_files (char* path)
{
	FRESULT res;
	FILINFO fno;
	DIR dir;
	int32_t i;
	char *fn;
#if _USE_LFN
	static char lfn[_MAX_LFN * (_DF1S ? 2 : 1) + 1];
	fno.lfname = lfn;
	fno.lfsize = sizeof(lfn);
#endif


	res = f_opendir(&dir, path);
	if (res == FR_OK) {
		i = strlen(path);
		for (;;) {
			res = f_readdir(&dir, &fno);
			if (res != FR_OK || fno.fname[0] == 0) break;
#if _USE_LFN
			fn = *fno.lfname ? fno.lfname : fno.fname;
#else
			fn = fno.fname;
#endif
			if (*fn == '.') continue;
			if (fno.fattrib & AM_DIR) {
				sprintf(&path[i], "/%s", fn);
				res = scan_files(path);
				if (res != FR_OK) break;
				path[i] = 0;
			} else {
				printf("%s/%s\n\r", path, fn);
			}
		}
	}
	return res;
}

/******************************************************************************
* Function name     : formatdisk(const TCHAR *pDrv)
* returns           : format result, 1: success
* parameters        : folder path
* Description       : format files under a certain path
* Notes             :
*******************************************************************************/
uint8_t formatdisk(const TCHAR *pDrv)
{
	FRESULT res;
	#if _FS_TINY == 0
	/** Format disk*/
	TRACE_INFO(" Please wait a moment. Formatting the disk...\n\r");
	res = f_mkfs(pDrv,    // Drv
	0,    // FDISK partition
	512); // AllocSize, size can be changed, TBC
	TRACE_INFO("  Format disk finished !\n\r");
	if( res != FR_OK ) {
		TRACE_ERROR("  f_mkfs pb: 0x%X\n\r", res);
		return 0;
	}
	return 1;
	#else
	TRACE_INFO("  Please run Full version FAT FS test first\n\r");
	return 0;
	#endif
}

/******************************************************************************
* Function name     : void XDMAC_Handler(void)
* returns           : 
* parameters        : 
* Description       : DMA interrupt handler
* Notes             :
*******************************************************************************/
//extern sXdmad Dma;
//void XDMAC_Handler(void)
//{
    //XDMAD_Handler(&dmaDrv);
    ////XDMAD_Handler(&Dma);
//}

/******************************************************************************
* Function name     : void XDMAC_Handler(void)
* returns           :
* parameters        :
* Description       : MCI interrupt handler. Forwards the event to the 
                      MCI driver handlers
* Notes             :
*******************************************************************************/
void HSMCI_Handler(void)
{
    MCID_Handler(&mciDrv[0]);
}
