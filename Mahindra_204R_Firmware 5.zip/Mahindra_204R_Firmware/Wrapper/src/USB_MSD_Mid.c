/******************************************************************************
*
* Copyright                                                  Template Version
* 2014 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * USB_MSD_Mid.c
 *
 * Created: 11/17/2015 11:27:38 AM
 *  Author: amit
 */

/******************************************************************************
* P U R P O S E: This module implements USB MSD Mid level application interfaces
*******************************************************************************/

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "chip.h"
#include "board.h"
#include "HFCP.h"
#include "libsdmmc.h"
#include "fatfs_config.h"
#include "Media.h"
#include "MEDSdcard.h"
#include "libstoragemedia.h"
#include "libsdmmc.h"
#include "MSDDriver.h"
#include "MSDLun.h"
#include "HSMCI_Mid.h"
#include "USB_MSD_Mid.h"
#include "Data_Logger.h"
#include "Led_Handler.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define DRV_SDMMC           0    /**< SD card */
#define MAX_LUNS            1


/** Maximum number of blocks read once */
#define NB_MULTI_BLOCKS     5

/** Split R/W to 2, first R/W 4 blocks then remaining */
#define NB_SPLIT_MULTI      4

/** Test settings: start block address (0) */
#define TEST_BLOCK_START    (0)

/** Test settings: end block address (total SD/MMC) */
#define TEST_BLOCK_END      SD_GetNumberBlocks(&sdDrv[bMciID])

/** Test settings: skip size when "skip" key pressed */
#define TEST_BLOCK_SKIP     (100 * 1024 * 2)    // 100M

/**  Number of errors displayed */
#define NB_ERRORS           5

/** Bytes per cluster, FS format is necessary to make it effective*/
#define AllOCSIZE		512

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
extern uint8_t USB_Device_Mode;
extern sMedia medias[MAX_LUNS];
extern  sSdCard sdDrv[BOARD_NUM_MCI];
extern const USBDDriverDescriptors msdDriverDescriptors; /** MSD Driver Descriptors List */

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/** Device LUNs. */
static MSDLun luns[MAX_LUNS];

/** LUN read/write buffer. */
//uint8_t mSdBuffer[MSD_BUFFER_SIZE];

uint8_t dataLogBuf[MSD_BUFFER_SIZE];


/** Total data write to disk */
uint32_t msdWriteTotal = 0;

/** Delay TO event */
uint8_t  msdRefresh = 0;

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/
extern void _ConfigureUotghs(void);

/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/
uint8_t *MSDAllocAddress;

/******************************************************************************
* Function name     : void USB_MSD_Mid_Init(void)
* returns           : None
* parameters        : None
* Description       : configures the port pins for HSMCI and also card detect 
                      port pin.
* Notes             :
*******************************************************************************/
void USB_MSD_Mid_Init(void)
{
     sSdCard *pSd = 0;
    uint8_t USBMsdState =0;     
         
    _ConfigureUotghs();
    
    HSMCI_ConfigurePIOs();
    Initialize_HSMCI_Drivers(0);
    
    USB_Device_Mode = MSD;
    
	Datalog_Reset_Queue();
	
	//MSDAllocAddress = pvPortMalloc(MSD_BUFFER_SIZE);
	
    _MemoriesInitialize(pSd);

    /* BOT driver initialization */
    MSDDriver_Initialize(&msdDriverDescriptors, luns, MAX_LUNS);

    /* connect if needed */
    USBD_Connect();    
    
	
    while (1) {
        /* Mass storage state machine */
        if (USBD_GetState() < USBD_STATE_CONFIGURED)
        {
           if(USBMsdState)
           {
                if(USBD_GetState() == USBD_STATE_SUSPENDED)
                {                    
                    //USBD_Disconnect();
					//vPortFree(MSDAllocAddress);
					_MemoriesDeInitialize(pSd);
                    DisconnectAllChanels();                    
                    Clear_MSD_Event();
					SD_DeInit(&sdDrv[0]);
					USB_Device_Mode = HID;
					USB_MSD_Led_OFF();					
                    break;
                }
           }
        }
        else {
            MSDDriver_StateMachine();
            /*if (msdRefresh) {
                msdRefresh = 0;
                if (msdWriteTotal < 50 * 1000) {
                    // Flush Disk Media
                }
                msdWriteTotal = 0;
            }*/
        }
        
        if(USBD_GetState() == USBD_STATE_CONFIGURED)
        {
			if(USBMsdState == 0) {
				USB_MSD_Led_ON();
			}
            USBMsdState = 1;
        }
    }    
}

/**
 * Initialize MSD Media & LUNs
 */
void _MemoriesInitialize(sSdCard *pSd)
{
    uint32_t i ;

    /* Reset all LUNs */
    for (i = 0; i < MAX_LUNS; i ++)
    LUN_Init(&luns[i], 0, 0, 0, 0, 0, 0, 0, 0);

    /*Initialize SD Card  */
    SDDiskInit(pSd);
    gNbMedias = 1;
}

void _MemoriesDeInitialize(sSdCard *pSd)
{
	uint32_t i ;

	/* Reset all LUNs */
	for (i = 0; i < MAX_LUNS; i ++)
	LUN_Init(&luns[i], 0, 0, 0, 0, 0, 0, 0, 0);
}

void SDDiskInit(sSdCard *pSd)
{
    uint8_t sdConnected;
    pSd = &sdDrv[0];
    
    /* Infinite loop */
    sdConnected=0;
    
    if (CardIsConnected(0)) 
    {
        if (sdConnected == 0) {
            sdConnected = 1;
            //printf("-I- connect to solt n\r");
            SD_Card_Init(pSd);
            MEDSdusb_Initialize(&medias[DRV_SDMMC], pSd);
        }
    } 
    else if (sdConnected) {
        sdConnected = 0;
        printf("** Card Disconnected\n\r");
    }
    
   /* LUN_Init(&(luns[DRV_SDMMC]),
    &(medias[DRV_SDMMC]),
    mSdBuffer, MSD_BUFFER_SIZE,
    0, 0, 0, 0,
    MSDCallbacks_Data);*/
   
	memset(&dataLogBuf[0],0, MSD_BUFFER_SIZE);
	LUN_Init(&(luns[DRV_SDMMC]), &(medias[DRV_SDMMC]), dataLogBuf, MSD_BUFFER_SIZE,0, 0, 0, 0, MSDCallbacks_Data); 
      
  /* LUN_Init(&(luns[DRV_SDMMC]),
   &(medias[DRV_SDMMC]),
   MSDAllocAddress, MSD_BUFFER_SIZE,
   0, 0, 0, 0,
   MSDCallbacks_Data);*/
}

/*----------------------------------------------------------------------------
 *        Callbacks
 *----------------------------------------------------------------------------*/
/**
 * Invoked when the MSD finish a READ/WRITE.
 * \param flowDirection 1 - device to host (READ10)
 *                      0 - host to device (WRITE10)
 * \param dataLength Length of data transferred in bytes.
 * \param fifoNullCount Times that FIFO is NULL to wait
 * \param fifoFullCount Times that FIFO is filled to wait
 */
void MSDCallbacks_Data(uint8_t flowDirection, uint32_t  dataLength,
                            uint32_t  fifoNullCount,uint32_t  fifoFullCount)
{
    fifoNullCount = fifoNullCount; /* dummy */
    fifoFullCount = fifoFullCount;  /*dummy */
    if (!flowDirection) {
        msdWriteTotal += dataLength;
    }
}