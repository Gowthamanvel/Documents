/******************************************************************************
*
* Copyright                                                  Template Version
* 2014 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * GPIO_Mid.c
 *
 * Created: 7/15/2015 6:09:16 PM
 *  Author: amit
 */ 

/******************************************************************************
* P U R P O S E: This module implements GPIO Mid level application interfaces
*******************************************************************************/
#ifndef __GPIO_MID_C
#define __GPIO_MID_C

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Proj_Config.h"
#include "chip.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "board.h"
#include "UART_Mid.h"
#include "GPIO_Mid.h"
#include "iso14230.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/**KWP_TXD Pin Configurations */
const Pin pinKWPTxd = PIN_KWP_TXD;

/**KWP_RXD Pin Configurations */
const Pin pinKWPRxd = PIN_KWP_RXD;

/**KWP_TXD_5BAUD Pin Configurations */
const Pin pinKWPTxd5Baud = PIN_KWP_TXD_5BAUD;

/**KLINE_PULLUP_SLCT Pin Configurations */
const Pin pinKLinePullupSlct = PIN_KLINE_PULLUP_SLCT;

/**KLINE_LLINE_SLCT Pin Configurations */
const Pin pinKLineLLineSlct = PIN_KLINE_LLINE_SLCT;

/**KLINE_ISO_SLCT Pin Configurations */
const Pin pinKLineIsoSlct = PIN_KLINE_ISO_SLCT;

/**LLINE_ISO_SLCT Pin Configurations */
const Pin pinLLineIsoSlct = PIN_LLINE_ISO_SLCT;


/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/*******************************************************************************
* Function Name  : Config_Pin_Output
* Description    : Configures the GPIO Pin As Output.
* Input          : p_GPIO_pin : The GPIO Pin which needs to configured
* Output         : None
* Return         : None
*******************************************************************************/
void Config_Pin_Output(KWP_GPIOs_t p_GPIO_pin)
{
    switch (p_GPIO_pin)
    {
        case KW_TXD             :
        {
            PIO_Configure( &pinKWPTxd, 1 );
            break;
        }
        case KW_RXD             :
        {
            PIO_Configure( &pinKWPRxd, 1 );
            break;
        }
        case KLINE_PULLUP_SLCT  :
        {
            PIO_Configure( &pinKLinePullupSlct, 1 );
            break;
        }
          
        case KLINE_LLINE_SLCT   :
        {
            PIO_Configure( &pinKLineLLineSlct, 1 );
            break;
        }
          
        case LLINE_ISO_SLCT     :
        {
            PIO_Configure( &pinLLineIsoSlct, 1 );
            break;
        }
          
        case KLINE_ISO_SLCT     :
        {            
            PIO_Configure( &pinKLineIsoSlct, 1 );
            break;
        }
          
        case KW_TX_5BAUD        :
        {
            PIO_Configure( &pinKWPTxd5Baud, 1 );
            break;
        }
          
        default                 :
        {
            break;
        }          
    }
}    

/*******************************************************************************
* Function Name  : Set_Pin_High
* Description    : Sets GPIO Pin @ High Level.
* Input          : p_GPIO_pin : The GPIO Pin used
* Output         : None
* Return         : None
*******************************************************************************/
void Set_Pin_High(KWP_GPIOs_t p_GPIO_pin)
{
    switch (p_GPIO_pin)
    {
        case KW_TXD             :
        {            
            PIO_Set( &pinKWPTxd );
            break;
        }
        case KW_RXD             :
        {
            PIO_Set( &pinKWPRxd );
            break;
        }
        case KLINE_PULLUP_SLCT  :
        {
            PIO_Set( &pinKLinePullupSlct );
            break;
        }
        
        case KLINE_LLINE_SLCT   :
        {
            PIO_Set( &pinKLineLLineSlct );
            break;
        }
        
        case LLINE_ISO_SLCT :
        {
            PIO_Set( &pinLLineIsoSlct );
            break;
        }
        
        case KLINE_ISO_SLCT :
        {
            PIO_Set( &pinKLineIsoSlct );
            break;
        }
        
        case KW_TX_5BAUD        :
        {
            PIO_Set( &pinKWPTxd5Baud );
            break;
        }
        
        default                 :
        {
            break;
        }        
    }
}

/*******************************************************************************
* Function Name  : Set_Pin_Low
* Description    : Sets GPIO Pin @ Low Level.
* Input          : p_GPIO_pin : The GPIO Pin used
* Output         : None
* Return         : None
*******************************************************************************/
void Set_Pin_Low(KWP_GPIOs_t p_GPIO_pin)
{
    switch (p_GPIO_pin)
    {
        case KW_TXD             :
        {
            PIO_Clear( &pinKWPTxd);
            break;
        }
        case KW_RXD             :
        {
            PIO_Clear( &pinKWPRxd);
            break;
        }
        case KLINE_PULLUP_SLCT  :
        {
            PIO_Clear( &pinKLinePullupSlct);
            break;
        }
        
        case KLINE_LLINE_SLCT   :
        {
            PIO_Clear( &pinKLineLLineSlct);
            break;
        }
        
        case LLINE_ISO_SLCT :
        {
            PIO_Clear( &pinLLineIsoSlct);
            break;
        }
        
        case KLINE_ISO_SLCT :
        {
            PIO_Clear( &pinKLineIsoSlct);
            break;
        }
        
        case KW_TX_5BAUD        :
        {
            PIO_Clear( &pinKWPTxd5Baud);
            break;
        }
        
        default                 :
        {
            break;
        }        
    }
}

/*******************************************************************************
* Function Name  : Config_Pin_UART_Mode
* Description    : Configures Pin to UART Mode
* Input          : p_GPIO_pin : The GPIO Pin used
* Output         : None
* Return         : None
*******************************************************************************/
void Config_Pin_UART_Mode(KWP_GPIOs_t p_GPIO_pin)
{
    const Pin pPins[1] = {UART0_PINS};//UartPins[uartCh];
    switch (p_GPIO_pin)
    {
        case KW_TXD             :
        {
            /* Configure PIO */
            PIO_Configure( pPins, PIO_LISTSIZE( pPins ) ) ;            
            break;
        }
        case KW_RXD             :
        {
            //GPIO_PinAFConfig(GPIOA, GPIO_Pin_1, GPIO_AF_UART4);
            break;
        }
        default                 :
        {
            break;
        }
    }
}


/*******************************************************************************
* Function Name  : Initialise_Board_Detect_Pins
* Description    : Configures the Board Detect Pins as Input
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Initialise_Board_Detect_Pins(void)
{
    const Pin pPins[3] = { BOARD_DETECT_PIN0, BOARD_DETECT_PIN1, BOARD_DETECT_PIN2 };
    
    PIO_Configure( &pPins[BOARD_DETECT_0], 1 );
    PIO_Configure( &pPins[BOARD_DETECT_1], 1 );
    PIO_Configure( &pPins[BOARD_DETECT_2], 1 );    
}

/*******************************************************************************
* Function Name  : get_BoardDetect_Value
* Description    :returns the Board Detect Pins value
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t get_BoardDetect_Value(void)
{
    const Pin pPins[3] = { BOARD_DETECT_PIN0, BOARD_DETECT_PIN1, BOARD_DETECT_PIN2 };
    uint8_t value;
    value =  (2 << PIO_Get(&pPins[BOARD_DETECT_2])) |(1 << PIO_Get(&pPins[BOARD_DETECT_1])) | PIO_Get(&pPins[BOARD_DETECT_0]);
    return value;
}

#endif /*< End of __GPIO_MID_C */