/******************************************************************************
*
* Copyright                                                  Template Version
* 2014 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * UART_Mid.c
 *
 * Created: 7/15/2015 6:42:48 PM
 *  Author: amit
 */ 

/******************************************************************************
* P U R P O S E: This module implements UART Mid level application interfaces
*******************************************************************************/
#ifndef __UART_MID_C
#define __UART_MID_C

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Proj_Config.h"
#include "chip.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "board.h"
#include "GPIO_Mid.h"
#include "UART_Mid.h"
#include "iso14230.h"
#include "time_stamps.h"
#include "J2534_periodic.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
const uint32_t UART_ID[nUART] = { ID_UART0 };
Uart *UART_INTERFACE[nUART]  = { UART0 };
IRQn_Type UART_IRQ[nUART] = { UART0_IRQn };
Pin UartPins[nUART] = { UART0_PINS };
    
static QueueHandle_t UART_TX_QueueHandlers[nUART] = {0};
static QueueHandle_t UART_RX_QueueHandlers[nUART] = {0};   
    
UART_InitTypeDef UART_midConfig_v[nUART];
UART_Set_Param_t UART_Parameters[nUART];        
    
/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/
extern void AdressClaimHandler(void);

/******************************************************************************
* Function name		: void UART_Mid_Init(uint8_t, uint8_t)
* returns			: None
* parameters		: UART_chId_t uartCh, 
*                     UART_InitTypeDef Uart_InitData
* Description		: This function Initializes UART Interface.
* Notes			    : 
*******************************************************************************/
Mid_API_Status_t UART_MidInit(UART_chId_t uartCh, UART_InitTypeDef Uart_InitData)
{  
    const Pin pPins[1] = { UART0_PINS };
    
    /* Configure PIO */
    PIO_Configure( pPins, PIO_LISTSIZE( pPins ) ) ;
      
    PMC_EnablePeripheral(UART_ID[uartCh]);
   
    UART_Configure(UART_INTERFACE[uartCh], ( UART_MR_CHMODE_NORMAL | UART_MR_PAR_NO ), Uart_InitData.baudrate, BOARD_MCK);
    
    UART_Parameters[uartCh].Set_baudrate =  Uart_InitData.baudrate;
    
    
    NVIC_ClearPendingIRQ(UART_IRQ[uartCh]);
    NVIC_SetPriority( UART_IRQ[uartCh] ,UART_ISR_PRIORITY);

    /* Enables the UART to transfer and receive data. */
    UART_SetTransmitterEnabled ( UART_INTERFACE[uartCh] , 1);
    UART_SetReceiverEnabled ( UART_INTERFACE[uartCh] , 1);
    
    UART_EnableIt(UART_INTERFACE[uartCh], ( /*UART_IER_TXRDY |*/ UART_IER_RXRDY | UART_IER_OVRE | UART_IER_FRAME /*| UART_IER_PARE*/));
    /* Enable interrupt  */
    NVIC_EnableIRQ(UART_IRQ[uartCh]);
    
#if USE_FREERTOS
if(NULL == UART_TX_QueueHandlers[uartCh] ){
    UART_TX_QueueHandlers[uartCh] = xQueueCreate(Uart_InitData.txQueueSz, ( unsigned portBASE_TYPE ) sizeof(uint8_t) );
}    
if(NULL == UART_RX_QueueHandlers[uartCh] ){
    UART_RX_QueueHandlers[uartCh] = xQueueCreate( Uart_InitData.rxQueueSz, ( unsigned portBASE_TYPE ) sizeof(uint8_t) );
}    
#endif /*#if USE_FREERTOS*/

    /* Copy the configuration to UART_Mid */
    UART_midConfig_v[uartCh] = Uart_InitData;     
    
    return MID_PASS;      
}


/******************************************************************************
* Function name  	: void UART_MidDeInit(uint8_t)
* returns			: None
* parameters		: UART_chId_t uartCh - channel Number
* Description		: This function Deinitializes UART.
* Notes	:
*******************************************************************************/
Mid_API_Status_t UART_MidDeInit(UART_chId_t uartCh)
{
    memset((void *)&UART_midConfig_v[uartCh], 0, sizeof(UART_InitTypeDef));
    Uart_Clear_Tx_Q(uartCh,NORMAL_MODE);
    Uart_Clear_Rx_Q(uartCh,NORMAL_MODE);
    UART_MidDisable(uartCh);    
    PMC_DisablePeripheral(UART_ID[uartCh]);  
    
    /* Initialize Timeout to 0 */
    UART_Change_RxTimeOut(uartCh,0);
	
    /* Initialize Time Guard to 0 */
    UART_Change_TimeGuard(uartCh,0);
    
    /* Disable the Timer for Timeout and TimeGuard Only If No UART Active */
    Timer_Stop();      
 
    return MID_PASS;
}

/******************************************************************************
* Function name  	: void UART0_Handler(uint8_t)
* returns			: None
* parameters        : None
* Description		: UART 0 Interrupt Handler.
* Notes				:
*******************************************************************************/
void UART0_Handler()
{
    uint8_t intrType = 0;
    uint8_t uartRxData;
	uint8_t uartByte =0;
    BaseType_t fRx_TaskWokenByReceive = pdFALSE;    
    
    uint32_t Status = UART_GetStatus(UART_INTERFACE[KWP_UART_CHAN]);

    if(Status & (UART_SR_OVRE | UART_SR_FRAME | UART_SR_PARE)) 
    {
        UART_INTERFACE[KWP_UART_CHAN]->UART_CR = UART_CR_RSTSTA;
    }
    
    if(Status & UART_SR_TXEMPTY)
    {
        /* The Time Guard is not 0 */
        if(UART_Parameters[KWP_UART_CHAN].timeguard_localcount !=0)
        {
            /* Start Time Guard */
            UART_Parameters[KWP_UART_CHAN].timeguard_count=0;
            UART_Parameters[KWP_UART_CHAN].timeguard_enabled=1;
            UART_DisableIt(UART_INTERFACE[KWP_UART_CHAN], UART_SR_TXEMPTY);
        }
        /* The Time Guard is 0 */
        else
        {
            if( Q_To_Uart(KWP_UART_CHAN) == MID_FAIL)
            {
                /* Not Decided - Later May be Needed */
                UART_DisableIt(UART_INTERFACE[KWP_UART_CHAN], UART_SR_TXEMPTY);
            }
            else
            {
                /* Not Decided - Later May be Needed */
            }
        }
        intrType = intrType | ((uint8_t)0x1 << TX_INTR);
    }
    
    if(Status & UART_SR_RXRDY)
    {
		if(UART_Parameters[KWP_UART_CHAN].timeout_localcount !=0)
		{
			UART_Parameters[KWP_UART_CHAN].timeout_count=0;
			UART_Parameters[KWP_UART_CHAN].timeout_enabled=1;
		}
				
        /* Read one byte from the receive data register */
        uartRxData = UART_INTERFACE[KWP_UART_CHAN]->UART_RHR;       		
        uartByte =  uartRxData; 
        xQueueSendFromISR( UART_RX_QueueHandlers[KWP_UART_CHAN], &uartRxData,&fRx_TaskWokenByReceive);
		
		/**< New Implementation : Extended P1Max Timeout is introduced if complete packet is NOT received, 
		reset the Timeout value here, since Uart data is received */
		clearP1MaxExtendedTimeoutValue();		
        intrType = intrType | ((uint8_t)0x1 << RX_INTR);
    }
	if(intrType)
	{
		/**  New Implementation : passing the UART Byte to the handler,
		 to validate the data based on the length */
		ISO9141_14230_UARTIntrHandler(intrType, uartByte);    
	}
}

/******************************************************************************
* Function name  	: void UART_MidEnable(uint8_t)
* returns			: None
* parameters        : UART_chId_t uartCh - channel Number
* Description		: Uart Mid Enable.
* Notes	:
*******************************************************************************/
void UART_MidEnable(UART_chId_t uartCh)
{   
    PMC_EnablePeripheral(UART_ID[uartCh]);
    /* Enables the UART to transfer and receive data. */        
    UART_SetTransmitterEnabled ( UART_INTERFACE[uartCh] , 1);
    UART_SetReceiverEnabled ( UART_INTERFACE[uartCh] , 1);
    
    UART_EnableIt(UART_INTERFACE[uartCh], ( /*UART_IER_TXRDY |*/ UART_IER_RXRDY | UART_IER_OVRE | UART_IER_FRAME /*| UART_IER_PARE*/));    
    
}

/******************************************************************************
* Function name  	: void UART_MidDisable(uint8_t)
* returns			: None
* parameters        : UART_chId_t uartCh - channel Number
* Description		: Uart Mid Disable.
* Notes	:
*******************************************************************************/
void UART_MidDisable(UART_chId_t uartCh)
{  
	/* Enables the UART to transfer and receive data. */   
	UART_SetTransmitterEnabled ( UART_INTERFACE[uartCh] , 0);
	UART_SetReceiverEnabled ( UART_INTERFACE[uartCh] , 0);
 
	UART_DisableIt(UART_INTERFACE[uartCh], ( /*UART_IER_TXRDY |*/ UART_IER_RXRDY | UART_IER_OVRE | UART_IER_FRAME/*| UART_IER_PARE*/));    
}

/******************************************************************************
* Function name  	: void UART_MidSend(uint8_t, uint8_t *, uint16_t)
* returns			: Mid_API_Status_t - status
* parameters        : UART_chId_t uartCh - channel Number
                    : uint8_t *p_buf - buffer
                    : uint16_t len - data length
* Description		: Uart Mid Send.
* Notes	:
*******************************************************************************/
Mid_API_Status_t UART_MidSend (UART_chId_t uartCh, uint8_t *p_buf, uint16_t len)
{
    Mid_API_Status_t fl_Status;
    
    fl_Status = MID_PASS;
    while(len--)
    {
        if( xQueueSendFromISR( UART_TX_QueueHandlers[uartCh] , (void *) p_buf, ( TickType_t ) 0 ) == pdFAIL)
        {
            fl_Status = MID_FAIL;
            break;
        }
        p_buf++;
    }    
    UART_EnableIt(UART_INTERFACE[uartCh], UART_IER_TXEMPTY);
    return fl_Status;
}

/******************************************************************************
* Function name  	: void UART_MidSendFirstByte(UART_chId_t, uint8_t)
* returns			: Mid_API_Status_t - status
* parameters        : UART_chId_t uartCh - channel Number
                    : uint8_t *p_buf - buffer                    
* Description		: Uart Mid Send.
* Notes	:
*******************************************************************************/
Mid_API_Status_t UART_MidSendFirstByte (UART_chId_t uartCh, uint8_t p_buf)
{
	Mid_API_Status_t fl_Status = MID_PASS;
	
	UART_PutChar(UART_INTERFACE[uartCh], p_buf);
	return fl_Status;
}

/******************************************************************************
* Function name  	: void UART_MidRecv(uint8_t, uint8_t *, uint16_t)
* returns			: uint16_t data received
* parameters        : UART_chId_t uartCh - channel Number
                    : uint8_t *p_buf - buffer
                    : uint16_t len - data length
* Description		: Uart Mid Receive.
* Notes	:
*******************************************************************************/
uint16_t UART_MidRecv (UART_chId_t uartCh, uint8_t *p_buf, uint16_t len)
{
    
    uint16_t loop=0;
    while(len--){
        if( xQueueReceiveFromISR( UART_RX_QueueHandlers[uartCh], (void *)p_buf, 0) != pdPASS) {
            break;
        }
        p_buf++, loop++;
    }
    return loop;
}

/******************************************************************************
* Function name  	: void UART_MidRecv(uint8_t, uint8_t *, uint16_t, int16_t)
*    returns		: uint16_t - data received
*    parameters         :UART_chId_t uartCh - channel Number
                        :uint8_t *p_buf - buffer
                        :uint16_t len - data length
                        :uint16_t maxTimeout -Timeout
* Description		: Uart Mid Recv.
* Notes	:
*******************************************************************************/
uint16_t UART_MidRecvWait (UART_chId_t uartCh, uint8_t *p_buf, uint16_t len, int16_t maxTimeout)
{
    
    uint16_t loop=0;
    while(len--){
        if( xQueueReceive( UART_RX_QueueHandlers[uartCh], (void *)p_buf,
                                    maxTimeout * portTICK_PERIOD_MS) != pdPASS) {
            break;
        }
        p_buf++, loop++;
    }
    return loop;
}

/*******************************************************************************
* Function Name  : Uart_Clear_Tx_Q
* Description    : Clears the Transmit Queue of UART
* Input          : UARTx: where x can be 0,1 select the UART peripheral.
* Output         : None
* Return         : none
*******************************************************************************/
void Uart_Clear_Tx_Q(UART_chId_t uartCh, uint8_t mode)
{
	if(mode == NORMAL_MODE)
	{
		if(NULL != UART_TX_QueueHandlers[uartCh] )
		{					
			xQueueReset(UART_TX_QueueHandlers[uartCh]);
		}
	}
	else
	{
		//Do Nothing
	}
}

/*******************************************************************************
* Function Name  : Uart_Clear_Rx_Q
* Description    : Clears the Receive Queue of UART
* Input          : UARTx: where x can be 0,1 select the UART peripheral.
* Output         : None
* Return         : none
*******************************************************************************/
void Uart_Clear_Rx_Q(UART_chId_t uartCh, uint8_t mode)
{
	if(mode == NORMAL_MODE)
	{
		if(NULL != UART_RX_QueueHandlers[uartCh] )
		{
			xQueueReset(UART_RX_QueueHandlers[uartCh]);
		}
	}
	else
	{
		//Do Nothing
	}
}

/*******************************************************************************
* Function Name  : UART_Set_Baudrate
* Description    : Enables Tx
* Input          :  - UARTx: where x can be 0 or 1 to select the UART peripheral.
*                   - baudrate : baudrate in bps
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Set_Baudrate(UART_chId_t uartCh, uint32_t baudrate)
{
    UART_midConfig_v[uartCh].baudrate = baudrate;
    Uart_Clear_Tx_Q(uartCh,NORMAL_MODE);
    Uart_Clear_Rx_Q(uartCh,NORMAL_MODE);
    UART_MidDisable(uartCh);    
    PMC_DisablePeripheral(UART_ID[uartCh]);
    UART_MidInit(uartCh, UART_midConfig_v[uartCh]);
}

/*******************************************************************************
* Function Name  : UART_Set_DataLength
* Description    : Sets the Data Length
* Input          :  - p_uart_chno  : where x can be 0 or 1 to select the UART peripheral.
*                   - p_bit_length : Bit Length to Configure ( 5 to 8 )
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Set_DataLength(UART_chId_t uartCh,uint8_t dataLength)
{
    UART_midConfig_v[uartCh].dataLen = dataLength;
    Uart_Clear_Tx_Q(uartCh,NORMAL_MODE);
    Uart_Clear_Rx_Q(uartCh,NORMAL_MODE);
    UART_MidDisable(uartCh);    
    PMC_DisablePeripheral(UART_ID[uartCh]);
    UART_MidInit(uartCh, UART_midConfig_v[uartCh]);
}

/*******************************************************************************
* Function Name  : UART_Set_Stopbits
* Description    : Sets The No. of Stop bits
* Input          :  - p_uart_chno: uart channel ( 1 to 3 )
*                   - p_no_of_stopbits : no of stop bits
*                     Possible values: 1 or 2
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Set_Stopbits(UART_chId_t uartCh, UART_Stopbits_t stopbits)
{
    UART_midConfig_v[uartCh].stopbits = stopbits;
    Uart_Clear_Tx_Q(uartCh,NORMAL_MODE);
    Uart_Clear_Rx_Q(uartCh,NORMAL_MODE);
    UART_MidDisable(uartCh);    
    PMC_DisablePeripheral(UART_ID[uartCh]);
    UART_MidInit(uartCh, UART_midConfig_v[uartCh]);
}
/*******************************************************************************
* Function Name  : UART_Set_Parity
* Description    : Sets parity
* Input          :  - UARTx: where x can be 0 or 1 to select the UART peripheral.
*                   - p_set_parity : Required parity
*                     Possible values
*                     UART_PARITY_DISABLE
*                     UART_PARITY_ODD
*                     UART_PARITY_EVEN
*                     UART_PARITY_FORCED_HIGH
*                     UART_PARITY_FORCED_LOW
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Set_Parity(UART_chId_t uartCh, UART_Parity_t parity)
{
    UART_midConfig_v[uartCh].parity = parity;
    Uart_Clear_Tx_Q(uartCh,NORMAL_MODE);
    Uart_Clear_Rx_Q(uartCh,NORMAL_MODE);
    UART_MidDisable(uartCh);    
    PMC_DisablePeripheral(UART_ID[uartCh]);
    UART_MidInit(uartCh, UART_midConfig_v[uartCh]);
}

/*******************************************************************************
* Function Name  : TC11_Handler
* Description    : Timer 3 Channel 2 configured for 1 msecs ticks.
					Main Peripheral Clock is 150Mhz, Clock Prescaler is 150
					So RC value should be 1000 for 1 msecs ticks 
					Interrupt triggers every 1 msecs and handles the operations accordingly
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
volatile uint32_t TC11Dummy_SR;
void TC11_Handler(void)
{
	/* Clear status bit to acknowledge interrupt */
	TC11Dummy_SR = TC3->TC_CHANNEL[ 2 ].TC_SR;
	
	AdressClaimHandler();	
    PERIODIC_handler();
	
	UART_timeguard_handler();
    UART_RXtimeout_handler();
	
	 /**< Moved to the separate Handler */
    /* ISO9141_14230_TimerIntrHandler();*/
}

/*******************************************************************************
* Function Name  : TC10_Handler
* Description    : Timer 3 Channel 1 configured for 500 usecs ticks.
					Main Peripheral Clock is 150Mhz, Clock Prescaler is 150
					So RC value should be 500 for 500 usecs ticks 
					Interrupt triggers every 500 usecs and handles the operations accordingly 
					The purpose of maintaining this timer is for KLine Initialization accuracy :
					* ISO9141_14230_TimerIntrhandler() API is called from this ISR.
					* The Initialization sequence (25msecs Low-25 msecs High sequence) are handled here,
					* The Generic Timestamp timer is used for this handling which is 1msecs,
					* So for more accuracy in handling the ISO9141_14230_TimerIntrhandler(), 500usecs timers was reqd
					* Can also be reduced to 250usecs, but cannot be increased to 1msecs
* Input          :  
* Output         : None
* Return         : None
*******************************************************************************/
volatile uint32_t TC10Dummy_SR;
void TC10_Handler(void)
{
	/* Clear status bit to acknowledge interrupt */
	TC10Dummy_SR = TC3->TC_CHANNEL[ 1 ].TC_SR;
	ISO9141_14230_TimerIntrHandler();	
}


void Timer_Init(void)
{
    #if 0
    PMC_EnablePeripheral(ID_TC3); 
    TC_Configure( TC1, 0, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );
    TC1->TC_CHANNEL[ 0 ].TC_RC = 1000;
    /* Configure and enable interrupt on RC compare */
    NVIC_ClearPendingIRQ(TC3_IRQn);
    NVIC_SetPriority( TC3_IRQn ,TIMER_ISR_PRIORITY);
    NVIC_EnableIRQ(TC3_IRQn);
        
    TC1->TC_CHANNEL[ 0 ].TC_IER = TC_IER_CPCS ;
        
    /** Start the counter */
    TC_Start( TC1, 0 );
    
    
     PMC->PMC_PCK[6] = PMC_PCK_PRES(TC_PROG_CLK_PRESCALER - 1) | TC_PROG_CLK_SELECT;
     PMC->PMC_SCER |= PMC_SCER_PCK6;
     
     PMC_EnablePeripheral(ID_TC11);
     TC_Configure( TC3, 2, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );
     TC3->TC_CHANNEL[ 2 ].TC_RC = 1000;
          
     /* Configure and enable interrupt on RC compare */
     NVIC_ClearPendingIRQ(TC11_IRQn);
     NVIC_SetPriority( TC11_IRQn ,TIMER_ISR_PRIORITY);
     NVIC_EnableIRQ(TC11_IRQn);     
     TC3->TC_CHANNEL[ 2 ].TC_IER = TC_IER_CPCS ;    
     /** Start the counter */
     TC_Start( TC3, 2 );
     #endif
}

void Timer_Stop( void )
{
   // TC_Stop(TC3, 2);
} 

/*******************************************************************************
* Function Name  : Q_To_Uart
* Description    : Transmits one Byte of data from UARTx Tx Queue
* Input          : - p_uart_chno : UART Channel
* Output         : None
* Return         : Mid_API_Status_t : Status byte indicating whether a byte was successfully
fetched from Tx Queue or not
*******************************************************************************/
uint32_t uartSendCount = 0;
Mid_API_Status_t Q_To_Uart(UART_chId_t uartCh)
{
    uint8_t dequeuedByte;
    //IMP
    if( xQueueReceiveFromISR( UART_TX_QueueHandlers[uartCh], (void *)&dequeuedByte, 0) != pdPASS) {
        return MID_FAIL;
    }
	uartSendCount++;
	UART_EnableIt(UART_INTERFACE[KWP_UART_CHAN], UART_SR_TXEMPTY);
    UART_PutChar(UART_INTERFACE[uartCh], dequeuedByte);
    return MID_PASS;
}

/*******************************************************************************
* Function Name  : UART_timeguard_handler
* Description    : Handles UART TimeGuard
* Input          : None.
* Output         : None
* Return         : None
*******************************************************************************/
volatile uint32_t timegurdDummyCount = 0;
void UART_timeguard_handler(void)
{
	uint8_t dummyData=0;
    if(UART_Parameters[KWP_UART_CHAN].timeguard_enabled==1)
    {
        timegurdDummyCount++;
        UART_Parameters[KWP_UART_CHAN].timeguard_count++;
        if(UART_Parameters[KWP_UART_CHAN].timeguard_count==UART_Parameters[KWP_UART_CHAN].timeguard_localcount)
        {
            /* Time Guard operation is Disabled */
            UART_Parameters[KWP_UART_CHAN].timeguard_enabled=0;
            //UART_EnableIt(UART_INTERFACE[KWP_UART_CHAN], UART_SR_TXEMPTY);
            if( Q_To_Uart(KWP_UART_CHAN) == MID_FAIL)
            {
                /* Not Decided - Later May be Needed */
                UART_DisableIt(UART_INTERFACE[KWP_UART_CHAN], UART_SR_TXEMPTY);
            }
            else
            {
                /* Not Decided - Later May be Needed */
            }
            ISO9141_14230_UARTIntrHandler( ((uint8_t)0x1 << TX_INTR), dummyData);
        }
    }
}

/*******************************************************************************
* Function Name  : UART_RXtimeout_handler
* Description    : Handles UART RX TimeOut
* Input          : None.
* Output         : None
* Return         : None
*******************************************************************************/
void UART_RXtimeout_handler(void)
{
	uint8_t dummyData =0;
    if(UART_Parameters[KWP_UART_CHAN].timeout_enabled==1)
    {
        (UART_Parameters[KWP_UART_CHAN].timeout_count)++;
        if(UART_Parameters[KWP_UART_CHAN].timeout_count==UART_Parameters[KWP_UART_CHAN].timeout_localcount)
        {
            /* Start Timeout */
            UART_Parameters[KWP_UART_CHAN].timeout_count=0;
            /* Handle Receive Time-out */
            ISO9141_14230_UARTIntrHandler( ((uint8_t)0x1 << RXTIMEOUT_INTR), dummyData);
        }
    }
}

/*******************************************************************************
* Function Name  : UART_Change_TimeGuard
* Description    : Updates TimeGuard
* Input          : - p_uart_chno: UART Channel to Use
*                  - TimeGuard:Time Guard value in uS
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Change_TimeGuard(UART_chId_t uartCh, uint32_t timeGuard)
{
    uint32_t fl_timeguard=0;

    /* Check for Proper Time guard value */
    if(timeGuard >= portTICK_PERIOD_MS*1000)
    {
        /* Time Guard = set time guard+1bit time
        1 byte time = (1/Baudrate)*10^6(in us)*/
        fl_timeguard = timeGuard+(1000000/UART_Parameters[uartCh].Set_baudrate);
        UART_Parameters[uartCh].timeguard_localcount=(uint16_t)(fl_timeguard/ (portTICK_PERIOD_MS*1000));
        /* Add Tolerance of +500us to keep the TG always > than set Value */
        /*UART_Parameters[fl_chIndx].timeguard_localcount+=1;*/
    }
    else
    {
        UART_Parameters[uartCh].timeguard_localcount=0;
    }
    /* Reset Time Guard*/
    UART_Parameters[uartCh].timeguard_count=0;
    UART_Parameters[uartCh].timeguard_enabled=0;
}
/*******************************************************************************
* Function Name  : UART_Change_RxTimeOut
* Description    : Updates Receive Time-out
* Input          : - p_uart_chno: UART Channel to Use
*                  - RxTimeOut: receive Time out value in uS
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Change_RxTimeOut(UART_chId_t uartCh, uint32_t rxTimeOut)
{
    uint32_t fl_timeout=0;

    /* Check for Proper Time out value */
    if (rxTimeOut >= (portTICK_PERIOD_MS*1000))
    {
        /* Time out = set time out+1byte time
        1 byte time = (1/Baudrate*10)*10^6(in us)*/
        fl_timeout = rxTimeOut+((1000000*10)/UART_Parameters[uartCh].Set_baudrate);
        UART_Parameters[uartCh].timeout_localcount=(uint16_t)(fl_timeout/ (portTICK_PERIOD_MS*1000));
        /* Add Tolerance - if reminder is > than ISR rate/2 add 1 to count else do nothing */
        if((fl_timeout%(portTICK_PERIOD_MS*1000))>((portTICK_PERIOD_MS*1000)/2))
        {
            UART_Parameters[uartCh].timeout_localcount+=1;
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /*UART_Parameters[fl_chIndx].timeout_localcount=0;*/
    }
    /* Reset Time Out */
    UART_Parameters[uartCh].timeout_count=0;
    UART_Parameters[uartCh].timeout_enabled=0;
}

/*******************************************************************************
* Function Name  : UART_Restart_RxTimeOut
* Description    : Restarts Receive Time-out
* Input          : - p_uart_chno: UART Channel to Use
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Restart_RxTimeOut(UART_chId_t uartCh)
{
    
    if(UART_Parameters[uartCh].timeout_localcount !=0)
    {
        /* Start Time Out */
        UART_Parameters[uartCh].timeout_count=0;
        UART_Parameters[uartCh].timeout_enabled=1;
    }
    else
    {
        /* Do Nothing */
    }
}

/*******************************************************************************
* Function Name  : ISO9141_14230_Validate_Data_Received
* Description    : Validates the 14230 frames,  based on the length
* Input          : recvdLength : Data length received on P1Max Timeout
* Output         : None
* Return         : ISO9141_14230_PKT_STATUS : pkt complete/incomplete pkt
* Author         : Amit: Tata Motors Fix for delayed interbyte time
*******************************************************************************/
uint16_t ISO9141_14230_Get_Data_Length( uint8_t recvdData, uint16_t* lengthIndex)
{
	uint8_t frameAddrModeInfo = ADDRESS_PRESENT;
	uint16_t pktlength=0;
	
	if(*lengthIndex == 0)
	{
		
		if( (recvdData & FRAME_FORMAT_MODE_BITS) == 0)
		{
			frameAddrModeInfo = NO_ADDRESS;
		}
		else
		{
			frameAddrModeInfo = ADDRESS_PRESENT;
		}
		
		if( (recvdData & FRAME_FORMAT_HDR_LENGTH_BITS) != FRAME_FORMAT_HDR_LEN_ZERO)
		{
			pktlength = ( (recvdData & FRAME_FORMAT_HDR_LENGTH_BITS) + ((frameAddrModeInfo == ADDRESS_PRESENT) ? HDR_FRM_TA_SA_CK : HDR_FRM_CK));
			*lengthIndex =0;
		}
		else
		{
			*lengthIndex = ((frameAddrModeInfo == ADDRESS_PRESENT) ? LENGTH_INDEX_WITH_ADDR : LENGTH_INDEX_WO_ADDR);
		}
	}
	else
	{
		pktlength = recvdData + ((frameAddrModeInfo == ADDRESS_PRESENT) ? HDR_FRM_TA_SA_LEN_CK : HDR_FRM_LEN_CK);
		*lengthIndex =0;
	}
	return (pktlength);
}

#endif /**< End of __UART_MID_C */
