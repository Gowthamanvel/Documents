/******************************************************************************
*
* Copyright                                                  Template Version
* 2014 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/*
 * ADC_Mid.c
 *
 * Created: 7/29/2015 2:27:40 PM
 *  Author: amit
 */  

/******************************************************************************
* P U R P O S E: This module implements ADC Mid level application interfaces
*******************************************************************************/


/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "chip.h"
#include "ADC_Mid.h"
#include "HFCP.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/


/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
* Function name  	: void afe_adc_initialization(uint8_t)
* returns			: None
* parameters        : None
* Description		: UART 4 Interrupt Handler.
* Notes	:
*******************************************************************************/
void afe_adc_initialization(void) 
{
    AFEC_Initialize( AFEC0, ID_AFEC0 );
    
    AFEC_SetModeReg(AFEC0,
                    AFEC_MR_FREERUN_ON
                    | AFEC_EMR_RES_NO_AVERAGE
                    |(1 << AFEC_MR_TRANSFER_Pos)
                    |(2 << AFEC_MR_TRACKTIM_Pos)
                    | AFEC_MR_ONE
                    | AFEC_MR_SETTLING_AST3
                    | AFEC_MR_STARTUP_SUT64);

    AFEC_SetClock( AFEC0, AFE_CLK, BOARD_MCK ) ;
    
    AFEC_SetExtModeReg(AFEC0,
                        0
                        | AFEC_EMR_RES_NO_AVERAGE
                        | AFEC_EMR_TAG
                        | AFEC_EMR_STM );
                        
                        
   AFEC_SetAnalogOffset(AFEC0, ADC_CHANNEL, 0x800);
    
   AFEC_SetAnalogControl(AFEC0, AFEC_ACR_IBCTL(1) | AFEC_ACR_PGA0_ON | AFEC_ACR_PGA1_ON );
    
    AFEC_EnableChannel(AFEC0, ADC_CHANNEL);
}

/*******************************************************************************
* Function Name  : Read_BatteryVoltage
* Input          : USB buffer.
* Return         : None.
* Description    : This function processes the battery Voltage
* Note           : Since the Example Code Provided for ADC had set AnalogOffset to 
                   800, so 800 is substraced from the ADC Count Value.
                   Code to be visited again for optimization
*******************************************************************************/
uint8_t Read_BatteryVoltage(uint32_t *BatVg)
{
    uint32_t retry_count = 0;
    uint32_t adc_count;
    uint32_t local_Adc_Count=0;
    uint8_t fl_status;

    AFEC_StartConversion(AFEC0);

    local_Adc_Count =  AFEC_GetConvertedData( AFEC0,ADC_CHANNEL );          
    adc_count = ((local_Adc_Count & 0xFFFF ) - 0x800);
    for(retry_count = 0; retry_count< 9; retry_count++)
    {
        local_Adc_Count = AFEC_GetConvertedData( AFEC0,ADC_CHANNEL );  
       adc_count += ((local_Adc_Count & 0xFFFF ) - 0x800);
    }
    
    adc_count = adc_count/10;
    
    /* VOLT_DIVISOR - corresponds to Voltage divider compensation factor */
    /* ADC_STEP_VAL_uV - ADVref/ADCresolution in uV */
    
    adc_count = (adc_count*ADC_STEP_VAL_uV*VOLT_DIVISOR)/1000;
    
    /* Round off  to nearest 10th of a volt */
    if((adc_count%100) >= 50)
    {
        adc_count += 100 - (adc_count%100);
    }
    else
    {
        adc_count -= (adc_count%100);
    }
    *BatVg = adc_count;
    fl_status = TRUE;

    return fl_status;
}
