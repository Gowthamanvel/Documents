/******************************************************************************
*
* Copyright                                                  Template Version
* 2014 Dearborn Electronics India                            <Ver # >
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/
/******************************************************************************
* P U R P O S E: This module implements SPI low level application interfaces
*******************************************************************************/
#ifndef __SPI_LOW_C
#define __SPI_LOW_C

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Proj_Config.h" 
#include "chip.h" 
#include "SPI_Mid.h" 
#include "spi_dma.h"
#include "Wifi_SN8200.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "board.h"
#include "HFCP.h"
#include "Garuda_Main.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#ifndef ATMEL_SAMV7x
#define ATMEL_SAMV7x				1
#endif

#define SPI_500KBPS_CLK				0
#define SPI_1MBPS_CLK				1
#define SPI_5MBPS_CLK				2
#define SPI_10MBPS_CLK				3
#define SPI_15MBPS_CLK				4

#define SPI_CHIP_SELECT             1

/******************************************************************************
*   S T R U C T U R E  A N D  E N U M E R A T I O N    D E F I N I T I O N S
*******************************************************************************/
/** WiFi Interrupt Pin Configurations */
const Pin pinWiFiIntr = PIN_WIFI_INTERRUPT;

/** WiFi Reset Pin Configurations */
const Pin pinWiFiReset = PIN_WIFI_RESET;

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void External_Interrupt_Config(void);
void SPI_DMA_Init (void);
bool Is_DMA_Tx_Complete(uint8_t);
void WIFI_INTERRUPT_HANDLER(const Pin* pPin );

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
Spid SpiDma;
SpidCmd SpiCommand;
SpidCmd SpiDummyTx;
sXdmad Dma;

QueueHandle_t spiRxQueue;


uint8_t pTxBuffer[SPI_DMA_TX_MAX_SIZE];
uint8_t pRxBuffer[SPI_DMA_TX_MAX_SIZE+40];

/**WiFi(SN8200) SPI Pin Configurations */
static const Pin spi_pins[] = {
	PIN_SPI_MISO,
	PIN_SPI_MOSI,
	PIN_SPI_SPCK,
	PIN_SPI_NPCS1
};

/** WiFi(SN8200) SPI clock configuration */
static const uint32_t clockConfigurations[5] = { 500000,1000000, 5000000, 10000000, 15000000};
	
/** SPI Clock setting (Hz) */
static uint32_t spiClock = 5000000;	
 
extern uint32_t spiDmaTxChannel;
extern uint32_t spiDmaRxChannel;
extern uint8_t tempbuf[SPI_DMA_RX_SIZE];


/******************************************************************************
*               S P I  W R A P P E R   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/
/*******************************************************************************
* Function Name  : SPIFreeRTOS_Init
* Description    : Initializes FreeRTOS specific resources required by the SPI
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPIFreeRTOS_Init (void)
{
    spiRxQueue = xQueueCreate( SPI_RX_Queue_SIZE, ( unsigned portBASE_TYPE )(sizeof(Dynamic_QStruct_t) ));
    vQueueAddToRegistry(spiRxQueue, "SPIRxQ");
}

/*******************************************************************************
* Function Name  : SPI_Init
* Description    : Initializes the SPI peripheral according to the specified
*                  parameters in the SPI_InitStruct .
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
Mid_API_Status_t SPI_Mid_Init(void)
{
	Mid_API_Status_t status = MID_PASS ;
	
#if ATMEL_SAMV7x	
	Dma.pXdmacs = XDMAC;

	PIO_Configure(spi_pins, PIO_LISTSIZE(spi_pins));
	spiClock = clockConfigurations[SPI_15MBPS_CLK];

	/* External_Interrupt_Config(); */ /*Should be called only once, so called from Garuda main function */
			 
	SPID_Configure(&SpiDma, SPI0, ID_SPI0, (SPI_MR_MSTR | SPI_MR_MODFDIS | SPI_MR_WDRBT | SPI_PCS( SPI_CHIP_SELECT )), &Dma);				
	SPI_ConfigureNPCS( SPI0, SPI_CHIP_SELECT, SPI_DLYBCT( 1000, BOARD_MCK ) | SPI_DLYBS(1000, BOARD_MCK) | SPI_SCBR(spiClock, BOARD_MCK) | SPI_CSR_NCPHA);			
		
     /* Enable the SPI Peripheral */
    PMC_EnablePeripheral (ID_SPI0);	
	
	#if CODE_OPTIMIZATION
	/* Initialize DMA controller using channel 0 for RX, 1 for TX. */
    if (_spid_configureDmaChannels(&SpiDma) )
	{
        status = MID_FAIL;
	}
	
	/* Configure and enable interrupt on RC compare */  	
	NVIC_ClearPendingIRQ(XDMAC_IRQn);
    NVIC_SetPriority( XDMAC_IRQn ,SPI_DMA_RX_IRQ_PRIORITY);
    NVIC_EnableIRQ(XDMAC_IRQn);		
	#endif
	SPI_Enable (SPI0 );	
		
    SPI_ChipSelect (SPI0, (1 << SPI_CHIP_SELECT));    
     
    return status;
#endif
}

/*******************************************************************************
* Function Name  : SPI_Mid_Deinit
* Description    : Initializes the SPI peripheral according to the specified
*                  parameters in the SPI_InitStruct .
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
Mid_API_Status_t SPI_Mid_Deinit(void)
{
    Mid_API_Status_t status = MID_PASS ;
    
    /* Enable the SPI Peripheral */
    PMC_DisablePeripheral (ID_SPI0);    
    SPI_Disable (SPI0 );
    
   return status; 
}    

/*******************************************************************************
* Function Name  : External_Interrupt_Config
* Description    : Initializes the SPI External Interrupt.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void External_Interrupt_Config(void)
{
#if ATMEL_SAMV7x
	/* Configure pios as inputs. */
	PIO_Configure( &pinWiFiIntr, 1 ) ;

	/* Adjust pio debounce filter parameters, uses 10 Hz filter. */
	/* TBD PIO_SetDebounceFilter( &pinWiFiIntr, 10 ) ; */

	NVIC_SetPriority((IRQn_Type)pinWiFiIntr.id , EXT_INT_IRQ_PRIORITY);
	
	/* Initialize pios interrupt handlers, see PIO definition in board.h. */
	/* Interrupt on falling edge  */
	PIO_ConfigureIt( &pinWiFiIntr, WIFI_INTERRUPT_HANDLER ) ; 
	
	/* Enable PIO controller IRQs. */
	NVIC_EnableIRQ( (IRQn_Type)pinWiFiIntr.id ) ;

	/* Enable PIO line interrupts. */
	PIO_EnableIt( &pinWiFiIntr ) ;
#endif
}

/*******************************************************************************
* Function Name  : SPI_Mid_Transmit
* Description    : SPI transmits 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_Mid_Transmit (uint8_t *SPIDmaPacket, uint16_t SPIDmaTxLen)
{  
#if ATMEL_SAMV7x
	SpiCommand.TxSize = SPIDmaTxLen;
	memcpy((void*)&pTxBuffer[0],&SPIDmaPacket[0], SPIDmaTxLen);	
	SpiCommand.pTxBuff = (uint8_t *)pTxBuffer;
	SpiCommand.RxSize= SPIDmaTxLen;
	SpiCommand.pRxBuff = (uint8_t *)pRxBuffer;
	SpiCommand.spiCs = 3;		
	 SPID_SendCommand(&SpiDma, &SpiCommand);    
#endif	
}

/*******************************************************************************
* Function Name  : SPI_Dummy_Transmit
* Description    : SPI transmits 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_Dummy_Transmit (uint8_t *SPIDmaPacket, uint16_t SPIDmaTxLen)
{  
#if ATMEL_SAMV7x
	SpiDummyTx.TxSize = SPIDmaTxLen; 
    SpiDummyTx.pTxBuff = (uint8_t *)tempbuf;
	SpiDummyTx.RxSize= SPIDmaTxLen;
	SpiDummyTx.pRxBuff = (uint8_t *)pRxBuffer;
	SpiDummyTx.spiCs = 3;	
	SPID_SendCommand(&SpiDma, &SpiDummyTx);
#endif	
}

/*******************************************************************************
* Function Name  : SPI_Mid_Recieve
* Description    : SPI Reception 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
Mid_API_Status_t SPI_Mid_Recieve (Dynamic_QStruct_t *dataFromQ, TickType_t timeout)
{ 	
	if(xQueueReceive(spiRxQueue, dataFromQ, timeout)== pdTRUE)
	{
		return MID_PASS;
	}  
	else
	{
		return MID_FAIL;
	}
}


/*******************************************************************************
* Function Name  : WIFI_INTERRUPT_HANDLER
* Description    : Wifi handler 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void WIFI_INTERRUPT_HANDLER(const Pin* pPin )
{
	if ( pPin == &pinWiFiIntr )
	{        
		Initiate_Wifi_Rx(TRUE);	
	}
}

/*******************************************************************************
* Function Name  : SPIx_RX_DMA_IRQ
* Description    : presently implemented in the SPI DMA Callback functions 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPIx_RX_DMA_IRQ(void) 
{
#if 0 
	BaseType_t xWifiTaskWoken = pdFALSE;
	Dynamic_QStruct_t dataToQ;

	dataToQ.address = pvPortMalloc(SPI_DMA_RX_SIZE);
	if(dataToQ.address)
	{
		dataToQ.len = SPI_DMA_RX_SIZE;
		memcpy(dataToQ.address,(uint8_t *)&aRxBuffer[0],dataToQ.len);
		if(xQueueSendFromISR(spiRxQueue, (void*)&dataToQ, &xWifiTaskWoken) == pdFALSE)
		{
			printf("SPI DEBUG : Error to write in SPI Queue\r\n");
			vPortFree(dataToQ.address);
		}
	}  
#endif
}
  
/*******************************************************************************
* Function Name  : SN8200ConfigReset
* Description    : Configure the WiFi Reset Pin.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/  
void SN8200ConfigReset (void)
{
#if ATMEL_SAMV7x
	PIO_Configure( &pinWiFiReset, 1 ); 
#endif
}

/*******************************************************************************
* Function Name  : SN8200HoldReset
* Description    : CLear the WiFi Reset Pin.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SN8200HoldReset(void)
{
#if ATMEL_SAMV7x
	PIO_Clear( &pinWiFiReset) ;
	//vTaskDelay(1000);
#endif
}

/*******************************************************************************
* Function Name  : SN8200ReleaseReset
* Description    : Set the WiFi Reset Pin.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SN8200ReleaseReset(void)
{
#if ATMEL_SAMV7x
	PIO_Set( &pinWiFiReset ) ;
	vTaskDelay(1000);
#endif	
}

/*******************************************************************************
* Function Name  : Start_SPI_Rx_DMA
* Description    : Transmit dummy SPI data for reading data from SN8200
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Start_SPI_Rx_DMA (void)
{  
#if ATMEL_SAMV7x	
	SPI_Dummy_Transmit(&tempbuf[0] ,SPI_DMA_RX_SIZE);
#endif	
}

/*******************************************************************************
* Function Name  : Stop_SPI_Rx_DMA
* Description    : Stop DMA Reception
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Stop_SPI_Rx_DMA (void)
{   
#if ATMEL_SAMV7x
    XDMAD_StopTransfer(&Dma, spiDmaRxChannel );  
#endif	

#if NXP_LPC_43XX
	Chip_GPDMA_Stop(LPC_GPDMA, dmaChSSPRx);
#endif
	  
#if ST_STM32F4XX  
    DMA_Cmd(SPIx_RX_DMA_STREAM,DISABLE);
#endif
}

/*******************************************************************************
* Function Name  : Is_Ext_Int_Line_Low
* Description    : returns the wifi interrupt pin status 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool Is_Ext_Int_Line_Low(void)
{
#if ATMEL_SAMV7x
    return  !(PIO_Get(&pinWiFiIntr));
    /* return  !(PIO_GetOutputDataStatus(&pinWiFiIntr)); */	
#endif	
}

/*******************************************************************************
* Function Name  : DMA_IRQHandler
* Description    : OLD FUNCTIONALITY
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void DMA_IRQHandler(void)
{
#if ATMEL_SAMV7x
return ;
#endif	

#if NXP_LPC_43XX	
	  if (Chip_GPDMA_Interrupt(LPC_GPDMA, dmaChSSPTx) == SUCCESS) {
	  }
	  
	  if (Chip_GPDMA_Interrupt(LPC_GPDMA, dmaChSSPRx) == SUCCESS) {
		  SPIx_RX_DMA_IRQ();
	  }
#endif
}

/*******************************************************************************
* Function Name  : XDMAC_Handler
* Description    : XDMAC_Handler
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void XDMAC_Handler(void)
{
    XDMAD_Handler(&Dma);
}

/*******************************************************************************
* Function Name  : SPID_Rx_Cb
* Description    : SPID_Rx_Cb
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
volatile uint8_t allocIndex = 0;
static uint8_t  allocatedBuffer[50][SPI_DMA_RX_SIZE];
Dynamic_QStruct_t dataToQ; 

 void SPID_Rx_Cb(uint32_t channel, Spid* pArg)
{
    SpidCmd *pSpidCmd = pArg->pCurrentCommand;   
	BaseType_t xWifiTaskWoken = pdFALSE;
		
	if(channel > 3)
	return;	
		
	if (channel != spiDmaRxChannel)
    return;				
	
    SCB_CleanInvalidateDCache();	   
			
	dataToQ.address = allocatedBuffer[allocIndex];
	/* dataToQ.address = pvPortMalloc(SPI_DMA_RX_SIZE); */
	
	allocIndex++;	
	if(allocIndex == 50)
	{
		allocIndex = 0;	
	}
		
    if(dataToQ.address)
    {
      /* dataToQ.address = (uint8_t*)&pArg->pCurrentCommand->pRxBuff[0]; */
      dataToQ.len = SPI_DMA_RX_SIZE;	  
      memcpy(dataToQ.address,(uint8_t *)&pArg->pCurrentCommand->pRxBuff[0],dataToQ.len); 

      if(xQueueSendFromISR(spiRxQueue, (void*)&dataToQ, &xWifiTaskWoken) == pdFALSE)
      {
        printf("SPI DEBUG : Error to write in SPI Queue\r\n");
        /* vPortFree(dataToQ.address);*/
      }
    }
	
	 /* Release the dataflash semaphore */
    pArg->semaphore++;
		
    /* Invoke the callback associated with the current command */
    if (pSpidCmd && pSpidCmd->callback) {
        pSpidCmd->callback(0, pSpidCmd->pArgument);
    }
}

/*******************************************************************************
* Function Name  : WiFI_Mid_Reset
* Description    : WiFI_Mid_Reset
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void WiFI_Mid_Reset (void)
{
    Garuda_Main_ResetQueue(spiRxQueue, ( unsigned portBASE_TYPE )(sizeof(Dynamic_QStruct_t)), DONT_RELEASE); //TBD    
}


#endif /*< End of #ifndef __SPI_MID_C*/
/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version  Author  Date
* 1.0  Mahadeva Swamy B        July 13, 2013
******************************************************************************/