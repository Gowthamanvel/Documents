/*
 * USB_Mid.c
 *
 * Created: 5/12/2015 2:26:09 PM
 *  Author: Ramesh D
 */ 


/******************************************************************************
* P U R P O S E: This module implements CAN middle level application interfaces
*******************************************************************************/
/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Proj_Config.h"
#include "chip.h"
#include "USB_Mid.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "board.h"
#include "HFCP.h"
#include "Garuda_Main.h"


/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/

#ifndef ATMEL_SAMV7x
#define ATMEL_SAMV7x				1
#endif

#define USB_RX_Queue_SIZE			100 //16 Changed to 64 to support 1Mbps 4096 bytes data transfer
#define USB_TX_Queue_SIZE			500

#define USB_PACKET_SIZE				64

extern USBDDriverDescriptors hiddTransferDriverDescriptors;

/******************************************************************************
*               P R I V A T E   V A R I A B L E S
*******************************************************************************/
static QueueHandle_t	usbRxQueue;
static QueueHandle_t	usbTxQueue;

static QueueHandle_t	usbTxRelease;

static TaskHandle_t		usbTxTaskHandle;
static TaskHandle_t		usbRxTaskHandle;
//static uint8_t			*pRxBuffer = NULL;
static QueueHandle_t	usbFreeBufferQueue;
static SemaphoreHandle_t rxTaskExecLock;
static SemaphoreHandle_t txTaskExecLock;

//#ifdef DEBUG
static uint32_t			rxBufferAddCount = 0;
static uint32_t			rxBufferReleaseCount = 0;
//static uint32_t			txBufferAddCount = 0;
//static uint32_t         txBufferReleaseCount = 0;
uint32_t USBtxComplete;

#define RX_BUFFER_ADD()		(rxBufferAddCount++)
#define RX_BUFFER_RELEASE()	(rxBufferReleaseCount++)
#define TX_BUFFER_ADD()		(txBufferAddCount++)
#define TX_BUFFER_RELEASE() (txBufferReleaseCount++)
//#endif

volatile uint8_t nowQ;
volatile uint8_t nowIntr;


/******************************************************************************
*               USB  W R A P P E R   F U N C T I O N S
*******************************************************************************/


void USB_Tx_Task (void *);
void USB_Rx_Task (void *);
void _ConfigureUotghs(void);
void USB_Mid_Trace(uint8_t *pBuffer, uint16_t len);
void USB_Mid_EmergencySend(void *pArg, uint8_t status, uint32_t transferred, uint32_t remaining);
void USB_Mid_ClearBuffer (void *pArg, uint8_t status, uint32_t transfered, uint32_t remaining);
void USB_Mid_AsyncTx (void *pArg, uint8_t status, uint32_t transfered, uint32_t remaining);

/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/
void USBFreeRTOS_Init (void) {
	uint8_t i;
	uint8_t	*pBuff;

    rxTaskExecLock = xSemaphoreCreateBinary();
	txTaskExecLock = xSemaphoreCreateBinary();
    if (!rxTaskExecLock || !txTaskExecLock)
    {
        return;
    }

    /* Initialized Required Q's for the task */
    /* Create Rx Queue */
    usbRxQueue = xQueueCreate(USB_RX_Queue_SIZE, sizeof(uint8_t*));
    if (usbRxQueue == NULL) {
        /* Queue creation failed */
        TRACE_INFO("Rx Queue creation failed\n\r");
        return;
    }

    /* Create Tx Queue */
    usbTxQueue = xQueueCreate(USB_TX_Queue_SIZE, sizeof(uint8_t*));
    if (usbTxQueue == NULL) {
        /* Queue creation failed */
        TRACE_INFO("Tx Queue creation failed\n\r");
        return;
    }

    /* Create Free Buffers Queue */
    usbFreeBufferQueue = xQueueCreate(USB_RX_Queue_SIZE, sizeof(uint8_t*));
    if (usbFreeBufferQueue == NULL) {
        /* Free buffer Qeueue creation failed */
        TRACE_INFO("USB RX Free buffer Qeueue creation failed\r\n");
    }

    for (i = 0; i < USB_RX_Queue_SIZE; i++) {
        pBuff = pvPortMalloc(USB_PACKET_SIZE);
        if (pBuff) {
            memset(pBuff, 0, USB_PACKET_SIZE);
            if (xQueueSend(usbFreeBufferQueue, &pBuff, portTICK_PERIOD_MS) == pdFAIL) {
                vPortFree(pBuff);
            }
        }
    }

	/* Add Queues to MPU registry */
	vQueueAddToRegistry(usbRxQueue, "USB_rxQ");
	vQueueAddToRegistry(usbTxQueue, "USB_txQ");
	vQueueAddToRegistry(usbFreeBufferQueue, "USB_Free_rxQ");
	
	/* Create Tx Task */
	if (pdFAIL == xTaskCreate(USB_Tx_Task, "USB Tx Task", USB_TASK_STACK_SIZE, NULL, USB_TX_TASK_PRIORITY, &usbTxTaskHandle)) {
		/* Tx Task creation failed */
		TRACE_INFO("Tx Task creation failed\n\r");
		return;
	}
	
	/* Create Rx Task */
	if (pdFAIL == xTaskCreate(USB_Rx_Task, "USB Rx Task", USB_TASK_STACK_SIZE, NULL, USB_TX_TASK_PRIORITY, &usbRxTaskHandle)) {
		/* Rx Task creation failed */
		TRACE_INFO("Rx Task Creation Failed\n\r");
		return;
	}
	USB_Mid_Init();
	
	usbTxRelease = xQueueCreate(16, sizeof(void*));
	if (!usbTxRelease) {
		TRACE_INFO_WP("Tx Release Queue creation failed");
	}
}

void USB_Mid_Init (void) {
	
	_ConfigureUotghs();
	/* USB Hid Device Initialize */
	HIDDTransferDriver_Initialize(&hiddTransferDriverDescriptors);
		
	/* Connect USB Device */
	USBD_Connect();
	//USBHS_SetHostSpeed(USBHS, USBHS_CTRL_USBE);
}

uint8_t usbTxBufferArray[48][USB_PACKET_SIZE];
volatile uint8_t usbTxArrayIndex;
void USB_Mid_Transmit (uint8_t *txData, uint16_t txLen, uint8_t release) {

	if (!txData) {
		/* Invalid parameters */
		return ;
	}
	else if (!txLen)
	{
		vPortFree(txData);
		return;
	}
	else if (txLen > USB_PACKET_SIZE) {
		txLen = USB_PACKET_SIZE;
	}
	
	// Working Code
	memset(usbTxBufferArray[usbTxArrayIndex], 0, USB_PACKET_SIZE);
	memcpy(usbTxBufferArray[usbTxArrayIndex], txData, txLen);
    
    if(RELEASE == release)
    {        
	    vPortFree(txData);
    }        

	HIDDTransferDriver_Write(usbTxBufferArray[usbTxArrayIndex], USB_PACKET_SIZE, NULL/*USB_Mid_ClearBuffer*/, 0/*txData*/);
	USBtxComplete++;
	usbTxArrayIndex++;
	if (usbTxArrayIndex == 48)
	{
		usbTxArrayIndex = 0;
	}
}

void HIDDTransferDriver_ReportReceivedCb(HIDDFunction *pHidd, uint8_t status, uint32_t transferred, uint32_t remaining) {
	//uint8_t i;
	uint8_t *pBuff;
	HIDDReport *pOut = pHidd->pOutputList[pHidd->bCurrOutput];
	BaseType_t xUSBTaskWoken = pdFALSE;
	remaining = remaining;
	if (status != USBRC_SUCCESS) {
		TRACE_ERROR("HIDDFun::ReadReport: %x\n\r", status);
		return;
	}

	/* Transfered information */
	pOut->wTransferred = transferred;

	/* Data Change callback */
	if (pOut->fCallback)
	pOut->fCallback(HIDD_EC_REPORTCHANGED, pOut->pArg);

	/* Proceed to next output report */
	pHidd->bCurrOutput ++;
	if (pHidd->bCurrOutput >= pHidd->bOutputListSize)
	pHidd->bCurrOutput = 0;
		
	/* Enqueue the current report to the rx queue */
	/*if (pOut->wTransferred < USB_PACKET_SIZE) {
		T-RACE_INFO("USB: %u < USB_PACKET_SIZE\n\r", pOut->wTransferred);
	}*/
	
	//TRACE_INFO("@:%p Start reading a report\n\r", usbRxQueue);
	if (xQueueReceiveFromISR(usbFreeBufferQueue, &pBuff, &xUSBTaskWoken) == pdTRUE) {
		memcpy(pBuff, pOut->bData, pOut->wTransferred);
		//TRACE_INFO("Data @[%p] enqueued to rx Queue\n\r", pBuff);
		//TRACE_INFO_WP("\n\rusbRx:");
		//USB_Mid_Trace(pBuff, pOut->wTransferred);
		xUSBTaskWoken = pdFALSE;
		if (xQueueSendFromISR(usbRxQueue, &pBuff, &xUSBTaskWoken) != pdTRUE) {
			/* Unable to enqueue data isr */
			TRACE_INFO("USB: Unable to enqueue ISR\n\r");
			//TRACE_ERROR("error: rxSize:%d\n\r", pOut->wTransferred);
		}
		RX_BUFFER_ADD();
		//portYIELD_FROM_ISR(xUSBTaskWoken);
	}
	else {
		TRACE_INFO_WP("USB No buffer free\n\r");
	}
	//Send_To_HFCP_Queue(pOut->bData, pOut->wTransferred);

	/* Start reading a report */
	USBD_Read(pHidd->bPipeOUT,
				pHidd->pOutputList[pHidd->bCurrOutput]->bData,
				pHidd->pOutputList[pHidd->bCurrOutput]->wMaxSize,
				(TransferCallback)HIDDTransferDriver_ReportReceivedCb,
				(void*)pHidd);
}

void USB_Rx_Task (void* pArg) {
	uint8_t *rxBuffer;
	//uint8_t i;
		
	/* USB Rx Handle Task */
	do {
//		while (xSemaphoreTake(rxTaskExecLock, portMAX_DELAY) != pdTRUE);
//		xSemaphoreGive(rxTaskExecLock);
		//TRACE_INFO_WP(",");
		if (xQueueReceive(usbRxQueue, &rxBuffer, portMAX_DELAY) == pdFALSE) {
			/* Unable to read data from the Rx queue */
			TRACE_ERROR("Unable to read data from the Rx queue\n\r");
			continue;
		}
		//TRACE_INFO_WP("usbRx:");
		//USB_Mid_Trace(rxBuffer, USB_PACKET_SIZE);
		Send_To_HFCP_No_Copy_Queue(rxBuffer, USB_PACKET_SIZE);
		RX_BUFFER_RELEASE();
		rxBuffer = pvPortMalloc(USB_PACKET_SIZE);
		if (rxBuffer) {
			//memset(rxBuffer, 0, USB_PACKET_SIZE);
			if (xQueueSend(usbFreeBufferQueue, &rxBuffer, 1) == pdFAIL) {
				vPortFree(rxBuffer);
			}
		}
	} while (1);
}


static uint8_t usbTxTaskLimit = 0;
void USB_Tx_Task (void* pArg) {
	uint8_t *txBuffer;
	//uint8_t i;
	TickType_t maxWaitTime = 0;

	/* USB Tx Handle Task */
	do {
		maxWaitTime = portMAX_DELAY;
		usbTxTaskLimit = 0;

		while (xQueueReceive(usbTxRelease, &txBuffer, maxWaitTime) == pdTRUE) {
			maxWaitTime = 0;
			if (txBuffer) {
				vPortFree(txBuffer);
			}
			if (maxWaitTime++ > 16) {
				break;
			}
		}
	} while(true);
}

void _ConfigureUotghs(void)
{
  
    /* UTMI parallel mode, High/Full/Low Speed */
    /* UUSBCK not used in this configuration (High Speed) */
    PMC->PMC_SCDR = PMC_SCDR_USBCLK;
    /* USB clock register: USB Clock Input is UTMI PLL */
    PMC->PMC_USB = PMC_USB_USBS;
    /* Enable peripheral clock for USBHS */
    PMC_EnablePeripheral(ID_USBHS);    
    USBHS->USBHS_CTRL = USBHS_CTRL_UIMOD_DEVICE;
	
	//USBHS_EnableHSTestMode(USBHS);
	USBHS_EnableHighSpeed(USBHS, false); //FULL SPEED
	//USBHS_EnableHighSpeed(USBHS, true); //HIGH SPEED
	//USBHS_EnableTestMode(USBHS, USBHS_DEVCTRL_SPDCONF_LOW_POWER);
    /* Enable PLL 480 MHz */
    PMC->CKGR_UCKR = CKGR_UCKR_UPLLEN | CKGR_UCKR_UPLLCOUNT(0xF);
    /* Wait that PLL is considered locked by the PMC */
    while( !(PMC->PMC_SR & PMC_SR_LOCKU) );

    /* IRQ */
   // NVIC_SetPriority(USBHS_IRQn, USB_HS_IRQ_PRIORITY);//3
    NVIC_EnableIRQ(USBHS_IRQn) ;
}

void USB_Mid_Trace(uint8_t *pBuffer, uint16_t len) {
	uint16_t i;
	for (i = 0; i < len; i++) {
		TRACE_INFO_WP("%02X", pBuffer[i]);
	}
	TRACE_INFO_WP("\n\r");
}

void USB_Mid_EmergencySend(void *pArg, uint8_t status, uint32_t transferred, uint32_t remaining) {
	uint8_t *txBuffer;
    BaseType_t fl_TaskWokenByReceive = pdFALSE;
	if (!remaining) {
		//if (xQueueIsQueueFullFromISR(usbTxQueue) == pdTRUE) {
			if (xQueueReceiveFromISR(usbTxQueue, &txBuffer, &fl_TaskWokenByReceive) == pdTRUE) {
				HIDDTransferDriver_Write(txBuffer, USB_PACKET_SIZE, USB_Mid_EmergencySend, 0);
				vPortFree(txBuffer);
			}
		//}
	}
}

void USB_Mid_ClearBuffer (void *pArg, uint8_t status, uint32_t transfered, uint32_t remaining) {
	BaseType_t xUsbTxCompleteToken = pdFALSE;
	if (pArg /* && !remaining */) {
		USBtxComplete++;
		xQueueSendFromISR(usbTxRelease, &pArg, &xUsbTxCompleteToken);
		portYIELD_FROM_ISR(xUsbTxCompleteToken);
	}
}

//
//void USB_Mid_Transmit(uint8_t *pTxData, uint16_t txLen) {
	//if (!pTxData || txLen) {
		///* Invalid parameters */
		//return;
	//}
	//
	//QueueHandle_t qHandle = HFCP_GetTxQueue();
	//if (!qHandle) {
		///* Invalid tx Queue */
		//return;
	//}
	//
	//if (HIDDTransferDriver_Write(txBuffer, USB_PACKET_SIZE, USB_Mid_ContinueSend, 0) == USBD_STATUS_SUCCESS) {
		///* USB Tx Fail */
		//return;
	//}
//}


uint8_t USB_Mid_Get_State (uint32_t waitPeriod) {
     vTaskDelay(portTICK_PERIOD_MS * waitPeriod);
    return (USBD_GetState());
}

/*
uint8_t USB_Mid_IsConnected (uint32_t waitPeriod) {
     vTaskDelay(portTICK_PERIOD_MS * waitPeriod);
    return (USBD_GetState() == USBD_STATE_CONFIGURED);
}
*/

uint8_t USB_Mid_IsConnected (uint32_t waitPeriod) 
{
	uint32_t localPeriod = waitPeriod;
	while(localPeriod)
	{
		localPeriod -=100;
		vTaskDelay(100);		
		if(USBD_GetState() == USBD_STATE_CONFIGURED)
		break;
	}
	return (USBD_GetState() == USBD_STATE_CONFIGURED);		
}

void USB_Mid_FlushTxQueues (void) {
    uint8_t*     pRxBuffer = NULL;
    while (xQueueReceive(usbRxQueue, &pRxBuffer, 0) == pdTRUE)
    {
        if (pRxBuffer)
        {
            vPortFree(pRxBuffer);
        }
    }
}

void USB_Mid_pauseTask (void)
{
    if (rxTaskExecLock && txTaskExecLock)
    {
        while(xSemaphoreTake(rxTaskExecLock, portTICK_PERIOD_MS * 1) != pdTRUE);
		while(xSemaphoreTake(txTaskExecLock, portTICK_PERIOD_MS * 1) != pdTRUE);
    }
}

void USB_Mid_startTask (void)
{
	TRACE_INFO_WP("\n\rMaking USB Task\n\r");
    if (rxTaskExecLock && txTaskExecLock)
    {
		TRACE_INFO_WP("\n\rStart USB Task\n\r");
        xSemaphoreGive(rxTaskExecLock);
		xSemaphoreGive(txTaskExecLock);
    }
}

void USB_Mid_Reset (void)
{
    Garuda_Main_ResetQueue(usbRxQueue, USB_PACKET_SIZE, RELEASE);
    Garuda_Main_ResetQueue(usbTxQueue, USB_PACKET_SIZE, RELEASE);
    //xQueueReset(usbFreeBufferQueue);    
}

void USB_Mid_AsyncTx (void *pArg, uint8_t status, uint32_t transfered, uint32_t remaining) {
	uint8_t *txBuffer = NULL;
	BaseType_t xUsbTxCompleteToken = pdFALSE;
	if (xQueueReceiveFromISR(usbTxQueue, &txBuffer, &xUsbTxCompleteToken) == pdTRUE && txBuffer)
	{
		/* send the txBuffer */
		if (HIDDTransferDriver_Write(txBuffer, USB_PACKET_SIZE, USB_Mid_AsyncTx, txBuffer) != USBD_STATUS_SUCCESS) {
			xQueueSendFromISR(usbTxQueue, &txBuffer, &xUsbTxCompleteToken);
			HIDDTransferDriver_Write(NULL, 0, USB_Mid_AsyncTx, NULL);
		}
	}
	if (pArg && !remaining) {
		USBtxComplete++;
		xQueueSendFromISR(usbTxRelease, &pArg, &xUsbTxCompleteToken);
	}
	portYIELD_FROM_ISR(xUsbTxCompleteToken);
}
