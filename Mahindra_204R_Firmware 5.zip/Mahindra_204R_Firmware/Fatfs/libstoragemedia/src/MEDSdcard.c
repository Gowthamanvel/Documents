/* ----------------------------------------------------------------------------
 *         SAM Software Package License 
 * ----------------------------------------------------------------------------
 * Copyright (c) 2012, Atmel Corporation
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */
/**
 * \file
 *
 * Implementation of media layer for the SdCard.
 *
 */

/*------------------------------------------------------------------------------
 *         Headers
 *------------------------------------------------------------------------------*/
#include "board.h"
#include "Media.h"
#include "MEDSdcard.h"
#include "libsdmmc.h"
#include "time_stamps.h"
#include "Proj_Config.h"
#include <assert.h>
#include <string.h>
/*------------------------------------------------------------------------------
 *         Constants
 *------------------------------------------------------------------------------*/
#include "FreeRTOS.h"
extern volatile TickType_t xTickCount;
/** Number of SD Slots */
#define NUM_SD_SLOTS            1
/** Default block size for SD/MMC card access */
#define SD_BLOCK_SIZE       512
/**
 * \brief  Reads a specified amount of data from a SDCARD memory
 * \param  media    Pointer to a Media instance
 * \param  address  Address of the data to read
 * \param  data     Pointer to the buffer in which to store the retrieved
 *                   data
 * \param  length   Length of the buffer
 * \param  callback Optional pointer to a callback function to invoke when
 *                   the operation is finished
 * \param  argument Optional pointer to an argument for the callback
 * \return Operation result code
 */
uint32_t readstatus1 = 0;
uint32_t readstatus2 = 0;
static uint8_t MEDSdcard_Read(sMedia *media,
									uint32_t  address,
									void          *data,
									uint32_t  length,
									MediaCallback callback,
									void          *argument)
{
	uint8_t error;

	// Check that the media is ready
	if (media->state != MED_STATE_READY) {

		TRACE_INFO("Media busy\n\r");
		return MED_STATUS_BUSY;
	}

	// Check that the data to read is not too big
	if ((length + address) > media->size) {

		TRACE_WARNING("MEDSdcard_Read: Data too big: %d, %d\n\r",
					  (int)length, (int)address);
		return MED_STATUS_ERROR;
	}

	// Enter Busy state
	media->state = MED_STATE_BUSY;

	readstatus1++;
	error = SD_Read((sSdCard*)media->interface, address, data,length,NULL,NULL);
    readstatus2++;
	// Leave the Busy state
	media->state = MED_STATE_READY;

	// Invoke callback
	if (callback != 0) {

		callback(argument, error, 0, 0);
	}

	return error;
}

/**
 * \brief  Writes data on a SDRAM media
 * \param  media    Pointer to a Media instance
 * \param  address  Address at which to write
 * \param  data     Pointer to the data to write
 * \param  length   Size of the data buffer
 * \param  callback Optional pointer to a callback function to invoke when
 *                   the write operation terminates
 * \param  argument Optional argument for the callback function
 * \return Operation result code
 * \see    Media
 * \see    MediaCallback
 */

#if DATALOG_DEBUG
uint32_t timeindex1  = 0;
uint32_t endtime1 = 0;
uint32_t starttime1 = 0;
uint16_t timebuffer[200];
uint8_t writeStatus =0;
#endif
static uint8_t MEDSdcard_Write(sMedia         *media,
									uint32_t  address,
									void          *data,
									uint32_t  length,
									MediaCallback callback,
									void          *argument)
{
	uint8_t error;

	// Check that the media if ready
	if (media->state != MED_STATE_READY) {

		TRACE_WARNING("MEDSdcard_Write: Media is busy\n\r");
		return MED_STATUS_BUSY;
	}

	// Check that the data to write is not too big
	if ((length + address) > media->size) {

		TRACE_WARNING("MEDSdcard_Write: Data too big\n\r");
		return MED_STATUS_ERROR;
	}

	// Put the media in Busy state
	media->state = MED_STATE_BUSY;

	#if DATALOG_DEBUG
	//get_time_stamp(&starttime1);
	starttime1 = xTickCount;
	writeStatus = 1;
	#endif
	error = SD_Write((sSdCard*)media->interface, address,data,length,NULL,NULL);
	
	#if DATALOG_DEBUG
    writeStatus = 0;
	
	//get_time_stamp(&endtime1);
	endtime1 = xTickCount;
		
	if( (endtime1 - starttime1) > 200)
	{
		timebuffer[timeindex1++] = endtime1 - starttime1;
	}
	if(timeindex1 == 200)
	timeindex1 =0;
	#endif	

	// Leave the Busy state
	media->state = MED_STATE_READY;

	// Invoke the callback if it exists
	if (callback != 0) {

		callback(argument, error, 0, 0);
	}

	return error;
}

/**
 * \brief  Reads a specified amount of data from a SDCARD memory
 * \param  media    Pointer to a Media instance
 * \param  address  Address of the data to read
 * \param  data     Pointer to the buffer in which to store the retrieved
 *                   data
 * \param  length   Length of the buffer
 * \param  callback Optional pointer to a callback function to invoke when
 *                   the operation is finished
 * \param  argument Optional pointer to an argument for the callback
 * \return Operation result code
 */
static uint8_t MEDSdusb_Read(sMedia         *media,
							 uint32_t       address,
							 void          *data,
							 uint32_t       length,
							 MediaCallback  callback,
							 void          *argument)
{
	uint8_t error;
	// Check that the media is ready
	if (media->state != MED_STATE_READY) {
		//printf("MEDSdusb_Read: Busy\n\r");
		return MED_STATUS_BUSY;
	}
	// Check that the data to read is not too big
	if ((length + address) > media->size) {
		//printf("MEDSdusb_Read: Data too big: %d, %d\n\r", 
			//(int)length, (int)address);
		return MED_STATUS_ERROR;
	}
	// Enter Busy state
	media->state = MED_STATE_BUSY;
  #if 1
	error = SD_Read((sSdCard*)media->interface,
					 address,data,length,
					 (fSdmmcCallback)callback,NULL);
	error = (error ? MED_STATUS_ERROR : MED_STATUS_SUCCESS);
	media->state = MED_STATE_READY;
	if (callback) callback(argument, error, 0, 0);
	return error;
  #else
	MEDTransfer * pXfr;
	// Start media transfer
	pXfr = &media->transfer;
	pXfr->data     = data;
	pXfr->address  = address;
	pXfr->length   = length;
	pXfr->callback = callback;
	pXfr->argument = argument;

	error = SD_Read((sSdCard*)media->interface,
					 address,
					 data,
					 length,
					 (fSdmmcCallback)SdMmcCallback,
					 media);
	return (error ? MED_STATUS_ERROR : MED_STATUS_SUCCESS);
  #endif
}

/**
 * \brief  Writes data on a SDRAM media
 * \param  media    Pointer to a Media instance
 * \param  address  Address at which to write
 * \param  data     Pointer to the data to write
 * \param  length   Size of the data buffer
 * \param  callback Optional pointer to a callback function to invoke when
 *                   the write operation terminates
 * \param  argument Optional argument for the callback function
 * \return Operation result code
 * \see    Media
 * \see    MediaCallback
 */
static uint8_t MEDSdusb_Write(sMedia         *media,
							  uint32_t       address,
							  void          *data,
							  uint32_t       length,
							  MediaCallback  callback,
							  void          *argument)
{
	uint8_t error;
	if (media->state != MED_STATE_READY) {
		TRACE_INFO("MEDSdusb_Write: Busy\n\r");
		return MED_STATUS_BUSY;
	}
	// Check that the data to write is not too big
	if ((length + address) > media->size) {
		TRACE_WARNING("MEDSdcard_Write: Data too big\n\r");
		return MED_STATUS_ERROR;
	}
	// Put the media in Busy state
	media->state = MED_STATE_BUSY;
  #if 1
	error = SD_Write((sSdCard*)media->interface,address,data,length,
				(fSdmmcCallback)callback,NULL);
	error = (error ? MED_STATUS_ERROR : MED_STATUS_SUCCESS);
	media->state = MED_STATE_READY;
	if (callback) callback(argument, error, 0, 0);
	return error;
  #else
	MEDTransfer * pXfr;
	// Start media transfer
	pXfr = &media->transfer;
	pXfr->data = data;
	pXfr->address = address;
	pXfr->length = length;
	pXfr->callback = callback;
	pXfr->argument = argument;

	error = SD_Write((sSdCard*)media->interface,
					  address,
					  data,
					  length,
					  (fSdmmcCallback)SdMmcCallback,
					  media);
	return (error ? MED_STATUS_ERROR : MED_STATUS_SUCCESS);
  #endif
}

/**
 * \brief  Initializes a Media instance 
 * \param  media Pointer to the Media instance to initialize
 * \return 1 if success.
 */
uint8_t MEDSdcard_Initialize(sMedia *media, sSdCard *pSdDrv)
{
	TRACE_INFO("MEDSdcard init\n\r");
	// Initialize media fields
	media->interface = pSdDrv;
	#if !defined(OP_BOOTSTRAP_MCI_on)
	media->write = MEDSdcard_Write;
	#else
	media->write = 0;
	#endif
	media->read = MEDSdcard_Read;
	media->lock = 0;
	media->unlock = 0;
	media->handler = 0;
	media->flush = 0;

	media->blockSize = SD_BLOCK_SIZE;
	media->baseAddress = 0;
	media->size = pSdDrv->dwNbBlocks;

	media->mappedRD  = 0;
	media->mappedWR  = 0;
	media->removable = 1;

	media->state = MED_STATE_READY;

	media->transfer.data = 0;
	media->transfer.address = 0;
	media->transfer.length = 0;
	media->transfer.callback = 0;
	media->transfer.argument = 0;

	return 1;
}

/**
 * \brief  Initializes a Media instance
 * \param  media Pointer to the Media instance to initialize
 * \return 1 if success.
 */
uint8_t MEDSdusb_Initialize(sMedia *media, sSdCard *pSdDrv)
{
	printf("MEDSdusb init\n\r");

	// Initialize media fields
	media->interface = pSdDrv;
	media->write = MEDSdusb_Write;
	media->read = MEDSdusb_Read;
	media->lock = 0;
	media->unlock = 0;
	media->handler = 0;
	media->flush = 0;

	media->blockSize = SD_BLOCK_SIZE;
	media->baseAddress = 0;
	media->size = pSdDrv->dwNbBlocks;

	media->mappedRD  = 0;
	media->mappedWR  = 0;
	media->protected = 0;
	media->removable = 1;

	media->state = MED_STATE_READY;

	media->transfer.data = 0;
	media->transfer.address = 0;
	media->transfer.length = 0;
	media->transfer.callback = 0;
	media->transfer.argument = 0;

	return 1;
}

/**
 * \brief  erase all the SDCARD
 * \param  media Pointer to the Media instance to initialize
 */

void MEDSdcard_EraseAll(sMedia *media)
{
	uint8_t buffer[SD_BLOCK_SIZE];
	uint32_t block;
	uint32_t multiBlock = 1; // change buffer size for multiblocks
	uint8_t error;

	printf("MEDSdcard Erase All ...\n\r");

	// Clear the block buffer
	memset(buffer, 0, media->blockSize * multiBlock);

	for (block=0;
		 block < (media->size-multiBlock);
		 block += multiBlock) {
		error = SD_WriteBlocks((sSdCard*)media->interface, block,buffer,multiBlock);
		if( error ) {
		  printf("\n\r-F- Failed to erase block (%u) #%u\n\r", 
				(unsigned int)error,  (unsigned int)block);
		  /* Wait for watchdog reset or freeze the program */
		  while (1);
		}
	}
}

/**
 * \brief  erase block
 * \param  media Pointer to the Media instance to initialize
 * \param  block to erase
 */
void MEDSdcard_EraseBlock(sMedia *media, uint32_t block)
{
	uint8_t buffer[SD_BLOCK_SIZE];
	uint8_t error;

	// Clear the block buffer
	memset(buffer, 0, media->blockSize);
	error = SD_WriteBlocks((sSdCard*)media->interface, block,buffer,1);
	if( error ) {
		TRACE_ERROR("\n\r-F- Failed to write block (%u) #%u\n\r",
			(unsigned int)error, (unsigned int)block);
		/* Wait for watchdog reset or freeze the program */
		while (1);
	}
}

