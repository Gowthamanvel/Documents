/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.2>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This is the main application start file
*******************************************************************************/
/*
 * GccApplication1.c
 *
 * Created: 3/16/2015 5:22:20 PM
 *  Author: amit
 */ 
/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "board.h"
#include "FreeRTOS.h"
#include "Proj_Config.h"
#include "task.h"

#include "HFCP.h"
#include "GPIO_Mid.h"
#include "SPI_Mid.h"
#include "CAN_Mid.h"
#include "UART_Mid.h"
#include "App_Logic.h"
#include "Wifi_SN8200.h"
#include "Garuda_Main.h"
#include "Data_Logger.h"
#include "Mass_Storage.h"
#include "ADC_Mid.h"
#include "trace.h"
#include "Led_Handler.h"
#include "bootloader_support.h"
#include "USB_MSD_Mid.h"
 
#include "libsdmmc.h"
#include "fatfs_config.h"
#include "Media.h"
#include "MEDSdcard.h"
#include "libstoragemedia.h"
#include "libsdmmc.h"

#include "MSDDriver.h"
#include "MSDLun.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define BOOTLOADER_DEFINED  1
#if HFCP_DEBUG
uint16_t taskTracker[255][2];
uint8_t taskTrackerIndex;
#endif
#define ID_DRV DRV_MMC

#if _FS_TINY == 0
#define STR_ROOT_DIRECTORY "0:"
#else
#define STR_ROOT_DIRECTORY ""
#endif

#define ASSERT(condition, ...)  { \
	if (!(condition)) { \
		printf("-F- ASSERT: "); \
		printf(__VA_ARGS__); \
	} \
}

/** \def READ_MULTI
 *  \brief Define to test multi-read (SD_Read())
 *         or
 *         single-read is used (SD_ReadBlocks()) */
#define READ_MULTI
/** \def WRITE_MULTI
 *  \brief Define to test multi-write (SD_Write())
 *         or
 *         single-write is used (SD_WriteBlocks()) */
#define WRITE_MULTI

/** \macro SDT_ReadFun
 * Function used for SD card test reading.
 * \param pSd  Pointer to a SD card driver instance.
 * \param address  Address of the block to read.
 * \param nbBlocks Number of blocks to be read.
 * \param pData    Data buffer whose size is at least the block size.
 */
#ifdef  READ_MULTI
#define MMCT_ReadFun(pSd, blk, nbBlk, pData) \
	SD_Read(pSd, blk, pData, nbBlk, NULL, NULL)
#else
#define MMCT_ReadFun(pSd, blk, nbBlk, pData) \
	SD_ReadBlocks(pSd, blk, pData, nbBlk)
#endif

/** \macro SDT_WriteFun
 * Function used for SD card test writing.
 * \param pSd  Pointer to a SD card driver instance.
 * \param address  Address of the block to read.
 * \param nbBlocks Number of blocks to be read.
 * \param pData    Data buffer whose size is at least the block size.
 */
#ifdef  WRITE_MULTI
#define MMCT_WriteFun(pSd, blk, nbBlk, pData) \
	SD_Write(pSd, blk, pData, nbBlk, NULL, NULL)
#else
#define MMCT_WriteFun(pSd, blk, nbBlk, pData) \
	SD_WriteBlocks(pSd, blk, pData, nbBlk)
#endif

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
extern  sSdCard sdDrv[BOARD_NUM_MCI];

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/
/******************************************************************************
* Function name  	: main
* returns			: None
* parameters        : None
* Description		: Entry to the Application
* Notes	:
*******************************************************************************/
int main(void)
{  
	SystemInit();
    SystemCoreClockUpdate();

	/* Disable watchdog */
	WDT_Disable( WDT ) ;
  
	SCB_EnableICache();
	SCB_EnableDCache();

    /* Update internal flash Region to Full Access*/
    MPU_UpdateRegions(MPU_DEFAULT_IFLASH_REGION, IFLASH_START_ADDRESS, \
    MPU_AP_FULL_ACCESS |
    INNER_NORMAL_WB_NWA_TYPE( NON_SHAREABLE ) |
    MPU_CalMPURegionSize(IFLASH_END_ADDRESS - IFLASH_START_ADDRESS) |
    MPU_REGION_ENABLE);

    /* Set 6 WS for internal Flash writing (refer to errata) */
    EFC_SetWaitState(EFC, 6);
        
    FLASHD_Initialize(BOARD_MCK, 1);

    #if BOOTLOADER_DEFINED
    if (verify_application_integrity() != TRUE)
    {
        write_application_integrity();
    }
    #endif
    
	_SetupMemoryRegion();
	    
    /* Configure LEDs for Testing */
    Initialise_Leds();
	 	
    Initialise_Board_Detect_Pins();
    afe_adc_initialization();
        
    GarudaAppFreeRTOS_Init();
        
    /* Start the scheduler. */
    vTaskStartScheduler();
    for( ;; );
    
}

/*-----------------------------------------------------------*/
void vApplicationTickHook( void )
{
  
}

/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
  /* vApplicationMallocFailedHook() will only be called if
  configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h.  It is a hook
  function that will get called if a call to pvPortMalloc() fails.
  pvPortMalloc() is called internally by the kernel whenever a task, queue,
  timer or semaphore is created.  It is also called by various parts of the
  demo application.  If heap_1.c or heap_2.c are used, then the size of the
  heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
  FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
  to query the size of free heap space that remains (although it does not
  provide information on how the remaining heap might be fragmented). */
  taskDISABLE_INTERRUPTS();
  for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
  /* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
  to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
  task.  It is essential that code added to this hook function never attempts
  to block in any way (for example, call xQueueReceive() with a block time
  specified, or call vTaskDelay()).  If the application makes use of the
  vTaskDelete() API function (as this demo application does) then it is also
  important that vApplicationIdleHook() is permitted to return to its calling
  function, because it is the responsibility of the idle task to clean up
  memory allocated by the kernel to any task that has since been deleted. */
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
  ( void ) pcTaskName;
  ( void ) pxTask;
  
  /* Run time stack overflow checking is performed if
  configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
  function is called if a stack overflow is detected. */
  printf("ERROR : TASK OVER FLOW\r\n");
  taskDISABLE_INTERRUPTS();
  for( ;; );
}

/*-----------------------------------------------------------*/