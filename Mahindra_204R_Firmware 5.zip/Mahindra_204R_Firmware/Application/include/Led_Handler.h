/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
* Led_Handler.h
*
* Created: 8/3/2015 2:50:36 PM
*  Author: amit 
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements LED MAnagement interface
*******************************************************************************/
#ifndef LED_HANDLER_H_
#define LED_HANDLER_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
/* LEDs Used */
typedef enum
{
    DEVICE_LINK_STATUS,
    WIFI_STATUS,
    USB_STATUS,
    SD_CARD_STATUS,
    GSM_STATUS
} LEDs_t;

/* Blinking at 0.5 Hz. i.e. 2000 */
#define LINK_STATUS_COUNT  (20)
#define SDCARD_FULL_STATUS_COUNT (10)
#define STATUS_ON  1
#define STATUS_OFF 0


#define PIN_LINK_STATUS         { PIO_PD7, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT  } /* ORIGINAL { PIO_PD4, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT }  */
#define PIN_USB_STATUS          { PIO_PD5, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT  } /* ORIGINAL { PIO_PD6, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT }  */
#define PIN_GSM_STATUS          { PIO_PD4, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT  } /* ORIGINAL { PIO_PD7, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT }  */
#define PIN_SD_CARD_STATUS      { PIO_PD6, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT  } /* ORIGINAL { PIO_PD5, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT }  */
#define PIN_WIFI_STATUS         { PIO_PD1, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT  }
    
    
/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void Led_Task(void *PvParam);
void Initialise_Leds ( void );
void Link_Status_Led_ON( void );
void Link_Status_Led_OFF( void );

void USB_Led_ON( void );
void USB_Led_OFF( void );

void WiFi_Led_OFF( void );
void WiFi_Led_ON( void );

void USB_MSD_Led_ON( void );
void USB_MSD_Led_OFF( void );

void WiFi_ON_USB_OFF_Status( void );
void WiFi_OFF_USB_OFF_Status( void );
void WiFi_ON_USB_ON_Status( void );
void LEDFreeRTOS_Init(void);

void LED_Configure( LEDs_t dwLed );
void LED_Clear( LEDs_t dwLed );
void LED_Set( LEDs_t dwLed );

void FILE_GB_FULL_Led_ON( void );
void FILE_GB_FULL_Led_OFF( void );

#endif /* LED_HANDLER_H_ */

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      8/3/2015 2:50:13 PM
* Initial version.
*
******************************************************************************/