/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements xyz
*******************************************************************************/
#ifndef APP_ISO9141_14230_H
   #define APP_ISO9141_14230_H

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "iso14230.h"
//#include "Garuda_appl.h"

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
#define KWP_ENABLED true

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
/* Function to determine pullup */
uint8_t CheckIf_VBATTis24V(void);

/* Call Back Functions */
void App_InitData(ISO9141_14230_LinkInitRet_S *);
void App_ErrHandler(uint8_t, uint8_t);
void App_FirstByteRxd(uint8_t,uint32_t);
void KWPFreeRTOS_Init(void);

#endif

/******************************************************************************
 * R E V I S I O N   H I S T O R Y
 * $History: $
 * Version  Author  Date
 * 1.0  Karthik Subramanian    June 06, 2008
 * 1.1  Mahadeva               April 21, 2014
********************************************************************************
 * 1.0  Initial Version
********************************************************************************
********************************************************************************
 * 1.1  Get_KLPullUp renameds as CheckIf_VBATTis24V
*******************************************************************************/
