/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
* Data_Logger.h
*
* Created: 8/26/2015 4:11:43 PM
*  Author: amit
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements Data Logger MAnagement interface
*******************************************************************************/
#ifndef DATA_LOGGER_H_
#define DATA_LOGGER_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "ff.h"
#define DATA_LOG_Q_SIZE 2500
#define SD_WRITE_Q_SIZE 10
#define DATA_LOG_EVENT_BIT 0x1
#define MSD_MODE_EVENT_BIT (1 << 1)
#define START_LOGGING_EVENT_BIT (1 << 2)

#define SD_CARD_WRITE_SIZE		16384 //8192*2

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void DataLogFreeRTOS_Init(void);

void SDCard_Tx_Task(void *PvParam);
void DataLog_Init (void);
bool Is_DataLog_Active (void);
void Set_DatLog_Event (void);
void Clear_DatLog_Event (void);
void Flush_Datalog (void);
void WriteToLog (Dynamic_QStruct_t);
void DataLog_Task(void *PvParam);
void WriteToLogwithMemAlloc(uint8_t *pHfcpAck);
void Send_To_SD_Write_Queue(uint8_t *WriteBuf, uint16_t reqLen, uint32_t sector );

void Set_MSD_Event (void);
void Clear_MSD_Event (void);

void Stop_Logging_Event (void);
void Start_Logging_Event (void);
bool Is_Start_Logging_Active(void);
void Datalog_Reset_Queue(void);

void OpenDataLoggingFile( FIL* DataLogFile );

#endif /* DATA_LOGGER_H_ */ 

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      8/3/2015 2:50:13 PM
* Initial version.
*
******************************************************************************/