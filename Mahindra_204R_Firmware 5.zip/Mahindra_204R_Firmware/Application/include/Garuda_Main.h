/*
 * Garuda_Main.h
 *
 *  Created on: May 27, 2015
 *      Author: ramesh
 */

#ifndef GARUDA_MAIN_H_
#define GARUDA_MAIN_H_
/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include <stdint.h>
#include "queue.h"
/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

#define GARUDA_MAIN_TASK_NAME                       "Garuda Main Task"

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
typedef enum {
	GARUDA_IN_IDLE_STATE							= 0,
	GARUDA_IN_INIT_STATE							= 1,
	GARUDA_IN_MODE_DETECT_STATE						= 2,
	GARUDA_IN_APP_INIT_STATE						= 3,
	GARUDA_IN_RUNNING_STATE							= 4,
	GARUDA_IN_STOP_STATE							= 5,
	GARUDA_IN_MSD_STATE								= 6,
	GARUDA_DATA_LOGGING_STATE						= 7	
} Garuda_Main_State;

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void GarudaFreeRTOS_Init (void);
void GarudaAppFreeRTOS_Init (void);
void Garuda_Main_ResetQueue (QueueHandle_t qHandle, uint16_t elementSize, uint8_t release);


#endif /* GARUDA_MAIN_H_ */
