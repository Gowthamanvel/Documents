/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements time stamp interface
*******************************************************************************/
#ifndef TIME_STAMPS_H
#define TIME_STAMPS_H

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "stdint.h"

#define    TC_PROG_CLK_PRESCALER       150
#define    TC_PROG_CLK_SELECT          PMC_PCK_CSS_MCK 

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/
/* Defined to indicate the status of the time stamp id */
typedef enum    {
/* Holds the status to indicate valid time stamp id */
TIME_STAMP_VALID,
/* Holds the run status to indicate invalid time stamp id */
TIME_STAMP_INVALID = 0xFF
} TIME_STAMP_ID_STATUS;

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/* Gets time stamp value of particular time stamp */
uint32_t get_time_stamp(uint32_t *p_time_stamp_val);
/* stops time stamp incrementing */
//uint8_t stop_time_stamp( void );
uint8_t stop_time_stamp( uint8_t p_time_stamp_id );
/* Starts the timer for particular time stamp */
uint8_t start_time_stamp(void );
uint8_t stop_timestamp_timer( void );
void Disable_Timer_Interrupt(void);
void Start_DataLogging_Timestamp(void);
void Stop_DataLogging_Timestamp(void);
uint8_t get_extended_data_logging_timestamp(uint64_t *p_time_stamp_val);
uint64_t get_extended_32Bit_data_logging_timestamp(uint64_t *p_time_stamp_val);


#endif
/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      13-May-2008
* Initial version.
*
******************************************************************************/