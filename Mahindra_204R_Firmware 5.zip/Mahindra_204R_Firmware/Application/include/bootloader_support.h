/*
 * bootloader_support.h
 *
 * Created: 7/1/2015 3:47:56 PM
 *  Author: ramesh
 */ 


#ifndef BOOTLOADER_SUPPORT_H_
#define BOOTLOADER_SUPPORT_H_


extern uint8_t verify_application_integrity (void);
extern uint8_t write_application_integrity (void);
extern void jumpToBootloader (void);
extern void clear_application_integrity (void);
extern void erase_application_integrity (void);


#endif /* BOOTLOADER_SUPPORT_H_ */