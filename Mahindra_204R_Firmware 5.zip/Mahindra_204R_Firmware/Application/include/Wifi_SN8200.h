/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.0>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements CAN middle level application interfaces
*******************************************************************************/
#ifndef __WIFI_SN8200_TASK_H
#define __WIFI_SN8200_TASK_H


/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Proj_Config.h"
#include "FreeRTOS.h"

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
#define SN8200_RX_MAX_PAYLOD_LEN 1500

#define SN8200_HDR  0x80

#define SOM_CHAR 0x02
#define EOM_CHAR 0x04


typedef enum {
  WIFI_ON_REQ = 0,
  WIFI_OFF_REQ,
  WIFI_JOIN_REQ,
  WIFI_DISCONNECT_REQ,
  WIFI_GET_STATUS_REQ,
  WIFI_SCAN_REQ,
  WIFI_GET_STA_RSSI_REQ,
  WIFI_AP_CTRL_REQ,
  
  WIFI_NETWORK_STATUS_IND = 0x10,
  WIFI_SCAN_RESULT_IND,
  WIFI_RSSI_IND,
  
  WIFI_ON_RSP = 0x80,
  WIFI_OFF_RSP,
  WIFI_JOIN_RSP,
  WIFI_DISCONNECT_RSP,
  WIFI_GET_STATUS_RSP,
  WIFI_SCAN_RSP,
  WIFI_GET_STA_RSSI_RSP,
  WIFI_AP_CTRL_RSP,
} WIFI_subcmd_id_e;

enum {
  WIFI_SUCCESS,
  WIFI_FAIL,
  WIFI_NETWORK_UP = 0x10,
  WIFI_NETWORK_DOWN,
};

typedef enum {
  SNIC_INIT_REQ = 0,
  SNIC_CLEANUP_REQ,
  SNIC_SEND_FROM_SOCKET_REQ,
  SNIC_CLOSE_SOCKET_REQ,
  SNIC_SOCKET_PARTIAL_CLOSE_REQ,
  SNIC_GETSOCKOPT_REQ,
  SNIC_SETSOCKOPT_REQ,
  SNIC_SOCKET_GETNAME_REQ,
  SNIC_SEND_ARP_REQ,
  SNIC_GET_DHCP_INFO_REQ,
  SNIC_RESOLVE_NAME_REQ,
  SNIC_IP_CONFIG_REQ,
  
  SNIC_TCP_CREATE_SOCKET_REQ = 0x10,
  SNIC_TCP_CREATE_CONNECTION_REQ,
  SNIC_TCP_CONNECT_TO_SERVER_REQ,
  
  SNIC_UDP_CREATE_SOCKET_REQ,
  SNIC_UDP_START_RECV_REQ,
  SNIC_UDP_SIMPLE_SEND_REQ,
  SNIC_UDP_SEND_FROM_SOCKET_REQ,
  
  SNIC_TCP_CONNECTION_STATUS_IND = 0x20,
  SNIC_TCP_CLIENT_SOCKET_IND,
  SNIC_CONNECTION_RECV_IND,
  SNIC_UDP_RECV_IND,
  SNIC_ARP_REPLY_IND,
  
  SNIC_INIT_RSP = 0x80,
  SNIC_CLEANUP_RSP = 0x81,
  SNIC_SEND_RSP = 0x82,
  SNIC_SETSOCKOPT_RESP = 0x86,
  SNIC_GET_DHCP_INFO_RSP = 0x89,
  SNIC_IP_CONFIG_RSP = 0x8B,
  SNIC_TCP_CREATE_SOCKET_RSP = 0x90,
  SNIC_TCP_CREATE_CONNECTION_RSP,
  SNIC_TCP_CONNECT_TO_SERVER_RSP,
  
  SNIC_UDP_CREATE_SOCKET_RSP = 0x93,
  SNIC_UDP_SEND_FROM_SOCKET_RSP = 0x96,
} SNIC_subcmd_id_e;


typedef enum {
  SNIC_SUCCESS=0,
  SNIC_FAIL,
  SNIC_INIT_FAIL,
  SNIC_CLEANUP_FAIL,
  SNIC_GETADDRINFO_FAIL,
  SNIC_CREATE_SOCKET_FAIL,
  SNIC_BIND_SOCKET_FAIL,
  SNIC_LISTEN_SOCKET_FAIL,
  SNIC_ACCEPT_SOCKET_FAIL,
  SNIC_PARTIAL_CLOSE_FAIL,
  SNIC_CONNECTION_PARTIALLY_CLOSED = 0x0A,
  SNIC_CONNECTION_CLOSED,
  SNIC_CLOSE_SOCKET_FAIL,
  SNIC_PACKET_TOO_LARGE,
  SNIC_SEND_FAIL,
  SNIC_CONNECT_TO_SERVER_FAIL,
  SNIC_NOT_ENOUGH_MEMORY = 0x10,
  SNIC_TIMEOUT,
  SNIC_CONNECTION_UP,
  SNIC_GETSOCKOPT_FAIL,
  SNIC_SETSOCKOPT_FAIL,
  SNIC_INVALID_ARGUMENT,
  SNIC_SEND_ARP_FAIL,
  SNIC_INVALID_SOCKET,
  SNIC_CONNECT_TO_SERVER_PENDING,
  SNIC_SOCKET_NOT_BOUND,
  SNIC_SOCKET_NOT_CONNECTED,
} SNIC_return_code_e;

typedef enum
{
  IDLE,
  RECV_LENL,
  RECV_LENH,
  RECV_CMD,
  RECV_PAYLOAD,
  RECV_CKSUM,
  RECV_EOF  
}SN8200_RxState_t;

typedef enum
{
  CMD_ID_NAK = 0x0,
  CMD_ID_GEN = 0x1,
  CMD_ID_IO = 0x3,
  CMD_ID_WIFI = 0x50,
  CMD_ID_SNIC = 0x70,
  CMD_ID_ACK = 0x7F
}SN8200_Cmd_t;

typedef enum
{
  STA_MODE,
  SOFTAP_MODE,
  NONE_MODE
}WifiMode_t;

typedef enum {
  MODE_WIFI_OFF,
  MODE_NO_NETWORK,
  MODE_STA_JOINED,
  MODE_AP_STARTED,
  MODE_SNIC_INIT_NOT_DONE,
  MODE_SNIC_INIT_DONE,
  /* Non-mode special values */
  MODE_LIST_END,
  MODE_ANY,
} serial_wifi_mode_t;


BaseType_t Initiate_Wifi_Rx(bool);
bool Is_Tx_Complete (TickType_t timeout);
void WiFiFreeRTOS_Init(void);
void Send_To_Socket (uint8_t , uint8_t *, uint16_t );
WifiMode_t Wifi_Init(void);        
void Wifi_Start_Network(WifiMode_t);

void Wifi_pauseTask (void);
void Wifi_startTask (void);
void Wifi_Task_Reset (void);

#endif /* __WIFI_SN8200_TASK_H */
