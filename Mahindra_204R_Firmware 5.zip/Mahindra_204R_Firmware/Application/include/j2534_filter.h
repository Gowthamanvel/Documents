/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # 1.2>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements j2534 filters
*******************************************************************************/
#ifndef __J2534_FILTER_H
#define __J2534_FILTER_H

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "j2534_filter.h"
#include "chip.h"
#include "HFCP.h"

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/* Number of J2534 PASSTHRU Message Filters */
#define J2534_NUM_FILTER      10

/* = (Number of byte that will be verified  by the J2534 filters)/4 */
/* As per the present configuration 12 bytes are verified by the J2534 filters */
#define J2534_MSGLEN          12

/* Determine Minimum */

#define MIN(x,y) (((x)<(y))?(x):(y))

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
/* J2534 filter types */
typedef enum
{
  J2534_PASS_FILTER = 1,
  J2534_BLOCK_FILTER
} J2534_filterType_t;

/* J2534 filter structure */
typedef struct
{
  uint8_t Protocol_ID;                 /* Protocol ID as Per J2534 */
  J2534_filterType_t filterType;    /* J2534 filter type */
  uint8_t MaskLen;                     /* Mask message length */
  uint8_t maskMsg[12];                 /* Mask message */
  uint8_t PatternLen;                  /* Pattern message length */
  uint8_t patternMsg[12];              /* Pattern message */
} J2534_filter_t;

/* Resultant action of J2534 filtering */
typedef enum
{
  J2534_BLOCK,          /* Message is blocked by j2534 filters */
  J2534_PASS,           /* Message is passed through j2534 filters  */
  GARUDA_INVALID_CH	    /* Channel is not Used */
} J2534_rsltFilter_t;

/* Error encountered while J2534 filter configuration */
typedef enum
{
  J2534_NO_ERROR,       /* Desire operation is done successfully */
  J2534_FLT_NOT_FREE,   /* All j2534 filters are in use */
  J2534_INVLD_FLTID,    /* Invalid filter ID (either the filter ID is out of the
                         * permissible range or the filter isn't configured) */
  J2534_INVLD_FLT_TYPE, /* Invalid filtertype */
  J2534_INVLD_PRID      /* The Wrong Protocol ID */
} J2534_stError_t;

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
extern J2534_stError_t J2534_ConfigFilter(const J2534_filter_t* p_pFilter,
                                          uint8_t* p_pFilterID);
extern J2534_stError_t J2534_ClearFilter(uint8_t p_filterID,uint8_t p_J2534PrID);
extern J2534_rsltFilter_t J2534_checkFilter(uint8_t *p_pJ2534Msg,
                                            uint16_t p_MsgLen,
											GARUDA_ChannelNum_t GarudaChannel);
extern J2534_stError_t J2534_ClearAllFilter(uint8_t p_J2534PrID);
extern J2534_stError_t J2534_ExclusiveFilter (void);
extern J2534_stError_t J2534_InclusiveFilter (void);

#endif /* __J2534_FILTER_H */


/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* 1.1 Sanjeeva 06-Aug-08
* 1.Fixed defects #11 and #12 of the Defect_Log.xls
********************************************************************************
* 1.1 Sanjeeva 06-Aug-08
* 1.Fixed defects #11 and #12 of the Defect_Log.xls
*******************************************************************************/
