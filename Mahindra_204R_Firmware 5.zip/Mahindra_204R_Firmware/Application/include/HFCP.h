/******************************************************************************
**					Dearborn Electronics India, Bangalore
*******************************************************************************
** Project Name	: Garuda
** File Name		: new_protocol.h
** Description		: This files implements USB to UART data transmission
** Date			: Nov 25,2007
** Version		: 0.1
** Author			: Sudhir
******************************************************************************/
#ifndef HPCF_H
#define HPCF_H
#include "Proj_Config.h"
#include "CAN_Mid.h"


/* LED handling */
#define LINK_STATUS 1
//#define WIFI        2
//#define TEST        3


#define CAN1_TX_QUEUE                                   0
#define CAN1_RX_QUEUE                                   1
#define CAN2_TX_QUEUE                                   2
#define CAN2_RX_QUEUE                                   3

#define MAX_CAN_FILTERS                                    10

/* Transmit Flags - Masks */
#define	WAIT_P3_MIN_ONLY             	            (0x00000200)
/* KWP protocol ID */
#define KWP_PROTOCOL_ID										(0x04)
#define ISO_9141_PROTO_ID									(0x03)

/* CAN protocol ID */
#define CAN_PROTOCOL_ID										(0x05)   
#define CAN_CH1_PROTO_ID									(0x90)
#define ISO15765_PROTO_ID									(0x06) 
#define ISO15765_PROTO_CH1_PROTO_ID							(0x94)

/* J1708 Protocol ID */
#define J1708_PROTOCOL_ID                                  (0xC5)

/* J1708 Protocol ID */
#define J1939_PROTOCOL_ID									(0xC6)
#define J1939_CH1_PROTOCOL_ID								(0xC7)


/* Non-Protocol (Setup) command ID */
#define SETUP_CMD_ID             0xC3

/* Session Management command Id */
#define SESSION_MANAGEMENT        0xC4
#define Manage_Session            1
#define SESSION_OPEN              1
#define SESSION_CLOSE             0

/* Bootloader Mode Command ID */
#define BOOLOADER_MODE			  0xEE

#define DATA_LOG_MODE             2
#define DATA_LOG_START            1
#define DATA_LOG_STOP             0

/* Invalid Protocol id */
#define UNINITIALIZED_PROTO_ID 0xFF

/* Connect Flags */
#define CAN_29BIT_ID                                       (0x00000100)
#define CAN_ID_BOTH                                        (0x00000800)
#define ISO9141_K_LINE_ONLY                                (0x00001000)
#define ISO9141_NO_CHECKSUM                                (0x00000200)



/* IOCTL_command */
#define IOCTL_COMMAND                                       0x06
#define IOCTL_RESPONSE                                      0x06




/* IOCTL commands */
#define Get_config							        0x01
#define Get_config_ACK						                0x01
#define Set_config							        0x02
#define Set_config_ACK						                0x02
#define Read_VBATT							        0x03
#define Read_VBATT_ACK						                0x03
#define KWP_FiveBaudInitialize                              0x04
#define KWP_FiveBaudInitialize_ACK                          0x04
#define KWP_FastInitialize                                  0x05
#define KWP_FastInitialize_ACK                              0x05
#define clear_all_msg_filters			                    0x0A
#define clear_all_msg_filters_ACK		                    0x0A
#define clear_all_periodic_msgs			                    0x09
#define clear_all_periodic_msgs_ACK		                    0x09
#define clear_tx_buffer                                     0x07
#define clear_tx_buffer_ACK                                 0x07
#define clear_rx_buffer                                     0x08
#define clear_rx_buffer_ACK                                 0x08
#define protect_J1939_addr									0xC4
#define protect_J1939_addr_ACK								0xC4


/*IOCTL config parameters*/
#define Get_data_rate 					                    0x01
#define Get_data_rate_ACK				                    0x01

#define Get_loopback 					                    0x03
#define Get_loopback_ACK				                    0x03

#define Get_P1_MIN						                    0x06
#define Get_P1_MIN_ACK					                    0x06
#define Get_P1_MAX						                    0x07
#define Get_P1_MAX_ACK					                    0x07
#define Get_P2_MIN						                    0x08
#define Get_P2_MIN_ACK					                    0x08
#define Get_P2_MAX						                    0x09
#define Get_P2_MAX_ACK					                    0x09
#define Get_P3_MIN						                    0x0A
#define Get_P3_MIN_ACK					                    0x0A
#define Get_P3_MAX						                    0x0B
#define Get_P3_MAX_ACK					                    0x0B
#define Get_P4_MIN						                    0x0C
#define Get_P4_MIN_ACK					                    0x0C
#define Get_P4_MAX						                    0x0D
#define Get_P4_MAX_ACK					                    0x0D


#define Get_sample_point				                    0x17
#define Get_sample_point_ACK			                    0x17

#define Get_SJW							                    0x18
#define Get_SJW_ACK						                    0x18

#define Set_data_rate 					                    0x01
#define Set_data_rate_ACK				                    0x01

#define Set_loopback 					                    0x03
#define Set_loopback_ACK				                    0x03

#define Set_P1_MIN						                    0x06
#define Set_P1_MIN_ACK					                    0x06

#define Set_P1_MAX						                    0x07
#define Set_P1_MAX_ACK					                    0x07

#define Set_P2_MIN						                    0x08
#define Set_P2_MIN_ACK					                    0x08

#define Set_P2_MAX						                    0x09
#define Set_P2_MAX_ACK					                    0x09

#define Set_P3_MIN						                    0x0A
#define Set_P3_MIN_ACK					                    0x0A

#define Set_P3_MAX						                    0x0B
#define Set_P3_MAX_ACK					                    0x0B

#define Set_P4_MIN						                    0x0C
#define Set_P4_MIN_ACK					                    0x0C

#define Set_P4_MAX						                    0x0D
#define Set_P4_MAX_ACK					                    0x0D

#define Set_sample_point				                    0x17
#define Set_sample_point_ACK			                    0x17

#define Set_SJW							                    0x18
#define Set_SJW_ACK						                    0x18

/* Filter comands */
#define Start_msg_filter                                    0x0B
#define Start_msg_filter_ACK                                0x0B
#define Stop_msg_filter                                     0x0C
#define Stop_msg_filter_ACK                                 0x0C


/* CAN Service ids */
#define CAN_EnableComm       		                        0x02
#define CAN_EnableComm_ACK   		                        0x02

#define CAN_DisableComm       		                        0x03
#define CAN_DisableComm_ACK   		                        0x03

#define CAN_Send_msg      	                                0x08
#define CAN_Send_msg_ACK 			                        0x08

#define CAN_Receive_msg      	   	                        0x0A
#define handle_periodic_msg                                 0x09
#define handle_periodic_msg_ACK                             0x09

#define tx_done_CAN_msg                                     0x0D


/* KWP Service ids */
#define KWP_EnableComm       		                        0x02
#define KWP_EnableComm_ACK   		                        0x02

#define KWP_DisableComm       		                        0x03
#define KWP_DisableComm_ACK   		                        0x03

#define KWP_Send_msg      	                                0x08
#define KWP_Send_msg_ACK 			                        0x08

#define KWP_Receive_msg      	   	                        0x0A

/* J1708 Service ID's */
#define J1708_EnableComm       		                        0x02
#define J1708_EnableComm_ACK   		                        0x02

#define J1708_DisableComm       		                0x03
#define J1708_DisableComm_ACK   		                0x03

#define J1708_Send_msg      	                                0x08
#define J1708_Send_msg_ACK 			                0x08

#define J1708_Receive_msg      	   	                        0x0A

#define J1708_Reset                                             0xC0
#define J1708_Reset_ACK                                         0xC0

#define J1708_Mode                                              0xC1
#define J1708_Mode_ACK                                          0xC1

#define J1708_Pass_All_Filter_ON                                0xC2
#define J1708_Pass_All_Filter_ON_ACK                            0xC2

#define J1708_Filter_Type                                       0xC3
#define J1708_Filter_Type_ACK                                   0xC3

#define J1708_Pass_All_Filter_OFF                               0x0A
#define J1708_Pass_All_Filter_OFF_ACK                           0x0A

#define J1708_Loopback                                          0x15
#define J1708_Loopback_ACK                                      0x15

#define J1708_SetConfig                                         0x02
#define J1708_SetConfig_ACK                                     0x02

#define Set_Message_Receive                                     0x20
#define Set_Message_Receive_ACK                                 0x20


/* J1939 Service ids */
#define J1939_EnableComm       		                        0x02
#define J1939_EnableComm_ACK   		                        0x02

#define J1939_DisableComm       		                    0x03
#define J1939_DisableComm_ACK   		                    0x03

#define J1939_Send_msg      	                            0x08
#define J1939_Send_msg_ACK 			                        0x08

#define J1939_Receive_msg      	   	                        0x0A

#define Get_J1939_T1										0x06
#define Get_J1939_T1_ACK									0x06
#define Get_J1939_T2										0x07
#define Get_J1939_T2_ACK									0x07
#define Get_J1939_T3										0x08
#define Get_J1939_T3_ACK									0x08
#define Get_J1939_T4										0x09
#define Get_J1939_T4_ACK									0x09
#define Get_J1939_BRDCST_MIN_DELAY							0x0A
#define Get_J1939_BRDCST_MIN_DELAY_ACK						0x0A

#define Set_J1939_T1										0x06
#define Set_J1939_T1_ACK									0x06
#define Set_J1939_T2										0x07
#define Set_J1939_T2_ACK									0x07
#define Set_J1939_T3										0x08
#define Set_J1939_T3_ACK									0x08
#define Set_J1939_T4										0x09
#define Set_J1939_T4_ACK									0x09
#define Set_J1939_BRDCST_MIN_DELAY							0x0A
#define Set_J1939_BRDCST_MIN_DELAY_ACK						0x0A


#define GLOBAL_ADDRESS										0xFF
#define CLAIMED_ADDRESS										0x01
#define PDU_FORMAT_ADDRESS_CLAIM							0xEE

#define TP_CON_MANAGEMENT									0xEC
#define TP_DATA_TRANSFER									0xEB
#define REQUEST_MANAGEMENT									0xEA
#define ACK_MANAGEMENT										0xE8


/* Setup Command Service ids */
#define Setup_FW_Version       		0x04
#define Setup_FW_Version_ACK   		0x04
/* Data logging commands */
#define Start_Data_logging          0xF0
#define Stop_Data_logging           0xF1
#define Data_logging_mode_query     0xF2

/* J2534 Error codes */
#define	STATUS_NOERROR				                        0x00
#define	ERR_NOT_SUPPORTED			                        0x01
#define	ERR_INVALID_CHANNEL_ID		                        0x02
#define	ERR_INVALID_PROTOCOL_ID		                        0x03
#define	ERR_NULL_PARAMETER			                        0x04
#define	ERR_INVALID_IOCTL_VALUE		                        0x05
#define	ERR_INVALID_FLAGS			                        0x06
#define	ERR_FAILED					                        0x07
#define	ERR_INVALID_DEVICE_ID		                        0x08
#define	ERR_TIMEOUT					                        0x09
#define	ERR_INVALID_MSG				                        0x0A
#define	ERR_INVALID_TIME_INTERVAL	                        0x0B
#define	ERR_EXCEEDED_LIMIT			                        0x0C
#define	ERR_INVALID_MSG_ID			                        0x0D
#define	ERR_DEVICE_IN_USE			                        0x0E
#define	ERR_INVALID_IOCTL_ID		                        0x0F
#define	ERR_BUFFER_EMPTY			                        0x10
#define	ERR_BUFFER_FULL				                        0x11
#define	ERR_BUFFER_OVERFLOW			                        0x12
#define	ERR_PIN_INVALID				                        0x13
#define	ERR_CHANNEL_IN_USE			                        0x14
#define	ERR_MSG_PROTOCOL_ID			                        0x15
#define	ERR_INVALID_FILTER_ID		                        0x16
#define	ERR_NO_FLOW_CONTROL			                        0x17
#define	ERR_NOT_UNIQUE				                        0x18
#define	ERR_INVALID_BAUDRATE		                        0x19
#define	ERR_DEVICE_NOT_CONNECTED	                        0x1A

#define KLINE_BUSY                                          0x20
/*J1939 Addresss Not Claimed */
#define	ERR_ADDRESS_NOT_CLAIMED								0x21						

/* J2534 Periodic msg commands */
#define	START_NEW_PERIODIC_MSG_TXN	                        0x01
#define	UPDATE_DATA_TO_MSG_ID				                0x02
#define	STOP_PERIODIC_MSG_TXN				                0x03
#define	SUSPEND_ALL_PERIODIC_MSG_TXN		                0x04
#define	CHANGE_MSG_PERIODICITY				                0x05
/* VBATT ADC Channel */
#define	VBATT_CHANNEL    0
#define	ADC_STEP_VAL_uV										805  /*3222*/ /* Vref/Vresolution (3.3/1024)10^6*/
#define	VOLT_DIVISOR     11   /* Compensation factor 1/11th of VBATT @ ADC  */
/* Number of Channels Used in Garuda */
#define NO_OF_CHANNEL_USED									7   // 4 + 2 (for J1939 protocol CH1 and CH2) + 1 (9141) 


#define HFCP_COM_MODE_DEFAULT 0
#define HFCP_COM_MODE_USB  1
#define HFCP_COM_MODE_WIFI 2

#define USB_MODE		0
#define WIFI_MODE		1
#define DEFAULT_MODE	0xFF

#define HID 1
#define MSD 0

/* USB LINK STATUS */
#define USB_LINK_ON 1
#define USB_LINK_OFF 0

/* VBATT STATUS */
#define VBATT_LINK_ON 1
#define VBATT_LINK_OFF 0

#define DONT_RELEASE 0
#define RELEASE		 1
#define DONT_RELEASE_ISR 2

/*  Type Defines UsedFor J2534 Filters & Periodic Message */
/* Garuda Channel Definitions */
/* The channels need to be re-arranged as GarudaProID_Used[] array entry*/
typedef enum
{
  GARUDA_CAN_CH1,
  GARUDA_KWP_CH1,
  GARUDA_CAN_CH2,
  GARUDA_J1708,
  GARUDA_J1939_CH1,
  GARUDA_J1939_CH2
} GARUDA_ChannelNum_t;

typedef enum {
    GARUDA_IN_USB_MODE              = 0,
    GARUDA_IN_WIFI_MODE             = 1,
} GARUDA_CommunicationMode_t;

typedef struct
{
	uint8_t protocol_id;
	uint8_t sourceAddr;
	uint8_t nameIdentifier[8];
	uint16_t periodicity;
	uint16_t localperiodicity;
	uint32_t msgId;
}ADDRESS_CLAIM;

/* The Used Protocols in Garuda */
extern uint8_t GarudaProID_Used[NO_OF_CHANNEL_USED];
/* holds the timestamp id returned by start_time_stamp() */
extern uint8_t timestamp_id[NO_OF_CHANNEL_USED];


/* Function prototypes */
extern void process_IOCTL_command( uint8_t *fl_USB_buffer_out);
extern void process_KWP_command(uint8_t *fl_USB_buffer_out);
extern void process_CAN_command( uint8_t *fl_USB_buffer_out);
//extern void process_J1708_command( USB_buffer_def *fl_USB_buffer_out);
extern void process_setup_command(uint8_t *fl_USB_buffer_out);
extern void process_session_mgmt_command( uint8_t *fl_USB_buffer_out);
extern void KWPNewMsgRxed(uint8_t channel_no);
//extern void CANNewMsgRxed(uint8_t p_channel_no_U8, CAN_RX_BUFF_S *p_rx_can_msg);
uint8_t get_CAN_CH1_status(void);
uint8_t get_CAN_status(void);
uint8_t get_KWP_CH1_status(void);
uint8_t get_KWP_status(void);
uint8_t get_J1708_status(void);
uint32_t Get_Connect_Flags(uint8_t protocol_id);
extern uint8_t get_connected_channels(void);
extern void process_Setup_command( uint8_t *fl_USB_buffer_out);
extern void clear_connected_channels(void);
extern void hfcp_disable_CAN(void);
extern void hfcp_disable_CAN_CH1(void);
extern void fill_update_sd_buffer(void);
extern uint8_t get_CAN_or_ISO(void);
extern uint8_t get_CAN1_or_ISO1(void);
uint8_t Read_BatteryVoltage(uint32_t *BatVg);
void DisconnectAllChanels( void );
void Garuda_Tx_data_on_USB(uint8_t *p_data_U8, uint16_t p_length, uint8_t release);
/* Global variables */

/**< Newly Added Functionalities */
void HFCPTx_Task(void *PvParam);
void HFCPRx_Task(void *PvParam);
void HFCPFreeRTOS_Init (void);

void Send_To_HFCP_Queue(uint8_t *, uint16_t);
void Send_To_HFCP_No_Copy_Queue(uint8_t *hfcpReqBuf, uint16_t reqLen);
void Socket_To_Tx(uint8_t);

void HFCP_pauseTask (void);
void HFCP_startTask (void);
void HFCP_Task_Reset (void);
void HFCP_setApplicationMode (GARUDA_CommunicationMode_t mode);

uint8_t get_ISO9141_or_14230(void);

/* J1939 Protocol */
void process_J1939_command( uint8_t *buffer );
uint8_t get_CAN_or_ISO15756_or_J1939(void);
uint8_t get_CANCH1_or_ISO15756CH1_or_J1939CH1(void);
void AdressClaimHandler(void);
void suspend_J1939_addressClaim(void);
void J1939_AddressClaim_Global_Response(uint8_t *p_pJ2534Msg, uint16_t p_MsgLen, GARUDA_ChannelNum_t GarudaChannel);
#endif

/******************************************************************************
**					R E V I S I O N		H I S T O R Y
*******************************************************************************
** Please update in the following format:
**
** Revision No		Date(dd/mm/yy)				Author
** Description of change
**
*******************************************************************************
** 0.1				25/11/07				Sudhir
** Initial version
*******************************************************************************/
