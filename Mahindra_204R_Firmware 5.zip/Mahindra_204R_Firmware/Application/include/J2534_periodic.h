/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements interface for periodic message handler
*******************************************************************************/
#ifndef HFCP_PERIODIC_H
   #define HFCP_PERIODIC_H

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "stdint.h"
#include "HFCP.h"
//#include "iso14230.h"

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/


/* Enums defined for Error Handling */
typedef enum  {

/* Defines error not supported */
PERIODIC_FAILED,

/* Defines error for invalid protocol id */
PERIODIC_INVALID_PROTOCOL_ID,

/* Defines error for invalid periodicity*/
PERIODIC_INVALID_TIME_INTERVAL,

/* Defines error for exceeded maximum number of periodic message id */
PERIODIC_EXCEEDED_LIMIT,

/* Defines error for invalid message id */
PERIODIC_INVALID_MSG_ID,

/* Defines function call success */
PERIODIC_SUCCESS

} PERIODIC_ERROR_STATUS;

/* Enums defined for the periodic message commands */
typedef enum    {

/* Defined for starting a new periodic message */
PERIODIC_STARTNEW_PMSG = 1,

/* Defined for updating periodic message */
PERIODIC_UPDATE_PMSG,

/* Defined for stopping a particular periodic message */
PERIODIC_STOP_PMSG,

/* Defined for suspending all periodic message */
PERIODIC_SUSPEND_PMSG,

/* Defined for changind periodicity of periodic message */
PERIODIC_CHANGE_PERIOD_PMSG

} PERIODIC_COMMAND;

/* Structure to hold the message transmitted periodically */
typedef struct
{
    uint32_t tx_flags; /* Transmit flags */
    uint8_t length;    /* Length of data field */
    uint8_t data[12];  /* Data field maximum 12 byets as per J2534 */
} proto_msg_TYPE;

/* Structure defined for handling periodic messages */
typedef struct  {

/* Periodic message id given for each periodic message (1-10) */
uint8_t   prmsg_id;

/* Protocol identifier */
uint8_t protocol_id;

/* 12 bytes of data that is to be transmitted periodically */
proto_msg_TYPE proto_msg;

/* Periodicity ranges between 5- 65535 */
uint16_t periodicity;

/* Periodicity used to handle transmission periodically */
uint16_t local_periodicity;

 } PERIODIC_MSG;

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

void PERIODIC_handler (void);
uint8_t PERIODIC_msg_cmd ( PERIODIC_MSG * ,  uint8_t);
uint8_t suspend_pmsg( uint8_t);
void PeriodicMessageFreeRTOS_Init(void);

//TickType_t getNextTimerPeriod( uint8_t channel );
uint8_t updateNextTimerPeriod(uint8_t channel, uint32_t updatePeriod);

#endif

/******************************************************************************
 * R E V I S I O N   H I S T O R Y
 * $History: $
 * Version      Author                          Date
 ******************************************************************************
 * 1.0          Saritha.T                         Mar 04, 2007
 * Initial version.
 *
 ******************************************************************************
 * 1.1          Saritha.T                         May 08, 2008
 * Changed prototype for function PERIODIC_msg_cmd().
 *
 ******************************************************************************/
