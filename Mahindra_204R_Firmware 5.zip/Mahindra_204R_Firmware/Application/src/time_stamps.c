/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.2>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements time stamps
*******************************************************************************/
#ifndef TIME_STAMPS_C
#define TIME_STAMPS_C

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "board.h"
#include "time_stamps.h"
//#include "HFCP.h"
/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
volatile uint32_t extended32BitTimerCount=0;
/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/


/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
* Function name	: uint8_t get_time_stamp( uint8_t p_time_stamp_id,
*                 uint32_t *p_time_stamp_val)
*    returns		: returns TIME_STAMP_VALID if p_time_stamp_id is valid
*                         else it returns TIME_STAMP_INVALID.
*    p_time_stamp_id    : time stamp id of which time stamp value has to be
*                         returned.
*   *p_time_stamp_val   : pointer which stores time stamp value.
* Description		: This function returns status of valid time stamp id
*                         is passed and time stamp value of particular
*                         time stamp is stored in the pointer passed.
* Notes			: roll over for time stamps is not handled.
*******************************************************************************/
uint32_t get_time_stamp(uint32_t *p_time_stamp_val)
{    
    uint32_t upper_first_read, upper_second_read, lower_read;
        
    upper_first_read = TC0->TC_CHANNEL[1].TC_CV;
    lower_read = TC0->TC_CHANNEL[0].TC_CV;
        
    // Read a second time to make sure the counters did not increment during the read instruction
    upper_second_read =TC0->TC_CHANNEL[1].TC_CV;
        
    // If the upper counter incremented, read channel 0 again to make sure the time reading is valid
    if (upper_first_read != upper_second_read) {
        lower_read = TC0->TC_CHANNEL[0].TC_CV;
    }
    *p_time_stamp_val = ( lower_read | (upper_second_read << 16));            
        
    return ( lower_read | (upper_second_read << 16));
}

/******************************************************************************
* Function name	: uint8_t stop_time_stamp( uint8_t p_time_stamp_id)
*    returns		: returns TIME_STAMP_VALID if p_time_stamp_id is valid
*                         else it returns TIME_STAMP_INVALID.
*    p_time_stamp_id    : time stamp id of which function has to stop incrementing
*                         the time stamp value.
* Description		: stops time stamp incrementing.
* Notes			:
*******************************************************************************/
//uint8_t stop_time_stamp( void )
uint8_t stop_time_stamp( uint8_t p_time_stamp_id )
{
    uint8_t fl_tstatus = TIME_STAMP_VALID;
	//AMIT
    // TC_Stop( TC0, 0 ); 
    // TC_Stop( TC0, 1 );
    
    return fl_tstatus;
}

uint8_t stop_timestamp_timer( void )
{
    uint8_t fl_tstatus = TIME_STAMP_VALID;
	
    TC_Stop( TC0, 0 ); 
    TC_Stop( TC0, 1 );    
    return fl_tstatus;
}

/******************************************************************************
* Function name	: uint8_t start_time_stamp_timer0(void )
*    returns		: Returns TIME_STAMP_INVALID, if more than 100
*                         time stamps are started else array index
*                         of the time_stamp_val[]
* Description		: starts the timer for new time stamp
* Notes		: Time stamp is limited to 100.
*******************************************************************************/
uint8_t start_time_stamp(void )
{
    PMC->PMC_PCK[6] = PMC_PCK_PRES(TC_PROG_CLK_PRESCALER - 1) | TC_PROG_CLK_SELECT; 
    PMC->PMC_SCER |= PMC_SCER_PCK6; 
        
    PMC_EnablePeripheral(ID_TC0);
    TC_Configure( TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK1
                    | TC_CMR_ACPA_SET
                    | TC_CMR_ACPC_CLEAR
                    | TC_CMR_WAVE);

    TC0->TC_CHANNEL[ 0 ].TC_RC = 0;
    TC0->TC_CHANNEL[ 0 ].TC_RA = 0xFFFF;		
    TC_Start( TC0, 0 );    
                
    PMC_EnablePeripheral(ID_TC1);
    TC_Configure( TC0, 1, TC_CMR_BURST_XC1 | TC_CMR_WAVE | TC_CMR_TCCLKS_TIMER_CLOCK1 );
    TC0->TC_BMR = TC_BMR_TC1XC1S_TIOA0;
	
    TC_Start( TC0, 1 );            				
			
    /**< This is the Fix for KWP Initialization Issue*/
    /**< busy wait until first lost pulse is generated */
    while((TC0->TC_CHANNEL[0].TC_CV) < 0xFFFF);
        
    return 0;      
}


/*
void start_and_sync_time_stamp(uint32_t curr_time_in_uS)
{
    disable_timer(3);
    init_timer(3, TIMER3_INTERVAL, curr_time_in_uS);
    enable_timer(3);
}
*/


uint8_t get_data_logging_time_stamp(uint32_t *p_time_stamp_val)
{
  uint8_t fl_tstatus;

   get_time_stamp(p_time_stamp_val);
   fl_tstatus = TIME_STAMP_VALID;
   return fl_tstatus;

}

/******************************************************************************
* Function name  	: Start_DataLogging_Timestamp
* returns			: None
* parameters        : None
* Description		: Timer 2 Initialization
* Notes			    : * Timer TC0 Channel 2 is used for Data Logging timer
					  * This 16 timer shall be configured for overflow interrupt 
					  * On interrupt, 32 bit variable is incremented to obtain 
						48 bit timer.			
*******************************************************************************/
void Start_DataLogging_Timestamp(void)
{
	#if 0
	PMC_EnablePeripheral(ID_TC2);
	
	TC_Configure( TC0, 2, TC_CMR_TCCLKS_TIMER_CLOCK1
	| TC_CMR_ACPA_SET
	| TC_CMR_ACPC_CLEAR
	| TC_CMR_WAVE);

	TC0->TC_CHANNEL[ 2 ].TC_RC = 0;
	TC0->TC_CHANNEL[ 2 ].TC_RA = 0xFFFF;
	 
	/* Configure and enable interrupt on RC compare */
	NVIC_ClearPendingIRQ(TC2_IRQn);
	NVIC_SetPriority( TC2_IRQn ,6/*TIMER_ISR_PRIORITY*/);
	NVIC_EnableIRQ(TC2_IRQn);
	TC0->TC_CHANNEL[2].TC_IER = TC_IER_COVFS;
	
	TC_Start( TC0, 2 );
	
	while((TC0->TC_CHANNEL[2].TC_CV) < 0xFFFF);		
	#endif
}

/******************************************************************************
* Function name  	: Start_DataLogging_Timestamp
* returns			: None
* parameters        : None
* Description		: stop the data logging timer.
* Notes			    :
*******************************************************************************/
void Stop_DataLogging_Timestamp(void)
{
	#if 0
	TC0->TC_CHANNEL[2].TC_IDR = TC_IER_COVFS;
	
	NVIC_ClearPendingIRQ(TC2_IRQn);	
	NVIC_DisableIRQ(TC2_IRQn) ;	
	TC_Stop( TC0, 2 );
	extended32BitTimerCount=0;
	#endif
}

#if 0
/* Notes : 1. This timer is not available in SAME70N series,
			  since its only 100 pin Microcontroller.
		   2. DataLogger Timestamp is being used for 
			  STMIN Handling for CAN2			  	  			   
*/
/******************************************************************************
* Function name  	: TC2_Handler
* returns			: None
* parameters        : None
* Description		: Timer 2 ISR for 16 bit timer overflow.
* Notes			    : 
*******************************************************************************/	
void TC2_Handler(void)
{
	volatile uint32_t dummy;
	
	dummy = TC0->TC_CHANNEL[ 2 ].TC_SR;	
	if ( (dummy & TC_SR_COVFS) == TC_SR_COVFS )
	{
		extended32BitTimerCount++;
	}
}
#endif

/******************************************************************************
* Function name  	: get_extended_32Bit_data_logging_timestamp
* returns			: 64 bit timestamp
* parameters        : p_time_stamp_val
* Description		: get the extended 32 bit data logging timestamp					
* Notes				: This Function shall read the 16 bit timer value from the
					  timer register, and then appends the 32 bit counter value
					  obtained from the 16 bit timer overflow interrupts. 
*******************************************************************************/
uint64_t get_extended_32Bit_data_logging_timestamp(uint64_t *p_time_stamp_val)
{		
	#if 0
	uint32_t lower_read;
	
	lower_read = TC0->TC_CHANNEL[0].TC_CV;
	*p_time_stamp_val = (uint64_t)lower_read |  ((uint64_t)extended32BitTimerCount << 16);

	return *p_time_stamp_val;
	#endif
	uint32_t DatalogTime =0;
	*p_time_stamp_val = get_time_stamp(&DatalogTime);
	 return *p_time_stamp_val;
}


#endif
/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      13-May-2008
* Initial version.
*
******************************************************************************/

