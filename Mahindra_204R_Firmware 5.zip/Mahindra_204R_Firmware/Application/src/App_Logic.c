#include "Proj_Config.h"
#include "App_Logic.h"
#include "Wifi_SN8200.h"
#include "SPI_Mid.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"
#include "CAN_Mid.h"






