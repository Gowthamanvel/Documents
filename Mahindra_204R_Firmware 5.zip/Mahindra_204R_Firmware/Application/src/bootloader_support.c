/*
 * bootloader_support.c
 *
 * Created: 6/30/2015 7:12:58 PM
 *  Author: ramesh
 */


#include "chip.h"
#include "flashd.h"
#include "rstc.h"
#include "FreeRTOS.h"
#include "task.h"
#include "bootloader_support.h"

#define APP_INTEGRITY_VERIFY_ADDR_OFFSET	(0x0007FFFCu)  
#define APP_INTEGRITY_VERIFY_VAL			(0x55555555u)
#define APP_INTEGRITY_CLEAR_VAL				(0xFFFFFFFFu)
#define APP_FLASH_ERASE_VAL                 (0xFFFFFFFFu)
#define APP_INTEGRITY_ERASE_PAGE_OFFSET     (0x0047FE00u) // 0x00419000 IFLASH_ADDR + IFLASH_SIZE/2 - (16 * IFLASH_PAGE_SIZE)

uint8_t verify_application_integrity (void)
{
	volatile uint32_t *pAddr = (uint32_t*)(IFLASH_ADDR + APP_INTEGRITY_VERIFY_ADDR_OFFSET);
	return ((*pAddr) == APP_INTEGRITY_VERIFY_VAL);
}

uint8_t write_application_integrity (void)
{
	volatile uint32_t pAddr = (IFLASH_ADDR + APP_INTEGRITY_VERIFY_ADDR_OFFSET);
	volatile uint32_t key = APP_INTEGRITY_VERIFY_VAL;
    erase_application_integrity();

	FLASHD_Write(pAddr, &key, sizeof(key));
	return 0;
}

void clear_application_integrity (void)
{
	//volatile uint32_t pAddr = (IFLASH_ADDR + APP_INTEGRITY_VERIFY_ADDR_OFFSET);
	//volatile uint32_t key = APP_INTEGRITY_CLEAR_VAL;
    erase_application_integrity();
}

extern uint32_t dwLastPageAddress;


void erase_application_integrity (void)
{
    uint8_t  ucError;
    ucError = FLASHD_ErasePages(APP_INTEGRITY_ERASE_PAGE_OFFSET, 16);
    
    if(ucError)
    {
        //while(1);
    }
}


uint32_t _flashAddr;
uint32_t	_zero = 0;
void jumpToBootloader (void)
{
   // vTaskEndScheduler();
    MPU_DisableRegion();
    clear_application_integrity();
    RSTC_ProcessorReset();
    vTaskDelay(portTICK_PERIOD_MS * 5000);
	portDISABLE_INTERRUPTS();
	SCB_CleanDCache();
	SCB_DisableDCache();
	//SCB_CleanICache();
	SCB_DisableICache();
	_zero = 0;
	
	//__asm volatile ("str r5, [%0] \n" : "=r"(_zero));
    __asm volatile ("movs r5, #0 \n");
	__asm volatile ("msr control, r5 \n");
		
	SCB->VTOR = IFLASH_ADDR;
	_flashAddr = (void (*)(void))(IFLASH_ADDR+4);
	
	__set_MSP(*(uint32_t*)IFLASH_ADDR);
	__asm volatile ("dsb \n");
	
	__asm volatile ("ldr pc, [%0] \n" : "=r"(_flashAddr));
}