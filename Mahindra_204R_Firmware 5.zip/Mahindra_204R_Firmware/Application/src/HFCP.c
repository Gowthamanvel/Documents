/******************************************************************************
**					Dearborn Electronics India, Bangalore
*******************************************************************************
** Project Name	: Garuda
** File Name		: new_protocol.c
** Description		: This files implements HFCP command implementation
** Date			: Feb 12,2009
** Version		: 0.4
** Author			: Sanjeeva
******************************************************************************/

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "chip.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "HFCP.h"
#include "Wifi_SN8200.h"
#include "CAN_Mid.h"
#include "Data_Logger.h"
#include "App_Logic.h"
#include "j2534_filter.h"
#include "J2534_periodic.h"
#include "app_iso14230.h"
#include "iso14230.h"
#include "CAN_Mid.h"
#include "USB_Mid.h"
#include "USBD_HAL.h"
#include "ADC_Mid.h"
#include "SPI_Mid.h"
#include "sdmmc_cmd.h"
#include "HSMCI_Mid.h"
#include "time_stamps.h"
#include "bootloader_support.h"
#include "Led_Handler.h"
/******************************************************************************
*                               D E F I N A T I O N S 
*******************************************************************************/
#define HFCP_TX_Queue_SIZE              1000
#define HFCP_RX_Queue_SIZE              250 /*Initially 50: Changed to 100/250, to 
											 allow 4096 bytes of data to be 
											 transmitted on to the CAN network*/		

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*                            T Y P E   D E F S
*******************************************************************************/
#define GARUDA_USB_DEBUG	1
/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
extern uint8_t HFCPComMode;
extern uint8_t USB_Device_Mode;
extern void SD_DeInit(sSdCard *pSd);
extern Garuda_Debug_Info Garuda_Debug;
extern Garuda_Debug_Info Garuda_Debug_CAN2;
int COnnected;
/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/* The Constant data array of Protocols IDs which need are enabled
by Garuda - Re-arange GARUDA_ChannelNum_t(.h file) in same order*/

/*J1939 : Added 2 Channels for J1939*/ /*9141 and ISO-14230 on separate channels */
uint8_t GarudaProID_Used[NO_OF_CHANNEL_USED]={0x05,0x04,0x90,0xC5,0xC6,0xC7,0x03}; 
uint8_t timestamp_id[NO_OF_CHANNEL_USED] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

uint8_t AdressClaimInitiated = 0;
uint8_t AdressClaimStatus	=0;
uint8_t device_claimed_Address=0xFE;

uint8_t l_connected_channels            = 0;

uint8_t l_connected_channel_1            = 0;
uint8_t l_connected_channel_2            = 0;
uint8_t l_connected_channel_Kline		 = 0;
uint8_t l_connected_channel_J1939_1		 = 0;
uint8_t l_connected_channel_J1939_2		 = 0;

static uint8_t CAN_active               = 0;
static uint8_t CAN_CH1_active           = 0;
static uint8_t KWP_active               = 0;
static uint8_t J1708_active             = 0;
static uint8_t CAN_or_ISO               = 0;
static uint8_t CAN1_or_ISO1             = 0;
static uint8_t CAN_or_ISO15765_J1939	= 0;
static uint8_t CANCH1_or_ISO15765CH1_J1939CH1 = 0;
static uint32_t CAN_connect_flags       = 0;
static uint32_t KWP_connect_flags       = 0;
static uint8_t ISO_9141_OR_14230		= 0;

static uint32_t CAN_CH1_connect_flags   = 0;
static uint32_t stored_msg_id_CAN          = 0;
static uint32_t stored_tx_flags_CAN        = 0;
static uint32_t stored_msg_id_CAN_CH1      = 0;
static uint32_t stored_tx_flags_CAN_CH1    = 0;
static uint8_t stored_is_ext_frm           = FALSE;
static GARUDA_CommunicationMode_t appMode;

static uint16_t hfcp_max_in_single_frame;
static uint16_t hfcp_max_resp_size;
static SemaphoreHandle_t xTaskExecLock;

/* ECU_SendMessage shall use this buffer */
static ISO9141_14230_TxMsg_S l_App_ISO9141_14230TxMsg_S;
/* Flags to Indicate the Segment Transfer */
static uint8_t l_KWPTX_SegTrnsfr=0;

static QueueHandle_t xHFCP_TX_Queue;
static QueueHandle_t xHFCP_RX_Queue;
static uint8_t hfcpTxSock;

/* STMin Value is received from the Vehicle via Flow Control Message(15765).
IOCTL commands for handling STMin is not supported in this version */
uint8_t CAN1_Vehicle_STMinValue =0;
uint8_t CAN2_vehicle_STMinValue =0;

extern SemaphoreHandle_t xCAN1StartTx;
extern SemaphoreHandle_t xCAN2StartTx;

extern uint8_t getCAN1TXStatus(void);
extern uint8_t getCAN2TXStatus(void); 
/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
/////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct QueueDefinition
{
    int8_t *pcHead;					/*< Points to the beginning of the queue storage area. */
    int8_t *pcTail;					/*< Points to the byte at the end of the queue storage area.  Once more byte is allocated than necessary to store the queue items, this is used as a marker. */
    int8_t *pcWriteTo;				/*< Points to the free next place in the storage area. */

    union							/* Use of a union is an exception to the coding standard to ensure two mutually exclusive structure members don't appear simultaneously (wasting RAM). */
    {
        int8_t *pcReadFrom;			/*< Points to the last place that a queued item was read from when the structure is used as a queue. */
        UBaseType_t uxRecursiveCallCount;/*< Maintains a count of the number of times a recursive mutex has been recursively 'taken' when the structure is used as a mutex. */
    } u;

    List_t xTasksWaitingToSend;		/*< List of tasks that are blocked waiting to post onto this queue.  Stored in priority order. */
    List_t xTasksWaitingToReceive;	/*< List of tasks that are blocked waiting to read from this queue.  Stored in priority order. */

    volatile UBaseType_t uxMessagesWaiting;/*< The number of items currently in the queue. */
    UBaseType_t uxLength;			/*< The length of the queue defined as the number of items it will hold, not the number of bytes. */
    UBaseType_t uxItemSize;			/*< The size of each items that the queue will hold. */

    volatile BaseType_t xRxLock;	/*< Stores the number of items received from the queue (removed from the queue) while the queue was locked.  Set to queueUNLOCKED when the queue is not locked. */
    volatile BaseType_t xTxLock;	/*< Stores the number of items transmitted to the queue (added to the queue) while the queue was locked.  Set to queueUNLOCKED when the queue is not locked. */

    #if ( configUSE_TRACE_FACILITY == 1 )
    UBaseType_t uxQueueNumber;
    uint8_t ucQueueType;
    #endif

    #if ( configUSE_QUEUE_SETS == 1 )
    struct QueueDefinition *pxQueueSetContainer;
    #endif

} xQUEUE;

/* The old xQUEUE name is maintained above then typedefed to the new Queue_t
name below to enable the use of older kernel aware debuggers. */
typedef xQUEUE Queue_t;

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/******************************************************************************
*           P R I V A T E   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
uint8_t get_CAN_or_ISO(void);
uint8_t get_CAN1_or_ISO1(void);

static void process_CAN_IOCTL_cmd(uint8_t *fl_USB_buffer_out);
static void process_KWP_IOCTL_cmd(uint8_t *buffer);

/******************************************************************************
* Function name	        : HFCPTxFreeRTOS_Init
*    returns	        : None
*    parameters         : None
* Description           : Initialize the FreeRTOS for WiFi
*******************************************************************************/
void HFCPFreeRTOS_Init (void)
{
    xTaskExecLock = xSemaphoreCreateBinary();
    if (!xTaskExecLock) {
        return ;
    }

    /**< HFCP Tx Task */  
    if(pdTRUE != xTaskCreate(HFCPTx_Task, "HFCP_Tx_Task",HFCP_TX_TASK_STACK_SIZE, 
                            (void *) NULL, HFCP_TX_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
    
    }
  
    /**< HFCP Rx Task */  
    if(pdTRUE != xTaskCreate(HFCPRx_Task, "HFCP_Rx_Task", HFCP_RX_TASK_STACK_SIZE, 
                            (void *) NULL, HFCP_RX_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
    
    }
  
    /**< HFCP TX Queue */
    xHFCP_TX_Queue = xQueueCreate( HFCP_TX_Queue_SIZE, 
                                ( unsigned portBASE_TYPE ) ( sizeof(Dynamic_QStruct_t) ));
  
    /**< HFCP RX Queue */
    xHFCP_RX_Queue = xQueueCreate( HFCP_RX_Queue_SIZE, 
                                ( unsigned portBASE_TYPE ) ( sizeof(Dynamic_QStruct_t) ));             
  
    vQueueAddToRegistry(xHFCP_TX_Queue, "HFCPTxQ"); 
    vQueueAddToRegistry(xHFCP_RX_Queue, "HFCPRxQ");
    return ;
}

/******************************************************************************
* Function name	        : HFCP_setApplicationMode
*    returns	        : none
*    parameters         : mode
* Description           : Sets the Garuda Application Mode
*******************************************************************************/
void HFCP_setApplicationMode (GARUDA_CommunicationMode_t mode)
{
    if (mode == GARUDA_IN_USB_MODE)
    {
        appMode = mode;
        hfcp_max_in_single_frame = HFCP_MAX_USB_SINGLE;
        hfcp_max_resp_size = HFCP_MAX_USB_RESP_SIZE;
		HFCPComMode = HFCP_COM_MODE_USB;
    }
    else if (mode == GARUDA_IN_WIFI_MODE)
    {
        appMode = mode;
        hfcp_max_in_single_frame = HFCP_MAX_IN_SINGLE_FRAME;
        hfcp_max_resp_size = MAX_HFCP_RESP_SIZE;
        HFCPComMode = HFCP_COM_MODE_WIFI;
    }
    else
    {
        TRACE_INFO_WP("hfcp:Invalid Application init Mode\r\n");
        while(1);
    }
}

/******************************************************************************
* Function name	        : Socket_To_Tx
*    returns	        : none
*    parameters         : mode
* Description           : Gets the Connection received Socket Number. 
*******************************************************************************/
void Socket_To_Tx (uint8_t sockNum)
{
  hfcpTxSock = sockNum;
}


/******************************************************************************
* Function name     : HFCPTx_Task
* returns           : None
* parameters        : None
* Description       : Handles WiFi Operations
*******************************************************************************/
//#define TEST_CODE_1 1

uint8_t hfcpTxFrame[SPI_DMA_TX_MAX_SIZE];
uint32_t HFCPTxCount =0;
uint32_t HFCPQueueReceiveCount = 0;
uint32_t hfcpTaskTxLimit = 0;
uint32_t hfcpMaxTxPerSch = 0;
uint32_t ZeroCount;
uint32_t TwoCount;
uint32_t HFCPTxQueueDataPending;
extern volatile TickType_t xTickCount;

#if HFCP_DEBUG
uint32_t hfcpTaskStart = 0;
uint32_t hfcpTaskStop = 0;
uint32_t hfcpTaskDiffTime = 0;
extern uint16_t taskTracker[255][2];
extern uint8_t taskTrackerIndex;
uint32_t HFCPTaskTickCount = 0;
#endif

uint32_t PrevHFCPTxQueueDataPending = 2;
uint32_t lesscount =0;

void HFCPTx_Task(void *PvParam)
{
	uint16_t hfcpCopyIndx;
	uint16_t hfcpFrameLen;
   
	Dynamic_QStruct_t dataFromQ;   
      
	uint32_t activeHFCPQReadTimeout;
   
	#if TEST_CODE_1
	uint32_t HFCPQReadTimeout = 2;
	uint32_t currHFCPQReadTimeout = 2;
	#endif
   
	uint32_t taskDiffTime = 0;
  
  
  for( ; ; )
  {         
    //while(xSemaphoreTake(xTaskExecLock, portMAX_DELAY) != pdTRUE);
    //xSemaphoreGive(xTaskExecLock);

    hfcpCopyIndx = (appMode == GARUDA_IN_USB_MODE)?(0):(10); /* Left 10 Bytes For SN8200 Header */
    hfcpFrameLen = 0;
    activeHFCPQReadTimeout = portMAX_DELAY;

    if (hfcpMaxTxPerSch < hfcpTaskTxLimit)
    {
        hfcpMaxTxPerSch = hfcpTaskTxLimit;
    }
    hfcpTaskTxLimit = 0;

    while (xQueueReceive(xHFCP_TX_Queue, (void*)&dataFromQ, activeHFCPQReadTimeout) == pdTRUE)
    {        
        // HFCPQReadTimeout = 0;
        if (appMode == GARUDA_IN_USB_MODE)
        {		  
          activeHFCPQReadTimeout = 2;  
          /* send data over usb */
          USB_Mid_Transmit(dataFromQ.address, dataFromQ.len, dataFromQ.freeAddress);
          HFCPTxCount++;
        }
        /* Else if application is in WiFi mode */
        else if (appMode == GARUDA_IN_WIFI_MODE)
        {
            if(hfcpFrameLen == 0) {
				hfcpCopyIndx = 10;
				#if HFCP_DEBUG
				 hfcpTaskStart = xTickCount; 
				 #endif
				 }  
            HFCPQueueReceiveCount++;                                    
            memcpy(&hfcpTxFrame[hfcpCopyIndx], (void*)dataFromQ.address, dataFromQ.len);
            hfcpCopyIndx+=dataFromQ.len;
            hfcpFrameLen+=dataFromQ.len; 
            if( dataFromQ.freeAddress == RELEASE){
                vPortFree(dataFromQ.address);
            }             
            if((hfcpFrameLen + HFCP_MAX_IN_SINGLE_FRAME) > MAX_HFCP_RESP_SIZE )
            {
                break;
            }
            activeHFCPQReadTimeout = 0;//2;
             #if TEST_CODE_1
             if(HFCPTaskTickCount >= 400)
             {
                 HFCPTaskTickCount = 0;
                 
                 //taskENTER_CRITICAL();
                 HFCPTxQueueDataPending = (((Queue_t*)xHFCP_TX_Queue)->uxMessagesWaiting);
                 //taskEXIT_CRITICAL();
                 
                 if(HFCPTxQueueDataPending > 0)
                 {
                     TwoCount++;
                     currHFCPQReadTimeout = 2;
                 }
                 else
                 {
                     ZeroCount++;
                     currHFCPQReadTimeout = 0;
                 }
                 
                 if(currHFCPQReadTimeout == PrevHFCPTxQueueDataPending)
                 {
                     if(currHFCPQReadTimeout == 0) {
                         HFCPQReadTimeout = currHFCPQReadTimeout;
                     }
                 }
                 
                 PrevHFCPTxQueueDataPending = currHFCPQReadTimeout;
                 if (currHFCPQReadTimeout == 2){
                     HFCPQReadTimeout = 2;
                 }
                 //ADDED
                 activeHFCPQReadTimeout = HFCPQReadTimeout;
             }
             else
             {
                 activeHFCPQReadTimeout = HFCPQReadTimeout;
             }
             #endif                        
        }
        /* Else drop current data start over */
        else
        {
          TRACE_INFO_WP("hfcp:Invalid App Mode\r\n");
        }
        if (++hfcpTaskTxLimit >= 48) {
             break;
        }
    }

    if (appMode == GARUDA_IN_WIFI_MODE)
    {
         HFCPTxCount++;  
		 if(hfcpFrameLen < 1280)
		 lesscount++;
		 
		  hfcpTaskStart = xTickCount; 
        Send_To_Socket(hfcpTxSock, hfcpTxFrame,hfcpFrameLen);
        if(false == Is_Tx_Complete(portMAX_DELAY))
        { 
        /* Retry?????*/
        } 
        #if HFCP_DEBUG
        hfcpTaskStop = xTickCount;
        taskDiffTime = (hfcpTaskStop < hfcpTaskStart) ? (((~0u) - hfcpTaskStop) + hfcpTaskStart) : (hfcpTaskStop - hfcpTaskStart);
        if (hfcpTaskDiffTime < taskDiffTime)
        {
            hfcpTaskDiffTime = taskDiffTime;
        }
        HFCPTaskTickCount +=taskDiffTime;
        //taskTracker[taskTrackerIndex][0] = 'H';
		taskTracker[taskTrackerIndex][0]  = ((Queue_t*)xHFCP_TX_Queue)->uxMessagesWaiting;
        taskTracker[taskTrackerIndex++][1] = taskDiffTime;
		#endif
          
    }
    portYIELD_WITHIN_API();
  }
}
/******************************************************************************
* Function name         : HFCPRx_Task
* returns               : None
* parameters            : None
* Description           : Handles WiFi Operations
*******************************************************************************/
uint8_t hfcpAckFrame[3];
void HFCPRx_Task(void *PvParam)
{    
  Dynamic_QStruct_t dataFromQ;
  
  for( ; ; )
  { 
    /**< HFCP_Rx_Task(); */
    if( xQueueReceive( xHFCP_RX_Queue, &dataFromQ, portMAX_DELAY) == pdPASS)
    {
		if (!dataFromQ.address)
		{
			/* Invalid buffer, drop */
			continue;
		}
      /* Handle CAN commands here */            
      if((dataFromQ.address[0] == CAN_PROTOCOL_ID) || (dataFromQ.address[0] == CAN_CH1_PROTO_ID) ||
         (dataFromQ.address[0] == ISO15765_PROTO_ID) || (dataFromQ.address[0] == ISO15765_PROTO_CH1_PROTO_ID))
      {
        process_CAN_command(&dataFromQ.address[0]);
      } 
      else if( (dataFromQ.address[0] == KWP_PROTOCOL_ID) || (dataFromQ.address[0] == ISO_9141_PROTO_ID) )
      {
        process_KWP_command(&dataFromQ.address[0]);
      }
      else if(dataFromQ.address[0] == J1708_PROTOCOL_ID)
      {
        
      }
      /* Handle Non Protocol commands here */
      else if(dataFromQ.address[0] == SETUP_CMD_ID)
      {
        process_Setup_command(&dataFromQ.address[0]);
      }
      /* Handle Non Protocol commands here */
      else if(dataFromQ.address[0] == SESSION_MANAGEMENT)
      {       
        process_session_mgmt_command(&dataFromQ.address[0]);
      } 
      else if (dataFromQ.address[0] == BOOLOADER_MODE)
      {
            jumpToBootloader();
      }                      
	  else if( (dataFromQ.address[0] == J1939_PROTOCOL_ID) || (dataFromQ.address[0] == J1939_CH1_PROTOCOL_ID) ) 
	  {
		  process_J1939_command(&dataFromQ.address[0]);
	  }
      else
      {
        hfcpAckFrame[0] = dataFromQ.address[0];
        hfcpAckFrame[1] = dataFromQ.address[1];
        hfcpAckFrame[2] = ERR_NOT_SUPPORTED;                
        (void)Garuda_Tx_data_on_USB(hfcpAckFrame,3,DONT_RELEASE);
      }
      vPortFree(dataFromQ.address);
    }
    //vTaskDelay(1);
  }  
}

/******************************************************************************
* Function name     : Send_To_HFCP_Queue
* returns           : None
* parameters        : hfcpReqBuf, reqLen
* Description       : Sends the data to the HFCP Queue
*******************************************************************************/
void Send_To_HFCP_Queue(uint8_t *hfcpReqBuf, uint16_t reqLen)
{  
  Dynamic_QStruct_t dataToQ;
  
  dataToQ.len = reqLen;  
  dataToQ.address = pvPortMalloc(dataToQ.len);
  
  if(dataToQ.address)
  {
    memcpy(dataToQ.address,hfcpReqBuf,dataToQ.len); 
    if(xQueueSend(xHFCP_RX_Queue, (void*)&dataToQ, 0 ) == pdFAIL)
    { 
      vPortFree((void*)dataToQ.address);
    }
  }
}

/******************************************************************************
* Function name     : Send_To_HFCP_No_Copy_Queue
* returns           : None
* parameters        : hfcpReqBuf, reqLen
* Description       : Sends the data to the HFCP Queue.
*******************************************************************************/
void Send_To_HFCP_No_Copy_Queue(uint8_t *hfcpReqBuf, uint16_t reqLen)
{  
  Dynamic_QStruct_t dataToQ;
  
  dataToQ.len = reqLen;  
  dataToQ.address = hfcpReqBuf;
  
  if(dataToQ.address)
  {
    if(xQueueSend(xHFCP_RX_Queue, (void*)&dataToQ, 0 ) == pdFAIL)
    { 
      vPortFree((void*)dataToQ.address);
    }
  }
}


/******************************************************************************
**	Function Name	:Garuda_Tx_data_on_USB
**	Input Params	:
**	Output Params	:
**	Description	:
******************************************************************************/
uint32_t canHfeqfcnt;
uint32_t Release = 0;
uint8_t  HFCPAllocatedBuffer[64][64]; 
uint8_t  HFCPAllocatedBufferIndex;
uint32_t allocatedCount =0;
  
  
 uint32_t hfcpTxqueueAlloc =0;
 uint32_t GarudaTxdataonUSB =0;
  
void Garuda_Tx_data_on_USB(uint8_t *pHfcpAck, uint16_t len, uint8_t release)
{
  Dynamic_QStruct_t dataToQ;

  if(0 == len)
  {
    vPortFree(pHfcpAck);  
    return;
  }
    
    dataToQ.len = len;  
  
    if(dataToQ.len < HFCP_TX_BUFFER_SIZE) {
    dataToQ.len = HFCP_TX_BUFFER_SIZE;
    }    
   
    if((release == DONT_RELEASE) || (release == DONT_RELEASE_ISR))
    {
		allocatedCount++;
        dataToQ.address = HFCPAllocatedBuffer[HFCPAllocatedBufferIndex++];
		if(64== HFCPAllocatedBufferIndex) 
		HFCPAllocatedBufferIndex=0;
        dataToQ.freeAddress = DONT_RELEASE;
        
    }
    else
    {    
        dataToQ.address = pvPortMalloc(dataToQ.len);        
        dataToQ.freeAddress = RELEASE;
    }
    
  if(dataToQ.address)
  {
	  hfcpTxqueueAlloc++;
    memcpy(dataToQ.address,pHfcpAck,dataToQ.len); 
    if(release == RELEASE)
    {
	    vPortFree(pHfcpAck);
	    Release++;
    }

    if(release == DONT_RELEASE_ISR)
    {
            if(xQueueSendFromISR(xHFCP_TX_Queue, (void*)&dataToQ, 0 ) != pdTRUE) //== pdFAIL)
            {
                canHfeqfcnt++;
                vPortFree((void*)dataToQ.address);
            }
    }
    else
    {
            if(xQueueSend(xHFCP_TX_Queue, (void*)&dataToQ, 0 ) != pdTRUE) //== pdFAIL)
            {
                canHfeqfcnt++;
                vPortFree((void*)dataToQ.address);
            }
    }
  }
  else
  {
        GarudaTxdataonUSB++;
        if(release == RELEASE)
        {
	        vPortFree(pHfcpAck);
	        Release++;
        }      
  }
}


/*******************************************************************************
* Function Name  : Get_Connect_Flags
* Description    :
* Input          : None.
* Return         : None.
*******************************************************************************/
uint32_t Get_Connect_Flags(uint8_t protocol_id)
{
  if((protocol_id == CAN_PROTOCOL_ID) || (protocol_id == ISO15765_PROTO_ID))
  {
    return CAN_connect_flags;
  }
  if((protocol_id == CAN_CH1_PROTO_ID) || (protocol_id == ISO15765_PROTO_CH1_PROTO_ID))
  {
    return CAN_CH1_connect_flags;
  }
  else if(protocol_id == KWP_PROTOCOL_ID)
  {
    return KWP_connect_flags;
  }
  else
  {
    return UNINITIALIZED_PROTO_ID;
  }
}

//TEST
uint32_t HFCPInitCount = 0;

/*******************************************************************************
* Function Name  : process_CAN_command
* Description    :
* Input          : None.
* Return         : None.
*******************************************************************************/
void process_CAN_command( uint8_t *buffer)
{
  uint8_t fl_channel_no_U8 =0,fl_status_U8 = STATUS_NOERROR,command =0;  
  CAN_TX_Msg_t  fl_CAN_Tx_msg_S;
  uint16_t msg_cnt = 0, data_len = 0;
  uint32_t fl_baud_rate_U32;
  uint32_t current_time_stamp = 0;
  uint8_t fl_connection_flag_U8,fl_USB_tx_data_U8A[64];
  uint8_t base_indx = 0, loop_count=0;
  uint32_t fl_msg_id = 0, fl_tx_flags = 0;
  uint8_t ch_id=0;
  command = buffer[1] ;
  /* J2534 Periodic messages */
  PERIODIC_MSG j2534_periodic_msg;
   uint8_t periodic_msg_cmd = 0;
  J2534_filter_t fl_filter_config;
  uint8_t fl_FilterID,fl_Protocol_ID_U8;
  J2534_stError_t fl_filt_config_status, fl_filt_stop_status;  
  uint8_t fl_Q_Status;
  uint8_t Ack_Required=0;
  
  
  switch(command)
  {
  case CAN_EnableComm:
    {
      fl_status_U8 = STATUS_NOERROR;
      fl_baud_rate_U32 = (uint32_t)buffer[2];
      fl_baud_rate_U32 = (fl_baud_rate_U32)| (uint32_t)buffer[3] << 8;
      fl_baud_rate_U32 = (fl_baud_rate_U32)| (uint32_t)buffer[4] << 16;
      fl_baud_rate_U32 = (fl_baud_rate_U32)| (uint32_t)buffer[5] << 24;
      	  
      /* Handle CAN Channel 1 */
      if((buffer[0] == CAN_PROTOCOL_ID) || (buffer[0] == ISO15765_PROTO_ID))
      {
		CAN1_Vehicle_STMinValue = 0;  
        fl_channel_no_U8 = CAN_CH1;
        CAN_or_ISO = buffer[0];
		CAN_or_ISO15765_J1939 = buffer[0];
		
        CAN_connect_flags = (uint32_t)buffer[9];
        CAN_connect_flags <<=8;
        CAN_connect_flags |= (uint32_t)buffer[8];
        CAN_connect_flags <<=8;
        CAN_connect_flags |= (uint32_t)buffer[7];
        CAN_connect_flags <<=8;
        CAN_connect_flags |= (uint32_t)buffer[6];
        
        TRACE_INFO_WP("HFCP DEBUG : CAN 1 Enable Communication Cmd \r\n");
        
        fl_status_U8 =  CAN_Mid_Init(CAN_CH1,fl_baud_rate_U32);
        
        if((ERR_INVALID_BAUDRATE != fl_status_U8) && (ERR_INVALID_CHANNEL_ID != fl_status_U8))
        {
          if((CAN_connect_flags & CAN_ID_BOTH) == CAN_ID_BOTH )
          {
            fl_connection_flag_U8 = RX_BOTH_STD_EXT_MSG;
          }
          else if((CAN_connect_flags & CAN_29BIT_ID )== CAN_29BIT_ID)
          {
            fl_connection_flag_U8 = RX_ONLY_EXT_MSG;
          }
          else if((CAN_connect_flags & CAN_29BIT_ID )== 0)
          {
            fl_connection_flag_U8 = RX_ONLY_STD_MSG;
          }
          else
          {
            fl_status_U8 = ERR_INVALID_FLAGS;
          }
          
          if(fl_status_U8 != ERR_INVALID_FLAGS)
          {
            fl_status_U8 = CAN_Mid_Enable(fl_channel_no_U8,fl_connection_flag_U8);
            if(fl_status_U8==STATUS_NOERROR)
            {
              l_connected_channels++;              
			  l_connected_channel_1 = 1; 
            }
          }
          else
          {
            /* Do nothing as fl_status_U8 has been modified */
          }
        }
        else
        {
          /* Do nothing as fl_status_U8 has been modified */
        }
        if( fl_status_U8 == STATUS_NOERROR)
        {          
          CAN_active = 1;
        }
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0] ;
        fl_USB_tx_data_U8A[1] = CAN_EnableComm_ACK;
        fl_USB_tx_data_U8A[3] = fl_status_U8;
		
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      /* Handle CAN Channel 2 */
      else if((buffer[0] == CAN_CH1_PROTO_ID) || (buffer[0] == ISO15765_PROTO_CH1_PROTO_ID))
      {
		CAN2_vehicle_STMinValue = 0;  
        fl_channel_no_U8 = CAN_CH2;
        CAN1_or_ISO1 = buffer[0];
		CANCH1_or_ISO15765CH1_J1939CH1 = buffer[0];
        CAN_CH1_connect_flags = (uint32_t)buffer[9];
        CAN_CH1_connect_flags <<=8;
        CAN_CH1_connect_flags |= (uint32_t)buffer[8];
        CAN_CH1_connect_flags <<=8;
        CAN_CH1_connect_flags |= (uint32_t)buffer[7];
        CAN_CH1_connect_flags <<=8;
        CAN_CH1_connect_flags |= (uint32_t)buffer[6];
        fl_status_U8 =  CAN_Mid_Init(CAN_CH2,fl_baud_rate_U32);
        if((ERR_INVALID_BAUDRATE != fl_status_U8) && (ERR_INVALID_CHANNEL_ID != fl_status_U8))
        {
          if((CAN_CH1_connect_flags & CAN_ID_BOTH) == CAN_ID_BOTH )
          {
            fl_connection_flag_U8 = RX_BOTH_STD_EXT_MSG;
          }
          else if((CAN_CH1_connect_flags & CAN_29BIT_ID )== CAN_29BIT_ID)
          {
            fl_connection_flag_U8 = RX_ONLY_EXT_MSG;
          }
          else if((CAN_CH1_connect_flags & CAN_29BIT_ID )== 0)
          {
            fl_connection_flag_U8 = RX_ONLY_STD_MSG;
          }
          else
          {
            fl_status_U8 = ERR_INVALID_FLAGS;
          }
          if(fl_status_U8 != ERR_INVALID_FLAGS)
          {
            fl_status_U8 = CAN_Mid_Enable(fl_channel_no_U8,fl_connection_flag_U8);
            if(fl_status_U8==STATUS_NOERROR)
            {
              l_connected_channels++;              
			  l_connected_channel_2 = 1;
            }
            
            
            printf("HFCP DEBUG : CAN 2 Enable Communication Cmd \r\n");
          }
          else
          {
            /* Do nothing as fl_status_U8 has been modified */
          }
        }
        else
        {
          /* Do nothing as fl_status_U8 has been modified */
        }
        if( fl_status_U8 == STATUS_NOERROR)
        {          
          CAN_CH1_active = 1;
        }
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0] ;
        fl_USB_tx_data_U8A[1] = CAN_EnableComm_ACK;
        fl_USB_tx_data_U8A[3] = fl_status_U8;		
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      else
      {
        /* ERROR: It should never enter here */
        fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
      }
      break;
    }
  case CAN_DisableComm:
    {
      if((buffer[0] == CAN_PROTOCOL_ID) || (buffer[0] == ISO15765_PROTO_ID))
      {
        fl_channel_no_U8 = CAN_CH1;
        CAN_or_ISO = 0;
        CAN_or_ISO15765_J1939 = 0;
		//STMinValue =0;
		CAN1_Vehicle_STMinValue = 0;  
        /* Clears All the Filters Configured */
        J2534_ClearAllFilter(CAN_PROTOCOL_ID);
        /* Suspend all periodic messages */   
        suspend_pmsg(CAN_PROTOCOL_ID); 
        
        CAN_ClearQ(CAN1_TX_QUEUE); 
		if(getCAN1TXStatus())
		{
			xSemaphoreGive(xCAN1StartTx); 	
		}		
				              
        CAN_ClearQ(CAN1_RX_QUEUE);
        
        #if GARUDA_DEBUG
        printf("HFCP DEBUG : CAN Disable Communication Cmd \r\n");
        #endif
        
        fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
        if( fl_status_U8 == STATUS_NOERROR)
        {
          CAN_active = 0;
          if(l_connected_channels)
          {
            l_connected_channels--;
          }
		  l_connected_channel_1 = 0;          
        }
        CAN_connect_flags = 0;
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0];
        fl_USB_tx_data_U8A[1] = CAN_DisableComm_ACK;
        fl_USB_tx_data_U8A[2] = fl_status_U8;
		
		/* Added the Debug Messages in USB Frame for ACK Packet */
		#if GARUDA_USB_DEBUG
		Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
		memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
		#endif
		
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
        /*Garuda_init();*/ /* Commented to fix the issue of not transmitting Ack for DisableComm
        Side effects are yet to be investigated */
      }
      else if((buffer[0] == CAN_CH1_PROTO_ID) || (buffer[0] == ISO15765_PROTO_CH1_PROTO_ID))
      {
        fl_channel_no_U8 = CAN_CH2;
        CAN1_or_ISO1 = 0;
		CANCH1_or_ISO15765CH1_J1939CH1 = 0;
        CAN2_vehicle_STMinValue = 0;  
        /* Clears All the Filters Configured */
        J2534_ClearAllFilter(CAN_CH1_PROTO_ID);                
        /* Suspend all periodic messages */
        suspend_pmsg(CAN_CH1_PROTO_ID); 
               
        CAN_ClearQ(CAN2_TX_QUEUE);
		if(getCAN2TXStatus())
		{
			xSemaphoreGive(xCAN2StartTx);
		}
        CAN_ClearQ(CAN2_RX_QUEUE);
        
        fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
        if( fl_status_U8 == STATUS_NOERROR)
        {
          CAN_CH1_active = 0;
          if(l_connected_channels)
          {
            l_connected_channels--;
          }
		  l_connected_channel_2 = 0;          
        }
        CAN_CH1_connect_flags = 0;

        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0];
        fl_USB_tx_data_U8A[1] = CAN_DisableComm_ACK;
        fl_USB_tx_data_U8A[2] = fl_status_U8;
		
		#if GARUDA_USB_DEBUG
		Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
		memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
		#endif
		
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
        /*Garuda_init();*/ /* Commented to fix the issue of not transmitting Ack for DisableComm
        Side effects are yet to be investigated */
      }
      else
      {
        /* ERROR: It should never enter here */
        fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
        
      }
      break;
    }
  case IOCTL_COMMAND:
    {
      process_CAN_IOCTL_cmd(buffer);
      break;
    }
  case CAN_Send_msg:
    {
      if((buffer[0] == CAN_PROTOCOL_ID) || (buffer[0] == ISO15765_PROTO_ID))
      {
        ch_id = 1;
      }
      else if((buffer[0] == CAN_CH1_PROTO_ID) || (buffer[0] == ISO15765_PROTO_CH1_PROTO_ID))
      {
        ch_id = 2;
      }
      else
      {
        /* ERROR: */
      }
      /* Unsegmented USB transfer */
	  
	  HFCPInitCount++;
	  
      if(buffer[2] == 0)
      {        
        data_len = buffer[3] | buffer[4] << 8 ;
        if((data_len & 0xC000) == 0x0000) /* Mode 0 */
        {		  
		  ((ch_id == 1) ? (CAN1_Vehicle_STMinValue = 0) : (CAN2_vehicle_STMinValue = 0));
          data_len &= 0x3FFF;
          fl_tx_flags = ( (uint32_t)buffer[5]        |
                         (uint32_t)buffer[6]  << 8  |
                           (uint32_t)buffer[7]  << 16 |
                             (uint32_t)buffer[8]  << 24 );
          fl_msg_id =   ( (uint32_t)buffer[9]  << 24 |
                         (uint32_t)buffer[10] << 16 |
                           (uint32_t)buffer[11] << 8  |
                             (uint32_t)buffer[12] );
          //memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
          if(CAN_EXT_MSG == (fl_tx_flags & CAN_EXT_MSG)) /* Extended Frame */
          {                        
            fl_CAN_Tx_msg_S.ide = TRUE;
          }
          else /* Standard Frame */
          {                        
            fl_CAN_Tx_msg_S.ide = FALSE;
          }
          fl_CAN_Tx_msg_S.msg_id = fl_msg_id;
          fl_CAN_Tx_msg_S.rtr = 0;
          /* Copy data length */
          fl_CAN_Tx_msg_S.dlc = (uint8_t)data_len-4; /* subtract Msg Id length */
          /* Copy all data bytes into buffer */
          memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[13], fl_CAN_Tx_msg_S.dlc);
          // fl_CAN_Tx_msg_S.is_periodic_msg = FALSE; /* IS PERIODIC MESSAGE REMOVED */
          if(ch_id == 1)
          {
            //AMIT  fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
            fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
          }
          else if (ch_id == 2)
          {
            //AMIT fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
            fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);                       
          }
          
          if (fl_Q_Status == MID_FAIL)// OLD CODE(fl_Q_Status == CAN_Q_FULL)
          {
            /* Message lost as the Buffer is full */
            
            memset(&fl_USB_tx_data_U8A,0,64);
            fl_USB_tx_data_U8A[0] = buffer[0] ;
            fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
            fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
            fl_USB_tx_data_U8A[3] = ERR_BUFFER_FULL;
            (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
          }
          else
          {
            /* Clear the USB buffer as it has been processed */
            
            memset(&fl_USB_tx_data_U8A,0,64);
            fl_USB_tx_data_U8A[0] = buffer[0] ;
            fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
            fl_USB_tx_data_U8A[2] = buffer[2];
            fl_USB_tx_data_U8A[3] = fl_status_U8;
            if(ch_id == 1)
            {
                //get_data_logging_time_stamp(&current_time_stamp);
                get_time_stamp(&current_time_stamp);
            }
            else
            {              
                  //get_data_logging_time_stamp(&current_time_stamp);
                  get_time_stamp(&current_time_stamp);
            }
            fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
            fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
            fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
            fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
			
			#if GARUDA_USB_DEBUG
			if(ch_id == 1)
			{
				Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
				memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
			}
			else
			{
				Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
				memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
			}
			#endif
            (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
          }
        }
        else if((data_len & 0xC000) == 0x4000) /* Mode 1 */
        {          
		   ((ch_id == 1) ? (CAN1_Vehicle_STMinValue = 0) : (CAN2_vehicle_STMinValue = 0));
          /* buffer[5] - Supposed to hold
          conversation Id - To be incorporated */
          if(ch_id == 1)
          {
            stored_tx_flags_CAN = ( (uint32_t)buffer[6]        |
                                   (uint32_t)buffer[7]  << 8  |
                                     (uint32_t)buffer[8]  << 16 |
                                       (uint32_t)buffer[9]  << 24 );
            stored_msg_id_CAN =   ( (uint32_t)buffer[10]  << 24 |
                                   (uint32_t)buffer[11] << 16 |
                                     (uint32_t)buffer[12] << 8  |
                                       (uint32_t)buffer[13] );
            //memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
            if(CAN_EXT_MSG == (stored_tx_flags_CAN & CAN_EXT_MSG)) /* Extended Frame */
            {
              fl_CAN_Tx_msg_S.ide = TRUE;
            }
            else /* Standard Frame */
            {
              fl_CAN_Tx_msg_S.ide = FALSE;
            }
            stored_is_ext_frm = fl_CAN_Tx_msg_S.ide;
            fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN;
          }
          else
          {
            stored_tx_flags_CAN_CH1 = ( (uint32_t)buffer[6]        |
                                       (uint32_t)buffer[7]  << 8  |
                                         (uint32_t)buffer[8]  << 16 |
                                           (uint32_t)buffer[9]  << 24 );
            stored_msg_id_CAN_CH1 =   ( (uint32_t)buffer[10]  << 24 |
                                       (uint32_t)buffer[11] << 16 |
                                         (uint32_t)buffer[12] << 8  |
                                           (uint32_t)buffer[13] );
            memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
            if(CAN_EXT_MSG == (stored_tx_flags_CAN_CH1 & CAN_EXT_MSG)) /* Extended Frame */
            {
              fl_CAN_Tx_msg_S.ide = TRUE;
            }
            else /* Standard Frame */
            {
              fl_CAN_Tx_msg_S.ide = FALSE;
            }
            fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN_CH1;
          }
          data_len &= 0x3FFF;
          fl_CAN_Tx_msg_S.rtr = 0;
          /* Copy data length */
          fl_CAN_Tx_msg_S.dlc = (uint8_t)data_len-4; /* subtract Msg Id length */
          /* copy all data bytes into buffer */
          memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[14], fl_CAN_Tx_msg_S.dlc);
          // fl_CAN_Tx_msg_S.is_periodic_msg = FALSE; /* IS PERIODIC MESSAGE REMOVED */
          if(ch_id == 1)
          {
            //fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S); AMIT
            fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
          }
          else if (ch_id == 2)
          {
            //fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);//AMIT
            fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);  
          }
          if (fl_Q_Status == MID_FAIL) // OLD CODE (fl_Q_Status == CAN_Q_FULL)
          {
            /* Message lost as the Buffer is full */
            
            memset(&fl_USB_tx_data_U8A,0,64);
            fl_USB_tx_data_U8A[0] = buffer[0] ;
            fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
            fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
            fl_USB_tx_data_U8A[3] = ERR_BUFFER_FULL;
            (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
          }
          else
          {
            /* Clear the USB buffer as it has been processed */
            
            memset(&fl_USB_tx_data_U8A,0,64);
            fl_USB_tx_data_U8A[0] = buffer[0] ;
            fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
            fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
            fl_USB_tx_data_U8A[3] = fl_status_U8;
            if(ch_id == 1)
            {             
                // get_data_logging_time_stamp(&current_time_stamp);
                get_time_stamp(&current_time_stamp);
            }
            else
            {              
                //get_data_logging_time_stamp(&current_time_stamp);
                get_time_stamp(&current_time_stamp);
            }
            fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
            fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
            fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
            fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
			
			#if GARUDA_USB_DEBUG
			if(ch_id == 1)
			{
				Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
				memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));	
			}
			else
			{
				Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
				memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
			}
			
			#endif
			
            (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
          }
        }
        else if((data_len & 0xC000) == 0x8000) /* Mode 2 */
        {
          /* buffer[5] - Supposed to hold
          conversation Id - To be incorporated
          buffer[6],[7] - Supposed to hold
          Separation time - To be incorporated  */
		  		  	  		  
		  ((ch_id == 1) ? (CAN1_Vehicle_STMinValue =  buffer[6]) : (CAN2_vehicle_STMinValue =  buffer[6]));			  
		  
          if(HFCPComMode == HFCP_COM_MODE_USB)
          {
            Ack_Required = 1;
          }
          else if(HFCPComMode == HFCP_COM_MODE_WIFI)
          {
            Ack_Required = buffer[5];
          }
          
          //memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
          
          if(ch_id == 1)
          {
            fl_CAN_Tx_msg_S.ide = stored_is_ext_frm;
            fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN;
          }
          else
          {
            if(CAN_EXT_MSG == (stored_tx_flags_CAN_CH1 & CAN_EXT_MSG)) /* Extended Frame */
            {
              fl_CAN_Tx_msg_S.ide = TRUE;
            }
            else /* Standard Frame */
            {
              fl_CAN_Tx_msg_S.ide = FALSE;
            }
            fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN_CH1;
          }
          data_len &= 0x3FFF;
          //data_len = 56; /* temp fix - investigate with Vijay */
          if(data_len <= 56)
          {
            if((data_len % 8) != 0)
            {
              msg_cnt = (data_len / 8) + 1;
            }
            else
            {
              msg_cnt = (data_len / 8);
            }
            base_indx = 8;
            while(msg_cnt--)
            {
              fl_CAN_Tx_msg_S.rtr = 0;
              /* Copy data length */
              if(data_len >= 8)
              {
                data_len -=8;
                fl_CAN_Tx_msg_S.dlc = 8;
              }
              else
              {
                fl_CAN_Tx_msg_S.dlc = data_len;
                data_len =0;
              }
              /* copy all data bytes into buffer */
              memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[base_indx], fl_CAN_Tx_msg_S.dlc);
              // fl_CAN_Tx_msg_S.is_periodic_msg = FALSE;
              if(ch_id == 1)
              {
                //fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S);AMIT
				fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
              }
              else if (ch_id == 2)
              {
                //fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
				fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);
              }
              if(MID_FAIL != fl_Q_Status) // OLD CODE (CAN_Q_FULL != fl_Q_Status)
              {
                base_indx += 8;
                //printf("Err\n\r");
              }
              else
              {
                /* Do nothing */
                /* Note that the "while" in this "else if" is blocking.
                i.e. till it writes all the frames to CAN interface it will
                not exit. A queue strategy is to be implemented such
                that there is always space for 7 frames.
                */
              }
            }
          }
          else
          {
            fl_status_U8 = ERR_FAILED;
          }
          /* Clear the USB buffer as it has been processed */
          
          if (Ack_Required == TRUE)
          {
            
            /*memset(&fl_USB_tx_data_U8A,0,64); */
            fl_USB_tx_data_U8A[0] = buffer[0] ;
            fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
            fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
            fl_USB_tx_data_U8A[3] = fl_status_U8;
            if(ch_id == 1)
            {              
               //get_data_logging_time_stamp(&current_time_stamp);
               get_time_stamp(&current_time_stamp);
            }
            else
            {                
               //get_time_stamp(timestamp_id[GARUDA_CAN_CH2], &current_time_stamp);
               //get_data_logging_time_stamp(&current_time_stamp);
               get_time_stamp(&current_time_stamp);
            }
            fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
            fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
            fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
            fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
			
			#if GARUDA_USB_DEBUG
			if(ch_id == 1)
			{
				Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
				memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
			}
			else
			{
				Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
				memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
			}
			#endif
			
            (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
          }
        }
        /* Multiple Messages in Single USB */
        else if((data_len & 0xC000) == 0xC000) /* Mode 3 */
        {			
		   ((ch_id == 1) ? (CAN1_Vehicle_STMinValue = 0) : (CAN2_vehicle_STMinValue = 0));	
          base_indx = 5;
          msg_cnt = (uint8_t) (data_len & 0x3FFF);
          
          while(msg_cnt--)
          {
            //memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
            
            fl_tx_flags = ( (uint32_t)buffer[base_indx+0]        |
                           (uint32_t)buffer[base_indx+1]  << 8  |
                             (uint32_t)buffer[base_indx+2]  << 16 |
                               (uint32_t)buffer[base_indx+3]  << 24 );
            fl_msg_id =   ( (uint32_t)buffer[base_indx+4]  << 24 |
                           (uint32_t)buffer[base_indx+5]  << 16 |
                             (uint32_t)buffer[base_indx+6]  << 8  |
                               (uint32_t)buffer[base_indx+7] );
            base_indx += 8;
            if(CAN_EXT_MSG == (fl_tx_flags & 0x00000100)) /* Extended Frame */
            {
              fl_CAN_Tx_msg_S.ide = TRUE;
            }
            else /* Standard Frame */
            {
              fl_CAN_Tx_msg_S.ide = FALSE;
            }
            data_len = buffer[base_indx++];
            fl_CAN_Tx_msg_S.dlc = data_len;
            fl_CAN_Tx_msg_S.rtr = 0;
            fl_CAN_Tx_msg_S.msg_id = fl_msg_id;
            /* copy all data bytes into buffer */
            memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[base_indx], fl_CAN_Tx_msg_S.dlc);
            //fl_CAN_Tx_msg_S.is_periodic_msg = FALSE; 
            do
            {
              if(ch_id == 1)
              {
                //fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
                fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
              }
              else if (ch_id == 2)
              {
                //fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);AMIT
                fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);
              }
            }while(fl_Q_Status == ERR_BUFFER_FULL);
            //while(ERR_BUFFER_FULL == CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S,ch_id));
            base_indx += data_len;
          }
          /* Clear the USB buffer as it has been processed */
          
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = buffer[0] ;
          fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
          fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
          fl_USB_tx_data_U8A[3] = fl_status_U8;
          if(ch_id == 1)
          {            
             //get_data_logging_time_stamp(&current_time_stamp);
             get_time_stamp(&current_time_stamp);
          }
          else
          {            
             //get_data_logging_time_stamp(&current_time_stamp);
             get_time_stamp(&current_time_stamp);
          }
          fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
          fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
          fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
          fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
		  
		  #if GARUDA_USB_DEBUG
		  if(ch_id == 1)
		  {
			 Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
			 memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
		  }
		  else
		  {
			  Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
			  memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
		  }		  
		  #endif
		  
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
        }
        /* ERROR : Illegal Mode */
        else
        {
          /* Clear the USB buffer as it has been processed */
          
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = buffer[0] ;
          fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
          fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
          fl_USB_tx_data_U8A[3] = ERR_FAILED;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
        }
      }
      /* ERROR:For CAN segmented USB transfer is not needed */
      else
      {
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0] ;
        fl_USB_tx_data_U8A[1] = CAN_Send_msg_ACK;
        fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
        fl_USB_tx_data_U8A[3] = ERR_FAILED;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      break;
    }
  case Start_msg_filter:
    {
      if((buffer[0] == ISO15765_PROTO_ID)|| (buffer[0] == CAN_PROTOCOL_ID))
      {
        fl_Protocol_ID_U8 = CAN_PROTOCOL_ID;
      }
      else if((buffer[0] == ISO15765_PROTO_CH1_PROTO_ID)|| (buffer[0] == CAN_CH1_PROTO_ID))
      {
        fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
      }
      
      fl_filter_config.Protocol_ID = fl_Protocol_ID_U8;
      fl_filter_config.filterType = (J2534_filterType_t)buffer[2];
      fl_filter_config.MaskLen = buffer[3];
      for(loop_count = 0; loop_count < fl_filter_config.MaskLen; loop_count++)
      {
        fl_filter_config.maskMsg[loop_count] = buffer[4 + loop_count];
      }
      fl_filter_config.PatternLen = buffer[4+fl_filter_config.MaskLen];
      for(loop_count = 0; loop_count < fl_filter_config.PatternLen; loop_count++)
      {
        fl_filter_config.patternMsg[loop_count] = buffer[5+fl_filter_config.MaskLen+ loop_count];
      }
      fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config, &fl_FilterID);
     // printf("HFCP DEBUG : Filter Config (ID)(status) = (%d) (%d) \r\n",fl_filter_config.); 
      
      if(fl_filt_config_status != J2534_NO_ERROR)
      {
        if(fl_filt_config_status == J2534_FLT_NOT_FREE)
        {
          fl_status_U8 = ERR_EXCEEDED_LIMIT;
        }
        else
        {
          fl_status_U8 = ERR_FAILED;
        }
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0] ;
        fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
        fl_USB_tx_data_U8A[2] = fl_status_U8;
        fl_USB_tx_data_U8A[3] = fl_FilterID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
      }
      else
      {
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0] ;
        fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
        fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
        fl_USB_tx_data_U8A[3] = fl_FilterID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
      }
      //printf("HFCP DEBUG : Start Mesage Filter (ID)(status) = (%d) (%d) \r\n",fl_FilterID, fl_status_U8); 
	  COnnected = 1;
      break;
    }
  case Stop_msg_filter:
    {
      if((buffer[0]==ISO15765_PROTO_ID)||
         (buffer[0]==CAN_PROTOCOL_ID))
      {
        fl_Protocol_ID_U8 =CAN_PROTOCOL_ID;
      }
      else if((buffer[0]==ISO15765_PROTO_CH1_PROTO_ID)||
              (buffer[0]==CAN_CH1_PROTO_ID))
      {
        fl_Protocol_ID_U8 =CAN_CH1_PROTO_ID;
      }
      fl_FilterID = buffer[2];
      fl_filt_stop_status = J2534_ClearFilter(fl_FilterID,fl_Protocol_ID_U8);
      if(fl_filt_stop_status != J2534_NO_ERROR)
      {
        if(fl_filt_stop_status == J2534_INVLD_FLTID)
        {
          fl_status_U8 = ERR_INVALID_FILTER_ID;
        }
        else
        {
          fl_status_U8 = ERR_FAILED;
        }
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
        fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
        fl_USB_tx_data_U8A[2] = fl_status_U8;
        fl_USB_tx_data_U8A[3] = fl_FilterID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
        
      }
      else
      {
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = buffer[0] ;
        fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
        fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
        fl_USB_tx_data_U8A[3] = fl_FilterID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      printf("HFCP DEBUG : Stop Mesage Filter = %d \r\n",fl_status_U8); 
      break;
    }
  case handle_periodic_msg:
    {
      if(((buffer[0])==ISO15765_PROTO_ID)||((buffer[0])==CAN_PROTOCOL_ID))
      {
        fl_Protocol_ID_U8 =CAN_PROTOCOL_ID;
      }
      else if((buffer[0]==ISO15765_PROTO_CH1_PROTO_ID)||(buffer[0]==CAN_CH1_PROTO_ID))
      {
        fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
      }
      periodic_msg_cmd = buffer[2];
      j2534_periodic_msg.protocol_id=fl_Protocol_ID_U8;
      j2534_periodic_msg.periodicity  = buffer[3]      |
        buffer[4] << 8 |
          buffer[5] << 16|
            buffer[6] << 24;
      j2534_periodic_msg.prmsg_id = buffer[7];
      j2534_periodic_msg.proto_msg.tx_flags = buffer[8]       |
        buffer[9]  << 8 |
          buffer[10] << 16|
            buffer[11] << 24;
      if((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN) ||
         (periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID))
      {
        j2534_periodic_msg.proto_msg.length = buffer[12];
      }
      else
      {
        j2534_periodic_msg.proto_msg.length = 0;
      }
      for(loop_count = 0;
          loop_count < j2534_periodic_msg.proto_msg.length;
          loop_count++)
      {
        j2534_periodic_msg.proto_msg.data[loop_count] = buffer[13+loop_count];
      }
      
      if(PERIODIC_SUCCESS ==
         PERIODIC_msg_cmd(&j2534_periodic_msg,periodic_msg_cmd))
      {
        fl_status_U8 = STATUS_NOERROR;
      }
      else
      {
        fl_status_U8 = ERR_FAILED;
      }
      /* Send Acknowledgment to J2534 DLL*/
      
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = handle_periodic_msg_ACK;
      fl_USB_tx_data_U8A[2] = fl_status_U8;
      fl_USB_tx_data_U8A[3] = j2534_periodic_msg.prmsg_id;
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      break;

    }
  default:
    {
      break;
    }
  }

}

/*******************************************************************************
* Function Name  : process_CAN_IOCTL_cmd
* Input          : USB buffer.
* Return         : None.
* Description    : This function processes the IOCTL cmds related to CAN
*******************************************************************************/
static void process_CAN_IOCTL_cmd(uint8_t *buffer)
{
  uint8_t fl_USB_tx_data_U8A[64], ch_id=0, fl_Protocol_ID_U8;
  uint32_t fl_current_baud_rate_U32=0;
  uint8_t  fl_loopback_status_U8 =0,fl_IOCTL_CMD_U8=0,fl_set_BR_ret_status_U8=0;
  uint8_t fl_SAM_status_U8 = 0,fl_SJW_status_U8 = 0;
  J2534_stError_t fl_filt_stopAll_status;
  Mid_API_Status_t fl_Q_clear_status = MID_FAIL;
  
  memset(&fl_USB_tx_data_U8A[0],0,64);
  fl_IOCTL_CMD_U8 = buffer[2]; /* IOCTL Command */
  if((buffer[0] == CAN_PROTOCOL_ID) || (buffer[0] == ISO15765_PROTO_ID))
  {
    ch_id = 1;
  }
  else if((buffer[0] == CAN_CH1_PROTO_ID) || (buffer[0] == ISO15765_PROTO_CH1_PROTO_ID))
  {
    ch_id = 2;
  }
  else
  {
    /* ERROR: It will never reach here */
  }
  switch(fl_IOCTL_CMD_U8)
  {
  case Get_config:
    {
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;     /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = Get_config_ACK;     /* ACK for Get config CMD*/
      if( Get_data_rate == buffer[4])	        /*Get config parameter ID == Data rate*/
      {
        printf("HFCP DEBUG : CAN IOCTL Get Baud Rate Cmd \r\n");                                        
        //CAN_Mid_Get_Config(buffer[2], CAN_BAUDRATE, &fl_current_baud_rate_U32);
        
        //fl_current_baud_rate_U32 = CAN_Mid_get_current_baudrate(buffer[2]);
		fl_current_baud_rate_U32 = CAN_Mid_get_current_baudrate(ch_id);
        if(0xFFFFFFFF == fl_current_baud_rate_U32)
        {
          fl_USB_tx_data_U8A[3] = ERR_FAILED;
        }
        else
        {
          fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
        }
        fl_USB_tx_data_U8A[4] = buffer[3];	/* ACK for data rate parameter */
        fl_USB_tx_data_U8A[5] = Get_data_rate_ACK;	/* ACK for data rate parameter */
        fl_USB_tx_data_U8A[6] = (uint8_t)((fl_current_baud_rate_U32 )      & 0xFF);
        fl_USB_tx_data_U8A[7] = (uint8_t)((fl_current_baud_rate_U32 >> 8)  & 0xFF);
        fl_USB_tx_data_U8A[8] = (uint8_t)((fl_current_baud_rate_U32 >> 16) & 0xFF);
        fl_USB_tx_data_U8A[9] = (uint8_t)((fl_current_baud_rate_U32 >> 24) & 0xFF);        
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],10,DONT_RELEASE);
      }
      else if( Get_loopback == buffer[4])	/*Get loopback status*/
      {
        printf("HFCP DEBUG : CAN IOCTL Get Loopback Cmd \r\n");
        fl_loopback_status_U8 = LowLevel_CAN_get_loopback_status(ch_id);
        /* Legacy code */        
        if(ERR_INVALID_CHANNEL_ID == fl_loopback_status_U8)
        {
            fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
        }
        else
        {
            fl_USB_tx_data_U8A[3] = fl_loopback_status_U8;
        }
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
        fl_USB_tx_data_U8A[4] = 1;	                            /* number of bytes */
        fl_USB_tx_data_U8A[5] = Get_loopback_ACK;	            /* ACK for loopback status */
        fl_USB_tx_data_U8A[6] = fl_loopback_status_U8;              /* 0 - OFF, 1 - ON */
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],7,DONT_RELEASE);
      }
      else if( Get_sample_point == buffer[4])	/* Get sample point value */
      {
        printf("HFCP DEBUG : CAN IOCTL Get Sample Point Cmd \r\n");        
        //CAN_Mid_Get_Config(ch_id, CAN_SAMPLING_POINT, (uint32_t*)&fl_SAM_status_U8);
        fl_SAM_status_U8 = LowLevel_CAN_get_current_sampling_mode(ch_id);
        /* Legacy code */ 
        if(ERR_INVALID_CHANNEL_ID == fl_SAM_status_U8)
        {
            fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
        }
        else
        {
            fl_USB_tx_data_U8A[3] = fl_SAM_status_U8;
        }       
        
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = Get_sample_point_ACK;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      else if( Get_SJW == buffer[4])	/*Get SJW value */
      {
        printf("HFCP DEBUG : CAN IOCTL Get SJW Cmd \r\n");        
        //CAN_Mid_Get_Config(ch_id, CAN_SJW, (uint32_t*)&fl_SJW_status_U8);
        fl_SJW_status_U8 = LowLevel_CAN_get_current_SJW(ch_id);
        /* Legacy code */
        if(ERR_INVALID_CHANNEL_ID == fl_SJW_status_U8)
        {
            fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
        }
        else
        {
            fl_USB_tx_data_U8A[3] = fl_SJW_status_U8;
        }        
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = Get_SJW_ACK;	/* ACK for data rate parameter */
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      else
      {
        fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      break;
    }
    
  case Set_config:
    {
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = Set_config_ACK;	/* ACK for Get config CMD*/
      if( Set_data_rate == buffer[4])	   /*Set config parameter ID == Data rate*/
      {
        printf("HFCP DEBUG : CAN IOCTL Set Baud Rate Cmd \r\n");
        fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[5];
        fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[6] <<8;
        fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[7] <<16;
        fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[8] <<24;
        
        /* Added Code for Deinitilization CAN Interface.        */
        /* Initialization of CAN with set config baudrate       */
        /* Update the Baud Rate to Global Structure             */
        CAN_Mid_DeInit((ch_id - 1));
        CAN_Mid_Init(((ch_id == 1)? CAN_CH1 : CAN_CH2),fl_current_baud_rate_U32);                
        fl_set_BR_ret_status_U8 = CAN_Mid_set_baudrate(fl_current_baud_rate_U32, ch_id);
        
        fl_USB_tx_data_U8A[3] = fl_set_BR_ret_status_U8;	/* ACK for data rate parameter */
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = Set_data_rate_ACK;	        /* ACK for data rate parameter */
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      else if( Set_loopback == buffer[4])	/*Set config parameter ID == loopback*/
      {
        if(buffer[5] == 1)
        {
           fl_loopback_status_U8 = LowLevel_CAN_enable_loopback(ch_id);
        }
        else if(buffer[5] == 0)
        {
          fl_loopback_status_U8 = LowLevel_CAN_disable_loopback(ch_id);
        }
        else
        {
          fl_loopback_status_U8 = ERR_INVALID_IOCTL_ID;
        }
        fl_USB_tx_data_U8A[3] = fl_loopback_status_U8;	        /* ACK for data rate parameter */
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = Set_loopback_ACK;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      
      else if((Set_sample_point == buffer[4]) ||(Set_SJW == buffer[4]))
      {
        fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      else
      {
        fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
        fl_USB_tx_data_U8A[4] = buffer[3];
        fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      }
      break;
    }
  case clear_all_msg_filters:
    {
      if((buffer[0]==ISO15765_PROTO_ID)||(buffer[0]==CAN_PROTOCOL_ID))
      {
        fl_Protocol_ID_U8 =CAN_PROTOCOL_ID;
      }
      else if((buffer[0]==ISO15765_PROTO_CH1_PROTO_ID)||(buffer[0]==CAN_CH1_PROTO_ID))
      {
        fl_Protocol_ID_U8 =CAN_CH1_PROTO_ID;
      }
      fl_filt_stopAll_status = J2534_ClearAllFilter(fl_Protocol_ID_U8);
      if(fl_filt_stopAll_status==J2534_NO_ERROR)
      {
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Staus No_ERROR */
      }
      else
      {
        fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
      }
      
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = clear_all_msg_filters_ACK; /* Command ID */
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      break;
    }
  case clear_all_periodic_msgs:
    {
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = clear_all_periodic_msgs_ACK;
      if((buffer[0]==ISO15765_PROTO_ID)||(buffer[0]==CAN_PROTOCOL_ID))
      {
        fl_Protocol_ID_U8 =CAN_PROTOCOL_ID;
      }
      else if((buffer[0]==ISO15765_PROTO_CH1_PROTO_ID)||(buffer[0]==CAN_CH1_PROTO_ID))
      {
        fl_Protocol_ID_U8 =CAN_CH1_PROTO_ID;
      }
      suspend_pmsg(fl_Protocol_ID_U8); /* Suspend all periodic messages */
      fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Error status*/
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      break;
    }
    
  case clear_tx_buffer:
    {
      if((buffer[0]==ISO15765_PROTO_ID)||(buffer[0]==CAN_PROTOCOL_ID))
      {        
        fl_Q_clear_status = CAN_ClearQ(CAN1_TX_QUEUE); 
		if(getCAN1TXStatus())
		{
			xSemaphoreGive(xCAN1StartTx);
		}                        
      }
      else if((buffer[0]==ISO15765_PROTO_CH1_PROTO_ID)||(buffer[0]==CAN_CH1_PROTO_ID))
      {        
        fl_Q_clear_status = CAN_ClearQ(CAN2_TX_QUEUE);
		if(getCAN2TXStatus())
		{
			xSemaphoreGive(xCAN2StartTx);
		}
      }
      else
      {
          fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
      }
      
      if(fl_Q_clear_status == MID_PASS)
      {
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Staus No_ERROR */
      }
      else
      {
        fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
      }
      
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = clear_tx_buffer_ACK; /* Command ID */
	  
	  #if GARUDA_USB_DEBUG
		if(ch_id == 1)
		{
			Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
			memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
		}
		else
		{
			Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
			memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
		}	  
	  #endif			
			
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);      
      break;
    }
    
  case clear_rx_buffer:
    {
      if((buffer[0]==ISO15765_PROTO_ID)||(buffer[0]==CAN_PROTOCOL_ID))
      {        
        fl_Q_clear_status = CAN_ClearQ(CAN1_RX_QUEUE);
      }
      else if((buffer[0]==ISO15765_PROTO_CH1_PROTO_ID)||(buffer[0]==CAN_CH1_PROTO_ID))
      {        
        fl_Q_clear_status = CAN_ClearQ(CAN2_RX_QUEUE);
      }
      else
      {
         fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */ 
      }
      
      if(fl_Q_clear_status == MID_PASS)
      {
          fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Staus No_ERROR */
      }      
      else
      {
         fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */ 
      }
            
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = clear_rx_buffer_ACK; /* Command ID */
	  
	  #if GARUDA_USB_DEBUG
      if(ch_id == 1)
	  {
		 Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
		 memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));  
	  }
	  else
	  {
		 Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();  
		 memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
	  }	  
	 
	  #endif
	  
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);      
      break;
    }
  default:
    {
      fl_USB_tx_data_U8A[0] = buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = fl_IOCTL_CMD_U8;	/* ACK for Get config CMD*/
      fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;	/* ACK for data rate parameter */
      fl_USB_tx_data_U8A[4] = buffer[3];
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
      break;
    }
  }  
}




/*******************************************************************************
* Function Name  : process_KWP_command
* Description    :
* Input          : None.
* Return         : None.
*******************************************************************************/
void process_KWP_command(uint8_t *buffer)
{
	uint8_t fl_status_U8,fl_USB_tx_data_U8A[64],command=0;
	uint32_t fl_baudrate_U32 = 0;
	PERIODIC_MSG j2534_periodic_msg;
	uint8_t periodic_msg_cmd = 0;
	J2534_filter_t fl_filter_config;
	uint8_t fl_FilterID,loop_count=0,fl_Protocol_ID_U8;
	J2534_stError_t fl_filt_config_status,fl_filt_stop_status;
	uint32_t current_time_stamp = 0;
	ISO9141_14230_Init_S  fl_App_ISO9141_14230Init_S;
	ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus;
	uint16_t fl_IdxLen;
	/* The Length has to retained with successive Calls */
	static uint16_t fl_KWPTX_LocalLen;
  
	command = buffer[1];
  
	switch(command)
	{
		case KWP_EnableComm:
		{
			memset(&fl_USB_tx_data_U8A,0,64);
			fl_USB_tx_data_U8A[0] = buffer[0] ;
			fl_USB_tx_data_U8A[1] = KWP_EnableComm_ACK ;
			fl_baudrate_U32 = (uint32_t)buffer[5];
			fl_baudrate_U32 <<=8;
			fl_baudrate_U32 |= (uint32_t)buffer[4];
			fl_baudrate_U32 <<=8;
			fl_baudrate_U32 |= (uint32_t)buffer[3];
			fl_baudrate_U32 <<=8;
			fl_baudrate_U32 |= (uint32_t)buffer[2];
	  
			if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
			{								
				ISO_9141_OR_14230 = buffer[0];	/**< Added to check the Active Protocol */				
				
				KWP_connect_flags = (uint32_t)buffer[9];
				KWP_connect_flags <<=8;
				KWP_connect_flags |= (uint32_t)buffer[8];
				KWP_connect_flags <<=8;
				KWP_connect_flags |= (uint32_t)buffer[7];
				KWP_connect_flags <<=8;
				KWP_connect_flags |= (uint32_t)buffer[6];
        
				/* Determine the Initialization structure */
				fl_App_ISO9141_14230Init_S.ProtocolId = buffer[0];
				fl_App_ISO9141_14230Init_S.Baudrate   = fl_baudrate_U32;
				fl_App_ISO9141_14230Init_S.Flags      = KWP_connect_flags;
        
				if(((KWP_connect_flags & ISO9141_K_LINE_ONLY)== ISO9141_K_LINE_ONLY) ||
				   ((KWP_connect_flags & ISO9141_NO_CHECKSUM)== ISO9141_NO_CHECKSUM) ||
					 (KWP_connect_flags == 0x0000000))
				{
					/* Call the Driver Init function */
					ISO9141_14230_Init(&fl_App_ISO9141_14230Init_S);          
					KWP_active = 1;
					fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				}
				else
				{
					fl_USB_tx_data_U8A[2] = ERR_INVALID_FLAGS;
				}
			}
			else
			{
				/* ERROR: It should never enter here */
				fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
				break;
			}
			l_connected_channels++;
			l_connected_channel_Kline = 1;
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
			break;
		}
		
		case KWP_DisableComm:
		{
			memset(&fl_USB_tx_data_U8A,0,64);
			fl_USB_tx_data_U8A[0] = buffer[0] ;
			fl_USB_tx_data_U8A[1] = KWP_DisableComm_ACK ;
			J2534_ClearAllFilter(KWP_PROTOCOL_ID);//buffer[0]);
			suspend_pmsg(KWP_PROTOCOL_ID);//buffer[0]); /* Suspend all periodic messages */
			ISO9141_14230_Reset();
			
			if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
			{				
				ISO_9141_OR_14230 = 0;
				if(l_connected_channels)
				{
					l_connected_channels--;
				}
				l_connected_channel_Kline = 0;
				KWP_active = 0;
				//stop_time_stamp(timestamp_id[GARUDA_KWP_CH1]);
			}
			else
			{
				/* ERROR: It should never enter here */
				fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
				break;
			}
			fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
			break;
		}
		
		case IOCTL_COMMAND:
		{
			process_KWP_IOCTL_cmd(buffer);
			break;
		}
		
		case KWP_Send_msg:
		{
			if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
			{				        
				/* Check the Segment Number if it is 0 or 1 copy the Flag and Length Details */
				if((0 == buffer[2])||(1 == buffer[2]))
				{
					l_App_ISO9141_14230TxMsg_S.Length = ((uint16_t)buffer[3]|(uint16_t)buffer[4]  << 8);
          
					/* If No Segmented Message Then Pass to Lower Layer */
					if(0 == buffer[2])
					{
						/* If Length is 0 then dont copy data and Flags */
						if(0 != l_App_ISO9141_14230TxMsg_S.Length)
						{
							l_App_ISO9141_14230TxMsg_S.Flags = ((uint32_t)buffer[5]       |
							(uint32_t)buffer[6]  << 8  |
							(uint32_t)buffer[7]  << 16 |
							(uint32_t)buffer[8]  << 24 );
							
							for(fl_IdxLen = 0; fl_IdxLen < l_App_ISO9141_14230TxMsg_S.Length; fl_IdxLen++)
							{
								l_App_ISO9141_14230TxMsg_S.Data[fl_IdxLen] = buffer[9+fl_IdxLen];					
							}
						}
						else
						{
							/* Do Nothing*/
						}
						
						/* MArk the Flag = NO Segmented Transfer */
						l_KWPTX_SegTrnsfr = 0;
						/* Call the Write Message function */
						fl_ISO9141_14230RetStatus = ISO9141_14230_WriteMsg(&l_App_ISO9141_14230TxMsg_S);
            
						/* Determine the Response */
						memset(&fl_USB_tx_data_U8A,0,64);
						fl_USB_tx_data_U8A[0] = buffer[0];
						fl_USB_tx_data_U8A[1] = KWP_Send_msg_ACK ;
						fl_USB_tx_data_U8A[2] = buffer[2] ;
						/* Update time stamp on USB TX Frame */
						current_time_stamp = l_App_ISO9141_14230TxMsg_S.Timestamp;
						fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
						fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
						fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
						fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
						
						/* Update the Error Code based on the return */
						if(fl_ISO9141_14230RetStatus == ISO9141_14230_TXQ_FULL)
						{
							fl_USB_tx_data_U8A[3] = ERR_BUFFER_FULL;
						}
						else
						{
							fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
						}
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
					}
					/* For Segment No 1 */
					else
					{
						l_App_ISO9141_14230TxMsg_S.Flags = ((uint32_t)buffer[5]       |
						(uint32_t)buffer[6]  << 8  |
						(uint32_t)buffer[7]  << 16 |
						(uint32_t)buffer[8]  << 24 );
					
						/* MArk the Flag = Segmented Transfer */
						l_KWPTX_SegTrnsfr = 1;
						/* The Local Length is 0 since 1st Segment */
						fl_KWPTX_LocalLen = 0;
					
						/* There are 54 more bytes in the first USB frame */
						for(fl_IdxLen = 0;
							((fl_IdxLen <= 54) && (fl_KWPTX_LocalLen < l_App_ISO9141_14230TxMsg_S.Length));
							fl_IdxLen++)
						{
						  l_App_ISO9141_14230TxMsg_S.Data[fl_KWPTX_LocalLen] = buffer[9+fl_IdxLen];
						  fl_KWPTX_LocalLen++;
						}
						if(fl_KWPTX_LocalLen == l_App_ISO9141_14230TxMsg_S.Length)
						{
						  /* Determine the Response */
						  memset(&fl_USB_tx_data_U8A,0,64);
						  fl_USB_tx_data_U8A[0] = buffer[0];
						  fl_USB_tx_data_U8A[1] = KWP_Send_msg_ACK ;
						  fl_USB_tx_data_U8A[2] = buffer[2] ;
						  fl_USB_tx_data_U8A[3] = ERR_FAILED;
						  /*    ERR_TOO_FEW_BYTES; - To be fixed - with a different strategy
						  - Mahadev */
						  /* Currently Timestamp is not added */
						  (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
						}
						else
						{
						  /* Do Nothing */
						}
					}
				}
				/* It IS Segmented Message Read the Complete Message */
				else if((1 == l_KWPTX_SegTrnsfr)&&(buffer[2] > 1))
				{
					/* Data will be from 3 to 64 excluding ProtoID[0],ServiceId[1] and SEG No[2] */
					for(fl_IdxLen = 0;
						((fl_IdxLen < 61) && (fl_KWPTX_LocalLen < l_App_ISO9141_14230TxMsg_S.Length));
						fl_IdxLen++)
					{
						l_App_ISO9141_14230TxMsg_S.Data[fl_KWPTX_LocalLen] = buffer[3+fl_IdxLen];
						fl_KWPTX_LocalLen++;
					}
					/* All Data Copied Segmented Transfer Ends */
					if(fl_KWPTX_LocalLen == l_App_ISO9141_14230TxMsg_S.Length)
					{
						/* MArk the Flag = Segmented Transfer Ended*/
						l_KWPTX_SegTrnsfr = 0;
						/* Call the Write Message function */
						fl_ISO9141_14230RetStatus =
						ISO9141_14230_WriteMsg(&l_App_ISO9141_14230TxMsg_S);
						/* Determine the Response */
						memset(&fl_USB_tx_data_U8A,0,64);
						fl_USB_tx_data_U8A[0] = buffer[0];
						fl_USB_tx_data_U8A[1] = KWP_Send_msg_ACK ;
						fl_USB_tx_data_U8A[2] = buffer[2] ;
						/* Update time stamp on USB TX Frame */
						current_time_stamp = l_App_ISO9141_14230TxMsg_S.Timestamp;
						fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
						fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
						fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
						fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
						/* Update the Error Code based on the return */
						if(fl_ISO9141_14230RetStatus == ISO9141_14230_TXQ_FULL)
						{
							fl_USB_tx_data_U8A[3] = ERR_BUFFER_FULL;
						}
						else
						{
							fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
						}
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
					}
				}
				else
				{
					
				}
			}
			else
			{
				/* ERROR: It should never enter here */
				fl_USB_tx_data_U8A[0] = buffer[0];
				fl_USB_tx_data_U8A[1] = KWP_Send_msg_ACK ;
				fl_USB_tx_data_U8A[2] = buffer[2] ;
				fl_USB_tx_data_U8A[3] = ERR_INVALID_PROTOCOL_ID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			}
			break;
		}
	
		case Start_msg_filter:
		{
			if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
			{
				fl_Protocol_ID_U8 = KWP_PROTOCOL_ID;
			}
			/**< Changed for differentiating 14230 and 9141 protocol */
			fl_filter_config.Protocol_ID = fl_Protocol_ID_U8; /* buffer[0]; */ 
			fl_filter_config.filterType = (J2534_filterType_t)buffer[2];
			fl_filter_config.MaskLen = buffer[3];
			for(loop_count = 0; loop_count < fl_filter_config.MaskLen; loop_count++)
			{
				fl_filter_config.maskMsg[loop_count] = buffer[4 + loop_count];
			}
			fl_filter_config.PatternLen = buffer[4+fl_filter_config.MaskLen];
			for(loop_count = 0; loop_count < fl_filter_config.PatternLen; loop_count++)
			{
				fl_filter_config.patternMsg[loop_count] = buffer[5+fl_filter_config.MaskLen + loop_count];
			}
			fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config,&fl_FilterID);
      
			if(fl_filt_config_status != J2534_NO_ERROR)
			{
				if(fl_filt_config_status == J2534_FLT_NOT_FREE)
				{
					fl_status_U8 = ERR_EXCEEDED_LIMIT;
				}
				else
				{
					fl_status_U8 = ERR_FAILED;
				}
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
			}
			else
			{
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
			}
			break;
		}
		
		case Stop_msg_filter:
		{
			if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
			{
				fl_Protocol_ID_U8 = KWP_PROTOCOL_ID;
			}
		
			/* fl_Protocol_ID_U8 = buffer[0]; */ /**< Commented to have a common Id for 9141 and 14230 */
			fl_FilterID = buffer[2];
			fl_filt_stop_status = J2534_ClearFilter(fl_FilterID,fl_Protocol_ID_U8);
			if(fl_filt_stop_status != J2534_NO_ERROR)
			{
				if(fl_filt_stop_status == J2534_INVLD_FLTID)
				{
					fl_status_U8 = ERR_INVALID_FILTER_ID;
				}
				else
				{
					fl_status_U8 = ERR_FAILED;
				}
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
				fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
				
			}
			else
			{
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
				fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			}
			break;
		}
		
		case handle_periodic_msg:
		{
			if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
			{
				fl_Protocol_ID_U8 = KWP_PROTOCOL_ID;
			}
			
			periodic_msg_cmd = buffer[2];
			j2534_periodic_msg.protocol_id= fl_Protocol_ID_U8; /* buffer[0]; */
			
			j2534_periodic_msg.periodicity  = buffer[3]      |
			buffer[4] << 8 |
			buffer[5] << 16|
			buffer[6] << 24;
			
			j2534_periodic_msg.prmsg_id = buffer[7];
			
			j2534_periodic_msg.proto_msg.tx_flags = buffer[8]       |
			buffer[9]  << 8 |
			buffer[10] << 16|
			buffer[11] << 24;
			
			if((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN) ||
			(periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID))
			{
				j2534_periodic_msg.proto_msg.length = buffer[12];
			}
			else
			{
				j2534_periodic_msg.proto_msg.length = 0;
			}
			
			for(loop_count = 0;
			loop_count < j2534_periodic_msg.proto_msg.length;
			loop_count++)
			{
				j2534_periodic_msg.proto_msg.data[loop_count] = buffer[13+loop_count];
			}
      
			if(PERIODIC_SUCCESS ==
			PERIODIC_msg_cmd(&j2534_periodic_msg,periodic_msg_cmd))
			{
				fl_status_U8 = STATUS_NOERROR;
			}
			else
			{
				fl_status_U8 = ERR_FAILED;
			}
			
			/* Send Acknowledgement to J2534 DLL*/      
			memset(&fl_USB_tx_data_U8A,0,64);
			fl_USB_tx_data_U8A[0] = buffer[0] ;
			fl_USB_tx_data_U8A[1] = handle_periodic_msg_ACK;
			fl_USB_tx_data_U8A[2] = fl_status_U8;
			fl_USB_tx_data_U8A[3] = j2534_periodic_msg.prmsg_id;
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			break;
		}
		
		default:
		{
			break;
		}
	}
	return ;
}



/*******************************************************************************
* Function Name  : process_KWP_IOCTL_cmd
* Input          : USB buffer.
* Return         : None.
* Description    : This function processes the IOCTL cmds related to KWP
*******************************************************************************/
static void process_KWP_IOCTL_cmd(uint8_t *buffer)
{
	uint32_t fl_KWP_par_val_U32;
	uint8_t  fl_USB_tx_data_U8A[64];
	J2534_stError_t fl_filt_stopAll_status;
	ISO9141_14230_Cmd_S   fl_App_ISO9141_14230Cmd_S;
	ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus = NO_ERROR;
	//uint8_t  fl_channel_no_U8;  
  
	if( (buffer[0] == KWP_PROTOCOL_ID) || (buffer[0] == ISO_9141_PROTO_ID) )
	{
		//fl_channel_no_U8 = 1;
	}
	else
	{
		//fl_channel_no_U8 = 2;
	}
	memset(&fl_USB_tx_data_U8A,0,64);
  
	fl_USB_tx_data_U8A[0] = buffer[0];
	fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
  
	/* Determine the Command Structure */
	/* Get the Ioctl ID*/
	fl_App_ISO9141_14230Cmd_S.IOCtlId = buffer[2];
	/*Length data ( Only for Fivebaud and Fast Init)*/
	fl_App_ISO9141_14230Cmd_S.Length  = buffer[3];
  
	/* Clear All Periodic Messages Command */
	if(clear_all_periodic_msgs == fl_App_ISO9141_14230Cmd_S.IOCtlId)
	{
		fl_USB_tx_data_U8A[2] = clear_all_periodic_msgs_ACK;
		suspend_pmsg(KWP_PROTOCOL_ID);//buffer[0]); /* Suspend all periodic messages */
		fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Error status*/
		(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
	}
	/* Clear All Message Filters Command */
	else if (clear_all_msg_filters == fl_App_ISO9141_14230Cmd_S.IOCtlId)
	{
		fl_USB_tx_data_U8A[2] = clear_all_msg_filters_ACK;	/* ACK for Clear All Filters*/
		fl_filt_stopAll_status = J2534_ClearAllFilter(KWP_PROTOCOL_ID);//buffer[0]);
		if(fl_filt_stopAll_status==J2534_NO_ERROR)
		{
			fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Status No_ERROR */
		}
		else
		{
			fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
		}
		(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
	}
	else
	{
		/* Determine if the IOCtl is GET_CONFIG or SET_CONFIG to check for param id and param val */
		if((fl_App_ISO9141_14230Cmd_S.IOCtlId == GET_CONFIG) ||
		(fl_App_ISO9141_14230Cmd_S.IOCtlId == SET_CONFIG))
		{
			/* Parameter ID for Get Config and Setconfig */
			fl_App_ISO9141_14230Cmd_S.ParamId = buffer[4];
			/* Copy the Parameter Value */
			if(fl_App_ISO9141_14230Cmd_S.IOCtlId == SET_CONFIG)
			{        
				fl_KWP_par_val_U32 = buffer[5]      |
				buffer[6] << 8 |
				buffer[7] << 16|
				buffer[8] << 24;
			}
			fl_App_ISO9141_14230Cmd_S.pData = &fl_KWP_par_val_U32;
		}
		/* If IOCtl has no param id and value then assign address of data */
		else
		{
			fl_App_ISO9141_14230Cmd_S.pData = &buffer[4];
		}
    
		/* Call the Driver Command function */
		fl_ISO9141_14230RetStatus = ISO9141_14230_Command(&fl_App_ISO9141_14230Cmd_S);
    
    
		/* Determine the response */
		fl_USB_tx_data_U8A[2] = fl_App_ISO9141_14230Cmd_S.IOCtlId;
		fl_USB_tx_data_U8A[4] = fl_App_ISO9141_14230Cmd_S.Length;
    
		/* For Get / Set Config copy the Parameter value and Id to the
		Response frame */
		if((fl_App_ISO9141_14230Cmd_S.IOCtlId == GET_CONFIG) ||
			(fl_App_ISO9141_14230Cmd_S.IOCtlId == SET_CONFIG))
		{
			fl_USB_tx_data_U8A[5] = fl_App_ISO9141_14230Cmd_S.ParamId;
			if(fl_App_ISO9141_14230Cmd_S.IOCtlId == GET_CONFIG)
			{
				fl_USB_tx_data_U8A[6] = (uint8_t)((fl_KWP_par_val_U32 )      & 0xFF);
				fl_USB_tx_data_U8A[7] = (uint8_t)((fl_KWP_par_val_U32 >> 8)  & 0xFF);
				fl_USB_tx_data_U8A[8] = (uint8_t)((fl_KWP_par_val_U32 >> 16) & 0xFF);
				fl_USB_tx_data_U8A[9] = (uint8_t)((fl_KWP_par_val_U32 >> 24) & 0xFF);
			}
		}
    
		/* Update the Error Code based on the return */
		if(fl_ISO9141_14230RetStatus == NO_ERROR)
		{
			fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
		}
		else if(fl_ISO9141_14230RetStatus == INVALID_COMMAND)
		{
			fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
		}
		else if(fl_ISO9141_14230RetStatus == INVALID_PARAMETERID)
		{
			fl_USB_tx_data_U8A[3] = ERR_FAILED;
		}
		else
		{
			/* Do nothing */
		}
		
		/* Send the Response only if its not FAST INIT ot FIVE BAUD INIT */
		if((fl_App_ISO9141_14230Cmd_S.IOCtlId != FAST_INIT) &&
			(fl_App_ISO9141_14230Cmd_S.IOCtlId != FIVE_BAUD_INIT))
		{
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],10,DONT_RELEASE);
		}
	}
}

/*******************************************************************************
* Function Name  : process_J1939_IOCTL_cmd
* Description    :
* Input          : None.
* Return         : None.

PID  CMD  IOCTL CMDID			  ConnectFlags(EX_ID)
0xC6 0x06	0xAA 

IOTCL (0x06)

IOCTL CMD : Get_config				:
			Set_config				:
			clear_all_msg_filters	:
			clear_all_periodic_msgs	:
			clear_tx_buffer			:
			clear_rx_buffer			:
*******************************************************************************/
ADDRESS_CLAIM AdressClaim;
static void process_J1939_IOCTL_cmd(uint8_t *buffer)
{
	uint8_t fl_USB_tx_data_U8A[64], ch_id=0, fl_Protocol_ID_U8;
	uint32_t fl_current_baud_rate_U32=0;
	uint8_t  fl_loopback_status_U8 =0,fl_IOCTL_CMD_U8=0,fl_set_BR_ret_status_U8=0;
	uint8_t fl_SAM_status_U8 = 0,fl_SJW_status_U8 = 0;
	J2534_stError_t fl_filt_stopAll_status;
	Mid_API_Status_t fl_Q_clear_status = MID_FAIL;
	CAN_TX_Msg_t  CAN_Addr_Claim_Tx_msg_S;
	uint8_t command;
	uint8_t fl_Q_Status;
	//uint32_t NumofBytes =0;
	uint8_t srcAddtoClaim = 0;
	
	
	
	memset(&fl_USB_tx_data_U8A[0],0,64);
	fl_IOCTL_CMD_U8 = buffer[2]; /* IOCTL Command */
	
	if(buffer[0] == J1939_PROTOCOL_ID)
	{
		ch_id = 1;
	}
	else if(buffer[0] == J1939_CH1_PROTOCOL_ID) 
	{
		ch_id = 2;
	}
	else
	{
		/* ERROR: It will never reach here */
	}
	
	switch(fl_IOCTL_CMD_U8)
	{
		case Get_config:
		{
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;     /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = Get_config_ACK;     /* ACK for Get config CMD*/
			
			command = buffer[4];
			
			switch(command)
			{
				case Get_data_rate :
				{
					fl_current_baud_rate_U32 = CAN_Mid_get_current_baudrate(ch_id);
					if(0xFFFFFFFF == fl_current_baud_rate_U32)
					{
						fl_USB_tx_data_U8A[3] = ERR_FAILED;
					}
					else
					{
						fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
					}
					fl_USB_tx_data_U8A[4] = buffer[3];	/* ACK for data rate parameter */
					fl_USB_tx_data_U8A[5] = Get_data_rate_ACK;	/* ACK for data rate parameter */
					fl_USB_tx_data_U8A[6] = (uint8_t)((fl_current_baud_rate_U32 )      & 0xFF);
					fl_USB_tx_data_U8A[7] = (uint8_t)((fl_current_baud_rate_U32 >> 8)  & 0xFF);
					fl_USB_tx_data_U8A[8] = (uint8_t)((fl_current_baud_rate_U32 >> 16) & 0xFF);
					fl_USB_tx_data_U8A[9] = (uint8_t)((fl_current_baud_rate_U32 >> 24) & 0xFF);
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],10,DONT_RELEASE);
				break;	
				}
				case Get_loopback :
				{
					fl_loopback_status_U8 = LowLevel_CAN_get_loopback_status(ch_id);
					/* Legacy code */
					if(ERR_INVALID_CHANNEL_ID == fl_loopback_status_U8)
					{
						fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
					}
					else
					{
						fl_USB_tx_data_U8A[3] = fl_loopback_status_U8;
					}
					fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
					fl_USB_tx_data_U8A[4] = 1;									/* number of bytes */
					fl_USB_tx_data_U8A[5] = Get_loopback_ACK;					/* ACK for loopback status */
					fl_USB_tx_data_U8A[6] = fl_loopback_status_U8;              /* 0 - OFF, 1 - ON */
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],7,DONT_RELEASE);
				break;	
				}
				case Get_sample_point :
				{					
					fl_SAM_status_U8 = LowLevel_CAN_get_current_sampling_mode(ch_id);
				
					/* Legacy code */
					if(ERR_INVALID_CHANNEL_ID == fl_SAM_status_U8)
					{
						fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
					}
					else
					{
						fl_USB_tx_data_U8A[3] = fl_SAM_status_U8;
					}
				
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = Get_sample_point_ACK;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
				break;	
				}
				case Get_SJW :
				{
					fl_SJW_status_U8 = LowLevel_CAN_get_current_SJW(ch_id);
				
					/* Legacy code */
					if(ERR_INVALID_CHANNEL_ID == fl_SJW_status_U8)
					{
						fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
					}
					else
					{
						fl_USB_tx_data_U8A[3] = fl_SJW_status_U8;
					}
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = Get_SJW_ACK;	/* ACK for data rate parameter */
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
				break;	
				}
				
				case Get_J1939_T1:
				{
					break;
				}
				
				case Get_J1939_T2:
				{
					break;
				}
				
				case Get_J1939_T3:
				{
					break;
				}
				
				case Get_J1939_T4:
				{
					break;
				}
				
				case Get_J1939_BRDCST_MIN_DELAY:
				{
					break;
				}
				
				default:
				{
					fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
				break;
				}
			}
			break;
		}		
		case Set_config:
		{
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = Set_config_ACK;	/* ACK for Get config CMD*/
			
			command = buffer[4];
			
			switch(command)
			{
				case Set_data_rate :
				{
					fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[5];
					fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[6] <<8;
					fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[7] <<16;
					fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)buffer[8] <<24;
					
					/* Added Code for Deinitilization CAN Interface.        */
					/* Initialization of CAN with set config baudrate       */
					/* Update the Baud Rate to Global Structure             */
					CAN_Mid_DeInit((ch_id - 1));
					CAN_Mid_Init(((ch_id == 1)? CAN_CH1 : CAN_CH2),fl_current_baud_rate_U32);
					fl_set_BR_ret_status_U8 = CAN_Mid_set_baudrate(fl_current_baud_rate_U32, ch_id);
					
					fl_USB_tx_data_U8A[3] = fl_set_BR_ret_status_U8;	/* ACK for data rate parameter */
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = Set_data_rate_ACK;	        /* ACK for data rate parameter */
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
					break;
				}
				case Set_loopback :
				{
					if(buffer[5] == 1)
					{
						fl_loopback_status_U8 = LowLevel_CAN_enable_loopback(ch_id);
					}
					else if(buffer[5] == 0)
					{
						fl_loopback_status_U8 = LowLevel_CAN_disable_loopback(ch_id);
					}
					else
					{
						fl_loopback_status_U8 = ERR_INVALID_IOCTL_ID;
					}
					fl_USB_tx_data_U8A[3] = fl_loopback_status_U8;	        /* ACK for data rate parameter */
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = Set_loopback_ACK;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
					break;
				}
				case Set_sample_point :
				{
					fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
					break;
				}
				case Set_SJW :
				{
					fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
					break;
				}
				
				case Set_J1939_T1:
				{
					break;
				}
				
				case Set_J1939_T2:
				{
					break;
				}
				
				case Set_J1939_T3:
				{
					break;
				}
				
				case Set_J1939_T4:
				{
					break;
				}
				
				case Set_J1939_BRDCST_MIN_DELAY:
				{
					break;
				}
				
				default:
				{
					fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
					fl_USB_tx_data_U8A[4] = buffer[3];
					fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
					break;
				}
			}
			break;
		}
		case clear_all_msg_filters:
		{
			if(buffer[0]==J1939_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 =J1939_PROTOCOL_ID;
			}
			else if(buffer[0]==J1939_CH1_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 =J1939_CH1_PROTOCOL_ID;
			}
			fl_filt_stopAll_status = J2534_ClearAllFilter(fl_Protocol_ID_U8);
			if(fl_filt_stopAll_status==J2534_NO_ERROR)
			{
				fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Staus No_ERROR */
			}
			else
			{
				fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
			}
			
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = clear_all_msg_filters_ACK; /* Command ID */
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			break;
		}
		case clear_all_periodic_msgs:
		{
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = clear_all_periodic_msgs_ACK;
			
			if(buffer[0]==J1939_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 =J1939_PROTOCOL_ID; /* J1939 : TB Decided */
			}
			else if(buffer[0]==J1939_CH1_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 =J1939_CH1_PROTOCOL_ID; /* J1939 : TB Decided */
			}
			suspend_pmsg(fl_Protocol_ID_U8); /* Suspend all periodic messages */
			fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Error status*/
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			break;
		}		
		case clear_tx_buffer:
		{
			if(buffer[0]==J1939_PROTOCOL_ID)
			{
				fl_Q_clear_status = CAN_ClearQ(CAN1_TX_QUEUE);
				if(getCAN1TXStatus())
				{
					xSemaphoreGive(xCAN1StartTx);
				}
			}
			else if(buffer[0]==J1939_CH1_PROTOCOL_ID)
			{
				fl_Q_clear_status = CAN_ClearQ(CAN2_TX_QUEUE);
				if(getCAN2TXStatus())
				{
					xSemaphoreGive(xCAN2StartTx);
				}
			}
			else
			{
				fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
			}
			
			if(fl_Q_clear_status == MID_PASS)
			{
				fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Staus No_ERROR */
			}
			else
			{
				fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
			}
			
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = clear_tx_buffer_ACK; /* Command ID */
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			break;
		}		
		case clear_rx_buffer:
		{
			if(buffer[0]==J1939_PROTOCOL_ID)
			{
				fl_Q_clear_status = CAN_ClearQ(CAN1_RX_QUEUE);
			}
			else if(buffer[0]==J1939_CH1_PROTOCOL_ID)
			{
				fl_Q_clear_status = CAN_ClearQ(CAN2_RX_QUEUE);
			}
			else
			{
				fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
			}
			
			if(fl_Q_clear_status == MID_PASS)
			{
				fl_USB_tx_data_U8A[3] = STATUS_NOERROR;	/* Staus No_ERROR */
			}
			else
			{
				fl_USB_tx_data_U8A[3] = ERR_FAILED; /* Failed due to Wrong Protocol ID */
			}
			
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = clear_rx_buffer_ACK; /* Command ID */
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			break;
		}
		case protect_J1939_addr :
		{
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = protect_J1939_addr_ACK;	/* ACK for Get config CMD*/
			fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			
			#if 1			
			/*< Number of bytes in a array */
			//NumofBytes = buffer[3];
			
			/*Source Address to claim */
			srcAddtoClaim = buffer[4]; 
						
			CAN_Addr_Claim_Tx_msg_S.ide = TRUE;
			CAN_Addr_Claim_Tx_msg_S.rtr = 0;
			CAN_Addr_Claim_Tx_msg_S.dlc = 8;
			CAN_Addr_Claim_Tx_msg_S.msg_id =  0x18 << 24;
			CAN_Addr_Claim_Tx_msg_S.msg_id =  CAN_Addr_Claim_Tx_msg_S.msg_id | PDU_FORMAT_ADDRESS_CLAIM << 16;
			CAN_Addr_Claim_Tx_msg_S.msg_id =  CAN_Addr_Claim_Tx_msg_S.msg_id | GLOBAL_ADDRESS << 8;
			CAN_Addr_Claim_Tx_msg_S.msg_id =  CAN_Addr_Claim_Tx_msg_S.msg_id | srcAddtoClaim;			
			
			memcpy(&CAN_Addr_Claim_Tx_msg_S.data[0], &buffer[5],8);//NumofBytes	
						
			if(ch_id == 1)
			{				
				fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &CAN_Addr_Claim_Tx_msg_S);
			}
			else if (ch_id == 2)
			{
				fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &CAN_Addr_Claim_Tx_msg_S);                       
			}
			else
			{
				
			}
			
			if(MID_PASS == fl_Q_Status)
			{
				AdressClaim.sourceAddr = srcAddtoClaim;
				AdressClaim.msgId = CAN_Addr_Claim_Tx_msg_S.msg_id;
				AdressClaim.protocol_id = ch_id;
				AdressClaim.periodicity = 300;
				AdressClaim.localperiodicity = AdressClaim.periodicity;
				memcpy(&AdressClaim.nameIdentifier[0], &CAN_Addr_Claim_Tx_msg_S.data[0],8);
				AdressClaimInitiated = TRUE;
			}
			
			#endif
			break;
		}						
		default:
		{
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
			fl_USB_tx_data_U8A[2] = fl_IOCTL_CMD_U8;	/* ACK for Get config CMD*/
			fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[4] = buffer[3];
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
			break;
		}
	}
}

#define OLD_FRAME_FORMAT	1

void AdressClaimHandler(void)
{
	uint8_t resp[64];
	uint32_t time_stamp = 0;
	uint32_t rx_flags = 0x00000000;
	uint8_t dlc;	
		
	if(AdressClaimInitiated)
	{
		AdressClaim.localperiodicity--;
		if(0 == AdressClaim.localperiodicity) /**< Wait for 250 msecs for response*/ 
		{		
			dlc = 1;	
			rx_flags |= CAN_EXT_MSG;
			
			if(AdressClaimStatus == 0x00) /**< No response received : Address Claimed Successfully */
			{
				rx_flags |= J1939_ADDRESS_CLAIMED;
				device_claimed_Address = AdressClaim.sourceAddr;
			}
			else if(AdressClaimStatus == 0x01) /**< Positive Response response received : : Address Claimed Successfully */
			{
				rx_flags |= J1939_ADDRESS_CLAIMED;
				device_claimed_Address = AdressClaim.sourceAddr;
			}
			else if(AdressClaimStatus == 0x02) /**< Error Response response received : Not possible to claim the address */
			{
				rx_flags |= J1939_ADDRESS_LOST;
				device_claimed_Address = 0xFE;			
			}
			else
			{
				
			}
			
			#if MULTI_MODE_FRAME
			resp[0] = ( (1 == AdressClaim.protocol_id) ? get_CAN_or_ISO15756_or_J1939() : get_CANCH1_or_ISO15756CH1_or_J1939CH1());
			resp[1] = J1939_Receive_msg; 
			resp[2] = 0; /* Segment number */
			resp[3] = MODE | 0x01;           /* UPDATE THE MODE AND No of frames field, which is 1 */
			resp[4] = CAN_FIXED_PACKET_LENGTH + 4 + dlc; //NEED TO CHECK
			
			resp[5] = (uint8_t)(rx_flags & 0x000000FF);
			resp[6] = (uint8_t)((rx_flags >> 8) & 0x000000FF);
			
			get_time_stamp(&time_stamp);
			resp[7] = (uint8_t) ( time_stamp & 0x000000FF);
			resp[8] = (uint8_t)((time_stamp >> 8) & 0x000000FF);
			resp[9] = (uint8_t)((time_stamp >> 16) & 0x000000FF);
			resp[10] = (uint8_t)((time_stamp >> 24) & 0x000000FF);
			 
			resp[11] = (uint8_t)((AdressClaim.msgId  >> 24)  & 0x000000FF);
			resp[12] = (uint8_t)((AdressClaim.msgId  >> 16)  & 0x000000FF);
			resp[13] = (uint8_t)((AdressClaim.msgId  >> 8)   & 0x000000FF);
			resp[14] = (uint8_t)((AdressClaim.msgId)         & 0x000000FF);
			
			resp[15] = AdressClaim.sourceAddr;
			#endif
			
			#if OLD_FRAME_FORMAT
			resp[0] = ( (1 == AdressClaim.protocol_id) ? get_CAN_or_ISO15756_or_J1939() : get_CANCH1_or_ISO15756CH1_or_J1939CH1());
			resp[1] = J1939_Receive_msg;
			resp[2] = 0; /* Segment number */
			resp[3] = STATUS_NOERROR;
			
			resp[4] =  dlc + 4; 
			resp[5] = 0;  /* MSB of length */
						
			resp[6] = (uint8_t)(rx_flags & 0x000000FF);
			resp[7] = (uint8_t)((rx_flags >> 8) & 0x000000FF);
			resp[8] = (uint8_t)((rx_flags >> 16) & 0x000000FF);
			resp[9] = (uint8_t)((rx_flags >> 24) & 0x000000FF);
						
			get_time_stamp(&time_stamp);
			resp[10] = (uint8_t) ( time_stamp & 0x000000FF);
			resp[11] = (uint8_t)((time_stamp >> 8) & 0x000000FF);
			resp[12] = (uint8_t)((time_stamp >> 16) & 0x000000FF);
			resp[13] = (uint8_t)((time_stamp >> 24) & 0x000000FF);
						
			resp[14] = (uint8_t)((AdressClaim.msgId  >> 24)  & 0x000000FF);
			resp[15] = (uint8_t)((AdressClaim.msgId  >> 16)  & 0x000000FF);
			resp[16] = (uint8_t)((AdressClaim.msgId  >> 8)   & 0x000000FF);
			resp[17] = (uint8_t)((AdressClaim.msgId)         & 0x000000FF);
						
			resp[18] = AdressClaim.sourceAddr;
			#endif
			(void)Garuda_Tx_data_on_USB(&resp[0],  64, DONT_RELEASE_ISR);
			
			AdressClaimInitiated = 0;
		}
	}
}

void suspend_J1939_addressClaim(void)
{
	AdressClaimInitiated = 0;
	device_claimed_Address = 0xFE;
	memset(&AdressClaim,0, sizeof(ADDRESS_CLAIM));
}


/*******************************************************************************
* Function Name  : can_handle_periodic_msg(BYTE i)
* Description    :
* Input          : pvParameters	:
* Output         : None
* Return         : void
*******************************************************************************/
void J1939_AddressClaim_Global_Response(uint8_t *p_pJ2534Msg, uint16_t p_MsgLen, GARUDA_ChannelNum_t GarudaChannel)
{
	uint8_t loop_cnt=0;
	CAN_TX_Msg_t  fl_msg;
	Mid_API_Status_t fl_Q_Status;
			
	memset(&fl_msg, 0, sizeof(CAN_TX_Msg_t));		
	fl_msg.rtr = 0; /**< fl_msg.tx_app_buff.is_rem_frm = 0; */	
	fl_msg.ide = TRUE; /**<  fl_msg.tx_app_buff.is_ext_frm = TRUE; */	
		
	fl_msg.msg_id =  fl_msg.msg_id | 0x18 << 24;
	fl_msg.msg_id =  fl_msg.msg_id | PDU_FORMAT_ADDRESS_CLAIM << 16;
	fl_msg.msg_id =  fl_msg.msg_id | GLOBAL_ADDRESS << 8;
	fl_msg.msg_id =  fl_msg.msg_id | device_claimed_Address << 0;		
			
	fl_msg.dlc = p_MsgLen - 4;
	
	for(loop_cnt=0; loop_cnt < fl_msg.dlc; loop_cnt++)
	{
		fl_msg.data[loop_cnt] = AdressClaim.nameIdentifier[loop_cnt];
	}
	
	
	/* Add To Queue */
	if(GARUDA_J1939_CH1==GarudaChannel) //GARUDA_J1939_CH1
	{
		fl_Q_Status = CAN_Mid_Transmit_ISR(CAN_CH1, &fl_msg);
	}
	else if(GARUDA_J1939_CH2==GarudaChannel)
	{
		fl_Q_Status = CAN_Mid_Transmit_ISR(CAN_CH2, &fl_msg);
	}
	else
	{
		/* Do Nothing */
	}
	if (fl_Q_Status == MID_FAIL)
	{
		/* Queue is Full -- Not Decided the Action next */
	}
}






#if 1
/*******************************************************************************
* Function Name  : process_J1939_command
* Description    :
* Input          : None.
* Return         : None.

J1939_EnableComm :
PID  CMD  BaudRate			  ConnectFlags(EX_ID)
0xC6 0x02 0xAA 0xBB 0xCC 0xDD 0xFF 0xFF 0xFF 0xFF   
0xC7 0x02  
*******************************************************************************/
void process_J1939_command( uint8_t *buffer )
{
  uint8_t fl_channel_no_U8,fl_USB_tx_data_U8A[64],command=0;
  uint8_t fl_status_U8=0;
  uint32_t fl_baud_rate_U32;
  CAN_TX_Msg_t  fl_CAN_Tx_msg_S;
  PERIODIC_MSG j2534_periodic_msg;
  uint8_t periodic_msg_cmd = 0;
  uint8_t fl_Protocol_ID_U8;
  uint8_t fl_connection_flag_U8;
  J2534_filter_t fl_filter_config;
  J2534_stError_t fl_filt_config_status,fl_filt_stop_status;
  uint32_t fl_msg_id = 0, fl_tx_flags = 0;
  uint16_t msg_cnt = 0, data_len = 0;
  uint8_t fl_Q_Status;
  uint8_t Ack_Required=0;
  uint8_t ch_id=0,loop_count;
  uint8_t base_indx = 0;
  uint32_t current_time_stamp = 0;
  uint8_t fl_FilterID;
  //uint8_t SourceAddress;

  command = buffer[1];
  
  switch(command)
  {
	  case J1939_EnableComm:
		{
			fl_status_U8 = STATUS_NOERROR;
			fl_baud_rate_U32 = (uint32_t)buffer[2];
			fl_baud_rate_U32 = (fl_baud_rate_U32)| (uint32_t)buffer[3] << 8;
			fl_baud_rate_U32 = (fl_baud_rate_U32)| (uint32_t)buffer[4] << 16;
			fl_baud_rate_U32 = (fl_baud_rate_U32)| (uint32_t)buffer[5] << 24;
			
			if(buffer[0] == J1939_PROTOCOL_ID)
			{
				fl_channel_no_U8 = CAN_CH1;
				CAN_or_ISO15765_J1939 = buffer[0];
				CAN_connect_flags = (uint32_t)buffer[9];
				CAN_connect_flags <<=8;
				CAN_connect_flags |= (uint32_t)buffer[8];
				CAN_connect_flags <<=8;
				CAN_connect_flags |= (uint32_t)buffer[7];
				CAN_connect_flags <<=8;
				CAN_connect_flags |= (uint32_t)buffer[6];
				
				fl_status_U8 =  CAN_Mid_Init(CAN_CH1,fl_baud_rate_U32);
				
				if((ERR_INVALID_BAUDRATE != fl_status_U8) && (ERR_INVALID_CHANNEL_ID != fl_status_U8))
				{
					if((CAN_connect_flags & CAN_ID_BOTH) == CAN_ID_BOTH )
					{
						fl_connection_flag_U8 = RX_BOTH_STD_EXT_MSG;
					}
					else if((CAN_connect_flags & CAN_29BIT_ID )== CAN_29BIT_ID)
					{
						fl_connection_flag_U8 = RX_ONLY_EXT_MSG;
					}
					else if((CAN_connect_flags & CAN_29BIT_ID )== 0)
					{
						fl_connection_flag_U8 = RX_ONLY_STD_MSG;
					}
					else
					{
						fl_status_U8 = ERR_INVALID_FLAGS;
					}
					        
					if(fl_status_U8 != ERR_INVALID_FLAGS)
					{
						fl_status_U8 = CAN_Mid_Enable(fl_channel_no_U8,fl_connection_flag_U8);
						if(fl_status_U8==STATUS_NOERROR)
						{
							l_connected_channels++;
						}
						l_connected_channel_J1939_1 = 1;
					}
					else
					{
						/* Do nothing as fl_status_U8 has been modified */
					}
				}
				else
				{
					/* Do nothing as fl_status_U8 has been modified */
				}
				
				if( fl_status_U8 == STATUS_NOERROR)
				{
					CAN_active = 1;
				}
				        
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = J1939_EnableComm_ACK;
				fl_USB_tx_data_U8A[3] = fl_status_U8;
				        
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);										
			}
			else if(buffer[0] == J1939_CH1_PROTOCOL_ID)
			{
				CANCH1_or_ISO15765CH1_J1939CH1 = buffer[0];
			    fl_channel_no_U8 = CAN_CH2;			    
			    CAN_CH1_connect_flags = (uint32_t)buffer[9];
			    CAN_CH1_connect_flags <<=8;
			    CAN_CH1_connect_flags |= (uint32_t)buffer[8];
			    CAN_CH1_connect_flags <<=8;
			    CAN_CH1_connect_flags |= (uint32_t)buffer[7];
			    CAN_CH1_connect_flags <<=8;
			    CAN_CH1_connect_flags |= (uint32_t)buffer[6];
				
			    fl_status_U8 =  CAN_Mid_Init(CAN_CH2,fl_baud_rate_U32);
			    if((ERR_INVALID_BAUDRATE != fl_status_U8) && (ERR_INVALID_CHANNEL_ID != fl_status_U8))
			    {
				    if((CAN_CH1_connect_flags & CAN_ID_BOTH) == CAN_ID_BOTH )
				    {
					    fl_connection_flag_U8 = RX_BOTH_STD_EXT_MSG;
				    }
				    else if((CAN_CH1_connect_flags & CAN_29BIT_ID )== CAN_29BIT_ID)
				    {
					    fl_connection_flag_U8 = RX_ONLY_EXT_MSG;
				    }
				    else if((CAN_CH1_connect_flags & CAN_29BIT_ID )== 0)
				    {
					    fl_connection_flag_U8 = RX_ONLY_STD_MSG;
				    }
				    else
				    {
					    fl_status_U8 = ERR_INVALID_FLAGS;
				    }
				    if(fl_status_U8 != ERR_INVALID_FLAGS)
				    {
					    fl_status_U8 = CAN_Mid_Enable(fl_channel_no_U8,fl_connection_flag_U8);
					    if(fl_status_U8==STATUS_NOERROR)
					    {
						    l_connected_channels++;
					    }
						l_connected_channel_J1939_2 = 1;
				    }
				    else
				    {
					    /* Do nothing as fl_status_U8 has been modified */
				    }
			    }
			    else
			    {
				    /* Do nothing as fl_status_U8 has been modified */
			    }
			    if( fl_status_U8 == STATUS_NOERROR)
			    {
				    CAN_CH1_active = 1;
			    }
			        
			    memset(&fl_USB_tx_data_U8A,0,64);
			    fl_USB_tx_data_U8A[0] = buffer[0] ;
			    fl_USB_tx_data_U8A[1] = J1939_EnableComm_ACK;
			    fl_USB_tx_data_U8A[3] = fl_status_U8;
			    (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);	
			}
			else
			{
				/* ERROR: It should never enter here */
				fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
			}
		  break;
		}
	  case J1939_DisableComm:
		{
			if(buffer[0] == J1939_PROTOCOL_ID)
			{
				fl_channel_no_U8 = CAN_CH1;
				CAN_or_ISO15765_J1939 = 0;
				/* Clears All the Filters Configured */
				J2534_ClearAllFilter(J1939_PROTOCOL_ID);
				/* Suspend all periodic messages */   
				suspend_pmsg(J1939_PROTOCOL_ID); 
        
				suspend_J1939_addressClaim();
		
				CAN_ClearQ(CAN1_TX_QUEUE);
				if(getCAN1TXStatus())
				{
					xSemaphoreGive(xCAN1StartTx);
				}                
				CAN_ClearQ(CAN1_RX_QUEUE);
                
				fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
				if( fl_status_U8 == STATUS_NOERROR)
				{
					CAN_active = 0;
					if(l_connected_channels)
					{
						l_connected_channels--;
					}
					l_connected_channel_J1939_1 = 0;
				}
				CAN_connect_flags = 0;
        
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0];
				fl_USB_tx_data_U8A[1] = J1939_DisableComm_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
				/*Garuda_init();*/ /* Commented to fix the issue of not transmitting Ack for DisableComm
				Side effects are yet to be investigated */
			}
			else if(buffer[0] == J1939_CH1_PROTOCOL_ID)
			{
				fl_channel_no_U8 = CAN_CH2;
			    CANCH1_or_ISO15765CH1_J1939CH1 = 0;  
				/* Clears All the Filters Configured */
				J2534_ClearAllFilter(J1939_CH1_PROTOCOL_ID);                
				/* Suspend all periodic messages */
				suspend_pmsg(J1939_CH1_PROTOCOL_ID); 
               
			    suspend_J1939_addressClaim();
				
				CAN_ClearQ(CAN2_TX_QUEUE);
				if(getCAN2TXStatus())
				{
					xSemaphoreGive(xCAN2StartTx);
				}
				CAN_ClearQ(CAN2_RX_QUEUE);
        
				fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
				if( fl_status_U8 == STATUS_NOERROR)
				{
					CAN_CH1_active = 0;
					if(l_connected_channels)
					{
						l_connected_channels--;
					}
					l_connected_channel_J1939_2 = 0;
				}
				CAN_CH1_connect_flags = 0;

				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0];
				fl_USB_tx_data_U8A[1] = J1939_DisableComm_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
				/*Garuda_init();*/ /* Commented to fix the issue of not transmitting Ack for DisableComm
				Side effects are yet to be investigated */
			}
			else
			{
				/* ERROR: It should never enter here */
				fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);        
			}
		  break;
		}
	  case IOCTL_COMMAND:
		{
			process_J1939_IOCTL_cmd(buffer);		  
			break;
		}
	  case J1939_Send_msg:
		{
			if(buffer[0] == J1939_PROTOCOL_ID)
			{
				ch_id = 1;
			}
			else if(buffer[0] == J1939_CH1_PROTOCOL_ID)
			{
				ch_id = 2;
			}
			else
			{
				/* ERROR: */
			}
			
			#if 0
			/* Validate the source address from CAN Msg ID*/
			fl_msg_id =   ( (uint32_t)buffer[9]  << 24 |
						  (uint32_t)buffer[10]  << 16 |
						  (uint32_t)buffer[11]  << 8  |
						  (uint32_t)buffer[12] );
			SourceAddress = buffer[12];
			
			if( (device_claimed_Address != SourceAddress))// && ())
			{
				/* Message lost as the Buffer is full */
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
				fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
				fl_USB_tx_data_U8A[3] = ERR_ADDRESS_NOT_CLAIMED;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);				
				break;
			}	
			#endif			  
	  
			/* Unsegmented USB transfer */
			HFCPInitCount++;
	  
			if(buffer[2] == 0)
			{			
				data_len = buffer[3] | buffer[4] << 8 ;
				if((data_len & 0xC000) == 0x0000) /* Mode 0 */
				{
					data_len &= 0x3FFF;
					fl_tx_flags = ( (uint32_t)buffer[5]        |
									(uint32_t)buffer[6]  << 8  |
									(uint32_t)buffer[7]  << 16 |
										(uint32_t)buffer[8]  << 24 );
					fl_msg_id =   ( (uint32_t)buffer[9]  << 24 |
									(uint32_t)buffer[10] << 16 |
									(uint32_t)buffer[11] << 8  |
										(uint32_t)buffer[12] );
					//memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
					if(CAN_EXT_MSG == (fl_tx_flags & CAN_EXT_MSG)) /* Extended Frame */
					{                        
						fl_CAN_Tx_msg_S.ide = TRUE;
					}
					else /* Standard Frame */
					{                        
						fl_CAN_Tx_msg_S.ide = FALSE;
					}
					fl_CAN_Tx_msg_S.msg_id = fl_msg_id;
					fl_CAN_Tx_msg_S.rtr = 0;
					/* Copy data length */
					fl_CAN_Tx_msg_S.dlc = (uint8_t)data_len-4; /* subtract Msg Id length */
					/* Copy all data bytes into buffer */
					memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[13], fl_CAN_Tx_msg_S.dlc);
					// fl_CAN_Tx_msg_S.is_periodic_msg = FALSE; /* IS PERIODIC MESSAGE REMOVED */
					if(ch_id == 1)
					{
						//AMIT  fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
						fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
					}
					else if (ch_id == 2)
					{
						//AMIT fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
						fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);                       
					}
          
					if (fl_Q_Status == MID_FAIL)// OLD CODE(fl_Q_Status == CAN_Q_FULL)
					{
						/* Message lost as the Buffer is full */            
						memset(&fl_USB_tx_data_U8A,0,64);
						fl_USB_tx_data_U8A[0] = buffer[0] ;
						fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
						fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
						fl_USB_tx_data_U8A[3] = ERR_BUFFER_FULL;
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
					}
					else
					{
						/* Clear the USB buffer as it has been processed */            
						memset(&fl_USB_tx_data_U8A,0,64);
						fl_USB_tx_data_U8A[0] = buffer[0] ;
						fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
						fl_USB_tx_data_U8A[2] = buffer[2];
						fl_USB_tx_data_U8A[3] = fl_status_U8;
						if(ch_id == 1)
						{
							//get_data_logging_time_stamp(&current_time_stamp);
							get_time_stamp(&current_time_stamp);
						}
						else
						{              
								//get_data_logging_time_stamp(&current_time_stamp);
								get_time_stamp(&current_time_stamp);
						}
						fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
						fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
						fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
						fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
					}
				}/* End of Mode 0 */
				else if((data_len & 0xC000) == 0x4000) /* Mode 1 */
				{          
					/* buffer[5] - Supposed to hold
					conversation Id - To be incorporated */
					if(ch_id == 1)
					{
						stored_tx_flags_CAN = ( (uint32_t)buffer[6]        |
												(uint32_t)buffer[7]  << 8  |
													(uint32_t)buffer[8]  << 16 |
													(uint32_t)buffer[9]  << 24 );
						stored_msg_id_CAN =   ( (uint32_t)buffer[10]  << 24 |
												(uint32_t)buffer[11] << 16 |
													(uint32_t)buffer[12] << 8  |
													(uint32_t)buffer[13] );
						//memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
						if(CAN_EXT_MSG == (stored_tx_flags_CAN & CAN_EXT_MSG)) /* Extended Frame */
						{
							fl_CAN_Tx_msg_S.ide = TRUE;
						}
						else /* Standard Frame */
						{
							fl_CAN_Tx_msg_S.ide = FALSE;
						}
						stored_is_ext_frm = fl_CAN_Tx_msg_S.ide;
						fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN;
					}
					else
					{
						stored_tx_flags_CAN_CH1 = ( (uint32_t)buffer[6]        |
													(uint32_t)buffer[7]  << 8  |
														(uint32_t)buffer[8]  << 16 |
														(uint32_t)buffer[9]  << 24 );
						stored_msg_id_CAN_CH1 =   ( (uint32_t)buffer[10]  << 24 |
													(uint32_t)buffer[11] << 16 |
														(uint32_t)buffer[12] << 8  |
														(uint32_t)buffer[13] );
						memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
						if(CAN_EXT_MSG == (stored_tx_flags_CAN_CH1 & CAN_EXT_MSG)) /* Extended Frame */
						{
							fl_CAN_Tx_msg_S.ide = TRUE;
						}
						else /* Standard Frame */
						{
							fl_CAN_Tx_msg_S.ide = FALSE;
						}
						fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN_CH1;
					}
					data_len &= 0x3FFF;
					fl_CAN_Tx_msg_S.rtr = 0;
					/* Copy data length */
					fl_CAN_Tx_msg_S.dlc = (uint8_t)data_len-4; /* subtract Msg Id length */
					/* copy all data bytes into buffer */
					memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[14], fl_CAN_Tx_msg_S.dlc);
					// fl_CAN_Tx_msg_S.is_periodic_msg = FALSE; /* IS PERIODIC MESSAGE REMOVED */
					if(ch_id == 1)
					{
						//fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S); AMIT
						fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
					}
					else if (ch_id == 2)
					{
						//fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);//AMIT
						fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);  
					}
					if (fl_Q_Status == MID_FAIL) // OLD CODE (fl_Q_Status == CAN_Q_FULL)
					{
						/* Message lost as the Buffer is full */            
						memset(&fl_USB_tx_data_U8A,0,64);
						fl_USB_tx_data_U8A[0] = buffer[0] ;
						fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
						fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
						fl_USB_tx_data_U8A[3] = ERR_BUFFER_FULL;
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
					}
					else
					{
						/* Clear the USB buffer as it has been processed */            
						memset(&fl_USB_tx_data_U8A,0,64);
						fl_USB_tx_data_U8A[0] = buffer[0] ;
						fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
						fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
						fl_USB_tx_data_U8A[3] = fl_status_U8;
						if(ch_id == 1)
						{             
							// get_data_logging_time_stamp(&current_time_stamp);
							get_time_stamp(&current_time_stamp);
						}
						else
						{              
							//get_data_logging_time_stamp(&current_time_stamp);
							get_time_stamp(&current_time_stamp);
						}
						fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
						fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
						fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
						fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
					}
				}
				else if((data_len & 0xC000) == 0x8000) /* Mode 2 */
				{
					/* buffer[5] - Supposed to hold
					conversation Id - To be incorporated
					buffer[6],[7] - Supposed to hold
					Separation time - To be incorporated  */
					if(HFCPComMode == HFCP_COM_MODE_USB)
					{
						Ack_Required = 1;
					}
					else if(HFCPComMode == HFCP_COM_MODE_WIFI)
					{
						Ack_Required = buffer[5];
					}
          
					//memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));
          
					if(ch_id == 1)
					{
						fl_CAN_Tx_msg_S.ide = stored_is_ext_frm;
						fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN;
					}
					else
					{
						if(CAN_EXT_MSG == (stored_tx_flags_CAN_CH1 & CAN_EXT_MSG)) /* Extended Frame */
						{
							fl_CAN_Tx_msg_S.ide = TRUE;
						}
						else /* Standard Frame */
						{
							fl_CAN_Tx_msg_S.ide = FALSE;
						}
						fl_CAN_Tx_msg_S.msg_id = stored_msg_id_CAN_CH1;
					}
					data_len &= 0x3FFF;
					//data_len = 56; /* temp fix - investigate with Vijay */
					if(data_len <= 56)
					{
						if((data_len % 8) != 0)
						{
							msg_cnt = (data_len / 8) + 1;
						}
						else
						{
							msg_cnt = (data_len / 8);
						}
						base_indx = 8;
						while(msg_cnt--)
						{
							fl_CAN_Tx_msg_S.rtr = 0;
							/* Copy data length */
							if(data_len >= 8)
							{
								data_len -=8;
								fl_CAN_Tx_msg_S.dlc = 8;
							}
							else
							{
								fl_CAN_Tx_msg_S.dlc = data_len;
								data_len =0;
							}
							/* copy all data bytes into buffer */
							memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[base_indx], fl_CAN_Tx_msg_S.dlc);
							// fl_CAN_Tx_msg_S.is_periodic_msg = FALSE;
							if(ch_id == 1)
							{
								//fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S);AMIT
								fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
							}
							else if (ch_id == 2)
							{
								//fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
								fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);
							}
							if(MID_FAIL != fl_Q_Status) // OLD CODE (CAN_Q_FULL != fl_Q_Status)
							{
								base_indx += 8;
								//printf("Err\n\r");
							}
							else
							{
								/* Do nothing */
								/* Note that the "while" in this "else if" is blocking.
								i.e. till it writes all the frames to CAN interface it will
								not exit. A queue strategy is to be implemented such
								that there is always space for 7 frames.
								*/
							}
						}
					}
					else
					{
						fl_status_U8 = ERR_FAILED;
					}
					/* Clear the USB buffer as it has been processed */
          
					if (Ack_Required == TRUE)
					{            
						/*memset(&fl_USB_tx_data_U8A,0,64); */
						fl_USB_tx_data_U8A[0] = buffer[0] ;
						fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
						fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
						fl_USB_tx_data_U8A[3] = fl_status_U8;
						if(ch_id == 1)
						{              
							//get_data_logging_time_stamp(&current_time_stamp);
							get_time_stamp(&current_time_stamp);
						}
						else
						{                
							//get_time_stamp(timestamp_id[GARUDA_CAN_CH2], &current_time_stamp);
							//get_data_logging_time_stamp(&current_time_stamp);
							get_time_stamp(&current_time_stamp);
						}
						fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
						fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
						fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
						fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
						(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
					}
				}/* End Of Mode 2 */
				/* Multiple Messages in Single USB */
				else if((data_len & 0xC000) == 0xC000) /* Mode 3 */
				{
					base_indx = 5;
					msg_cnt = (uint8_t) (data_len & 0x3FFF);
          
					while(msg_cnt--)
					{
						//memset(&fl_CAN_Tx_msg_S,0,sizeof(fl_CAN_Tx_msg_S));            
						fl_tx_flags = ( (uint32_t)buffer[base_indx+0]        |
										(uint32_t)buffer[base_indx+1]  << 8  |
											(uint32_t)buffer[base_indx+2]  << 16 |
											(uint32_t)buffer[base_indx+3]  << 24 );
						fl_msg_id =   ( (uint32_t)buffer[base_indx+4]  << 24 |
										(uint32_t)buffer[base_indx+5]  << 16 |
											(uint32_t)buffer[base_indx+6]  << 8  |
											(uint32_t)buffer[base_indx+7] );
						base_indx += 8;
						if(CAN_EXT_MSG == (fl_tx_flags & 0x00000100)) /* Extended Frame */
						{
							fl_CAN_Tx_msg_S.ide = TRUE;
						}
						else /* Standard Frame */
						{
							fl_CAN_Tx_msg_S.ide = FALSE;
						}
						data_len = buffer[base_indx++];
						fl_CAN_Tx_msg_S.dlc = data_len;
						fl_CAN_Tx_msg_S.rtr = 0;
						fl_CAN_Tx_msg_S.msg_id = fl_msg_id;
						/* copy all data bytes into buffer */
						memcpy(&fl_CAN_Tx_msg_S.data[0], &buffer[base_indx], fl_CAN_Tx_msg_S.dlc);
						//fl_CAN_Tx_msg_S.is_periodic_msg = FALSE; 
						do
						{
							if(ch_id == 1)
							{
								//fl_Q_Status = CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S);
								fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &fl_CAN_Tx_msg_S);
							}
							else if (ch_id == 2)
							{
								//fl_Q_Status = CAN2_Mid_WriteTxQ(fl_CAN_Tx_msg_S);AMIT
								fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &fl_CAN_Tx_msg_S);
							}
						}while(fl_Q_Status == ERR_BUFFER_FULL);
						//while(ERR_BUFFER_FULL == CAN_Mid_WriteTxQ(fl_CAN_Tx_msg_S,ch_id));
						base_indx += data_len;
					}
					/* Clear the USB buffer as it has been processed */
          
					memset(&fl_USB_tx_data_U8A,0,64);
					fl_USB_tx_data_U8A[0] = buffer[0] ;
					fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
					fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
					fl_USB_tx_data_U8A[3] = fl_status_U8;
					if(ch_id == 1)
					{            
						//get_data_logging_time_stamp(&current_time_stamp);
						get_time_stamp(&current_time_stamp);
					}
					else
					{            
						//get_data_logging_time_stamp(&current_time_stamp);
						get_time_stamp(&current_time_stamp);
					}
					fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
					fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
					fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
					fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
				}/*End of Mode 3 */
				/* ERROR : Illegal Mode */
				else
				{
					/* Clear the USB buffer as it has been processed */          
					memset(&fl_USB_tx_data_U8A,0,64);
					fl_USB_tx_data_U8A[0] = buffer[0] ;
					fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
					fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
					fl_USB_tx_data_U8A[3] = ERR_FAILED;
					(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
  }
			}
			/* ERROR:For CAN segmented USB transfer is not needed */
  else
  {
  memset(&fl_USB_tx_data_U8A,0,64);
  fl_USB_tx_data_U8A[0] = buffer[0];
				fl_USB_tx_data_U8A[1] = J1939_Send_msg_ACK;
				fl_USB_tx_data_U8A[2] = buffer[2]; /* Segment number */
				fl_USB_tx_data_U8A[3] = ERR_FAILED;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			}
		  break;
		}
	  case Start_msg_filter:
		{
			if(buffer[0] == J1939_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 = J1939_PROTOCOL_ID;
			}
			else if(buffer[0] == J1939_CH1_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 = J1939_CH1_PROTOCOL_ID;
			}
  
			fl_filter_config.Protocol_ID = fl_Protocol_ID_U8;
			fl_filter_config.filterType = (J2534_filterType_t)buffer[2];
			fl_filter_config.MaskLen = buffer[3];
			for(loop_count = 0; loop_count < fl_filter_config.MaskLen; loop_count++)
  {
				fl_filter_config.maskMsg[loop_count] = buffer[4 + loop_count];
  }
			fl_filter_config.PatternLen = buffer[4+fl_filter_config.MaskLen];
			for(loop_count = 0; loop_count < fl_filter_config.PatternLen; loop_count++)
  {
				fl_filter_config.patternMsg[loop_count] = buffer[5+fl_filter_config.MaskLen+ loop_count];
			}
			fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config, &fl_FilterID);			
			      
			if(fl_filt_config_status != J2534_NO_ERROR)
    {
				if(fl_filt_config_status == J2534_FLT_NOT_FREE)
				{
					fl_status_U8 = ERR_EXCEEDED_LIMIT;
    }
    else
    {
					fl_status_U8 = ERR_FAILED;
    }
				      
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
  }
  else
  {
				      
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
			}						
		  break;
		}
	  case Stop_msg_filter:
    {
			if(buffer[0]==J1939_PROTOCOL_ID)			
      {
				fl_Protocol_ID_U8 =J1939_PROTOCOL_ID;
      }
			else if(buffer[0]==J1939_CH1_PROTOCOL_ID)			
			{
				fl_Protocol_ID_U8 =J1939_CH1_PROTOCOL_ID;
    }
    else
    {
				/*< Do Nothing */
			}
			fl_FilterID = buffer[2];
			fl_filt_stop_status = J2534_ClearFilter(fl_FilterID,fl_Protocol_ID_U8);
			if(fl_filt_stop_status != J2534_NO_ERROR)
			{
				if(fl_filt_stop_status == J2534_INVLD_FLTID)
				{
					fl_status_U8 = ERR_INVALID_FILTER_ID;
				}
				else
				{
					fl_status_U8 = ERR_FAILED;
    }
    
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
				fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);				      
			}
			else
			{
    
				memset(&fl_USB_tx_data_U8A,0,64);
				fl_USB_tx_data_U8A[0] = buffer[0] ;
				fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			}			
			break;
		}
	  case handle_periodic_msg:
    {
			if(buffer[0]==J1939_PROTOCOL_ID)
      {
				fl_Protocol_ID_U8 =J1939_PROTOCOL_ID;
      }
			else if(buffer[0]==J1939_CH1_PROTOCOL_ID)
			{
				fl_Protocol_ID_U8 = J1939_CH1_PROTOCOL_ID;
    }
			periodic_msg_cmd = buffer[2];
			j2534_periodic_msg.protocol_id=fl_Protocol_ID_U8;
			j2534_periodic_msg.periodicity  =	buffer[3]      |
												buffer[4] << 8 |
												buffer[5] << 16|
												buffer[6] << 24;
			j2534_periodic_msg.prmsg_id = buffer[7];
			j2534_periodic_msg.proto_msg.tx_flags = buffer[8]       |
													buffer[9]  << 8 |
													buffer[10] << 16|
													buffer[11] << 24;
			if((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN) || (periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID))
    {
				j2534_periodic_msg.proto_msg.length = buffer[12];
    }
			else
    {
				j2534_periodic_msg.proto_msg.length = 0;
    }
			for(loop_count = 0;
			loop_count < j2534_periodic_msg.proto_msg.length;
			loop_count++)
    {
				j2534_periodic_msg.proto_msg.data[loop_count] = buffer[13+loop_count];
			}
			
			if(PERIODIC_SUCCESS == PERIODIC_msg_cmd(&j2534_periodic_msg,periodic_msg_cmd))
			{
				fl_status_U8 = STATUS_NOERROR;
    }
    else
    {
				fl_status_U8 = ERR_FAILED;
    }
			/* Send Acknowledgment to J2534 DLL*/
			
			memset(&fl_USB_tx_data_U8A,0,64);
			fl_USB_tx_data_U8A[0] = buffer[0];
			fl_USB_tx_data_U8A[1] = handle_periodic_msg_ACK;
			fl_USB_tx_data_U8A[2] = fl_status_U8;
			fl_USB_tx_data_U8A[3] = j2534_periodic_msg.prmsg_id;
			(void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			break;
		}
	  default:
    {
		  break;
    }
  }
  return ;
}
#endif





#if COMMENTED
/*******************************************************************************
* Function Name  : process_J1708_cmd
* Description    :
* Input          : None.
* Return         : None.
*******************************************************************************/
void process_J1708_command( USB_buffer_def *fl_USB_buffer_out)
{
  uint8_t command = 0;
  uint8_t fl_USB_tx_data_U8A[64];
  uint8_t fl_j1708_datacnt = 0, fl_IdxLen;
  uint8_t fl_FilterID,loop_count=0,fl_status_U8;
  uint8_t fl_Protocol_ID_U8;
  int j;
  
  uint32_t current_time_stamp = 0;
  J1708_MSG*    j1708_rx_msg;
  J2534_filter_t fl_filter_config;
  J2534_stError_t fl_filt_config_status,fl_filt_stop_status;
  uint32_t fl_baudrate_U32;
  
  command = fl_USB_buffer_out->buffer[1];
  
  switch(command)
  {
  case J1708_EnableComm:
    {
      /* C5 02 */
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
      fl_USB_tx_data_U8A[1] = J1708_EnableComm_ACK;
      
      /* Read Baud rate from received msg */
      fl_baudrate_U32 = (uint32_t)fl_USB_buffer_out->buffer[5];
      fl_baudrate_U32 <<=8;
      fl_baudrate_U32 |= (uint32_t)fl_USB_buffer_out->buffer[4];
      fl_baudrate_U32 <<=8;
      fl_baudrate_U32 |= (uint32_t)fl_USB_buffer_out->buffer[3];
      fl_baudrate_U32 <<=8;
      fl_baudrate_U32 |= (uint32_t)fl_USB_buffer_out->buffer[2];
      
      if(fl_USB_buffer_out->buffer[0] == J1708_PROTOCOL_ID)
      {
        if((fl_baudrate_U32 == J1708_BAUD_9600)  ||
           (fl_baudrate_U32 == J1708_BAUD_19200) ||
             (fl_baudrate_U32 == J1708_BAUD_38400) ||
               (fl_baudrate_U32 == J1708_BAUD_57600))
        {
          j1708_current_baudrate = fl_baudrate_U32;
          j1708_init();
          fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
          J1708_active = true;
          l_connected_channels++;
        }
        else
        {
          fl_USB_tx_data_U8A[2] = ERR_INVALID_BAUDRATE;
        }
        
      }
      else
      {
        fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
      }
      
      /* Send data back to Host */
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
      break;
    }
    
  case J1708_DisableComm:
    {
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
      fl_USB_tx_data_U8A[1] = J1708_DisableComm_ACK;
      if(fl_USB_buffer_out->buffer[0] == J1708_PROTOCOL_ID)
      {
        j1708_deinit();
        J2534_ClearAllFilter(J1708_PROTOCOL_ID);
        fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
        if(l_connected_channels)
        {
          l_connected_channels--;
        }
        J1708_active = false;
      }
      else
      {
        fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
      }
      
      
      /* Send data back to Host */
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
      break;
    }
    
  case IOCTL_COMMAND:
    {
      /* C5 06 ..... */
      process_J1708_IOCTL_cmd(fl_USB_buffer_out);
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
      break;
    }
    
  case J1708_Send_msg:
    {
      /* C5 08 */
      if(fl_USB_buffer_out->buffer[0] == J1708_PROTOCOL_ID)
      {
        if(j1708_GetBusInit() == TRUE)/* Form the J1708 message */
        {
          if((j1708_msg = j1708_create_msg()) != NULL)
          {
            j1708_msg->prio = fl_USB_buffer_out->buffer[9];
            j1708_msg->mid = fl_USB_buffer_out->buffer[10]; /* buffer[10] has the MID */
            j1708_current_tx_mid = fl_USB_buffer_out->buffer[10];
            if(j1708_mode == J1708_MODE_CONVERTED)
            {
              /* Converted Mode -> All bytes are data. Checksum not transmitted */
              j1708_msg->data_len = ((uint16_t)fl_USB_buffer_out->buffer[3]      |
                                     (uint16_t)fl_USB_buffer_out->buffer[4]  << 8) - 2; /*-2 for MID and prio */
              if(j1708_msg->data_len > J1708_FRAME_MAX)
              {
                j1708_msg->data_len = J1708_FRAME_MAX;
              }
            }
            else
            {
              /* Raw mode -> Last byte is checksum. So -1 from data length */
              j1708_msg->data_len = ((uint16_t)fl_USB_buffer_out->buffer[3]      |
                                     (uint16_t)fl_USB_buffer_out->buffer[4]  << 8) - 3 ; /*-3 for MID, prio and csum */
              
              if(j1708_msg->data_len > J1708_FRAME_MAX)
              {
                j1708_msg->data_len = J1708_FRAME_MAX;
              }
              
              j1708_msg->csum = *(&fl_USB_buffer_out->buffer[0] + 9 + j1708_msg->data_len  + 2); /* 9 (0..8) is the overhead bits, +2 to offset MID and prio */
              
            }
            
            
            for(j=0;j<j1708_msg->data_len;j++)
            {
              j1708_msg->data_frame[j] = fl_USB_buffer_out->buffer[11+j];  /* Byte 11 onwards data bytes */
            }
            if (J1708_Q_FULL == j1708_enqueue(J1708_TX_Q, j1708_msg));
            
            /* Send the data on the bus */
            j1708_tx();
          }
          
          /* Send response to host */
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
          fl_USB_tx_data_U8A[1] = J1708_Send_msg_ACK ;
          fl_USB_tx_data_U8A[2] = fl_USB_buffer_out->buffer[2] ;
          /* Update time stamp on USB TX Frame */
          current_time_stamp = l_App_ISO9141_14230TxMsg_S.Timestamp;
          fl_USB_tx_data_U8A[4] = (uint8_t)((current_time_stamp )      & 0xFF);
          fl_USB_tx_data_U8A[5] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
          fl_USB_tx_data_U8A[6] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
          fl_USB_tx_data_U8A[7] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
          
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
        }
        else
        {
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
          fl_USB_tx_data_U8A[1] = J1708_Send_msg_ACK ;
          fl_USB_tx_data_U8A[2] = fl_USB_buffer_out->buffer[2] ;
          fl_USB_tx_data_U8A[3] = ERR_DEVICE_NOT_CONNECTED;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
        }
        
      }
      else
      {
        /* ERROR: It should never enter here */
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
        fl_USB_tx_data_U8A[1] = J1708_Send_msg_ACK ;
        fl_USB_tx_data_U8A[2] = fl_USB_buffer_out->buffer[2] ;
        fl_USB_tx_data_U8A[3] = ERR_INVALID_PROTOCOL_ID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
      break;
    }
    
  case J1708_Receive_msg:
    {
      /* C5 0A */
      if(j1708_GetBusInit() == TRUE)
      {
        j1708_rx_msg = j1708_dequeue(J1708_RX_Q);
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = J1708_PROTOCOL_ID;
        fl_USB_tx_data_U8A[1] = J1708_Receive_msg;
        fl_USB_tx_data_U8A[2] = 0;
        /* Copy J1708 data */
        fl_USB_tx_data_U8A[3] = j1708_rx_msg->mid;
        fl_USB_tx_data_U8A[4] = j1708_rx_msg->data_len;
        for(fl_IdxLen = 0; fl_IdxLen < 59; fl_IdxLen++)
        {
          fl_USB_tx_data_U8A[5+fl_IdxLen] = j1708_rx_msg->data_frame[fl_IdxLen];
          fl_j1708_datacnt++;
          if(fl_j1708_datacnt > j1708_rx_msg->data_len )
          {
            break;  /* All data bytes copied. Exit from loop */
          }
          fl_USB_tx_data_U8A[fl_IdxLen] = j1708_rx_msg->csum;
        }
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],64,DONT_RELEASE);
      }
      else
      {
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = J1708_PROTOCOL_ID;
        fl_USB_tx_data_U8A[1] = J1708_Receive_msg;
        fl_USB_tx_data_U8A[2] = 0;
        fl_USB_tx_data_U8A[3] = ERR_DEVICE_NOT_CONNECTED;
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      break;
    }
    
  case Start_msg_filter:
    {
      /* C5 0B
      byte 2- xx(filter type)
      byte 3- xx (mask Len)
      byte 4- xx (mask msg)
      byte 5- xx (pattern len)
      byte 6- xx (pattern msg */
      if(j1708_GetBusInit() == TRUE)
      {
        fl_filter_config.Protocol_ID = fl_USB_buffer_out->buffer[0];
        fl_filter_config.filterType = (J2534_filterType_t)fl_USB_buffer_out->buffer[2];
        fl_filter_config.MaskLen = fl_USB_buffer_out->buffer[3];
        for(loop_count = 0; loop_count < fl_filter_config.MaskLen; loop_count++)
        {
          fl_filter_config.maskMsg[loop_count] = fl_USB_buffer_out->buffer[4 + loop_count];
        }
        fl_filter_config.PatternLen = fl_USB_buffer_out->buffer[4+fl_filter_config.MaskLen];
        for(loop_count = 0; loop_count < fl_filter_config.PatternLen; loop_count++)
        {
          fl_filter_config.patternMsg[loop_count] = fl_USB_buffer_out->buffer[5+fl_filter_config.MaskLen + loop_count];
        }
        fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config,
                                                   &fl_FilterID);
        
        if(fl_filt_config_status != J2534_NO_ERROR)
        {
          if(fl_filt_config_status == J2534_FLT_NOT_FREE)
          {
            fl_status_U8 = ERR_EXCEEDED_LIMIT;
          }
          else
          {
            fl_status_U8 = ERR_FAILED;
          }
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0] ;
          fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
          fl_USB_tx_data_U8A[2] = fl_status_U8;
          fl_USB_tx_data_U8A[3] = fl_FilterID;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
        }
        else
        {
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0] ;
          fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
          fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
          fl_USB_tx_data_U8A[3] = fl_FilterID;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
        }
      }
      else
      {
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0] ;
        fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
        fl_USB_tx_data_U8A[2] = ERR_DEVICE_NOT_CONNECTED;
        fl_USB_tx_data_U8A[3] = 0x00;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      
      break;
    }
  case Stop_msg_filter:
    {
      /* C5 0C xx */
      if(j1708_GetBusInit() == TRUE)
      {
        fl_Protocol_ID_U8 = fl_USB_buffer_out->buffer[0];
        fl_FilterID = fl_USB_buffer_out->buffer[2];
        fl_filt_stop_status = J2534_ClearFilter(fl_FilterID,fl_Protocol_ID_U8);
        if(fl_filt_stop_status != J2534_NO_ERROR)
        {
          if(fl_filt_stop_status == J2534_INVLD_FLTID)
          {
            fl_status_U8 = ERR_INVALID_FILTER_ID;
          }
          else
          {
            fl_status_U8 = ERR_FAILED;
          }
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
          fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
          fl_USB_tx_data_U8A[2] = fl_status_U8;
          fl_USB_tx_data_U8A[3] = fl_FilterID;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
          
        }
        else
        {
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          memset(&fl_USB_tx_data_U8A,0,64);
          fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
          fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
          fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
          fl_USB_tx_data_U8A[3] = fl_FilterID;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
        }
      }
      else
      {
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
        fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
        fl_USB_tx_data_U8A[2] = ERR_DEVICE_NOT_CONNECTED;
        fl_USB_tx_data_U8A[3] = 0;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      
      break;
    }
  case Set_Message_Receive:
    {
      if(j1708_GetBusInit() == TRUE)
      {
        fl_Protocol_ID_U8 = fl_USB_buffer_out->buffer[0];
        j1708_host_rx_message_en = (enum J1708_MessageRxEnable)fl_USB_buffer_out->buffer[2];
        
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
        fl_USB_tx_data_U8A[1] = Set_Message_Receive_ACK;
        fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
        
      }
      else
      {
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8 ;
        fl_USB_tx_data_U8A[1] = Set_Message_Receive_ACK;
        fl_USB_tx_data_U8A[2] = ERR_DEVICE_NOT_CONNECTED;
      }
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      
      
      break;
    }
    
  }
}
#endif

#if COMMENTED
/*******************************************************************************
* Function Name  : process_J1708_IOCTL_cmd
* Description    :
* Input          : None.
* Return         : None.
*******************************************************************************/
static void process_J1708_IOCTL_cmd(USB_buffer_def *fl_USB_buffer_out)
{
  uint8_t IOCTL_command = 0, command = 0;
  uint8_t fl_USB_tx_data_U8A[64];
  J2534_filter_t fl_filter_config;
  uint8_t fl_FilterID;
  J2534_stError_t fl_filt_config_status,fl_filt_invert_status;
  uint8_t fl_status_U8 = STATUS_NOERROR;
  uint8_t fl_set_BR_ret_status_U8 = 0;
  uint32_t fl_current_baud_rate_U32 = 0;
  
  memset(&fl_USB_tx_data_U8A,0,64);
  
  IOCTL_command = fl_USB_buffer_out->buffer[2];
  /* fl_USB_buffer_out->buffer[3] is number of parameters being sent for SetConfig. We ignore it */
  switch(IOCTL_command)
  {
  case J1708_SetConfig:
    {
      fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = J1708_SetConfig_ACK; /* Set config Ack */
      command = fl_USB_buffer_out->buffer[4];
      switch (command)
      {
      case J1708_Filter_Type:
        {
          /* C5 06 02 xx C3 flt_type */
          /* EXCLUSIVE: Block all configured filters and configure a PASS ALL filter
          INCLUSIVE: Set configured filters to PASS */
          /* Check inclusive or exclusive filters, by default inclusive */
          if(j1708_GetBusInit() == TRUE)
          {
            if(fl_USB_buffer_out->buffer[5] == J1708_FILTER_EXCLUSIVE)
            {
              j1708_filterstate = J1708_FILTER_EXCLUSIVE;
              
              /* Invert filters, i.e. set configured PASS filters to BLOCK and vice versa */
              fl_filt_invert_status = J2534_ExclusiveFilter();
              if(fl_filt_invert_status == J2534_NO_ERROR)
              {
                /* Configure a Pass All filter */
                fl_filter_config.Protocol_ID = J1708_PROTOCOL_ID;
                fl_filter_config.filterType = J2534_PASS_FILTER;
                fl_filter_config.MaskLen = 0x01;
                fl_filter_config.PatternLen = 0x01;
                fl_filter_config.maskMsg[0] = 0x00;
                fl_filter_config.patternMsg[0] = 0x00;
                
                fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config, &j1708_pass_all_filter_id);
                if(fl_filt_config_status == J2534_NO_ERROR)
                {
                  fl_status_U8 = STATUS_NOERROR;
                }
                else
                {
                  fl_status_U8 = ERR_FAILED;
                }
              }
              else
              {
                fl_status_U8 = ERR_FAILED;
              }
            }
            else if(fl_USB_buffer_out->buffer[5] == J1708_FILTER_INCLUSIVE)
            {
              j1708_filterstate = J1708_FILTER_INCLUSIVE;
              fl_filt_invert_status = J2534_InclusiveFilter();
              if(fl_filt_invert_status == J2534_NO_ERROR)
              {
                /* Clear any previous pass all filters configured */
                fl_filt_config_status = J2534_ClearFilter(j1708_pass_all_filter_id,J1708_PROTOCOL_ID);
                if(fl_filt_config_status == J2534_NO_ERROR)
                {
                  fl_status_U8 = STATUS_NOERROR;
                }
                else
                {
                  fl_status_U8 = ERR_FAILED;
                }
              }
              else
              {
                fl_status_U8 = ERR_FAILED;
              }
            }
            else
            {
              /* Filter type sent is neither inclusive nor exclusive */
              fl_status_U8 = ERR_FAILED;
            }
          }
          else
          {
            fl_status_U8 = ERR_DEVICE_NOT_CONNECTED;
          }
          
          fl_USB_tx_data_U8A[3] = fl_status_U8;
          fl_USB_tx_data_U8A[4] = fl_USB_buffer_out->buffer[3];
          fl_USB_tx_data_U8A[5] = J1708_Filter_Type_ACK;
          
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          break;
        }
        
      case J1708_Mode:
        {
          /* C5 06 02 xx C1 mode */
          if(j1708_GetBusInit() == TRUE)
          {
            /* Check converted mode or raw mode, by default converted mode */
            if(fl_USB_buffer_out->buffer[5] == J1708_MODE_RAW)
            {
              /* RAW mode: Checksum is sent by the host. We just need to transmit the frame on the bus */
              j1708_mode = J1708_MODE_RAW;
            }
            else
            {
              /* CONVERTED mode: Checksum needs to be calculated by firmware and then transmitted */
              j1708_mode = J1708_MODE_CONVERTED;
            }
            
            fl_status_U8 = STATUS_NOERROR;
          }
          else
          {
            fl_status_U8 = ERR_DEVICE_NOT_CONNECTED;
          }
          
          fl_USB_tx_data_U8A[3] = fl_status_U8;
          fl_USB_tx_data_U8A[4] = fl_USB_buffer_out->buffer[3];
          fl_USB_tx_data_U8A[5] = J1708_Mode_ACK;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          break;
        }
      }
      
    case Set_data_rate:
      {
        if(j1708_GetBusInit() == TRUE)
        {
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
          fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE; /* IOCTL CMD ID*/
          fl_USB_tx_data_U8A[2] = Set_config_ACK;	/* ACK for Get config CMD*/
          if( Set_data_rate == fl_USB_buffer_out->buffer[4])	   /*Set config parameter ID == Data rate*/
          {
            fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)fl_USB_buffer_out->buffer[5];
            fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)fl_USB_buffer_out->buffer[6] <<8;
            fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)fl_USB_buffer_out->buffer[7] <<16;
            fl_current_baud_rate_U32 = fl_current_baud_rate_U32 | (uint32_t)fl_USB_buffer_out->buffer[8] <<24;
            
            if((fl_current_baud_rate_U32 == J1708_BAUD_9600)  ||
               (fl_current_baud_rate_U32 == J1708_BAUD_19200) ||
                 (fl_current_baud_rate_U32 == J1708_BAUD_38400) ||
                   (fl_current_baud_rate_U32 == J1708_BAUD_57600))
            {
              fl_set_BR_ret_status_U8 = STATUS_NOERROR;
              j1708_current_baudrate  = fl_current_baud_rate_U32;
              j1708_deinit();
              j1708_init();
            }
            else
            {
              fl_set_BR_ret_status_U8 = ERR_INVALID_BAUDRATE;
            }
          }
          else
          {
            fl_set_BR_ret_status_U8 = ERR_DEVICE_NOT_CONNECTED;
          }
          
          fl_USB_tx_data_U8A[3] = fl_set_BR_ret_status_U8;
          fl_USB_tx_data_U8A[4] = fl_USB_buffer_out->buffer[3];
          fl_USB_tx_data_U8A[5] = Set_data_rate_ACK;	        /* ACK for data rate parameter */
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
        }
        break;
      }
    }
  case J1708_Reset:
    {
      /* C5 06 C0 */
      memset(&fl_USB_tx_data_U8A,0,64);
      if(j1708_GetBusInit() == TRUE)
      {
        j1708_deinit();
        fl_status_U8 = STATUS_NOERROR;
      }
      else
      {
        fl_status_U8 = ERR_DEVICE_NOT_CONNECTED;
      }
      
      fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = J1708_Reset_ACK;
      fl_USB_tx_data_U8A[3] = fl_status_U8;	/* Error status*/
      
      
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
    }
    break;
    
  case J1708_Pass_All_Filter_ON:
    {
      if(j1708_GetBusInit() == TRUE)
      {
        fl_filter_config.Protocol_ID = J1708_PROTOCOL_ID;
        fl_filter_config.filterType = J2534_PASS_FILTER;
        fl_filter_config.MaskLen = 0x01;
        fl_filter_config.PatternLen = 0x01;
        fl_filter_config.maskMsg[0] = 0x00;
        fl_filter_config.patternMsg[0] = 0x00;
        
        fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config, &fl_FilterID);
        
        if(fl_filt_config_status != J2534_NO_ERROR)
        {
          if(fl_filt_config_status == J2534_FLT_NOT_FREE)
          {
            fl_status_U8 = ERR_EXCEEDED_LIMIT;
          }
          else
          {
            fl_status_U8 = ERR_FAILED;
          }
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0] ;
          fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;
          fl_USB_tx_data_U8A[2] = J1708_Pass_All_Filter_ON_ACK;
          fl_USB_tx_data_U8A[3] = fl_status_U8;
          fl_USB_tx_data_U8A[4] = fl_FilterID;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
        }
        else
        {
          fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
          fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0] ;
          fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;
          fl_USB_tx_data_U8A[2] = J1708_Pass_All_Filter_ON_ACK;
          fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
          fl_USB_tx_data_U8A[4] = fl_FilterID;
          (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
        }
      }
      else
      {
        fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
        fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0] ;
        fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;
        fl_USB_tx_data_U8A[2] = J1708_Pass_All_Filter_ON_ACK;
        fl_USB_tx_data_U8A[3] = ERR_DEVICE_NOT_CONNECTED;
        fl_USB_tx_data_U8A[4] = fl_FilterID;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
      }
      /* C5 06 C2 */
      
      break;
    }
    
  case J1708_Pass_All_Filter_OFF:
    {
      /* C5 06 0A */
      if(j1708_GetBusInit() == TRUE)
      {
        J2534_ClearAllFilter(J1708_PROTOCOL_ID);
        fl_status_U8 = STATUS_NOERROR;
      }
      else
      {
        fl_status_U8 = ERR_DEVICE_NOT_CONNECTED;
      }
      
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
      fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = J1708_Pass_All_Filter_OFF_ACK;
      fl_USB_tx_data_U8A[3] = fl_status_U8;	/* Error status*/
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      break;
    }
    
  case J1708_Loopback:
    {
      /* Loopback not implemented yet */
      if(j1708_GetBusInit() == TRUE)
      {
        fl_status_U8 = STATUS_NOERROR;
      }
      else
      {
        fl_status_U8 = ERR_DEVICE_NOT_CONNECTED;
      }
      fl_USB_buffer_out->flags = USB_BUFFER_OUT_EMPTY;
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = fl_USB_buffer_out->buffer[0];
      fl_USB_tx_data_U8A[1] = IOCTL_COMMAND; /* IOCTL CMD ID*/
      fl_USB_tx_data_U8A[2] = J1708_Loopback_ACK;
      fl_USB_tx_data_U8A[3] = fl_status_U8;	/* Error status*/
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      break;
    }
    
  }
}
#endif

/*******************************************************************************
* Function Name  : get_CAN_CH1_status
* Input          : None.
* Return         : None.
* Description    :
*******************************************************************************/
uint8_t get_CAN_CH1_status(void)
{
  return CAN_CH1_active;
}
/*******************************************************************************
* Function Name  : get_CAN_status
* Input          : None.
* Return         : None.
* Description    :
*******************************************************************************/
uint8_t get_CAN_status(void)
{
  return CAN_active;
}
/*******************************************************************************
* Function Name  : get_KWP_status
* Input          : None.
* Return         : None.
* Description    :
*******************************************************************************/
uint8_t get_KWP_status(void)
{
  return KWP_active;
}
/*******************************************************************************
* Function Name  : get_J1708_status
* Input          : None.
* Return         : None.
* Description    :
*******************************************************************************/
uint8_t get_J1708_status(void)
{
  return J1708_active;
}

/*******************************************************************************
* Function Name  : get_KWP_status
* Input          : None.
* Return         : None.
* Description    :
*******************************************************************************/
uint8_t get_ISO9141_or_14230(void)
{
	return ISO_9141_OR_14230;
}


extern  sSdCard sdDrv[BOARD_NUM_MCI];
extern uint8_t config;
extern uint8_t data_logging_complete;
uint8_t data_log_ts_id = 0;
uint8_t system_time_stamp[9];
uint8_t init_sd_once = 0;
uint16_t buff_size_in_MB = 0;  
//void process_Setup_command( USB_buffer_def *fl_USB_buffer_out)
void process_Setup_command( uint8_t *buffer)
{
  uint8_t fl_USB_tx_data_U8A[64];
  uint8_t command =0;
  uint8_t status=0;
  uint32_t BatteryVg;
  uint32_t curr_time_in_uS=0;
  
    
  command = buffer[1] ;
  /* J2534 Periodic messages */
  switch(command)
  {
  case Setup_FW_Version:
    {
      
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = SETUP_CMD_ID ;
      fl_USB_tx_data_U8A[1] = Setup_FW_Version_ACK ;
      fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
      fl_USB_tx_data_U8A[3] = 2;
      fl_USB_tx_data_U8A[4] = 0;
      fl_USB_tx_data_U8A[5] = 7;
	  fl_USB_tx_data_U8A[6] = 'T';
	  //fl_USB_tx_data_U8A[7] = 0X31;
	  //fl_USB_tx_data_U8A[8] = 0X33;
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],8,DONT_RELEASE);
      
      //AMIT IMPORTANT
      //vTaskDelay(2);
      //USB_MSD_Mid_Init();      
      break;
    }
  case IOCTL_COMMAND:
    {
      //IMPORTANT
      memset(&fl_USB_tx_data_U8A,0,64);
      if( Read_VBATT == buffer[2] )
      {
        fl_USB_tx_data_U8A[0] = SETUP_CMD_ID;
        fl_USB_tx_data_U8A[1] = IOCTL_COMMAND;
        fl_USB_tx_data_U8A[2] = Read_VBATT;
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
        fl_USB_tx_data_U8A[4] = 4; /* Length */
        
        if(TRUE == Read_BatteryVoltage(&BatteryVg))
        {
          fl_USB_tx_data_U8A[5] =  BatteryVg & 0x00FF;
          fl_USB_tx_data_U8A[6] =  (BatteryVg & 0xFF00)>>8;
          fl_USB_tx_data_U8A[7] =  0;
          fl_USB_tx_data_U8A[8] =  0;
        }
        else
        {
          fl_USB_tx_data_U8A[3] =  ERR_FAILED;
          fl_USB_tx_data_U8A[5] =  0;
          fl_USB_tx_data_U8A[6] =  0;
          fl_USB_tx_data_U8A[7] =  0;
          fl_USB_tx_data_U8A[8] =  0;
        }
      }
      else
      {
        /* Do Nothing */
      }
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      break;
    }
    case Start_Data_logging:
    {
        if(/*buffer[12] == 0*/1)
        {
            for(int i=0;i<9;i++)
            {
                system_time_stamp[i] = buffer[3+i];
            }
            
            curr_time_in_uS = (uint32_t)((system_time_stamp[7] | (system_time_stamp[8] << 8))*1000);
            
            //active_session_index = 0;
            /* 
            Possible values Datalog buffer size(buff_size_in_MB) are 32MB, 
            64MB, 128MB, 256MB, 512MB, 1024MB, SD_CARD_SIZE_MAX.
            !!!Assumed that PC application does the validation of this value!!!
            */
            buff_size_in_MB = (uint16_t)(buffer[13] | (buffer[14] << 8));
        
            /* delete the following line once PC app has the Buffer size selection implemented */
            // buff_size_in_MB = SD_CARD_SIZE_MAX;
            
            if(buffer[12] == 0)
            {
                //gl_SDcard_full = 0; 
            }
            
            //status = start_write_session(buff_size_in_MB, &session_num[active_session_index],
            //        system_time_stamp, fl_USB_buffer_out->buffer[2], fl_USB_buffer_out->buffer[12]);
			
           if (AnyCardIsConnected())
           {
	           Start_DataLogging_Timestamp();
	           Set_DatLog_Event();
           }
           else
           {
	           FILE_GB_FULL_Led_ON();
           }
            
            status = 0;
            
            if(status)
            {
                fl_USB_tx_data_U8A[0] = 0xC3;
                fl_USB_tx_data_U8A[1] = 0xF0;
                fl_USB_tx_data_U8A[2] = status;
                Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
            }
            else
            {
                //sessions_in_use++;
                fl_USB_tx_data_U8A[0] = 0xC3;
                fl_USB_tx_data_U8A[1] = 0xF0;
                fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
                Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
            }
        }
        break;             
    }
          
    
    case Stop_Data_logging:
    {
        if(buffer[2] == 0)
        {
              if(get_CAN_status() == 1)
              {
                hfcp_disable_CAN();
              }
              if(get_CAN_CH1_status() == 1)
              {
                hfcp_disable_CAN_CH1();
              }			  
              Clear_DatLog_Event();		
			  Flush_Datalog();
			  Stop_DataLogging_Timestamp();	  			  
        }
        else if(buffer[2] == 1)  
        {
            USBD_HAL_Disable();
            USBD_HAL_Disconnect();
            SD_DeInit(&sdDrv[0]);            
            vTaskDelay(2);
            //USB_MSD_Mid_Init();
            //Clear_DatLog_Event();
            Set_MSD_Event();
            USB_Device_Mode = MSD;
        }          
        else if(buffer[2] == 2)
        {                    
            Clear_DatLog_Event();
        }            
    }
    break;    

    case Data_logging_mode_query:
    {        
        fl_USB_tx_data_U8A[0] = 0xC3;
        fl_USB_tx_data_U8A[1] = 0xF2;
        
        /* 0 - Not started 1 - In data logging mode*/
        fl_USB_tx_data_U8A[2] = Is_DataLog_Active();
        
        //if(data_logging_complete)
        //{
        //    fl_USB_tx_data_U8A[2] = data_logging_complete; /* Bufer full in "Fill Once" mode */
       // }
        Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],3,DONT_RELEASE);
    break;    
    }
    
  default:
    {
      
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = SETUP_CMD_ID ;
      fl_USB_tx_data_U8A[1] = command;
      fl_USB_tx_data_U8A[2] = ERR_NOT_SUPPORTED;
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],6,DONT_RELEASE);
      break;
    }
  }
}

/*******************************************************************************
* Function Name  : process_Setup_command
* Input          : USB buffer.
* Return         : None.
* Description    : This function processes the setup cmds
*******************************************************************************/
void process_session_mgmt_command( uint8_t *buffer)
{
  uint8_t fl_USB_tx_data_U8A[64];
  uint8_t command =0;
  //uint32_t curr_time_in_uS=0;
  command = buffer[1] ;
  /* J2534 Periodic messages */
  switch(command)
  {
  case Manage_Session:
    {
      if(buffer[2] == SESSION_OPEN)
      {
        /* OLD IMPLEMENTATION : start_and_sync_time_stamp(0); */
        start_time_stamp();	
		
		#if GARUDA_USB_DEBUG
		memset(&Garuda_Debug,0,sizeof(Garuda_Debug_Info));
		memset(&Garuda_Debug_CAN2,0,sizeof(Garuda_Debug_Info));
		#endif
		
		if(get_connected_channels())
		{
			DisconnectAllChanels();			
		}	
       // Set_DatLog_Event();
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
        fl_USB_tx_data_U8A[1] = Manage_Session;
        fl_USB_tx_data_U8A[2] = SESSION_OPEN;
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      else if(buffer[2] == SESSION_CLOSE)
      {
        /*Stop Timestamp Timer */       
        stop_timestamp_timer();
		//imp
        //Clear_DatLog_Event();
		if(get_connected_channels())
		{
			DisconnectAllChanels();	
		}
						
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
        fl_USB_tx_data_U8A[1] = Manage_Session;
        fl_USB_tx_data_U8A[2] = SESSION_CLOSE;
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
		
		#if GARUDA_USB_DEBUG
		Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
		memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
		#endif
		
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      else
      {
        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
        fl_USB_tx_data_U8A[1] = Manage_Session;
        fl_USB_tx_data_U8A[2] = buffer[2];
        fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      break;
    }
  case DATA_LOG_MODE:
    {
		#if AMIT
      if(buffer[2] == DATA_LOG_START)
      {
        //IMPORTANT start_and_sync_time_stamp(0);
        Set_DatLog_Event();
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
        fl_USB_tx_data_U8A[1] = DATA_LOG_MODE;
        fl_USB_tx_data_U8A[2] = DATA_LOG_START;
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      else if(buffer[2] == DATA_LOG_STOP)
      {
        /*Stop Timestamp Timer */
        //IMPORTANT disable_timer(3);
        Clear_DatLog_Event();
        Flush_Datalog();
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
        fl_USB_tx_data_U8A[1] = DATA_LOG_MODE;
        fl_USB_tx_data_U8A[2] = DATA_LOG_STOP;
        fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
      else
      {        
        memset(&fl_USB_tx_data_U8A,0,64);
        fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
        fl_USB_tx_data_U8A[1] = DATA_LOG_START;
        fl_USB_tx_data_U8A[2] = buffer[2];
        fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
        (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      }
	  #endif
      break;
    }
  default:
    {
      
      memset(&fl_USB_tx_data_U8A,0,64);
      fl_USB_tx_data_U8A[0] = SESSION_MANAGEMENT ;
      fl_USB_tx_data_U8A[1] = buffer[1];
      fl_USB_tx_data_U8A[2] = buffer[2];
      fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
      (void)Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
      break;
    }
  }
}
/*******************************************************************************
* Function Name  : get_connected_channels
* Input          : USB buffer.
* Return         : None.
* Description    : Gets the value of l_connected_channels
*******************************************************************************/
uint8_t get_connected_channels(void)
{
 // return l_connected_channels;
  return (l_connected_channel_1 || l_connected_channel_2 || l_connected_channel_J1939_1  || l_connected_channel_J1939_2 || l_connected_channel_Kline);
}
/*******************************************************************************
* Function Name  : process_CAN_IOCTL_cmd
* Input          : USB buffer.
* Return         : None.
* Description    : clears l_connected_channels to 0
*******************************************************************************/
void clear_connected_channels(void)
{
  l_connected_channels = 0;
  l_connected_channel_1 = 0;
  l_connected_channel_2 = 0;
  l_connected_channel_J1939_1 = 0;
  l_connected_channel_J1939_2 = 0;
  l_connected_channel_Kline = 0;
  
}
/*******************************************************************************
* Function Name  : get_connected_channels
* Input          : USB buffer.
* Return         : None.
* Description    : Gets the value of l_connected_channels
*******************************************************************************/
uint8_t get_CAN_or_ISO(void)
{
  return CAN_or_ISO;
}
/*******************************************************************************
* Function Name  : get_connected_channels
* Input          : USB buffer.
* Return         : None.
* Description    : Gets the value of l_connected_channels
*******************************************************************************/
uint8_t get_CAN1_or_ISO1(void)
{
  return CAN1_or_ISO1;
}

/*******************************************************************************
* Function Name  : get_CAN_or_ISO15756_or_J1939
* Input          : void.
* Return         : None.
* Description    : Gets the value of CAN_or_ISO15756_or_J1939
*******************************************************************************/
uint8_t get_CAN_or_ISO15756_or_J1939(void)
{
	return CAN_or_ISO15765_J1939;
}

/*******************************************************************************
* Function Name  : get_CANCH1_or_ISO15756CH1_or_J1939CH1
* Input          : void.
* Return         : None.
* Description    : Gets the value of CANCH1_or_ISO15756CH1_or_J1939CH1
*******************************************************************************/
uint8_t get_CANCH1_or_ISO15756CH1_or_J1939CH1(void)
{
	return CANCH1_or_ISO15765CH1_J1939CH1;
}


/* Disable CAN channel - i.e.channel 1 */
void hfcp_disable_CAN(void)
{
  
    uint8_t fl_status_U8 = 0;
    CAN_or_ISO = 0;
	CAN_or_ISO15765_J1939 = 0;
  
    /* Clears All the Filters Configured */
    J2534_ClearAllFilter(CAN_PROTOCOL_ID);
    suspend_pmsg(CAN_PROTOCOL_ID); /* Suspend all periodic messages */
  
    /* Clear CAN RX and TX Queues */
    CAN_ClearQ(CAN1_TX_QUEUE);
    CAN_ClearQ(CAN1_RX_QUEUE);
    
    fl_status_U8 = CAN_Mid_Disable(CAN_CH1);
    if( fl_status_U8 == STATUS_NOERROR)
    {
        CAN_active = 0;
        if(l_connected_channels)
        {
            l_connected_channels--;
        }
		l_connected_channel_1 =0;
        //stop_time_stamp(timestamp_id[GARUDA_CAN_CH1]);
    }
    CAN_connect_flags = 0;

}


/* Disable CAN_CH1 channel - i.e.channel 2 */
void hfcp_disable_CAN_CH1(void)
{
  uint8_t fl_status_U8 = 0;
  CAN1_or_ISO1 = 0;
  CANCH1_or_ISO15765CH1_J1939CH1 = 0;
  /* Clears All the Filters Configured */
  J2534_ClearAllFilter(CAN_CH1_PROTO_ID);
  suspend_pmsg(CAN_CH1_PROTO_ID); /* Suspend all periodic messages */
  
  /* Clear CAN RX and TX Queues */
  CAN_ClearQ(CAN2_TX_QUEUE);
  CAN_ClearQ(CAN2_RX_QUEUE);
  
  fl_status_U8 = CAN_Mid_Disable(CAN_CH2);
  if( fl_status_U8 == STATUS_NOERROR)
  {
    CAN_CH1_active = 0;
    if(l_connected_channels)
    {
      l_connected_channels--;
    }
	l_connected_channel_2 =0;
    //stop_time_stamp(timestamp_id[GARUDA_CAN_CH1]);
  }
  CAN_CH1_connect_flags = 0;

}

void HFCP_pauseTask (void)
{
    if (xTaskExecLock)
    {
        while(xSemaphoreTake(xTaskExecLock, portTICK_PERIOD_MS * 1) != pdTRUE);
    }
}

void HFCP_startTask (void)
{
    if (xTaskExecLock)
    {
        xSemaphoreGive(xTaskExecLock);
    }
}

void HFCP_Task_Reset (void)
{
    QueueHandle_t queues[] = {xHFCP_TX_Queue, xHFCP_RX_Queue, NULL};
    Dynamic_QStruct_t dataStruct;
	QueueHandle_t *pQ = queues;

    //taskENTER_CRITICAL();
    while (*pQ)
    {
        while(xQueueReceive(*pQ, &dataStruct, portTICK_PERIOD_MS * 1) == pdTRUE)
        {
            if (dataStruct.address)
            {
                vPortFree(dataStruct.address);
            }
        }
        pQ++;
    }
}


void DisconnectAllChanels( void )
{    
    HFCP_Task_Reset();
    USB_Mid_Reset();
    WiFI_Mid_Reset();
    
    //if(l_connected_channels)
	if(get_connected_channels())
    {
        /* Clears All the Filters Configured */
        J2534_ClearAllFilter(CAN_PROTOCOL_ID);
        J2534_ClearAllFilter(CAN_CH1_PROTO_ID);
        J2534_ClearAllFilter(KWP_PROTOCOL_ID);
        
        /* Clears the CAN Queues */        
        CAN_ClearQ(CAN1_TX_QUEUE);
		if(getCAN1TXStatus())
		{
			xSemaphoreGive(xCAN1StartTx);
		}
        CAN_ClearQ(CAN1_RX_QUEUE);
        CAN_ClearQ(CAN2_TX_QUEUE);
		if(getCAN2TXStatus())
		{
			xSemaphoreGive(xCAN2StartTx);
		}
        CAN_ClearQ(CAN2_RX_QUEUE);

        clear_connected_channels();
        
        /* Suspend all periodic messages */
        suspend_pmsg(CAN_PROTOCOL_ID);
        suspend_pmsg(CAN_CH1_PROTO_ID);
        suspend_pmsg(KWP_PROTOCOL_ID);
        
        CAN_Mid_Disable(CAN_CH1);
        CAN_Mid_Disable(CAN_CH2);
        
        /* KWP Channel related de-init */
        ISO9141_14230_Reset();
    }
}


/******************************************************************************
**					R E V I S I O N		H I S T O R Y
*******************************************************************************
** Please update in the following format:
**
** Revision No		Date(dd/mm/yy)				Author
** Description of change
**
*******************************************************************************
** 0.1				23/11/07				Sudhir
** Initial version
** 0.2				12/02/09				Sanjeeva
** Added Support to transfer 3 CAN frames from one USB frame (Implementation 1)
** 0.3				12/02/09				Sanjeeva
** Added Support to transfer 5 CAN frames from one USB frame (Implementation 2)
** 0.4				12/02/09				Sanjeeva
** Added Support to transfer 7 CAN frames from one USB frame (Implementation 3)
** 0.5              20/03/09                Sanjeeva and Mahadeva
** J2534 Filter and Periodic message support and HFCP changes
** 0.5              25/06/09                Mahadeva
** Modified process_KWP_cmd and process_KWP_IOCTL_cmd for Innova KWP Migration
** Modified KWP Related Function as per KWP Migration
** 0.5.1             20/07/09                Mahadeva
** l_KWPRX_SegTrnsfr Flag Clear After Segmented USB Transmission Completion was
** not implemented previously. now it is cleared
** 0.6               22/07/09                Mahadeva
** READ_VBATT IOCTL Support Implemented
** 1.0               20/01/2014              Sanjeeva & Mahadeva
** Wifi Revision **
** CAN Disconect & Clear Buffers functions corrected
** Old Timestamp implementation Removed
** 1.1               22/01/2014              Sanjeeva & Mahadeva
** Timer 0 Init and Enable/Disable synched with KWP Connect/Disconnect
** Send_Msg-Mode 3 Ack is modified as per USB and Wifi DLL Requirement
*******************************************************************************
** 1.2               30/01/2014              Sanjeeva & Mahadeva
** l_connected_chanenels decremented only if its a non-zero
** VBATT Read implemnted as a fuction and it is also used by main.c
** Ack_Required will work depending on USB or Wifi Mode
** memcpy added for Mode 3 can Send msg to make can flashing work in Rel Mode
** (unecessory but flashing will not complete in Rel mode, remove after issue fixed)
** KOEL string removed from Read Version
*******************************************************************************
*******************************************************************************
** 1.2               05/02/2014              Sanjeeva & Mahadeva
** Ported to IAR 6.5 from 4.42 A
** memcpy from 1.2 Removed :)) and Works..
*******************************************************************************
*******************************************************************************
** 1.2               05/02/2014              Sanjeeva & Mahadeva
** Adc_Init Moved to system Init, As Battery Read is done before PassThruConnect
** unnecessary fill with 0 removed in CANNewMsgReceived
*******************************************************************************
*******************************************************************************
** 1.3               06/03/2014              Sanjeeva & Mahadeva
** CANNewMsgRecd moved to can_mid.c as PassThruReadMsgResp_CAN
** KWP Recieve Msgs moved to app_ISO14230 as PassThruReadMsgResp_KWP
** ReadBattVg retry and samples reduced
** processHFCPCmds() Removed
*******************************************************************************
*******************************************************************************
** 1.4               21/04/2014              Mahadeva
** For faster CAN Communication, memset with 0s and Seperate function calls
for CAN & CAN2 Implemented.
*******************************************************************************
*******************************************************************************
** 1.5               21/05/2014              Vipul & Mahadeva
** J1708 Protocol Handling Added
** LINK STATUS Init Behaviour Changed
** KWP2 Related Entries Deleted
** Timer Architecure Changes
*******************************************************************************/

