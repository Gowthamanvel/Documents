/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.2>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements Data Logger Managements
*******************************************************************************//*
 * Data_Logger.c
 *
 * Created: 8/26/2015 4:11:18 PM
 *  Author: amit
 */ 

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "board.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"
#include "HFCP.h"
#include "Proj_Config.h"
#include "Led_Handler.h"
#include "Proj_Config.h"
#include "Data_Logger.h"
#include "CAN_Mid.h"

#include "ff.h"
#include "Media.h"
#include "libsdmmc.h"
#include "fatfs_config.h"
#include "MEDSdcard.h"
#include "libstoragemedia.h"
#include "HSMCI_Mid.h"

#include "MSDDriver.h"
#include "MSDLun.h"
#include "USB_MSD_Mid.h"
#include "time_stamps.h"

#define DATALOG_DEBUG	1
/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#if DATALOG_DEBUG

uint32_t dlqfull			=0;
uint32_t dlqWrite			=0;
uint32_t CanReleaseCount	=0;
uint32_t totalFramedBuffer	=0;
uint32_t SDWriteFailure		=0;
uint32_t SDWriteSuccess		=0;

uint32_t queueErrorCount	=0;
uint32_t queueValue			=0;

uint32_t loggerTaskStart	=0;
uint32_t loggerTaskStop		=0;
uint32_t loggerTaskDiffTime =0;
uint32_t loggerTaskTickCount=0;
uint16_t queuebuf[200];

uint32_t logstop			=0;
uint32_t logstart			=0;
uint32_t logtracker[200];
uint8_t  logindex			=0;
uint64_t logstart64			=0;
uint32_t reopeningfiletime	=0;

extern volatile TickType_t xTickCount;
extern uint16_t taskTracker[255][2]; /*uint8_t*/
extern uint8_t taskTrackerIndex;

extern uint32_t CANqfull;
extern uint32_t CAN2qfull;
extern uint32_t CAN1MallocFailCount;
extern uint32_t CAN2MallocFailCount;
extern DWORD FileWriteCount;
#endif

//#define ADD_EXTRA_LOG 1
#if TEST_SD_CARD
QueueHandle_t SDWriteQ;
#endif
/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
QueueHandle_t dataLogQ;
EventGroupHandle_t dataLogEvent;

uint8_t framecompleted		=0;
uint8_t startLogging		=0;
uint16_t dataLogBufIndx		=0;
uint32_t fileNumber			=0;

char FileName[64];
extern uint8_t dataLogBuf[MSD_BUFFER_SIZE];//[SD_CARD_WRITE_SIZE];

extern  sSdCard sdDrv[BOARD_NUM_MCI];
extern uint8_t SDCardFull;
/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/


/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
/////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct QueueDefinition
{
	int8_t *pcHead;					/*< Points to the beginning of the queue storage area. */
	int8_t *pcTail;					/*< Points to the byte at the end of the queue storage area.  Once more byte is allocated than necessary to store the queue items, this is used as a marker. */
	int8_t *pcWriteTo;				/*< Points to the free next place in the storage area. */

	union							/* Use of a union is an exception to the coding standard to ensure two mutually exclusive structure members don't appear simultaneously (wasting RAM). */
	{
		int8_t *pcReadFrom;			/*< Points to the last place that a queued item was read from when the structure is used as a queue. */
		UBaseType_t uxRecursiveCallCount;/*< Maintains a count of the number of times a recursive mutex has been recursively 'taken' when the structure is used as a mutex. */
	} u;

	List_t xTasksWaitingToSend;		/*< List of tasks that are blocked waiting to post onto this queue.  Stored in priority order. */
	List_t xTasksWaitingToReceive;	/*< List of tasks that are blocked waiting to read from this queue.  Stored in priority order. */

	volatile UBaseType_t uxMessagesWaiting;/*< The number of items currently in the queue. */
	UBaseType_t uxLength;			/*< The length of the queue defined as the number of items it will hold, not the number of bytes. */
	UBaseType_t uxItemSize;			/*< The size of each items that the queue will hold. */

	volatile BaseType_t xRxLock;	/*< Stores the number of items received from the queue (removed from the queue) while the queue was locked.  Set to queueUNLOCKED when the queue is not locked. */
	volatile BaseType_t xTxLock;	/*< Stores the number of items transmitted to the queue (added to the queue) while the queue was locked.  Set to queueUNLOCKED when the queue is not locked. */

	#if ( configUSE_TRACE_FACILITY == 1 )
	UBaseType_t uxQueueNumber;
	uint8_t ucQueueType;
	#endif

	#if ( configUSE_QUEUE_SETS == 1 )
	struct QueueDefinition *pxQueueSetContainer;
	#endif

} xQUEUE;

/* The old xQUEUE name is maintained above then typedefed to the new Queue_t
name below to enable the use of older kernel aware debuggers. */
typedef xQUEUE Queue_t;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/*******************************************************************************
* Function Name  : DataLogFreeRTOS_Init
* Description    : Handles the Data Logger FreeRTOS initializations.
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void DataLogFreeRTOS_Init(void)
{
    if(pdFALSE == xTaskCreate(DataLog_Task, "Data_Log",DATALOG_TASK_STACK_SIZE,
    (void *) NULL, DATALOG_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        printf("Failed to create Data Log Task \r\n");
    }
    dataLogQ = xQueueCreate( DATA_LOG_Q_SIZE, ( unsigned portBASE_TYPE ) sizeof(Dynamic_QStruct_t));
    
    
    #if TEST_SD_CARD
    if(pdFALSE == xTaskCreate(SDCard_Tx_Task, "SD Card Write", SD_CARD_WRITE_TASK_STACK_SIZE,
    (void *) NULL, DATALOG_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        printf("Failed to createSD Card Write Task \r\n");
    }
    SDWriteQ = xQueueCreate( SD_WRITE_Q_SIZE, ( unsigned portBASE_TYPE ) sizeof(Dynamic_SD_Write_Struct_t));
    #endif
    dataLogEvent = xEventGroupCreate();
}

/*******************************************************************************
* Function Name  : Set_DatLog_Event
* Description    : Set_DatLog_Event
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Set_DatLog_Event (void)
{
    xEventGroupSetBits(dataLogEvent, DATA_LOG_EVENT_BIT);
    dataLogBufIndx = 0;
}

/*******************************************************************************
* Function Name  : Set_MSD_Event
* Description    : Set_MSD_Event
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Set_MSD_Event (void)
{
    xEventGroupSetBits(dataLogEvent, MSD_MODE_EVENT_BIT);    
}

/*******************************************************************************
* Function Name  : Clear_DatLog_Event
* Description    : Clear_DatLog_Event
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Clear_DatLog_Event (void)
{
    xEventGroupClearBits(dataLogEvent, DATA_LOG_EVENT_BIT);
}

/*******************************************************************************
* Function Name  : Clear_MSD_Event
* Description    : Clear_MSD_Event
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Clear_MSD_Event (void)
{
  xEventGroupClearBits(dataLogEvent, MSD_MODE_EVENT_BIT);
}

/*******************************************************************************
* Function Name  : Is_DataLog_Active
* Description    : Is_DataLog_Active
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
bool Is_DataLog_Active(void)
{
    if(xEventGroupGetBits(dataLogEvent) & DATA_LOG_EVENT_BIT)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/*******************************************************************************
* Function Name  : Is_Start_Logging_Active
* Description    : Is_Start_Logging_Active
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
bool Is_Start_Logging_Active(void)
{
    if(xEventGroupGetBits(dataLogEvent) & START_LOGGING_EVENT_BIT)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/*******************************************************************************
* Function Name  : WriteToLog
* Description    : WriteToLog
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void WriteToLog (Dynamic_QStruct_t dataToQ)
{
    dataToQ.len = 64;
	#if DATALOG_DEBUG
	dlqWrite++;
	#endif
    if(xQueueSend(dataLogQ, &dataToQ, 0) != pdTRUE)
    { 
		#if DATALOG_DEBUG       
        dlqfull++;
		USB_MSD_Led_ON();
		#endif
		vPortFree((void*)dataToQ.address);
    }
}

/*******************************************************************************
* Function Name  : Datalog_Reset_Queue
* Description    : Datalog_Reset_Queue
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Datalog_Reset_Queue(void)
{
	Dynamic_QStruct_t dataReadFromQ;
	
	while (xQueueReceive(dataLogQ,  &dataReadFromQ, 0) == pdTRUE)
	{
		vPortFree(dataReadFromQ.address);
	}
}

#if TEST_SD_CARD
/******************************************************************************
**	Function Name	:Garuda_Tx_data_on_USB
**	Input Params	:
**	Output Params	:
**	Description	:
******************************************************************************/
uint32_t canBuffeqfcnt;
uint32_t CanBufRelease = 0;
uint32_t GarudaTxdataFail =0;

void WriteToLogwithMemAlloc(uint8_t *pHfcpAck)
{
    Dynamic_QStruct_t dataToQ;

    dataToQ.len = HFCP_TX_BUFFER_SIZE;
    
    dataToQ.address = pvPortMalloc(dataToQ.len);

    if(dataToQ.address)
    {
        memcpy(dataToQ.address,pHfcpAck,dataToQ.len);
        vPortFree(pHfcpAck);
        CanBufRelease++;

        if(xQueueSend(dataLogQ, (void*)&dataToQ, 0 ) == pdFAIL)
        {
            canBuffeqfcnt++;
            vPortFree((void*)dataToQ.address);
        }
    }
    else
    {
        GarudaTxdataFail++;
        vPortFree(pHfcpAck);
        CanBufRelease++;
    }
}
#endif

/*******************************************************************************
* Function Name  : Flush_Datalog
* Description    : Flush_Datalog
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Flush_Datalog (void)
{
    Enq_CAN1_Remaining_Data();
    Enq_CAN2_Remaining_Data();
}

uint16_t bytesWritten;
uint8_t testbuffer[512];
/*******************************************************************************
* Function Name  : DataLog_Task
* Description    : DataLog_Task
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void DataLog_Task(void *PvParam)
{
    Dynamic_QStruct_t dataReadFromQ;
    
    FATFS   FatFs;
    FIL dataLogFile;
    uint32_t taskDiffTime = 0;
	FRESULT res;
	uint64_t current_time;
	
    /**< Initialize the HSMCI Ports pins for SD Card Operation */
    HSMCI_ConfigurePIOs();
 
    /**< Initialize driver instances */
    Initialize_HSMCI_Drivers(0);

    for(;;)
    {
        if((xEventGroupWaitBits(dataLogEvent,(EventBits_t) DATA_LOG_EVENT_BIT,pdFALSE, pdFALSE,portMAX_DELAY) & DATA_LOG_EVENT_BIT) == true)
        {
            SD_Card_Init(&sdDrv[0]);

            if (f_mount(&FatFs, "", 1) == FR_OK)
            {                                				
                sprintf(&FileName[0],"Garuda_DataLog_%llu.txt",get_extended_32Bit_data_logging_timestamp(&current_time));				
                if (f_open(&dataLogFile, (const char*)&FileName, FA_CREATE_ALWAYS | FA_WRITE) ==  FR_OK)                
				{      
					memset(&dataLogBuf[0], 0, 512);					
					sprintf((char*)&dataLogBuf[0], "Garuda Data Logger : DD/MM/YYYY HH-MM-SS");										
					f_write(&dataLogFile, (const char*)&dataLogBuf[0], 512, (UINT*) &bytesWritten);
					dataLogBufIndx = 0;
					startLogging = 1;
					 
                    while(Is_DataLog_Active())
                    {																															
                        while(xQueueReceive(dataLogQ, &dataReadFromQ, 50/*portMAX_DELAY*/) == pdPASS)
                        {
                            memcpy(&dataLogBuf[dataLogBufIndx], dataReadFromQ.address,dataReadFromQ.len);
                            vPortFree(dataReadFromQ.address);							
							
							#if DATALOG_DEBUG
                            CanReleaseCount++;
							#endif
                            dataLogBufIndx+= dataReadFromQ.len;
                            if((dataLogBufIndx+HFCP_MAX_IN_SINGLE_FRAME) > SD_CARD_WRITE_SIZE)
                            {
								#if DATALOG_DEBUG
                                totalFramedBuffer++;
								#endif
								framecompleted = 1;
								if(SDCardFull)
								{
									framecompleted = 0;
									dataLogBufIndx =0;									
								}								
                                break;
                            }
                        }
                        
                        if(dataLogBufIndx && framecompleted)
                        {
							#if DATALOG_DEBUG    
                            SDWriteSuccess++;
							#endif 
							framecompleted = 0;
                            dataLogBufIndx = SD_CARD_WRITE_SIZE;
                            
							#if DATALOG_DEBUG
                            loggerTaskStart = xTickCount;	
							get_time_stamp(&logstart);						                            																																												                                                                             
                            #endif
							
							res = f_write(&dataLogFile, dataLogBuf, dataLogBufIndx, (UINT*) &bytesWritten);							
							if(res == FR_FILE_MEMORY_4GB_FULL)
                            {
								#if DATALOG_DEBUG
                                SDWriteFailure++;
								#endif
																								
								get_time_stamp(&logstart);
														
								f_close(&dataLogFile);
								//OpenDataLoggingFile(&dataLogFile);
								fileNumber++;
								sprintf(&FileName[0],"Garuda_DataLog_%llu_%ld.txt",get_extended_32Bit_data_logging_timestamp(&current_time),fileNumber);
														
								if (f_open(&dataLogFile, (const char*)&FileName, FA_CREATE_ALWAYS | FA_WRITE) ==  FR_OK)
								{									
									memset(testbuffer, 0, 512);
															
									sprintf((char*)&testbuffer[0], "Garuda Data Logger2 : DD/MM/YYYY HH-MM-SS");
									f_write(&dataLogFile, (const char*)&testbuffer[0], 512, (UINT*) &bytesWritten);
																																							
									f_write(&dataLogFile, dataLogBuf, dataLogBufIndx, (UINT*) &bytesWritten);
									dataLogBufIndx = 0;
								}
														
								get_time_stamp(&logstop);
								reopeningfiletime = logstop - logstart;							                              
                            }
							 
							#if DATALOG_DEBUG 							                                                      
                            loggerTaskStop = xTickCount;
							get_time_stamp(&logstop);
                            taskDiffTime = (loggerTaskStop < loggerTaskStart) ? (((~0u) - loggerTaskStop) + loggerTaskStart) : (loggerTaskStop - loggerTaskStart);
                            if (loggerTaskDiffTime < taskDiffTime)
                            {
                                loggerTaskDiffTime = taskDiffTime;
                            }
                            loggerTaskTickCount +=taskDiffTime;
							
                            queueValue = ((Queue_t*)dataLogQ)->uxMessagesWaiting;
														
							taskTracker[taskTrackerIndex][0] = queueValue;							
                            taskTracker[taskTrackerIndex++][1] = taskDiffTime;
							logtracker[logindex++] = logstop - 	logstart;
							if(logindex == 200)
							logindex = 0;						
							#endif
							
                            #if DATALOG_DEBUG
							if(queueValue >= 500)
							{
								queuebuf[queueErrorCount++] = queueValue;
								if ( queueErrorCount == 200){
									queueErrorCount =0;
								}
								
								if(queueValue == 2500)
								{
									USB_MSD_Led_ON();
							 		printf("Error");
								}
							}
							#endif
							memset(&dataLogBuf[0],0, SD_CARD_WRITE_SIZE);
							dataLogBufIndx = 0;
                        }                                                    
                    }
					startLogging = 0;

					if(dataLogBufIndx)
					{
						dataLogBufIndx = SD_CARD_WRITE_SIZE;
						if(f_write(&dataLogFile, dataLogBuf, dataLogBufIndx, (UINT*) &bytesWritten) != FR_OK)
						{
							#if DATALOG_DEBUG
							SDWriteFailure++;
							#endif                                
						}
						dataLogBufIndx = 0;
					}
					
					#if ADD_EXTRA_LOG
					memset(testbuffer, 0 ,512);
					sprintf((char*)&testbuffer[0], 
					"Garuda Error Monitoring : TEST LOGS CAN1QFULL-%ld CAN2QFULL -%ld CAN1_MALLOC_FAIL - %ld CAN2_MALLOC_FAIL -%ld DATALOG_QFULL -%ld NO_OF_4GB_FILE-%ld",
															CANqfull, CAN2qfull, CAN1MallocFailCount, CAN2MallocFailCount, dlqfull, FileWriteCount );
					
					f_write(&dataLogFile, (const char*)&testbuffer[0], 512, (UINT*) &bytesWritten);
					
					#endif
									
                    f_close(&dataLogFile);
                    printf("File Closed\n\r");                    
                    if (f_mount(NULL, "", 0) == FR_OK)
                    {                        
                        printf("Drive Unmounted\n\r");
                    }
                    SD_DeInit(&sdDrv[0]);
                }
                else
                {
                    printf("File Not Created\n\r");
                }
            }
            else
            {
                printf("Unable to Mount Drive\n\r");
            }
        }
    }
}


void OpenDataLoggingFile( FIL* DataLogFile )
{
	#if TEST_CODE
	uint8_t openStatus = TRUE;
	uint8_t *allocAddress;
	uint16_t bytesWritten=0;
	
	fileNumber++;
	sprintf(&FileName[0],"Garuda_DataLog_%ld.txt",fileNumber);
	
	if (f_open(DataLogFile, (const char*)&FileName, FA_CREATE_ALWAYS | FA_WRITE) ==  FR_OK)
	{				
		//allocAddress = pvPortMalloc(512);
		//memset(testbuffer, 0, 512);		
				
		sprintf((char*)&testbuffer[0], "Garuda Data Logger2 : DD/MM/YYYY HH-MM-SS");
		f_write(DataLogFile, (const char*)&testbuffer[0], 512, (UINT*) &bytesWritten);
		
		//vPortFree((void*)allocAddress);
		
		//f_write(&DataLogFile, dataLogBuf, dataLogBufIndx, (UINT*) &bytesWritten);		
		dataLogBufIndx = 0;		
	}			
	//return 0;//openStatus;
	#endif
}




#if TEST_SD_CARD
/******************************************************************************
* Function name     : Send_To_HFCP_Queue
* returns           : None
* parameters        : hfcpReqBuf, reqLen
* Description       : Sends the data to the HFCP Queue
*******************************************************************************/
uint32_t WriteSDCardAllocFail = 0;
uint32_t WriteSDCardAllocCount = 0;
uint32_t WriteSDCardReleaseCount = 0;


void Send_To_SD_Write_Queue(uint8_t *WriteBuf, uint16_t reqLen, uint32_t sector )
{
    Dynamic_SD_Write_Struct_t dataToSDWriteQ;
    
    dataToSDWriteQ.len = reqLen;
    //dataToSDWriteQ.address = pvPortMalloc(dataToSDWriteQ.len);
    dataToSDWriteQ.address = pvPortMalloc(dataToSDWriteQ.len  * 512);
     
    if(dataToSDWriteQ.address)
    {
        WriteSDCardAllocCount++;
        dataToSDWriteQ.sector = sector;
        memcpy(dataToSDWriteQ.address,WriteBuf,( dataToSDWriteQ.len * 512));
        if(xQueueSend(SDWriteQ, (void*)&dataToSDWriteQ, 0 ) == pdFAIL)
        {
            vPortFree((void*)dataToSDWriteQ.address);            
        }
    }
    else
    {
        WriteSDCardAllocFail++;
    }
}

extern sMedia medias[1];
uint32_t SDErrorCount;

void SDCard_Tx_Task(void *PvParam)
{
    Dynamic_SD_Write_Struct_t dataReadFromSDWriteQ;
    uint16_t bytesWritten;
    FATFS   FatFs;
    FIL dataLogFile;
    uint32_t taskDiffTime = 0;

    for(;;)
    {
         while(xQueueReceive(SDWriteQ, &dataReadFromSDWriteQ, portMAX_DELAY) == pdPASS)
         {
             if(MED_STATUS_SUCCESS != MED_Write(&medias[0], dataReadFromSDWriteQ.sector, (void*)dataReadFromSDWriteQ.address, dataReadFromSDWriteQ.len, NULL, NULL))
             SDErrorCount++;
             
             vPortFree(dataReadFromSDWriteQ.address);
             WriteSDCardReleaseCount++;
         }             
    }
}            

#endif

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      8/3/2015 2:50:13 PM
* Initial version.
*
******************************************************************************/

