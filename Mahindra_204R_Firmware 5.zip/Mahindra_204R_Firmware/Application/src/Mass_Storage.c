/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.2>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
 * Mass_Storage.c
 *
 * Created: 11/23/2015 12:14:13 PM
 *  Author: amit
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements Data Logger Managements
*******************************************************************************/

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "board.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"
#include "HFCP.h"
#include "Proj_Config.h"
#include "Led_Handler.h"
#include "Proj_Config.h"
#include "Data_Logger.h"
#include "CAN_Mid.h"
#include "Mass_Storage.h"
#include "USB_MSD_Mid.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
extern EventGroupHandle_t dataLogEvent;
extern uint8_t USB_Device_Mode;

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/*******************************************************************************
* Function Name  : MassStorageFreeRTOS_Init
* Description    : Handles the Mass Storage FreeRTOS initializations.
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void MassStorageFreeRTOS_Init(void)
{
    if(pdFALSE == xTaskCreate(MSD_Management_Task, "Mass Storage", MSD_TASK_STACK_SIZE,
    (void *) NULL, MSD_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        printf("Failed to create MSD Task \r\n");
    }
}

/*******************************************************************************
* Function Name  : SDCard_Tx_Task
* Description    : Handles the Mass Storage Management
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void MSD_Management_Task(void *PvParam)
{
    for(;;)
    {
        if((xEventGroupWaitBits(dataLogEvent,(EventBits_t) MSD_MODE_EVENT_BIT,pdFALSE,
        pdFALSE,portMAX_DELAY)) && (USB_Device_Mode == MSD)) // & MSD_MODE_EVENT_BIT) == true)
        {
            USB_MSD_Mid_Init();
			//Clear_MSD_Event();
        }		 	          
    }
}

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                     11/23/2015 12:14:13 PM
* Initial version.
*
******************************************************************************/