/*
 * Garuda_Main.c
 *
 *  Created on: May 27, 2015
 *      Author: ramesh
 */


/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"
#include "Proj_Config.h"
#include "USB_Mid.h"
#include "SPI_Mid.h"
#include "HFCP.h"
#include "Wifi_SN8200.h"
#include "Garuda_Main.h"
#include "J2534_periodic.h"
#include "Led_Handler.h"
#include "app_iso14230.h"
#include "GPIO_Mid.h"
#include "Data_Logger.h"
#include "event_groups.h"
#include "Mass_Storage.h"
#include "USB_MSD_Mid.h"
/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
static Garuda_Main_State garuda_main_state;
uint8_t HFCPComMode;
/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/
void Garuda_Main_Task (void*);

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/
extern void External_Interrupt_Config(void);

void GarudaFreeRTOS_Init (void) {
    garuda_main_state = GARUDA_IN_IDLE_STATE;
    /* Initialize Garuda Main Task */
    if(pdTRUE != xTaskCreate(Garuda_Main_Task, GARUDA_MAIN_TASK_NAME, GARUDA_MAIN_TASK_STACK_SIZE,
                           (void *) NULL, GARUDA_MAIN_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        /* Unable to create Garuda Main Task */
        while(1);
        return;
    }
}

void GarudaAppFreeRTOS_Init (void)
{
    /* Initialize CAN Task */
    CAN_FreeRTOSInit();

    /* Initialize USB Task */
    USBFreeRTOS_Init();
	
	/* Initialize SPI */
	SPIFreeRTOS_Init();

    /* Initialize WiFi Task */
    WiFiFreeRTOS_Init();

    /* Initialize HFCP Task */
    HFCPFreeRTOS_Init();

    /* Initialize Garuda Main Task */
    GarudaFreeRTOS_Init();
    
    /* Initialize Periodic Messages Timers */
    PeriodicMessageFreeRTOS_Init();
    
    KWPFreeRTOS_Init();
    
    LEDFreeRTOS_Init();
    
    DataLogFreeRTOS_Init();
    
    MassStorageFreeRTOS_Init();
}

uint8_t usb_status = USB_LINK_OFF;
uint8_t vbatt_status = VBATT_LINK_OFF;
uint8_t Wifi_Initialized = FALSE;
uint8_t USB_Device_Mode = HID;
extern EventGroupHandle_t dataLogEvent;
uint8_t GarudaOperatingMode = DEFAULT_MODE;

void Garuda_Main_Task (void *pArg) {
    uint8_t wifiMode;
	uint8_t usbState;
    uint32_t BattVg = 0; 
    uint8_t boardConnected =0;   
	/* Garuda Main Task */
    
    boardConnected = get_BoardDetect_Value();
	USB_Device_Mode = HID;
	External_Interrupt_Config();
	SN8200ConfigReset();
	SN8200HoldReset();
    
    do {
		
		if(MSD == USB_Device_Mode)
		{
			garuda_main_state = GARUDA_IN_MSD_STATE;					
		}
		
        switch(garuda_main_state)         
        {						
        case GARUDA_IN_IDLE_STATE:
            garuda_main_state = GARUDA_IN_INIT_STATE;            
            break;
            
        case GARUDA_IN_INIT_STATE:            
            /* USB_Mid_Init();*/
            garuda_main_state = GARUDA_IN_MODE_DETECT_STATE;
			break;            
            
        case GARUDA_IN_MODE_DETECT_STATE:            
            if ((usbState = USB_Mid_IsConnected(5000)) && (GarudaOperatingMode != WIFI_MODE) ) {                
                USB_Led_ON();
                WiFi_Led_OFF();
                // Start in USB Mode                 
				HFCP_setApplicationMode(GARUDA_IN_USB_MODE);
                usb_status = USB_LINK_ON;
                Wifi_Initialized = FALSE;
                garuda_main_state = GARUDA_IN_RUNNING_STATE;
				GarudaOperatingMode = USB_MODE;				
            }
            else
            {				               
                 if((Read_BatteryVoltage(&BattVg)) && (BattVg > 5000) && (GARUDA_USB != boardConnected) && (!Is_DataLog_Active()) && (GarudaOperatingMode != USB_MODE))
                 {                                                         
                    /* Initialize SPI for Wifi */
                    SPI_Mid_Init();                                                         
                    SN8200HoldReset();
                    SN8200ReleaseReset();
                    /* Start in WiFi Mode */                
                    wifiMode = Wifi_Init();										
                    if(NONE_MODE != wifiMode)
                    {
                        Wifi_Start_Network(wifiMode);
                        WiFi_Led_ON();
                        USB_Led_OFF();
                        HFCP_setApplicationMode(GARUDA_IN_WIFI_MODE);
                        Wifi_Initialized = TRUE;
                        garuda_main_state = GARUDA_IN_RUNNING_STATE;
						GarudaOperatingMode = WIFI_MODE;
						USBD_Disconnect();
                    }
					else
					{
						/* If Wi-Fi initialization fails, try switching back to USB mode, else keep retrying to initialize Wi-Fi */
						SPI_Mid_Deinit();
						SN8200HoldReset();
						Wifi_Initialized = FALSE;
						HFCP_setApplicationMode(GARUDA_IN_USB_MODE);
						garuda_main_state = GARUDA_IN_STOP_STATE;
					}                        
                 }
                 else
                 {
                     /* Notes */
					 /* Scenario 1 - For USB Garuda (without Wi-Fi add-on board) if enumeration fails, we are stuck here. Currently this is 
					    NOT handled. So we need power cycling (disconnect USB and VBatt) to recover. 
						Can explore graceful handling (like USB re-init), if needed.
				     */
					 /* Scenario 2 - For Wi-Fi Garuda (with Wi-Fi add-on board) if Vbatt < 5 Volts, we are stuck here. Currently this is 
					    NOT handled. So we need power cycling (disconnect VBatt and ensure it is >5 Volts) to recover.
				     */
					 /* Scenario 3 - Datalogging is ON, no need of USB connection and No need of switching to Wi-Fi. 
					    No need of task delay as "USB_Mid_IsConnected(2000)" provides 100mS Task Delay.
				     */
                 }                    
            }
            break;
            
        case GARUDA_IN_RUNNING_STATE:
            /* Start running application based on mode */
			if(0 == Is_DataLog_Active())
			{		
			   if ( (usbState != USB_Mid_IsConnected(200)) && (GarudaOperatingMode == USB_MODE)) {
					TRACE_INFO("NOT RUNNING\r\n");
					garuda_main_state = GARUDA_IN_STOP_STATE;
					usb_status = USB_LINK_OFF;
					USB_Led_OFF();
					HFCP_setApplicationMode(GARUDA_IN_WIFI_MODE);
				}
            	
				/*	
				if((USBD_STATE_CONFIGURED == USB_Mid_Get_State(10)) && (TRUE == Wifi_Initialized))
				{
					SPI_Mid_Deinit();
					SN8200HoldReset();
					Wifi_Initialized = FALSE;
					HFCP_setApplicationMode(GARUDA_IN_USB_MODE);
				}                  
                                                  
				if(((HFCPComMode == HFCP_COM_MODE_USB) && (usb_status == USB_LINK_OFF)) ||
				((HFCPComMode == HFCP_COM_MODE_WIFI) && (Wifi_Initialized == FALSE)) )
				{
					// WiFi_OFF_USB_OFF_Status();
					WiFi_Led_OFF();
					USB_Led_OFF();
					DisconnectAllChanels();
					garuda_main_state = GARUDA_IN_STOP_STATE;
				}
				*/
			}
			else
			{
				 if (usbState != USB_Mid_IsConnected(200)) {					
					 garuda_main_state = GARUDA_IN_STOP_STATE;
					 usb_status = USB_LINK_OFF;
					 USB_Led_OFF();					 
				 }
			}				 
            break;
		    
        case GARUDA_IN_STOP_STATE:                 
			garuda_main_state = GARUDA_IN_INIT_STATE;			
            break;
			
		case GARUDA_IN_MSD_STATE :
			if(HID == USB_Device_Mode)
			{					
				garuda_main_state = GARUDA_IN_INIT_STATE;
				usb_status = USB_LINK_OFF;
				SPI_Mid_Deinit();
				SN8200HoldReset();
				Wifi_Initialized = FALSE;
			}
			vTaskDelay(1);			 				
			break;
			
            
        default:
            /* Corrupted state machine */
            while(1);
            break;
        }
    } while(1);
}

void Garuda_Main_ResetQueue (QueueHandle_t qHandle, uint16_t elementSize, uint8_t release)
{
    void *pBuffer;
    //taskENTER_CRITICAL();
    pBuffer = pvPortMalloc(elementSize);
    if (pBuffer)
    {
        while (xQueueReceive(qHandle, pBuffer, 1) == pdTRUE)
        {
            if (release)
                vPortFree(pBuffer);
        }
        vPortFree(pBuffer);
    }
    //taskEXIT_CRITICAL();
}



