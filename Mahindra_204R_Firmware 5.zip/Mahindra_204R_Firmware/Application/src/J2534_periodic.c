/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements periodic message handling
*******************************************************************************/

#ifndef HFCP_PERIODIC_C
#define HFCP_PERIODIC_C

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/

#include "board.h"
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "J2534_periodic.h"
#include "j2534_filter.h"
#include "HFCP.h"
#include "SPI_Mid.h"
#include "CAN_Mid.h"
#include "iso14230.h"
#include "time_stamps.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define    c_MAX_PERIODIC_MSG          10
#define    c_TX_IMMEDIATE_CNT          1
#define    PERIODIC_STEPVAL            1000
#define    TICK_PERIOD_MS              1 /* 1000/1000 */ 

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
static void can_handle_periodic_msg(uint8_t i, uint8_t p_ch_index);
static uint8_t startnew_pmsg (PERIODIC_MSG  *);
static uint8_t stop_pmsg( uint8_t , uint8_t );
uint8_t suspend_pmsg ( uint8_t );
static uint8_t update_new_pmsg (PERIODIC_MSG  *p_msg_ptr);

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/* The Constant data array of Protocols IDs which need are enabled
by Garuda - Re-arange GARUDA_ChannelNum_t(.h file) in same order*/

static uint8_t l_pmsg_count_hold[NO_OF_CHANNEL_USED]={0};
static uint8_t periodic_cnt=0;

/* Holds the structure of periodic messages that are to be transmitted */
static PERIODIC_MSG l_pmsg_buf[NO_OF_CHANNEL_USED][c_MAX_PERIODIC_MSG ];

/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/
void Garuda_Tx_data_on_USB(uint8_t *p_data_U8, uint16_t p_length, uint8_t release);

/******************************************************************************
* Function name : static BYTE update_new_pmsg (PERIODIC_MSG  *p_msg_ptr,
*                  BYTE *p_pmsg_id)
*    returns    : Returns PERIODIC_SUCCESS if it is success or
*                         else returns PERIODIC_EXCEEDED_LIMIT.
*    *p_msg_ptr : new periodic message pointer that has to
*                                 be transmitted.
* Description   : update the periodic msg into the periodic msg buffer
*******************************************************************************/
static uint8_t update_new_pmsg (PERIODIC_MSG  *p_msg_ptr)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i,j;
    
    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_msg_ptr->protocol_id==GarudaProID_Used[fl_ProtoIndex])
        {
            /* The Protocol ID Matched @fl_ProtoIndex*/
            break;
        }
    }
    
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        if((p_msg_ptr->prmsg_id < 1) || (p_msg_ptr->prmsg_id > 10))
        {
            fl_ret_val = PERIODIC_INVALID_MSG_ID;
        }
        else
        {
            /**< Disable Timer Interrupt */
            /**< __disable_interrupt(); */
            //Disable_Timer_Irq();
            
            for(i=0; i<c_MAX_PERIODIC_MSG; i++)
            {
                if(l_pmsg_buf[fl_ProtoIndex][i].prmsg_id == p_msg_ptr->prmsg_id)
                {
                    /**< Copy Tx Flags */
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.tx_flags =
                    p_msg_ptr->proto_msg.tx_flags;
                    
                    /**< Copy Message Length */
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length =
                    p_msg_ptr->proto_msg.length;
                    
                    /**< Copy Data */
                    for(j = 0; j < l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length; j++)
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[j] =
                    p_msg_ptr->proto_msg.data[j];
                    
                    /**< Copy Periodicity and local Periodicity */
                    l_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * portTICK_PERIOD_MS);
                    /* l_pmsg_buf[fl_ProtoIndex][i].local_periodicity = l_pmsg_buf[fl_ProtoIndex][i].periodicity; */
                    l_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT; 
                    
                    /**< Handling required */                     
                     //PERIODIC_handler();
                    
                    fl_ret_val = PERIODIC_SUCCESS;
                }
            }
            /**< Enable Timer Interrupt */
            /**< __enable_interrupt(); */
            //Enable_Timer_Irq();
        }
    }
    return fl_ret_val;
}



/******************************************************************************
* Function name : static BYTE startnew_pmsg (PERIODIC_MSG  *p_msg_ptr,
*                  BYTE *p_pmsg_id)
*    returns    : Returns PERIODIC_SUCCESS if it is success or
*                         else returns PERIODIC_EXCEEDED_LIMIT.
*    *p_msg_ptr : new periodic message pointer that has to
*                                 be transmitted.
* Description   : adds the periodic msg into the periodic msg buffer
* Notes         : if a periodic message comes after timer started then
*                         for first time it will transmit mesg after 1msec of
*                   timeout
*******************************************************************************/
static uint8_t startnew_pmsg(PERIODIC_MSG  *p_msg_ptr)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i,j;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_msg_ptr->protocol_id==GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        /*
        * verify for buffer full
        */

        if(l_pmsg_count_hold[fl_ProtoIndex] == 10)
        {
            fl_ret_val = PERIODIC_EXCEEDED_LIMIT;
        }
        else
        {

            for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
            {
                /*
                * search fr free buffer
                */

                if(l_pmsg_buf[fl_ProtoIndex][i].prmsg_id == 0)
                {
                    /* Store the Free Id  (1 to 10) */
                    l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = i + 1;

                    /* Update Id for response */
                    p_msg_ptr->prmsg_id  = l_pmsg_buf[fl_ProtoIndex][i].prmsg_id;

                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.tx_flags =
                        p_msg_ptr->proto_msg.tx_flags;
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length =
                        p_msg_ptr->proto_msg.length;
                    for(j = 0; j < l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length; j++)
                            l_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[j] =
                                p_msg_ptr->proto_msg.data[j];


                    /* l_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * 1000) / PERIODIC_STEPVAL; */
                    l_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * TICK_PERIOD_MS);
                    /* Transmit first message immediately, so local periodicity shd be c_TX_IMMEDIATE_CNT */
                    l_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT;
                                                   
                    //PERIODIC_handler();
                    
                    /* Increment the count of periodic message for the channel */
                    (l_pmsg_count_hold[fl_ProtoIndex])++;
                    periodic_cnt++;
                    fl_ret_val = PERIODIC_SUCCESS;
                    break;
                }
            }
        }
    }
    return fl_ret_val;
}

/******************************************************************************
* Function name    : static BYTE stop__pmsg( BYTE p_pmsg_id, BYTE p_protocol_id)
*    returns       : returns PERIODIC_SUCCESS, if success else
*                         returns PERIODIC_INVALID_MSG_ID.
*    p_pmsg_id          : periodic message id
*    p_protocol_id : protocol id
* Description      : removes the particular periodic message from
*                         the periodic message buffer
* Notes            :
*******************************************************************************/
static uint8_t stop_pmsg( uint8_t p_pmsg_id,uint8_t p_protocol_id)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_protocol_id==GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        /*
         * verifies for valid periodic msg id
         */

        if((p_pmsg_id < 1) || (p_pmsg_id > 10))
        {
            fl_ret_val = PERIODIC_INVALID_MSG_ID;
        }
        else
        {
            for(i=0; i<c_MAX_PERIODIC_MSG; i++)
            {
                 if(l_pmsg_buf[fl_ProtoIndex][i].prmsg_id == p_pmsg_id)
                 {
                    l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
                    (l_pmsg_count_hold[fl_ProtoIndex])--;
                    if(periodic_cnt)
                        periodic_cnt--;
                    fl_ret_val = PERIODIC_SUCCESS;
                 }
            }
            if( fl_ret_val!= PERIODIC_SUCCESS)
            {
                fl_ret_val = PERIODIC_INVALID_MSG_ID;
            }
        }
    }
    return fl_ret_val;
}

/******************************************************************************
* Function name : static BYTE suspend_pmsg (BYTE p_protocol_id)
*    returns        : returns PERIODIC_SUCCESS, if success else
*                         returns PERIODIC _FAILED.
*    p_protocol_id      : protocol id
* Description       : clears the periodic message buffer
* Notes         :
*******************************************************************************/
uint8_t suspend_pmsg(uint8_t p_protocol_id)
{

    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_protocol_id==GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        if((l_pmsg_count_hold[fl_ProtoIndex])!= 0)
        {
            for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
            {
                l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
            }
            l_pmsg_count_hold[fl_ProtoIndex]=0;
            fl_ret_val = PERIODIC_SUCCESS;
        }
        else
        {
            fl_ret_val = PERIODIC_FAILED;
        }
    }
    return fl_ret_val;
}


/******************************************************************************
* Function name : static void periodic_iso9141_14230(void)
*    returns        : Returns void
*    arg1           : index: Buffer index for retrieving data for Tx frame
* Description       : Function to handle ISO 9141 / 14230 periodic msgs
*******************************************************************************/
static void periodic_14230(uint8_t index)
{
    ISO9141_14230_TxMsg_S fl_App_ISO9141_14230TxMsg_S;
    ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus;
    uint16_t loop_cnt;

    /* Determine the Tx message */
    fl_App_ISO9141_14230TxMsg_S.Flags  = l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.tx_flags;
    fl_App_ISO9141_14230TxMsg_S.Length =l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.length;
    /* Check The Format byte for Length */
    /*if((l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.data[0])&0x3F)
    {
        // Format byte Lenghth Mask + Format + src + des byte
        fl_App_ISO9141_14230TxMsg_S.Length =
                                            ((l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.data[0])&0x3F)+3;
    }
    else
    {
        // Additional length + Format + src + des + Aditional Length byte
        fl_App_ISO9141_14230TxMsg_S.Length =
                                            l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.data[3]+4;
    }*/
    for(loop_cnt = 0;
    loop_cnt < fl_App_ISO9141_14230TxMsg_S.Length;
    loop_cnt++)
    {
        fl_App_ISO9141_14230TxMsg_S.Data[loop_cnt] = l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.data[loop_cnt];
    }
    /* Call the Write Message function */
    fl_ISO9141_14230RetStatus =
                               ISO9141_14230_WriteMsg(&fl_App_ISO9141_14230TxMsg_S);
    if(NO_ERROR != fl_ISO9141_14230RetStatus)
    {
      /* Q Full - Discard Message */
    }

}

/*******************************************************************************
* Function Name  : can_handle_periodic_msg(BYTE i)
* Description    :
* Input          : pvParameters	:
* Output         : None
* Return         : void
*******************************************************************************/
static void can_handle_periodic_msg(uint8_t i, uint8_t p_ch_index)
{

    uint8_t loop_cnt=0;
    CAN_TX_Msg_t  fl_msg;
    uint32_t CAN_tx_flags;
    Mid_API_Status_t fl_Q_Status;
    
    CAN_tx_flags = l_pmsg_buf[p_ch_index][i].proto_msg.tx_flags;
    fl_msg.rtr = 0; /**< fl_msg.tx_app_buff.is_rem_frm = 0; */
    
    if(CAN_tx_flags & CAN_29BIT_ID)
    {
        fl_msg.ide = TRUE; /**<  fl_msg.tx_app_buff.is_ext_frm = TRUE; */
    }
    else
    {
        fl_msg.ide =FALSE; /**< fl_msg.tx_app_buff.is_ext_frm = FALSE; */
    }
    
    fl_msg.msg_id = ((l_pmsg_buf[p_ch_index][i].proto_msg.data[3])|
                                (l_pmsg_buf[p_ch_index][i].proto_msg.data[2]<<8)|
                                (l_pmsg_buf[p_ch_index][i].proto_msg.data[1]<<16)|
                                l_pmsg_buf[p_ch_index][i].proto_msg.data[0]<<24);
                                
    /**< fl_msg.tx_app_buff.tx_buff_len = l_pmsg_buf[p_ch_index][i].proto_msg.length - 4; */    
    fl_msg.dlc = l_pmsg_buf[p_ch_index][i].proto_msg.length - 4;    
    
    for(loop_cnt=0; loop_cnt < fl_msg.dlc; loop_cnt++)
    {
        fl_msg.data[loop_cnt] =
            l_pmsg_buf[p_ch_index][i].proto_msg.data[4 + loop_cnt];
    }
    
    /**< fl_msg.is_periodic_msg = TRUE; */ //IMPORTANT ?? IS THIS REQUIRED ???
    
    /* Add To Queue */
    if(GARUDA_CAN_CH1==p_ch_index)
    {
         fl_Q_Status = CAN_Mid_Transmit_ISR(CAN_CH1, &fl_msg);
        //fl_Q_Status = CAN_Mid_WriteTxQ(fl_msg);
    }
    else if(GARUDA_CAN_CH2==p_ch_index)
    {
         fl_Q_Status = CAN_Mid_Transmit_ISR(CAN_CH2, &fl_msg);
        //fl_Q_Status = CAN2_Mid_WriteTxQ(fl_msg);
    }
    else
    {
        /* Do Nothing */
    }
    //if (fl_Q_Status == CAN_Q_FULL)
    if (fl_Q_Status == MID_FAIL)
    {
        /* Queue is Full -- Not Decided the Action next */
    }
}


/*******************************************************************************
* Function Name  : can_handle_periodic_msg(BYTE i)
* Description    :
* Input          : pvParameters	:
* Output         : None
* Return         : void
*******************************************************************************/
static void J1939_handle_periodic_msg(uint8_t i, uint8_t p_ch_index)
{
	uint8_t loop_cnt=0;
	CAN_TX_Msg_t  fl_msg;
	uint32_t CAN_tx_flags;
	Mid_API_Status_t fl_Q_Status;
	
	CAN_tx_flags = l_pmsg_buf[p_ch_index][i].proto_msg.tx_flags;
	fl_msg.rtr = 0; /**< fl_msg.tx_app_buff.is_rem_frm = 0; */
	
	if(CAN_tx_flags & CAN_29BIT_ID)
	{
		fl_msg.ide = TRUE; /**<  fl_msg.tx_app_buff.is_ext_frm = TRUE; */
	}
	else
	{
		fl_msg.ide =FALSE; /**< fl_msg.tx_app_buff.is_ext_frm = FALSE; */
	}
	
	fl_msg.msg_id = ((l_pmsg_buf[p_ch_index][i].proto_msg.data[3])|
	(l_pmsg_buf[p_ch_index][i].proto_msg.data[2]<<8)|
	(l_pmsg_buf[p_ch_index][i].proto_msg.data[1]<<16)|
	l_pmsg_buf[p_ch_index][i].proto_msg.data[0]<<24);
	
	/**< fl_msg.tx_app_buff.tx_buff_len = l_pmsg_buf[p_ch_index][i].proto_msg.length - 4; */
	fl_msg.dlc = l_pmsg_buf[p_ch_index][i].proto_msg.length - 4;
	
	for(loop_cnt=0; loop_cnt < fl_msg.dlc; loop_cnt++)
	{
		fl_msg.data[loop_cnt] =
		l_pmsg_buf[p_ch_index][i].proto_msg.data[4 + loop_cnt];
	}
	
	
	/* Add To Queue */
	if(GARUDA_J1939_CH1==p_ch_index)
	{
		fl_Q_Status = CAN_Mid_Transmit_ISR(CAN_CH1, &fl_msg);		
	}
	else if(GARUDA_J1939_CH2==p_ch_index)
	{
		fl_Q_Status = CAN_Mid_Transmit_ISR(CAN_CH2, &fl_msg);
	}
	else
	{
		/* Do Nothing */
	}
	if (fl_Q_Status == MID_FAIL)
	{
		/* Queue is Full -- Not Decided the Action next */
	}
}

/******************************************************************************
* Function name     : BYTE PERIODIC_msg_cmd ( PERIODIC_MSG *p_msg_ptr,
*                                       BYTE p_periodic_cmd, BYTE *p_pmsg_id  )
*    returns        : Returns the error status after processing the commands
*    *p_msg_ptr     : periodic message pointer
*                         no need to pass the parameter "local_periodicity"
*    p_periodic_cmd : periodic message command
* Description       : Verification of cmds and calls related functions
* Notes             :
*******************************************************************************/
uint8_t PERIODIC_msg_cmd (PERIODIC_MSG *p_msg_ptr,  uint8_t p_periodic_cmd)
{
    uint8_t fl_ret_val = PERIODIC_FAILED;

    switch(p_periodic_cmd )
    {
        case PERIODIC_STARTNEW_PMSG :
        {
            if ((p_msg_ptr -> periodicity >= 5) &&
                (p_msg_ptr -> periodicity <= 65535))
            {
              fl_ret_val = startnew_pmsg(p_msg_ptr);
            }
            else
            {
                fl_ret_val = PERIODIC_INVALID_TIME_INTERVAL;
            }
              break;
        }

        case PERIODIC_STOP_PMSG :
        {
              fl_ret_val = stop_pmsg( p_msg_ptr->prmsg_id,p_msg_ptr->protocol_id);
              break;
        }

        case PERIODIC_SUSPEND_PMSG:
        {
              fl_ret_val = suspend_pmsg(p_msg_ptr->protocol_id);
              break;
        }

        case PERIODIC_UPDATE_PMSG:
        {
              if ((p_msg_ptr -> periodicity >= 5) &&
              (p_msg_ptr -> periodicity <= 65535))
              {
                  fl_ret_val = update_new_pmsg(p_msg_ptr);
              }
              else
              {
                  fl_ret_val = PERIODIC_INVALID_TIME_INTERVAL;
              }
              break;              
        }

        case PERIODIC_CHANGE_PERIOD_PMSG :
        {
              /* Do nothing */
              break;
        }
        default :
        {
              fl_ret_val = PERIODIC_FAILED;
              break;
        }
    }
    return fl_ret_val;
}

/*******************************************************************************
* Function Name  : PERIODIC_handler( )
* Description    : Periodic Message handler
* Input          : pvParameters	:
* Output         : None
* Return         : void
*******************************************************************************/
void PERIODIC_handler(void)
{
    uint8_t i,j;

    if(periodic_cnt)
    {
        for(j=0;j<NO_OF_CHANNEL_USED;j++)
        {
            if(l_pmsg_count_hold[j] != 0)
            {
                for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
                {
                    if(l_pmsg_buf[j][i].prmsg_id != 0)
                    {
                        l_pmsg_buf[j][i].local_periodicity--;
                        
                        /**< Added to just update the local periodicity in case of overrun : AMIT */ 
                        if(l_pmsg_buf[j][i].local_periodicity > l_pmsg_buf[j][i].periodicity)
                        {
                            l_pmsg_buf[j][i].local_periodicity = l_pmsg_buf[j][i].periodicity;
                        }
                        
                        
                        if(l_pmsg_buf[j][i].local_periodicity == 0)
                        {
                            switch(j)
                            {
                            case GARUDA_CAN_CH1:
                                {
                                    can_handle_periodic_msg(i,GARUDA_CAN_CH1);
                                    break;
                                }
                            case GARUDA_KWP_CH1:
                                {
                                    /* Call transmit function for 9141 / 14230 */
                                    periodic_14230(i);
                                    break;
                                }
                            case GARUDA_CAN_CH2:
                                {
                                    can_handle_periodic_msg(i,GARUDA_CAN_CH2);
                                    break;
                                }
								case GARUDA_J1939_CH1:
								{
									J1939_handle_periodic_msg(i,GARUDA_J1939_CH1);
									break;
								}
								case GARUDA_J1939_CH2:
								{
									J1939_handle_periodic_msg(i,GARUDA_J1939_CH2);
									break;
								}
								
                            default :
                                {
                                    /* Do nothing */
                                    break;
                                }
                            }
                            l_pmsg_buf[j][i].local_periodicity = l_pmsg_buf[j][i].periodicity;
                        }
                    }
                }
            }
        }
    }
}
   
/*******************************************************************************
* Function Name  : PeriodicMessageFreeRTOS_Init( )
* Description    : Periodic Message FreeRTOS Initialization
* Input          : none	:
* Output         : None
* Return         : void
*******************************************************************************/
void PeriodicMessageFreeRTOS_Init(void)
{
	/**<  Timer 3 Channel 2 configured for 1 msecs ticks */ 
	/**<  Main Peripheral Clock is 150Mhz, Clock Prescaler is 150 */
	/**<  So RC value should be 1000 for 1 msecs ticks */
	/**<  Interrupt triggers every 1 msecs and handles the operations accordingly */ 
	 
    PMC->PMC_PCK[6] = PMC_PCK_PRES(TC_PROG_CLK_PRESCALER - 1) | TC_PROG_CLK_SELECT; 
    PMC->PMC_SCER |= PMC_SCER_PCK6; 
        
    PMC_EnablePeripheral(ID_TC11); 
    TC_Configure( TC3, 2, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );
    TC3->TC_CHANNEL[ 2 ].TC_RC = 1000;
                
    /* Configure and enable interrupt on RC compare */
    NVIC_ClearPendingIRQ(TC11_IRQn);
    NVIC_SetPriority( TC11_IRQn ,TIMER_ISR_PRIORITY);
    NVIC_EnableIRQ(TC11_IRQn);
        
    TC3->TC_CHANNEL[ 2 ].TC_IER = TC_IER_CPCS ;
        
    /** Start the counter */
    TC_Start( TC3, 2 );
	
	/**<  Timer 3 Channel 1 configured for 500 usecs ticks */
	/**<  Main Peripheral Clock is 150Mhz, Clock Prescaler is 150 */
	/**<  So RC value should be 500 for 500 usecs ticks */
	/**<  Interrupt triggers every 500 usecs and handles the operations accordingly */
	/**<  The purpose of maintaining this timer is for KLine Initialization accuracy :
	* ISO9141_14230_TimerIntrhandler() API is called from this ISR.
	* The Initialization sequence (25msecs Low-25 msecs High sequence) are handled here,
	* The Generic Timestamp timer is used for this handling which is 1msecs,
	* So for more accuracy in handling the ISO9141_14230_TimerIntrhandler(), 500usecs timers was reqd
	* Can also be reduced to 250usecs, but cannot be increased to 1msecs*/
	
	 PMC->PMC_PCK[6] = PMC_PCK_PRES(TC_PROG_CLK_PRESCALER - 1) | TC_PROG_CLK_SELECT;
	 PMC->PMC_SCER |= PMC_SCER_PCK6;
	
	
	 PMC_EnablePeripheral(ID_TC10);
	 TC_Configure( TC3, 1, TC_CMR_TCCLKS_TIMER_CLOCK1 | TC_CMR_CPCTRG );
	 TC3->TC_CHANNEL[ 1 ].TC_RC = 500;
	 
	 /* Configure and enable interrupt on RC compare */
	 NVIC_ClearPendingIRQ(TC10_IRQn);
	 NVIC_SetPriority( TC10_IRQn ,TIMER_ISR_PRIORITY);
	 NVIC_EnableIRQ(TC10_IRQn);
	 
	 TC3->TC_CHANNEL[ 1 ].TC_IER = TC_IER_CPCS ;
	 
	 /** Start the counter */
	 TC_Start( TC3, 1 );	
}


#endif
/******************************************************************************
 * R E V I S I O N   H I S T O R Y
 * $History: $
 * Version      Author                          Date
 ******************************************************************************
 * 1.0          Saritha.T                         Mar 04, 2007
 * Initial version.
 *
 ******************************************************************************
 * 1.1          Saritha.T                         May 08, 2008
 * Changed module name. Changed the functions PERIODIC_msg_cmd(), stop_pmsg()
 * and startnew_pmsg().
 * 1.2          Karthik S                         Jul 10, 2008
 * Changes to include ISO 9141 / 14230 periodic message
 * 1.3          Sanjeeva                          Aug 08, 2008
 * Modified startnew_pmsg(). The periodicity count takes TIMER0_ISR_RATE_IN_uS
 * into consideration.
 * 1.4          Mahadev                          Feb 18, 2009
 * Modified To Support Multichannel for Garuda.
 * 1.5          Mahadev                          Jun 25, 2009
 * Modified periodic_14230 function for KWP Migration Changes
 * 1.6          Sanjeeva & Mahadeva              Mar 06, 2014
 * periodic_cnt variable added to decide on further processing of
 * periodic_handler
 * 1.7          Sanjeeva & Mahadeva              Apr 21, 2014
 * set periodic message shall queue the first tx immediately(J2534 Fix)
 * Seperate CAN Q Implementation Chnages
 * 1.8          Mahadeva              May 21, 2014
 * Periodic Scaler Corrected as Periodic Handler Runs from Scheduler
 ******************************************************************************/
