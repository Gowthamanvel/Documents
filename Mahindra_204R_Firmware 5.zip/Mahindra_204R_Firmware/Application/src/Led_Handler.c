/******************************************************************************
*
* Copyright
* 2007 Dearborn Electronics India                            <Ver 1.2>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements LED Managements
*******************************************************************************//*
 * Led_Handler.c
 *
 * Created: 8/3/2015 2:50:13 PM
 *  Author: amit
 */ 

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "board.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "HFCP.h"
#include "Proj_Config.h"
#include "Led_Handler.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
extern uint8_t SDCardFull;

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
const Pin ledLinkStatus     = PIN_LINK_STATUS;
const Pin ledUSBStatus      = PIN_USB_STATUS;
const Pin ledWiFiStatus     = PIN_WIFI_STATUS;
const Pin ledGsmStatus      = PIN_GSM_STATUS;
const Pin ledSDCardStatus   = PIN_SD_CARD_STATUS;


/******************************************************************************
*                   P R I V A T E   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/*******************************************************************************
* Function Name  : LEDFreeRTOS_Init
* Description    : Handles the LEDs used in the Applications
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void LEDFreeRTOS_Init(void)
{
    if(pdTRUE != xTaskCreate(Led_Task, "LED_Task",LED_TASK_STACK_SIZE,
                    (void *) NULL, LED_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        
    }    
}

/*******************************************************************************
* Function Name  : LEDFreeRTOS_Init
* Description    : Handles the LEDs used in the Applications
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Led_Task(void *PvParam)
{
static uint16_t count = 0;
static uint8_t  status = STATUS_OFF;

static uint16_t SDcardFullLedcount = 0;
static uint8_t  SDcardFullStatus = STATUS_OFF;
uint8_t active_protocols;

    for(;;)
    {
        active_protocols = get_connected_channels();
        if(active_protocols > 0)
        {
            count++;
            if(count >= LINK_STATUS_COUNT)
            {
                if(status == STATUS_OFF)
                {                    
                    Link_Status_Led_ON();
                    status = STATUS_ON;
                }
                else
                {                 
                    Link_Status_Led_OFF();
                    status = STATUS_OFF;

                }
                count = 0;
            }
        }
        else
        {
            Link_Status_Led_OFF();
            /* This will ensure that LED comes ON as soon as "active_protocol" status changes,
            instead of waiting for the count to reach LINK_STATUS_COUNT */
            count = LINK_STATUS_COUNT;
            status = STATUS_OFF;
        }
		
		if(SDCardFull)
		{
			 SDcardFullLedcount++;
			 if(SDcardFullLedcount >= SDCARD_FULL_STATUS_COUNT)
			 {
				 if(SDcardFullStatus == STATUS_OFF)
				 {
					 FILE_GB_FULL_Led_ON();
					 SDcardFullStatus = STATUS_ON;
				 }
				 else
				 {
					 FILE_GB_FULL_Led_OFF();
					 SDcardFullStatus = STATUS_OFF;

				 }
				 SDcardFullLedcount = 0;
			 }
		}
		else
		{
			//FILE_GB_FULL_Led_OFF();
            /* This will ensure that LED comes ON as soon as "active_protocol" status changes,
            instead of waiting for the count to reach LINK_STATUS_COUNT */
            SDcardFullLedcount = SDCARD_FULL_STATUS_COUNT;
            SDcardFullStatus = STATUS_OFF;			
		}
        vTaskDelay(20);
    }        
}
    

/*******************************************************************************
* Function Name  : ConfigureLeds
* Description    : Configures the LEDs used in the Applications
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Initialise_Leds ( void )
{
    LED_Configure( DEVICE_LINK_STATUS ) ;
    LED_Configure( WIFI_STATUS ) ;
    LED_Configure( USB_STATUS ) ;
    LED_Configure( SD_CARD_STATUS ) ;
    LED_Configure( GSM_STATUS ) ;            
}


/*******************************************************************************
* Function Name  : LED_Configure
* Description    : LED_Configure
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void LED_Configure( LEDs_t dwLed )
{
    switch (dwLed)
    {
        case DEVICE_LINK_STATUS :
        {
             PIO_Configure( &ledLinkStatus, 1 );
             break;
        }
        case USB_STATUS :
        {
             PIO_Configure( &ledUSBStatus, 1 );
             break;            
        }
        case WIFI_STATUS :
        {
             PIO_Configure( &ledWiFiStatus, 1 );
             break;
        }
        case SD_CARD_STATUS :
        {
             PIO_Configure( &ledGsmStatus, 1 );
             break;
        }        
        case GSM_STATUS :
        {
             PIO_Configure( &ledSDCardStatus, 1 );
             break;
        }
                
        default:
        break;
    }            
}

/*******************************************************************************
* Function Name  : LED_Set
* Description    : LED_Set
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void LED_Set( LEDs_t dwLed )
{
    switch (dwLed)
    {
        case DEVICE_LINK_STATUS :
        {
            PIO_Clear( &ledLinkStatus);
            break;
        }
        case USB_STATUS :
        {
            PIO_Clear( &ledUSBStatus);
            break;
        }
        case WIFI_STATUS :
        {
            PIO_Clear( &ledWiFiStatus);
            break;
        }
        case SD_CARD_STATUS :
        {
            PIO_Clear( &ledSDCardStatus);
            break;
        }
        case GSM_STATUS :
        {
            PIO_Clear( &ledGsmStatus);
            break;
        }
        
        default:
        break;
    }
}

/*******************************************************************************
* Function Name  : LED_Clear
* Description    : LED_Clear
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void LED_Clear( LEDs_t dwLed )
{
    switch (dwLed)
    {
        case DEVICE_LINK_STATUS :
        {
            PIO_Set( &ledLinkStatus);
            break;
        }
        case USB_STATUS :
        {
            PIO_Set( &ledUSBStatus);
            break;
        }
        case WIFI_STATUS :
        {
            PIO_Set( &ledWiFiStatus);
            break;
        }
        case SD_CARD_STATUS :
        {
            PIO_Set( &ledSDCardStatus);
            break;
        }
        case GSM_STATUS :
        {
            PIO_Set( &ledGsmStatus);
            break;
        }
        
        default:
        break;
    }
}

/*******************************************************************************
* Function Name  : Link_Status_Led_ON
* Description    : Configures the Link_Status_Led_ON
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Link_Status_Led_ON( void )
{
    LED_Set(DEVICE_LINK_STATUS);
}

/*******************************************************************************
* Function Name  : Link_Status_Led_OFF
* Description    : Configures the Link_Status_Led_OFF
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void Link_Status_Led_OFF( void )
{
    LED_Clear(DEVICE_LINK_STATUS);
}

/*******************************************************************************
* Function Name  : USB_Led_ON
* Description    : USB_Led_ON
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void USB_Led_ON( void )
{
    LED_Set(USB_STATUS);
    LED_Clear(GSM_STATUS);
}

/*******************************************************************************
* Function Name  : USB_Led_OFF
* Description    : USB_Led_OFF
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void USB_Led_OFF( void )
{
    LED_Clear(USB_STATUS);
    LED_Clear(GSM_STATUS);    
}


/*******************************************************************************
* Function Name  : USB_MSD_Led_ON
* Description    : USB_MSD_Led_ON
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void USB_MSD_Led_ON( void )
{
	LED_Clear(USB_STATUS);
	LED_Set(GSM_STATUS);
}

/*******************************************************************************
* Function Name  : USB_MSD_Led_OFF
* Description    : USB_Led_OFF
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void USB_MSD_Led_OFF( void )
{
	LED_Clear(USB_STATUS);
	LED_Clear(GSM_STATUS);
}

/*******************************************************************************
* Function Name  : WIFi_Led_OFF
* Description    : WIFi_Led_OFF
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void WiFi_Led_OFF( void )
{
    LED_Clear(WIFI_STATUS);
    LED_Clear(SD_CARD_STATUS);
}

/*******************************************************************************
* Function Name  : WIFi_Led_ON
* Description    : WIFi_Led_ON
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void WiFi_Led_ON( void )
{
    LED_Set(WIFI_STATUS);
    LED_Clear(SD_CARD_STATUS);
}


void FILE_GB_FULL_Led_ON( void )
{
	LED_Clear(WIFI_STATUS);
	LED_Set(SD_CARD_STATUS);
}

void FILE_GB_FULL_Led_OFF( void )
{
	LED_Clear(WIFI_STATUS);
	LED_Clear(SD_CARD_STATUS);
}
/*******************************************************************************
* Function Name  : WiFi_Status_Led_ON
* Description    : Configures the WiFi_Status_Led_ON
* Input          : void
* Output         : None
* Return         : None
*******************************************************************************/
void WiFi_ON_USB_OFF_Status( void )
{
    LED_Set(USB_STATUS);
    LED_Clear(WIFI_STATUS);
}
void WiFi_OFF_USB_OFF_Status( void )
{
    LED_Clear(USB_STATUS);
    LED_Clear(WIFI_STATUS);
}
void WiFi_ON_USB_ON_Status( void )
{
    LED_Set(USB_STATUS);
    LED_Set(WIFI_STATUS);
}

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      8/3/2015 2:50:13 PM
* Initial version.
*
******************************************************************************/
