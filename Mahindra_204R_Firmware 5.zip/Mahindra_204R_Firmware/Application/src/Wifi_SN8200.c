/******************************************************************************
*
* Copyright
* 2014 Dearborn Electronics India                            <Ver 1.0>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements CAN middle level application interfaces
*******************************************************************************/
/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "Wifi_SN8200.h"
#include "Proj_Config.h"
#include "FreeRTOS.h"
#include "queue.h"
#include "task.h"
#include "semphr.h"
#include "SPI_Mid.h"
#include "HFCP.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define SNIC_RECV_BUF_SIZE      2048
#define GARUDA_IP_PORT          5001


/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void SNIC_Init (uint16_t);
void Get_Dhcp (WifiMode_t);
void SN8200_FrameError (void);
void WiFi_Task(void *PvParam);
void Get_Wifi_Status (WifiMode_t);
void WiFi_Intr_Task(void *PvParam);
void Set_Sock_Option_Tcp_NoDelay (uint8_t );
void Create_Tcp_Socket (bool , uint32_t , uint16_t );
void Start_Tcp_Server (uint8_t , uint16_t , uint8_t );
void Process_SN8200_Frame (SN8200_Cmd_t, uint8_t *, uint16_t);
void Construct_And_Transmit_SN8200Frame(SN8200_Cmd_t cmd_id, uint8_t *payload, uint16_t payload_len);

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
typedef struct 
{
  uint16_t len;    
  uint16_t data_indx;
  uint8_t  ack_reqd;
  uint8_t  cmd_id;
  uint8_t  payload[SN8200_RX_MAX_PAYLOD_LEN];
  uint8_t  chksum;
} SN8200_RxFrame_t;


static QueueHandle_t xWIFI_Init_Queue;
static SemaphoreHandle_t xSNICSendSuccess;
static SemaphoreHandle_t xSNICStartRx;
static uint8_t sn8200TxSeqNum;
static uint8_t tcpServerSockNum;

#define xWIFI_Init_QSize        20
#define xWIFI_Init_QElementSize 20

static SemaphoreHandle_t xTaskExecLock;

/******************************************************************************
*                   E X P O R T E D   F U N C T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/
extern QueueHandle_t spiRxQueue;

/******************************************************************************
* Function name	        : WiFiFreeRTOS_Init
*    returns	        : None
*    parameters         : None
* Description		: Initialize the FreeRTOS for WiFi
*******************************************************************************/
void WiFiFreeRTOS_Init(void)
{
    xTaskExecLock = xSemaphoreCreateBinary();
    if (!xTaskExecLock) {
        return;
    }
    
    if(pdFALSE == xTaskCreate(WiFi_Task, "WiFi_SN8200",WIFI_TASK_STACK_SIZE, 
                            (void *) NULL, WIFI_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        printf("Failed to create WiFi Task \r\n");
    }  
    
    if(pdFALSE == xTaskCreate(WiFi_Intr_Task, "WiFi_Intr",WIFI_INTR_TASK_STACK_SIZE,
                              (void *) NULL, WIFI_TASK_PRIORITY, ( TaskHandle_t * )NULL))
    {
        printf("Failed to create WiFi Task \r\n");
    }
        
    xWIFI_Init_Queue = xQueueCreate( xWIFI_Init_QSize, ( unsigned portBASE_TYPE ) xWIFI_Init_QElementSize);
  
    xSNICSendSuccess = xSemaphoreCreateBinary(); 
    vQueueAddToRegistry(xSNICSendSuccess, "SNICSemphr"); 
    xSNICStartRx = xSemaphoreCreateBinary();
    vQueueAddToRegistry(xSNICStartRx, "SNICSRxSemphr");
    return;
}

/******************************************************************************
* Function name	        : Wifi_Init
*    returns	        : None
*    parameters         : None
* Description           : Initialize the  WiFi in Soft AP Mode
*******************************************************************************/
WifiMode_t Wifi_Init(void)
{
  uint8_t u8LocalWiFiBuffer[20] = {0 , };  
  WifiMode_t wifiMode;  
  
  Get_Wifi_Status (STA_MODE);
  if( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer[0], 5000/*portMAX_DELAY*/) == pdPASS)
  {
    if((CMD_ID_WIFI == u8LocalWiFiBuffer[0]) &&
       (WIFI_GET_STATUS_RSP == u8LocalWiFiBuffer[1]) && 
         (MODE_STA_JOINED == u8LocalWiFiBuffer[2]) )
    {
      wifiMode = STA_MODE; 
      printf("STA Mode Joined \n\r");
    }
    else
    {      
      Get_Wifi_Status (SOFTAP_MODE);
      if( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer[0], portMAX_DELAY) == pdPASS)
      {
        if((CMD_ID_WIFI == u8LocalWiFiBuffer[0]) &&
           (WIFI_GET_STATUS_RSP == u8LocalWiFiBuffer[1]))
        {
          wifiMode = SOFTAP_MODE;
          printf("Connected as Soft AP Mode\n\r");
        }
      }
    }
  }
  else
  {
     wifiMode = NONE_MODE;
  }  
  return wifiMode;
}

/******************************************************************************
* Function name	        : Wifi_Start_Network
* returns		: None
* parameters            : None
* Description		: Handles WiFi Network Initialization Steps
*******************************************************************************/
uint32_t srcIP;

void Wifi_Start_Network(WifiMode_t flWifiMode)
{  
  uint8_t u8LocalWiFiBuffer[64] = {0 , };
  /* -----------------------------------------------------------------------*/
  /**< SNIC INITIALIZATION COMMAND                                          */
  /* -----------------------------------------------------------------------*/ 
  SNIC_Init(SNIC_RECV_BUF_SIZE);
  while( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer, portMAX_DELAY) == pdPASS)
  {
    if((CMD_ID_SNIC == u8LocalWiFiBuffer[0]) &&
       (SNIC_INIT_RSP == u8LocalWiFiBuffer[1]) && 
         (TRUE == u8LocalWiFiBuffer[2]))
    {
      printf("SNIC Initialization \n\r");
      break;
    }         
  }  
  
  /* -----------------------------------------------------------------------*/
  /**< SNIC GET DHCP DIRECT COMMAND                                         */
  /* -----------------------------------------------------------------------*/  
  Get_Dhcp(flWifiMode);
  while( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer, portMAX_DELAY) == pdPASS)
  {
    if((CMD_ID_SNIC == u8LocalWiFiBuffer[0]) &&
       (SNIC_GET_DHCP_INFO_RSP == u8LocalWiFiBuffer[1]))
    {            
      if (TRUE == u8LocalWiFiBuffer[2])
      {
        printf("IP assigned as %i.%i.%i.%i \n\r", u8LocalWiFiBuffer[3],
               u8LocalWiFiBuffer[4],u8LocalWiFiBuffer[5],u8LocalWiFiBuffer[6]);
        memcpy(&srcIP,&u8LocalWiFiBuffer[3],4);
        break;
      }
      else
      {
        Get_Dhcp(flWifiMode);  
        printf("IP not assigned\n\r");                
      }
    }
  } 
  
  /* -----------------------------------------------------------------------*/
  /**< TCP SOCKET CREATION COMMAND                                          */
  /* -----------------------------------------------------------------------*/       
  tcpServerSockNum = -1;
  Create_Tcp_Socket (true, srcIP, GARUDA_IP_PORT);
  while( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer, portMAX_DELAY) == pdPASS)
  {
    if((CMD_ID_SNIC == u8LocalWiFiBuffer[0])&&
       (SNIC_TCP_CREATE_SOCKET_RSP == u8LocalWiFiBuffer[1]))
    {            
      if (TRUE == u8LocalWiFiBuffer[2])
      {
        tcpServerSockNum = u8LocalWiFiBuffer[3];
        printf("Socket %d opened\n\r", tcpServerSockNum);
        break;
      } 
      else
      {
        printf("Socket creation failed\n\r");
      }
    }
  } 
  
  /* -----------------------------------------------------------------------*/
  /**< SET SOCKET OPTION TCP_NODELAY                                        */
  /* -----------------------------------------------------------------------*/ 
  Set_Sock_Option_Tcp_NoDelay(tcpServerSockNum);     
  
  while( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer, portMAX_DELAY) == pdPASS)
  {
    if((CMD_ID_SNIC == u8LocalWiFiBuffer[0]) &&
       (SNIC_SETSOCKOPT_RESP == u8LocalWiFiBuffer[1]) && 
         (TRUE == u8LocalWiFiBuffer[2]))
    {
      printf("TCP_NODELAY Configured \n\r");
      break;
    }         
  }  
  /* -----------------------------------------------------------------------*/
  /**< TCP CREATE CONNECTION COMMAND                                        */
  /* -----------------------------------------------------------------------*/ 
  Start_Tcp_Server (tcpServerSockNum, SNIC_RECV_BUF_SIZE, 1);
  while( xQueueReceive( xWIFI_Init_Queue, &u8LocalWiFiBuffer, portMAX_DELAY) == pdPASS)
  {
    if((CMD_ID_SNIC == u8LocalWiFiBuffer[0]) &&
       (SNIC_TCP_CREATE_CONNECTION_RSP == u8LocalWiFiBuffer[1]) && 
         (TRUE == u8LocalWiFiBuffer[2]))
    {
      printf("TCP- Socket Connection Success \n\r");
      break;
    } 
  }  
}

void SNIC_Init (uint16_t bufSize)
{
  uint8_t snicInitPload[10]; 
  
  snicInitPload[4] = SNIC_INIT_REQ;
  snicInitPload[5] = sn8200TxSeqNum++;
  snicInitPload[6] = (uint8_t) (bufSize>>8);
  snicInitPload[7] = (uint8_t) bufSize;
  Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, snicInitPload, 4);
}

void Get_Wifi_Status (WifiMode_t interface)
{
  uint8_t wifiStatPload[9]; 
  
  wifiStatPload[4] = WIFI_GET_STATUS_REQ;
  wifiStatPload[5] = sn8200TxSeqNum++;
  wifiStatPload[6] = interface;
  Construct_And_Transmit_SN8200Frame(CMD_ID_WIFI, wifiStatPload, 3);
}

void Get_Dhcp (WifiMode_t interface)
{
  uint8_t getDhcpPload[9]; 
  
  getDhcpPload[4] = SNIC_GET_DHCP_INFO_REQ;
  getDhcpPload[5] = sn8200TxSeqNum++;
  getDhcpPload[6] = interface;
  Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, getDhcpPload, 3);
}

void Create_Tcp_Socket (bool bindOption, uint32_t ip, uint16_t port)
{
  uint8_t createSockPload[15]; 
  
  createSockPload[4] = SNIC_TCP_CREATE_SOCKET_REQ;
  createSockPload[5] = sn8200TxSeqNum++;
  if(bindOption == true)
  {
    createSockPload[6] = 1;        
    memcpy(&createSockPload[7], &ip, 4);          
    createSockPload[11] = port>>8;         
    createSockPload[12] = port;
    
    Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, createSockPload, 9);   
  }
  else
  {
    createSockPload[6] = 0;
    Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, createSockPload, 3);
  }
}

void Start_Tcp_Server (uint8_t sockNum, uint16_t bufSize, uint8_t maxCnxns)
{
  uint8_t startSrvrPload[12]; 
  
  startSrvrPload[4] = SNIC_TCP_CREATE_CONNECTION_REQ;
  startSrvrPload[5] = sn8200TxSeqNum++;
  startSrvrPload[6] = sockNum;
  startSrvrPload[7] = (uint8_t) (bufSize>>8);
  startSrvrPload[8] = (uint8_t) bufSize;
  startSrvrPload[9] = maxCnxns;
  Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, startSrvrPload, 6);
}

void Send_To_Socket (uint8_t activeSock, uint8_t *sendPload, uint16_t ploadLen)
{
  sendPload[4] = SNIC_SEND_FROM_SOCKET_REQ;
  sendPload[5] = sn8200TxSeqNum++;
  sendPload[6] = activeSock;
  sendPload[7] = 0;
  sendPload[8] = ploadLen >> 8;
  sendPload[9] = ploadLen;
  Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, sendPload,ploadLen+6);
}

void Set_Sock_Option_Tcp_NoDelay (uint8_t activeSock)
{
  uint8_t setSockOpt[19];
  
  setSockOpt[4] = SNIC_SETSOCKOPT_REQ;
  setSockOpt[5] = sn8200TxSeqNum++;
  setSockOpt[6] = activeSock;
  setSockOpt[7] = 0x00;
  setSockOpt[8] = 0x06;
  setSockOpt[9] = 0x00;
  setSockOpt[10] = 0x01;
  setSockOpt[11] = 0x00;
  setSockOpt[12] = 0x04;
  setSockOpt[13] = 0x01;
  setSockOpt[14] = 0;
  setSockOpt[15] = 0;
  setSockOpt[16] = 0;
  Construct_And_Transmit_SN8200Frame(CMD_ID_SNIC, setSockOpt,13);
}

void Construct_And_Transmit_SN8200Frame(SN8200_Cmd_t cmd_id, uint8_t *payload, uint16_t payload_len)
{  
  payload[0] = SOM_CHAR;
  payload[1] = (payload_len & 0x7F) | SN8200_HDR; 
  payload[2] = SN8200_HDR | ((payload_len>>7)&0x3F);
  payload[3] = (cmd_id&0x7F)|SN8200_HDR; 
  payload[payload_len+4] = payload[1] + payload[2] + payload[3]; // checksum
  payload[payload_len+5] = EOM_CHAR; // Send EOM character
  
  /* SPI_Mid_Transmit(payload,SPI_DMA_RX_SIZE (payload_len+6)); */
  SPI_Mid_Transmit(payload, ((payload[4]==SNIC_SEND_FROM_SOCKET_REQ)?(payload_len+6) : SPI_DMA_RX_SIZE));
}

BaseType_t Initiate_Wifi_Rx(bool fromISR)
{
  BaseType_t xWifiTxTaskWoken = pdFALSE; 
  
  if(fromISR)
  {    
    xSemaphoreGiveFromISR(xSNICStartRx,&xWifiTxTaskWoken);
  }
  else
  {
    xSemaphoreGive(xSNICStartRx);
  }
  return xWifiTxTaskWoken;
}

bool Is_Tx_Complete (TickType_t timeout)
{
  if(xSemaphoreTake(xSNICSendSuccess, timeout))
  {
    return true;
  }
  else
  {
    return false;
  }
}

/******************************************************************************
* Function name	        : WiFi_Intr_Task
* returns		: None
* parameters            : None
* Description		: Handles WiFi Interrupt Operations
*******************************************************************************/
void WiFi_Intr_Task(void *PvParam)
{
    for(;;)
    {
        xSemaphoreTake(xSNICStartRx, portMAX_DELAY);
        
        while(Is_Ext_Int_Line_Low())
        {
            Start_SPI_Rx_DMA();
        }        
    }    
}


/******************************************************************************
* Function name	        : WiFi_Task
* returns		: None
* parameters            : None
* Description		: Handles WiFi Operations
*******************************************************************************/
static SN8200_RxFrame_t SN8200_RxFrame;
SN8200_RxState_t SN8200_State;
uint8_t ReadIndex;
uint8_t tempbuf[SPI_DMA_RX_SIZE] = {0, };

void WiFi_Task(void *PvParam)
{	
  Dynamic_QStruct_t dataFromQ;
  memset(&tempbuf[0], 0x04, sizeof(tempbuf));        	               
    
  for(;;)
  {
      if(MID_PASS == SPI_Mid_Recieve (&dataFromQ, portMAX_DELAY))	  
      {	              
        ReadIndex = 0;
        while(ReadIndex < SPI_DMA_RX_SIZE)
        {
          switch(SN8200_State)
          {
          case IDLE:
            {
              if(dataFromQ.address[ReadIndex] == SOM_CHAR)
              {               
                SN8200_State = RECV_LENL;
                SN8200_RxFrame.len = 0;
                SN8200_RxFrame.chksum = 0;				
              }
              break;
            }
          case RECV_LENL:
            {
              if( (dataFromQ.address[ReadIndex] & 0x80) == 0x80)
              {                
                SN8200_State=RECV_LENH;
                SN8200_RxFrame.len = (uint16_t) dataFromQ.address[ReadIndex] & 0x7F;
                SN8200_RxFrame.chksum+= dataFromQ.address[ReadIndex];				
              }
              else
              {
                SN8200_FrameError();
              }
              break;
            }
          case RECV_LENH:
            {
              if( (dataFromQ.address[ReadIndex] & 0x80) == 0x80)
              {                 
                SN8200_State=RECV_CMD;
                SN8200_RxFrame.len |= (uint16_t) (dataFromQ.address[ReadIndex] & 0x3f)<<7;
                SN8200_RxFrame.ack_reqd = (dataFromQ.address[ReadIndex] >> 6) & 0x01;
                SN8200_RxFrame.chksum+= dataFromQ.address[ReadIndex];				
                if(SN8200_RxFrame.len > 0x1700)
                {
                  while(1);
                }
              }
              else
              {
                SN8200_FrameError();
              }
              break;
            }
          case RECV_CMD:
            {
              if( (dataFromQ.address[ReadIndex] & 0x80) == 0x80)
              {                
                SN8200_State=RECV_PAYLOAD;
                SN8200_RxFrame.cmd_id = dataFromQ.address[ReadIndex] & 0x7f;
                SN8200_RxFrame.chksum+= dataFromQ.address[ReadIndex];   
                SN8200_RxFrame.data_indx = 0;				
              }
              else
              {
                SN8200_FrameError();
              }
              break;
            }
          case RECV_PAYLOAD:
            {
              SN8200_RxFrame.payload[SN8200_RxFrame.data_indx++] = dataFromQ.address[ReadIndex];
              if (SN8200_RxFrame.data_indx == SN8200_RxFrame.len)
              {                
                SN8200_State = RECV_CKSUM;  				                         
              }
              break;
            }
          case RECV_CKSUM:
            {
              if( (dataFromQ.address[ReadIndex] & 0x7F) == (SN8200_RxFrame.chksum & 0x07F))
              {                 
                SN8200_State = RECV_EOF; 			                                       
              }
              else
              {
                SN8200_FrameError();          
              }
              break;
            }
          case RECV_EOF:
            {
              if((dataFromQ.address[ReadIndex] == EOM_CHAR))
              { 
                /*Process Frame Here */  			            
                Process_SN8200_Frame((SN8200_Cmd_t)SN8200_RxFrame.cmd_id, &(SN8200_RxFrame.payload[0]), SN8200_RxFrame.len);                				
                SN8200_State = IDLE;                                       
              }
              else
              {
                SN8200_FrameError();          
              }
              break;
            }
          default:            
            break;
          }        
          ReadIndex++;
        }/**< End of While*/        
        //vPortFree(dataFromQ.address);
      }/* END OF if(MID_PASS == SPI_Mid_Recieve (&dataFromQ, portMAX_DELAY)) */      
  } /* END OF  for(;;) */
}


uint8_t InitResp[xWIFI_Init_QElementSize];  
uint32_t PacketSize,CmdlenProcd;
uint32_t sn8200TxErrCnt;
uint8_t sn8200Err;
uint32_t TotalMsgAck;
uint8_t LastFewErrors[50];
uint8_t LastFewErrorsi;
void Process_SN8200_Frame (SN8200_Cmd_t cmd, uint8_t *payload, uint16_t len)
{  
    //TRACE_INFO_WP("\n\rWiFi: %x\n\r", cmd);
  switch(cmd)
  {
  case CMD_ID_SNIC :
    {
      switch(payload[0])
      {        
      case SNIC_CONNECTION_RECV_IND:
        {
          PacketSize = ((payload[3] << 8)|payload[4]);
          CmdlenProcd = 0;          
          while(CmdlenProcd < PacketSize)
          {
            Send_To_HFCP_Queue(&(payload[5+CmdlenProcd]), 64);
            CmdlenProcd += 64;            
          }
          break;
        }
      case SNIC_CLEANUP_RSP :
        {
          InitResp[0] = CMD_ID_SNIC;
          InitResp[1] = payload[0];
          InitResp[2] = TRUE;
          xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);          
          break;
        }    
      case SNIC_INIT_RSP :
        {
          InitResp[0] = CMD_ID_SNIC;
          InitResp[1] = payload[0];
          InitResp[2] = TRUE;
          xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          break;
        }
      case SNIC_GET_DHCP_INFO_RSP:
        {
          if (SNIC_SUCCESS == payload[2])
          {                        
            InitResp[0] = CMD_ID_SNIC;
            InitResp[1] = payload[0];
            InitResp[2] = TRUE;
            memcpy(&InitResp[3], payload+9, 4);
            xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          }
          else
          {                        
            InitResp[0] = CMD_ID_SNIC;
            InitResp[1] = payload[0];
            InitResp[2] = FALSE;
          }
          break;
        }
      case SNIC_TCP_CREATE_SOCKET_RSP:
        {          
          if (SNIC_SUCCESS == payload[2])
          {            
            InitResp[0] = CMD_ID_SNIC;
            InitResp[1] = payload[0];
            InitResp[2] = TRUE;
            InitResp[3] = payload[3];
            xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          }
          break;
        }
      case SNIC_TCP_CREATE_CONNECTION_RSP :
        {
          
          if (SNIC_SUCCESS == payload[2])
          {            
            InitResp[0] = CMD_ID_SNIC;
            InitResp[1] = payload[0];
            InitResp[2] = TRUE;
            xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          }
          break;          
        }
      case SNIC_SEND_RSP :
        {          
          if (SNIC_SUCCESS == payload[2])
          {
            xSemaphoreGive(xSNICSendSuccess);
          }
          else
          {
            sn8200TxErrCnt++;
            sn8200Err = payload[2];             
            if(LastFewErrorsi < 50)
            {
              LastFewErrors[LastFewErrorsi++] = sn8200Err;
            }
            xSemaphoreGive(xSNICSendSuccess);
          }
          break;          
        }
      case SNIC_TCP_CONNECTION_STATUS_IND : 
        {
          printf("Socket Closed???\n\r");          
          break;
        }
      case SNIC_TCP_CLIENT_SOCKET_IND:
        {
          if(tcpServerSockNum == payload[2])
          {
            Socket_To_Tx(payload[3]);  			
            // printf("Connection Recieved From Socket %d\n\r", payload[3]);            
          }
          break;
        }
        
      case SNIC_SETSOCKOPT_RESP :
        {
          InitResp[0] = CMD_ID_SNIC;
          InitResp[1] = payload[0];
          if(SNIC_SUCCESS == payload[2])
          {
            InitResp[2] = TRUE;
          }
          else
          {
            InitResp[2] = FALSE;
          }
          xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          break;
        }
      default:
        {          
          break;
        }
      }      
      break;
    }
  case CMD_ID_WIFI :
    {      
      switch(payload[0])
      {
      case  WIFI_ON_RSP:
        {
          if (WIFI_SUCCESS == payload[2])
          {            
            InitResp[0] = CMD_ID_WIFI;
            InitResp[1] = payload[0];
            InitResp[2] = TRUE;
            xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          }
          break;
        }
      case  WIFI_OFF_RSP:
        {
          if (WIFI_SUCCESS == payload[2])
          {            
            InitResp[0] = CMD_ID_WIFI;
            InitResp[1] = payload[0];
            InitResp[2] = TRUE;
            xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);
          }
          break;
        }
        
      case  WIFI_GET_STATUS_RSP:
        {
          InitResp[0] = CMD_ID_WIFI;
          InitResp[1] = payload[0];
          InitResp[2] = payload[2];
          xQueueSend( xWIFI_Init_Queue, (void*)&InitResp[0], 0);		 
          break;
        }
      default:{        
        break;
        }
      }      
      break;
    }
    
  default :
    {   
	 printf("ERROR default\r\n");   
      break;
    }    
  }  
}
uint32_t frameerrcnt;
void SN8200_FrameError (void)
{
  frameerrcnt++;
  SN8200_State = IDLE;  
}

void Wifi_pauseTask (void)
{
    if (xTaskExecLock)
    {
        while(xSemaphoreTake(xTaskExecLock, portTICK_PERIOD_MS*1) != pdTRUE);
    }
}

void Wifi_startTask (void)
{
    if (xTaskExecLock)
    {
        xSemaphoreGive(xTaskExecLock);
    }
}


void Wifi_Task_Reset (void)
{
    QueueHandle_t queues[] = {spiRxQueue, NULL};
    Dynamic_QStruct_t dataStruct;
	QueueHandle_t *pQ = queues;

    //taskENTER_CRITICAL();
    while (*pQ)
    {
        while(xQueueReceive(*pQ, &dataStruct, portTICK_PERIOD_MS * 1) == pdTRUE)
        {
            if (dataStruct.address)
            {
                vPortFree(dataStruct.address);
            }
        }
        pQ++;
    }
    //taskEXIT_CRITICAL();
}
