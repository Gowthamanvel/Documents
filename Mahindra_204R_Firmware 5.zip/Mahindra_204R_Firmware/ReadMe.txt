!!!Base Version !!!
Release in field for M&M and Mahindra Reva 2.0.2 R :- http://172.16.2.19/svn/Garuda-Products/Firmware/Release/ValueEngg/Garuda/Garuda_DataLogger_SAME70_Release/M&M_202_Garuda_Workspace
All future updates will be maintained on this Branch. There will not be seperate path for seperate customers. Different tags will be used for different customers.
All the details of Tags and relavent customer and the release details will be maintained in this file.