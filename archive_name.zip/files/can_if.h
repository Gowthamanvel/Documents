/**
 *	@file can_if.h
 *
 *	Copyright (c) 2023-2024, Capgemini - Intelligent Devices
 */

#ifndef _CAN_IF_H_
#define	_CAN_IF_H_

#include	<glib.h>

#include	"g3d.h"
#include	"can.h"

/* CAN_CH_MAX is used in CAN.c */
#define	CAN_CHANNELS		2

#define	CAN_MONITOR_PERIOD	1

#define	CAN_DEFAULT_BITRATE	(500000)

enum CAN_States {
	CAN_DISCONNECTED,
	CAN_CONNECTED,
};

#define CANn 2

typedef enum USBHID_States USBHID_States_t;

#define	S_RXCANBUFFER		512

struct CANChannel {
	int channelno;
	int rfd;
	int wfd;
	uint32_t bitrate;
	gchar *ifname;
	uint32_t ifindex;
	GIOChannel *gch;
	gboolean state;
	GIOCondition cond;
	guint watch_source;
	uint8_t canbuf[S_RXCANBUFFER];
};

typedef struct CANChannel CANChannel_t;

struct CANContext {
	CANChannel_t can[CAN_CHANNELS];
};

typedef struct CANContext CANContext_t;

struct CAN_Init_Info {
	uint32_t u32Baudrate;
	uint8_t u8SJW;
	uint8_t u8SamplingMode;
	uint8_t u8LoopBackMode;
};

typedef struct CAN_Init_Info CAN_Init_Info_t;

ssize_t can_if_read(int channel, void *buf, size_t count);
ssize_t can_if_write(int channel, const void *buf, size_t count);
ssize_t can_if_fd_write(int channel, const void *buf, size_t count);
int can_if_init(uint32_t can_bitrate);
void can_if_deinit(void);
int can_if_reinit(void);
int can_if_reinit_chan(uint32_t chan, uint32_t bitrate);
ssize_t can_if_bcm_write(int bcmfd, const void *buf, size_t count);

uint32_t CAN_Mid_get_current_baudrate(uint8_t p_channel_no_U8);
uint32_t LowLevel_CAN_get_loopback_status(uint8_t p_channel_no_U8);
uint8_t LowLevel_CAN_enable_loopback(uint8_t p_channel_no_U8);
uint8_t LowLevel_CAN_disable_loopback(uint8_t p_channel_no_U8);
uint32_t CAN_Mid_set_baudrate(uint32_t baudrate, uint8_t chid);
uint8_t LowLevel_CAN_get_current_SJW(uint8_t p_channel_no_U8);
uint32_t LowLevel_CAN_get_current_sampling_mode(uint32_t channel);

#endif /* _CAN_IF_H_ */

