/**
 *  @file can_if.h
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _CAN_NL_IF_
#define _CAN_NL_IF_

#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/can.h>
#include <linux/can/raw.h>
#include <linux/rtnetlink.h>
#include <linux/netlink.h>

struct nl_if_state {
	struct nlmsghdr nlhdr;
	struct ifinfomsg if_info;
};

#define NL_BITTIMING_BUF (128)
struct nl_bt_req {
	struct nlmsghdr nlhdr;
	struct ifinfomsg if_info;
	uint8_t buf[NL_BITTIMING_BUF];
};

#ifndef _CAN_NETLINK_H
#if 0
/* changing to add CAN-FD features */
enum {
	IFLA_CAN_UNSPEC,
	IFLA_CAN_BITTIMING,
	IFLA_CAN_BITTIMING_CONST,
	IFLA_CAN_CLOCK,
	IFLA_CAN_STATE,
	IFLA_CAN_CTRLMODE,
	IFLA_CAN_RESTART_MS,
	IFLA_CAN_RESTART,
	IFLA_CAN_BERR_COUNTER,
	__IFLA_CAN_MAX
};
#else
enum {
	IFLA_CAN_UNSPEC,
	IFLA_CAN_BITTIMING,
	IFLA_CAN_BITTIMING_CONST,
	IFLA_CAN_CLOCK,
	IFLA_CAN_STATE,
	IFLA_CAN_CTRLMODE,
	IFLA_CAN_RESTART_MS,
	IFLA_CAN_RESTART,
	IFLA_CAN_BERR_COUNTER,
	IFLA_CAN_DATA_BITTIMING,
	IFLA_CAN_DATA_BITTIMING_CONST,
	IFLA_CAN_TERMINATION,
	IFLA_CAN_TERMINATION_CONST,
	IFLA_CAN_BITRATE_CONST,
	IFLA_CAN_DATA_BITRATE_CONST,
	IFLA_CAN_BITRATE_MAX,
	__IFLA_CAN_MAX
};

#endif

#endif /* _CAN_NETLINK_H */

int can_if_setbitrate(char *ifname, uint32_t bitrate);
int can_if_setdbitrate(char *ifname, uint32_t dbitrate);

#endif /* _CAN_NL_IF_ */

