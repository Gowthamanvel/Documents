/**
 *  @file g3_doip.h
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 *
 *  Reference : ISO 13400-2:2019
 *  Diagnostic communication over Internet Protocol (DoIP)
 *  (Part 2) : Transport protocol and network layer services
 *
 *  Protocols that should be supported by a DoIP client
 *  (Section 12)
 */

/* NOTE: Sec 7.8:
 * 1. All logical address are mapped to IP addresses
 *    - Read Section 6.2
 * 2. There is no mechanism to address multiple DoIP entities via a single IP address
 */

#ifndef _DOIP_H_
#define _DOIP_H_

#include <stdint.h>

#define PACKED __attribute__ ((packed))

#define VEHICLE_ID_NUM_LEN (17)
#define LOGICAL_ADDR_LEN   (2)
#define ENTITY_ID_LEN      (6)
#define GROUP_ID_LEN       (6)

#define SOCK_SEC_TCP_DATA  (13400)
#define SOCK_TCP_DATA      (3496)
#define SOCK_UDP_DISCOVERY (13400)
#define SOCK_UDP_TEST_EQUIPMENT_REQ_MIN (49152)
#define SOCK_UDP_TEST_EQUIPMENT_REQ_MAX (65535)

/* SOCK_UDP_TEST_EQUIPMENT_REQUEST in range 49152 to 65535 */

/* Table-16: Generic DoIP header; Also, Table-17 */
struct gen_doip_hdr
{
	uint8_t proto_ver;
	uint8_t	inv_proto_ver;
	uint16_t payload_type; /* Table-17 */
	uint32_t payload_len;
	uint8_t payload[0];
} PACKED;
typedef struct gen_doip_hdr gen_doip_hdr_t;

/* Table-17: DoIP payload type: VID Request, Response */
#define PL_TYPE_NEG_ACK      	0x0000
#define PL_TYPE_VIN_REQ      	0x0001
#define PL_TYPE_VIN_REQ_EID  	0x0002
#define PL_TYPE_VIN_REQ_VIN  	0x0003
#define PL_TYPE_VEH_ANN_MSG  	0x0004
#define PL_TYPE_VIN_RSP			0x0004

enum gen_doip_hdr_nack {
	DOIP_HDR_NACK_INCORRECT_PATTERN 	= 0,
	DOIP_HDR_NACK_UNKNOWN_PAYLOAD 		= 1,
	DOIP_HDR_NACK_MSG_TOO_LARGE 		= 2,
	DOIP_HDR_NACK_OUT_OF_MEMORY		= 3,
	DOIP_HDR_NACK_INVALID_PAYLOAD_LEN 	= 4,

	DOIP_HDR_NACK_RSVD
};

/*
 *   Table-2: PL_TYPE_VIN_REQ
 * --------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 0 |
 * |           | ver       | 0x0001 |         |
 * --------------------------------------------
 *
 *   Table-3: PL_TYPE_VIN_REQ_EID
 * --------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 6 | EID       |
 * |           | ver       | 0x0002 |         | (6 bytes) |
 * --------------------------------------------------------
 *
 *   Table-4: PL_TYPE_VIN_REQ_VIN
 * ---------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 17 | VIN       |
 * |           | ver       | 0x0003 |          | (17 bytes)|
 * ---------------------------------------------------------
 *
 *   Table-5: PL_TYPE_VIN_RSP, PL_TYPE_VEH_ANN_MSG
 * -------------------------------------------------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 31 | VIN        | Logical Addr | EID       | GID      | Action Req  | VIN / GID Sync |
 * |           | ver       | 0x0004 |          | (17 bytes) | (2 bytes)    | (6 bytes) | (6 bytes)| (1 byte)    | (1 byte)       |
 * -------------------------------------------------------------------------------------------------------------------------------
 */
typedef struct entity_id
{
	uint8_t eid[ENTITY_ID_LEN];
} PACKED entity_id_t;

typedef struct veh_id_num
{
	uint8_t vin[VEHICLE_ID_NUM_LEN];
} PACKED veh_id_num_t;

/* Do not change the order of the variables. Same as in veh_anno_msg_t */
struct doip_serv_info
{
	uint16_t laddr;
	uint8_t vin[VEHICLE_ID_NUM_LEN];
	uint8_t eid[ENTITY_ID_LEN];
	uint8_t gid[GROUP_ID_LEN];
} PACKED;
typedef struct doip_serv_info doip_serv_info_t;

typedef struct veh_anno_msg
{
	doip_serv_info_t sinfo;
	uint8_t ack_req;
	uint8_t vin_gin_sync;
} PACKED veh_anno_msg_t;

struct doip_server_list
{
	struct doip_server_list *next;
	doip_serv_info_t sinfo;
} PACKED;
typedef struct doip_server_list doip_server_list_t;

/*
 * Table-6: Further action required code
 */
enum veh_anno_msg_action_req
{
	VEH_ANNO_RESP_NO_ACTION_REQUIRED = 0x0,
	VEH_ANNO_RESP_NO_ACTION_ROUTTING_ACT_REQ = 0x10,
	/* Other values
	 * 0x01 to 0x0f -- Reserved
	 * 0x11 to 0xff -- Additional VM specific use
	 */
};

/*
 * Table-7: synchronization status code
 */
enum veh_anno_msg_sync_status_code
{
	VEH_ANNO_RESP_VIN_GID_SYNC_OK = 0x0,
	VEH_ANNO_RESP_VIN_GID_NOT_IN_SYNC = 0x10,
	/* Other values are reserved */
};

/* Table-17: DoIP payload type: Routing Activation Request, Response */
#define PL_TYPE_ROUTING_ACT_REQ 0x0005
#define PL_TYPE_ROUTING_ACT_RSP 0x0006
/*
 *   Table-46: PL_TYPE_ROUTING_ACT_REQ; Also, Table-13, 47, 49
 * ---------------------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 11 | Src Addr  | Activation Type | RSVD      | RSVD      |
 * |           | ver       | 0x0005 |          | (2 bytes) | (1 byte)        | (4 bytes) | (4 bytes) |
 * ---------------------------------------------------------------------------------------------------
 *
 * PL_TYPE_ROUTING_ACT_RSP;
 * --------------------------------------------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 13 | Logical Addr of | Logical Addr of      | Resp code | RSVD      | RSVD      |
 * |           | ver       | 0x0006 |          | client (2 bytes)| DoIP entity (2 byte) | (1 bytes) | (4 bytes) | (4 bytes) |
 * --------------------------------------------------------------------------------------------------------------------------
 *
 *
 */
typedef struct routing_act_req
{
	uint16_t src_addr;
	uint8_t act_type;
	uint32_t rsvd1;
	uint32_t rsvd2;
} PACKED routing_act_req_t;

typedef struct routing_act_resp
{
	uint16_t laddr_cli;
	uint16_t laddr_entity;
	uint8_t resp_code;
	uint32_t rsvd1;
	uint32_t rsvd2;
} PACKED routing_act_resp_t;

typedef struct check_alive_resp
{
	uint16_t src_addr;
} PACKED check_alive_resp_t;


enum doip_routing_act_req_type {
	DOIP_CLI_ROUT_ACT_REQ_TYPE_DEFAULT = 0x00,//16,
	DOIP_CLI_ROUT_ACT_REQ_TYPE_COMM_REQ = 0x01,//16,
	/* 0x216 to 0xDF16 : Reserved */
	DOIP_CLI_ROUT_ACT_REQ_TYPE_CENTRAL_SEC = 0xE0,//16,
	/* 0xE116 to 0xFF16 : VM-specific use */
};

enum doip_routing_act_resp {
	DOIP_CLI_ROUT_ACT_RESP_UNKNOWN_SRC = 0x0,
	DOIP_CLI_ROUT_ACT_RESP_NO_MORE_TCP_SOCK = 0x1,
	DOIP_CLI_ROUT_ACT_RESP_INV_SRC_ADDR = 0x2,
	DOIP_CLI_ROUT_ACT_RESP_ALREADY_ACTIVE = 0x3,
	DOIP_CLI_ROUT_ACT_RESP_NO_AUTH = 0x4,
	DOIP_CLI_ROUT_ACT_RESP_NO_CONFIRM = 0x5,
	DOIP_CLI_ROUT_ACT_RESP_UNSUPP_ROUT_ACT_TYPE = 0x6,
	DOIP_CLI_ROUT_ACT_RESP_REQUIRE_TLS = 0x7,
	/* 0x08 to 0x0F is reserved */
	DOIP_CLI_ROUT_ACT_RESP_SUCCESS = 0x10,
	DOIP_CLI_ROUT_ACT_RESP_ACTIVATED_CONFIRM_REQ = 0x11,
	/* 0x12 to 0xDF is reserved */
	/* 0xE0 to 0xFE is vehicle manufacturer specific */
	/* 0xFF is reserved */
};


/* Table-17: DoIP payload type: Alive Check Request, Response */
#define PL_TYPE_ALIVE_CHECK_REQ 0x0007
#define PL_TYPE_ALIVE_CHECK_RSP 0x0008

/*
 *   Table-27: PL_TYPE_ALIVE_CHECK_REQ
 * --------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 0 |
 * |           | ver       | 0x0007 |         |
 * --------------------------------------------
 *
 *   Table-28: PL_TYPE_ALIVE_CHECK_RSP
 * ---------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 2 | Logical Src Addr |
 * |           | ver       | 0x0008 |         | (2 bytes)        |
 * ---------------------------------------------------------------
 *
 */


/* Table-17: DoIP payload type: DoIP Entity status Request, Response */
#define PL_TYPE_ENTITY_STATUS_REQ 0x4001
#define PL_TYPE_ENTITY_STATUS_RSP 0x4002

/*
 *   Table-10: PL_TYPE_ENTITY_STATUS_REQ
 * --------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 0 |
 * |           | ver       | 0x4001 |         |
 * --------------------------------------------
 *
 *   Table-11: PL_TYPE_ENTITY_STATUS_RSP
 * ------------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 7 | Node type | MCTS     | NCTS     | MDS       |
 * |           | ver       | 0x4002 |         | (1 byte)  | (1 byte) | (1 byte) | (4 bytes) |
 * ------------------------------------------------------------------------------------------
 *
 */
typedef struct entity_status_resp
{
	uint8_t node_type;
	uint8_t msts;
	uint8_t mcts;
	uint8_t ncts;
	uint32_t mds;
} PACKED entity_status_resp_t;

/* Table-17: DoIP payload type: Power Mode Information Request, Response */
#define PL_TYPE_DIAG_PWR_MODE_REQ 0x4003
#define PL_TYPE_DIAG_PWR_MODE_RSP 0x4004

/* Table-9: Power Mode information response */
enum doip_cli_power_mode {
	DOIP_CLI_PM_NOT_READY = 0x0, /* Not all servers accessible via DoIP can communicate */
	DOIP_CLI_PM_READY = 0x01, /* All servers accessible via DoIP can communicate */
	DOIP_CLI_PM_NOT_SUPPORTED = 0x02, /* PM information request is not supported */
};

/*
 *   Table-8: PL_TYPE_DIAG_PWR_MODE_REQ
 * --------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 0 |
 * |           | ver       | 0x4003 |         |
 * --------------------------------------------
 *
 *   Table-9: PL_TYPE_DIAG_PWR_MODE_RSP
 * --------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = 2 | Diagnostic Power Mode |
 * |           | ver       | 0x4004 |         | (2 bytes)             |
 * --------------------------------------------------------------------
 *
 */

/* Table-17: DoIP payload type: Diagnostic message Request, Response */
#define PL_TYPE_DIAG_MSG     0x8001
#define PL_TYPE_DIAG_MSG_ACK 0x8002
#define PL_TYPE_DIAG_MSG_NAK 0x8003
/*
 *   Table-21: PL_TYPE_DIAG_MSG; Also Table-13, 22
 * ------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = n | Src Addr  | Dst Addr  | user data     |
 * |           | ver       | 0x8001 |         | (2 bytes) | (2 bytes) | (n - 4) bytes |
 * ------------------------------------------------------------------------------------
 *
 *   Table-23: PL_TYPE_DIAG_MSG_ACK; Also Table-13, 24
 * -----------------------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = n | Src Addr  | Dst Addr  | ACK code | Previous diagnostic |
 * |           | ver       | 0x8002 |         | (2 bytes) | (2 bytes) | (1 byte) | data (n - 5) bytes  |
 * -----------------------------------------------------------------------------------------------------
 *
 *   Table-25: PL_TYPE_DIAG_MSG_NAK; Also Table-13, 26
 * -----------------------------------------------------------------------------------------------------
 * | Proto ver | Inv proto | Type = | len = n | Src Addr  | Dst Addr  | NAK code | Previous diagnostic |
 * |           | ver       | 0x8003 |         | (2 bytes) | (2 bytes) | (1 byte) | data (n - 5) bytes  |
 * -----------------------------------------------------------------------------------------------------
 */
typedef struct diag_msg
{
	uint16_t srcaddr;
	uint16_t dstaddr;
	uint8_t diag_data[0];
} PACKED diag_msg_t;

/* Table-12: timeout values in milliseconds */
#define A_DoIP_Ctrl (2000)
#define A_DoIP_Announce_Wait (500)
#define A_DoIP_Announce_Interval (500)
#define A_DoIP_Announce_Num (3)
#define A_DoIP_Diagnostic_Message (2000)
#define T_TCP_General_Inactivity (5*60*1000)
#define T_TCP_Initial_Inactivity (2000)
#define T_TCP_Alive_Check (500)
//#define T_TCP_Alive_Check (1)
#define A_Processing_Time (2000)
#define A_Vehicle_Discovery_Timer (5000)

#if 0
/* Req 0.DoIP-185 SPP */
enum DoIP_TAtype {
	
};
#endif

/* Req 0.DoIP-188 SPP - DoIP_Result */
enum DoIP_Result {
	DoIP_OK,
	DoIP_HDR_ERROR,
	DoIP_TIMEOUT_A,
	DoIP_UNKNOWN_SA,
	DoIP_INVALID_SA,
	DoIP_UNKNOWN_TA,
	DoIP_MESSAGE_TOO_LARGE,
	DoIP_OUT_OF_MEMORY,
	DoIP_TARGET_UNREACHABLE,
	DoIP_NO_LINK,
	DoIP_NO_SOCKET,
	DoIP_ERROR
};

/* Table-11 : DoIP node type in Entity Status Response */
enum DoIP_NodeType {
	DoIP_NT_Gateway	= 0,
	DoIP_NT_Node	= 1,
	DoIP_NT_RSVD	= 2,
};

#endif /* _DOIP_H_ */
