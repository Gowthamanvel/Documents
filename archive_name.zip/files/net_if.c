/**
 *	@file net_if.c
 *
 *	Copyright (c) 2023, Capgemini - Intelligent Devices
 *
 *	This module implements the host network interface used for
 *	interacting with the Garuda using TCP/IP over USB CDC-Ethernet or
 *	Wi-Fi.
 */

#include	<unistd.h>
#include	<ifaddrs.h>
#include	<net/if.h>
#include	<netinet/tcp.h>
#include	<linux/if_addr.h>
#include	"g3d.h"
#include	"net_if.h"
#include	"hfcp.h"

static net_if_context_t net_if_ctx;

ssize_t net_if_write(const void *buf, size_t count)
{
	GIOStatus gstatus;
	GError *err;
	gsize bytes_written;

	bytes_written = 0;
	err = NULL;
#if 0
	gstatus = g_io_channel_write_chars(net_if_ctx.client_channel,
			(const gchar *)buf, count, &bytes_written, &err);
#else
	gstatus = g_io_channel_write(net_if_ctx.client_channel,
			(const gchar *)buf, count, &bytes_written);
#endif

	if (err || bytes_written != count) {
		ERR("write status=%d error message: %s", gstatus, err->message);
		g_error_free(err);
		return -1;
	}

	return bytes_written;
}

/*
 * Callback called to handle the received data from the accepted sockets.
 */
#if 0
static gboolean net_if_client_handler_cb(GIOChannel *channel,
					GIOCondition cond, gpointer data)

{
	net_if_context_t *ctx = (net_if_context_t *)data;
	GIOStatus gstatus;
	GError *err;
	gsize bytes_read;

	switch (cond) {
	case G_IO_IN: /* Data ready from client */
		bytes_read = 0;
		err = NULL;

#define OLD_READ 0
#if OLD_READ
		gstatus = g_io_channel_read_chars(channel,
				(gchar *)(ctx->rxbuf + ctx->rxbytes),
				HFCP_PKT_SIZE - ctx->rxbytes, &bytes_read, &err);
#else
		gstatus = g_io_channel_read(channel,
				(gchar *)(ctx->rxbuf + ctx->rxbytes),
				HFCP_PKT_SIZE - ctx->rxbytes, &bytes_read);
#endif
		if (bytes_read == 0) {
			DBG("Client connection closed gracefully.");
			goto ERR;
		}
		if (bytes_read > 0) {
			ctx->rxbytes += bytes_read;

			if (ctx->rxbytes > HFCP_PKT_SIZE) {
				WARN("Packet size greater than HFCP_PKT_SIZE."\
					" Ignoring data!");
				ctx->rxbytes = 0;
			}
		}
#if OLD_READ
		if (err != NULL) {
			ERR("read status=%d error message: %s", gstatus,
					err->message);
			g_error_free(err);
			ctx->rxbytes = 0;
		}
#endif
		if (ctx->rxbytes == HFCP_PKT_SIZE) {
			hexdump("NETIF-RD", ctx->rxbuf, ctx->rxbytes, 1);
			handle_hfcp_rx(ctx->rxbuf, ctx->rxbytes);
			ctx->rxbytes = 0;
		}
		break;

	case G_IO_OUT:
	case G_IO_PRI:
	case G_IO_ERR:
	case G_IO_HUP:
	case G_IO_NVAL:
		DBG("Ignoring condition: 0x%x!", cond);
		goto ERR;
	}

	return TRUE;

ERR:
	HFCP_setApplicationMode(GARUDA_IN_DEFAULT_MODE); // Switch to USB mode
	return FALSE;            // Remove the watch
}
#else
static gboolean net_if_client_handler_cb(GIOChannel *channel,
					GIOCondition cond, gpointer data)

{
	net_if_context_t *ctx = (net_if_context_t *)data;
	GIOStatus gstatus;
	gsize bytes_read;

	switch (cond) {
	case G_IO_IN: /* Data ready from client */
		bytes_read = 0;

		gstatus = g_io_channel_read(channel,
				(gchar *)ctx->rxbuf, HFCP_PKT_SIZE, &bytes_read);

		if (bytes_read == 0) {
			DBG("Client connection closed gracefully.");
			goto ERR;
		}

		ctx->rxbytes = bytes_read;
		hexdump("NETIF-RD", ctx->rxbuf, ctx->rxbytes, 1);
		handle_hfcp_rx(ctx->rxbuf, ctx->rxbytes);
		break;

	case G_IO_OUT:
	case G_IO_PRI:
	case G_IO_ERR:
	case G_IO_HUP:
	case G_IO_NVAL:
		DBG("Ignoring condition: 0x%x!", cond);
		goto ERR;
	}

	return TRUE;

ERR:
	HFCP_setApplicationMode(GARUDA_IN_DEFAULT_MODE); // Switch to USB mode
	return FALSE;            // Remove the watch
}
#endif
/*
 * Callback called for every incoming connection being accepted.
 */

static gboolean net_if_incoming_connection_cb(GSocketService *service,
		GSocketConnection *connection, GObject *sobject,
		gpointer user_data)
{
	net_if_context_t *ctx = (net_if_context_t *)user_data;
	GSocket *gsocket;
	GIOChannel *channel;
	gint sockfd;
	int enable = 1;

	DBG("Received connection from client!");

	gsocket = g_socket_connection_get_socket(connection);

	HFCP_setApplicationMode(GARUDA_IN_WIFI_MODE);

	sockfd = g_socket_get_fd(gsocket);

	if (setsockopt(sockfd, SOL_TCP, TCP_NODELAY, &enable, sizeof(enable))) {
		ERR("Failed to set TCP_NODELAY!");
		goto err;
	}

	channel = g_io_channel_unix_new(sockfd);
	if (!channel) {
		ERR("Failed to create channel for accepted client!");
		goto err;
	}

	ctx->rxbytes = 0;
	ctx->watch_source = g_io_add_watch(channel,
			G_IO_IN | G_IO_HUP | G_IO_ERR | G_IO_NVAL,
			net_if_client_handler_cb, user_data);

	ctx->client_channel = channel;

	g_io_channel_unref(channel);

err:
	g_object_ref(connection);

	ctx->connection = connection;

	return TRUE;
}

static int net_if_init_server(struct net_if_context *ctx)
{
	GSocketService *ifservice;
	GError *err;
	gboolean ret;

	ifservice = g_socket_service_new();

	err = NULL;
	ret = g_socket_listener_add_inet_port(G_SOCKET_LISTENER(ifservice),
			NET_IF_PORT, NULL, &err);

	if (ret && err != NULL) {
		ERR("%s", err->message);
		g_error_free(err);
		return -1;
	}

	g_signal_connect(ifservice, "incoming",
			G_CALLBACK(net_if_incoming_connection_cb), ctx);

	g_socket_service_start(ifservice);

	ctx->ifservice = ifservice;

	return 0;
}

static void net_if_deinit_server(struct net_if_context *ctx)
{
	g_socket_listener_close(G_SOCKET_LISTENER(ctx->ifservice));

	g_source_remove(ctx->watch_source);
}

int net_if_init(void)
{
	if (net_if_init_server(&net_if_ctx) < 0) {
		DBG("net_if_init_server failed!");
		HFCP_setApplicationMode(GARUDA_IN_DEFAULT_MODE);
		return -1;
	}

	return 0;
}

void net_if_deinit(void)
{
	net_if_deinit_server(&net_if_ctx);
	HFCP_setApplicationMode(GARUDA_IN_DEFAULT_MODE);
}

