#!/bin/sh


DNSMASQ_CONF="/etc/dnsmasq.conf"
HOSTAPD_CONF="/etc/g3-hostapd.conf"
WPASUPPLICANT_CONF="./g3-wpa_supplicant.conf"
SERIAL_NO=""
WIFI_SSID="G3"
BAND=""


source /etc/g3-dhcp.conf

create_ssid(){
SERIAL_NO=$(cat /dev/mtd5)
SERIAL_NO=${SERIAL_NO:10:11}
echo "$SERIAL_NO"
}

create_dnsmasq_conf()
{
	if [ ${DHCP} = "0" ]; then
		cat <<-DHCP_CONFIG >> ${DNSMASQ_CONF}
			dhcp-range=${DHCP_RANGE_START},${DHCP_RANGE_END},${DHCP_RANGE_MASK},${DHCP_LEASE_TIME}
			dhcp-option=option:router,${DHCP_GATEWAY_IP}
			dhcp-option=option:dns-server,${DHCP_GATEWAY_IP}
			dhcp-option=option:domain-name,local
			dhcp-authoritative
		DHCP_CONFIG
		sed -i 's/DHCP*=*"0"/DHCP="1"/' "/etc/g3-wlan.config"
	fi
}

source /etc/g3-hostapd-param.conf
source /etc/g3-wlan.config
create_hostapd_conf()
{
if [ ${WLAN_BAND} = "AP_2_4" ]; then
	echo "2.4GHz AP Mode"
	BAND="AP_2.4g"                                                                                         
	cat <<-HOSTAPD_CONFIG > ${HOSTAPD_CONF}
	logger_syslog=$LOGGER_SYSLOG
	logger_syslog_level=$LOGGER_SYSLOG_LEVEL
	logger_stdout=$LOGGER_STDOUT
	logger_stdout_level=$LOGGER_STDOUT_LEVEL
	ctrl_interface=$CTRL_INTERFACE
	ctrl_interface_group=$CTRL_INTERFACE_GROUP
	ssid=${WIFI_SSID}_${SERIAL_NO}_${BAND}
	hw_mode=$HW_MODE_2_4
	channel=$CHANNEL_2_4
	beacon_int=$BEACON_INT
	dtim_period=$DTIM_PERIOD
	max_num_sta=$MAX_NUM_STA
	rts_threshold=$RTS_THRESHOLD
	fragm_threshold=$FRAGM_THRESHOLD
	macaddr_acl=$MACADDR_ACL
	auth_algs=$AUTH_ALGS
	ignore_broadcast_ssid=$IGNORE_BROADCAST_SSID
	wmm_enabled=$WMM_ENABLED
	wmm_ac_bk_cwmin=$WMM_AC_BK_CWMIN
	wmm_ac_bk_cwmax=$WMM_AC_BK_CWMAX
	wmm_ac_bk_aifs=$WMM_AC_BK_AIFS
	wmm_ac_bk_txop_limit=$WMM_AC_BK_TXOP_LIMIT
	wmm_ac_bk_acm=$WMM_AC_BK_ACM
	wmm_ac_be_aifs=$WMM_AC_BE_AIFS
	wmm_ac_be_cwmin=$WMM_AC_BE_CWMIN
	wmm_ac_be_cwmax=$WMM_AC_BE_CWMAX
	wmm_ac_be_txop_limit=$WMM_AC_BE_TXOP_LIMIT
	wmm_ac_be_acm=$WMM_AC_BE_ACM
	wmm_ac_vi_aifs=$WMM_AC_VI_AIFS
	wmm_ac_vi_cwmin=$WMM_AC_VI_CWMIN
	wmm_ac_vi_cwmax=$WMM_AC_VI_CWMAX
	wmm_ac_vi_txop_limit=$WMM_AC_VI_TXOP_LIMIT
	wmm_ac_vi_acm=$WMM_AC_VI_ACM
	wmm_ac_vo_aifs=$WMM_AC_VO_AIFS
	wmm_ac_vo_cwmin=$WMM_AC_VO_CWMIN
	wmm_ac_vo_cwmax=$WMM_AC_VO_CWMAX
	wmm_ac_vo_txop_limit=$WMM_AC_VO_TXOP_LIMIT
	wmm_ac_vo_acm=$WMM_AC_VO_ACM
	own_ip_addr=$OWN_IP_ADDR
	wpa_key_mgmt=$WPA_KEY_MGMT
	wpa=$WPA
	rsn_pairwise=$RSN_PAIRWISE
	wpa_passphrase=$AP_PASSPHRASE
	HOSTAPD_CONFIG
else
	echo "5GHz AP Mode"
	BAND="AP_5g"
	cat <<-EOF > ${HOSTAPD_CONF}
	logger_syslog=$LOGGER_SYSLOG
	logger_syslog_level=$LOGGER_SYSLOG_LEVEL
	logger_stdout=$LOGGER_STDOUT
	logger_stdout_level=$LOGGER_STDOUT_LEVEL
	ctrl_interface=$CTRL_INTERFACE
	ctrl_interface_group=$CTRL_INTERFACE_GROUP
	ssid=${WIFI_SSID}_${SERIAL_NO}_${BAND}
	country_code=$COUNTRY_CODE
	ieee80211d=$IEE80211D
	hw_mode=$HW_MODE_5
	channel=$CHANNEL_5
	beacon_int=$BEACON_INT
	dtim_period=$DTIM_PERIOD
	max_num_sta=$MAX_NUM_STA
	rts_threshold=$RTS_THRESHOLD
	fragm_threshold=$FRAGM_THRESHOLD
	macaddr_acl=$MACADDR_ACL
	auth_algs=$AUTH_ALGS
	ignore_broadcast_ssid=$IGNORE_BROADCAST_SSID
	wmm_enabled=$WMM_ENABLED
	wmm_ac_bk_cwmin=$WMM_AC_BK_CWMIN
	wmm_ac_bk_cwmax=$WMM_AC_BK_CWMAX
	wmm_ac_bk_aifs=$WMM_AC_BK_AIFS
	wmm_ac_bk_txop_limit=$WMM_AC_BK_TXOP_LIMIT
	wmm_ac_bk_acm=$WMM_AC_BK_ACM
	wmm_ac_be_aifs=$WMM_AC_BE_AIFS
	wmm_ac_be_cwmin=$WMM_AC_BE_CWMIN
	wmm_ac_be_cwmax=$WMM_AC_BE_CWMAX
	wmm_ac_be_txop_limit=$WMM_AC_BE_TXOP_LIMIT
	wmm_ac_be_acm=$WMM_AC_BE_ACM
	wmm_ac_vi_aifs=$WMM_AC_VI_AIFS
	wmm_ac_vi_cwmin=$WMM_AC_VI_CWMIN
	wmm_ac_vi_cwmax=$WMM_AC_VI_CWMAX
	wmm_ac_vi_txop_limit=$WMM_AC_VI_TXOP_LIMIT
	wmm_ac_vi_acm=$WMM_AC_VI_ACM
	wmm_ac_vo_aifs=$WMM_AC_VO_AIFS
	wmm_ac_vo_cwmin=$WMM_AC_VO_CWMIN
	wmm_ac_vo_cwmax=$WMM_AC_VO_CWMAX
	wmm_ac_vo_txop_limit=$WMM_AC_VO_TXOP_LIMIT
	wmm_ac_vo_acm=$WMM_AC_VO_ACM
	ieee80211n=$IEEE80211N
	ieee80211ac=$IEEE80211AC
	eap_server=$EAP_SERVER
	own_ip_addr=$OWN_IP_ADDR
	wpa_key_mgmt=$WPA_KEY_MGMT
	wpa=$WPA
	rsn_pairwise=$RSN_PAIRWISE
	wpa_passphrase=$AP_PASSPHRASE
	EOF
fi
}

create_wpasupplicant_conf()
{
cat <<-HOSTAPD_CONFIG > ${WPASUPPLICANT_CONF}
	ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
	update_config=1

	network={
	    ssid="$WPA_SSID"
	    psk="$WPA_PASSPHRASE"
	    key_mgmt=WPA-PSK
	}

HOSTAPD_CONFIG
}

create_wlan_configs()
{
	if [ ${WLAN_MODE} == "AP" ]; then
		create_hostapd_conf
	else
		create_wpasupplicant_conf
	fi
}

run_config()
{
	create_ssid
	create_dnsmasq_conf
	create_wlan_configs
}

