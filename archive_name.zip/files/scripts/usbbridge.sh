#!/bin/sh

ip link add name br0 type bridge
ip link set dev br0 up

ip link set eth0 up
ip link set usb0 up

ip link set eth0 master br0
ip link set usb0 master br0
