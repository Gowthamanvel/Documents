#!/bin/sh
#
# Copyright (c) 2023, Capgemini - Intelligent Devices
#

GADGET_DIR=/sys/kernel/config/usb_gadget
HIDDESC=/tmp/hiddesc.bin

modprobe libcomposite

if [ -d "$GADGET_DIR/g1" ]; then
    echo "g1 directory already exists."
else
    mkdir "$GADGET_DIR/g1"
    echo "g1 directory created."
fi

cd $GADGET_DIR/g1


echo 0x03eb > idVendor
echo 0x5746 > idProduct

#echo 0x1d6b > idVendor
#echo 0x0104 > idProduct


if [ -d "strings/0x409" ]; then
    echo "strings/0x409 directory already exists."
else
    mkdir "strings/0x409"
    echo "strings/0x409 directory created."
fi

echo "1234567890" > strings/0x409/serialnumber
echo "LINUIX ARM RNDIS" > strings/0x409/manufacturer
echo "GARUDA USB RNDIS Gadget" > strings/0x409/product

# Enable HID Function
if [ -d "functions/hid.usb0" ]; then
    echo "functions/hid.usb0 directory already exists."
else
    mkdir "functions/hid.usb0"
    echo "Directory created."
fi

echo -ne \\x06\\xA0\\xFF\\x09\\x01\\xA1\\x01\\x09 > $HIDDESC
echo -ne \\x02\\x09\\x03\\x15\\x00\\x26\\xFF\\x00 >> $HIDDESC
echo -ne \\x75\\x08\\x96\\x00\\x02\\x81\\x00\\x09 >> $HIDDESC
echo -ne \\x04\\x09\\x05\\x15\\x00\\x26\\xFF\\x00 >> $HIDDESC
echo -ne \\x75\\x08\\x96\\x00\\x02\\x91\\x00\\x09 >> $HIDDESC
echo -ne \\x06\\x09\\x07\\x15\\x00\\x26\\xFF\\x00 >> $HIDDESC
echo -ne \\x75\\x08\\x95\\x04\\xB1\\x02\\xC0 >> $HIDDESC

echo 1 > functions/hid.usb0/protocol
echo 1 > functions/hid.usb0/subclass
echo 512 > functions/hid.usb0/report_length
cat $HIDDESC > functions/hid.usb0/report_desc

# Enable RNDIS function
if [ -d "functions/rndis.usb0" ]; then
    echo "functions/rndis.usb0 directory already exists."
else
    mkdir "functions/rndis.usb0"
	echo "RNDIS" > functions/rndis.usb0/os_desc/interface.rndis/compatible_id
	echo "5162001" > functions/rndis.usb0/os_desc/interface.rndis/sub_compatible_id
	echo "rndis.usb0 directory created."
fi

# Enable ACM function
if [ -d "functions/acm.usb0" ]; then
    echo "functions/acm.usb0 directory already exists."
else
    mkdir "functions/acm.usb0"
    echo "acm.usb0 directory created."
fi

# Setup the configuration
if [ -d "configs/c.1" ]; then
    echo "configs/c.1 directory already exists."
else
    mkdir "configs/c.1"
    echo "configs/c.1 directory created."
fi

if [ -d "configs/c.1/strings/0x409" ]; then
    echo "configs/c.1/strings/0x409 directory already exists."
else
    mkdir "configs/c.1/strings/0x409"
    echo "configs/c.1/strings/0x409 directory created."
fi

echo "HID+RNDIS+ACM" > configs/c.1/strings/0x409/configuration
echo 120 > configs/c.1/MaxPower


ln -s functions/rndis.usb0 configs/c.1
ln -s functions/acm.usb0 configs/c.1
ln -s functions/hid.usb0 configs/c.1

mkdir -p os_desc
echo 1 > os_desc/use
echo 0xcd > os_desc/b_vendor_code
echo "MSFT100" > os_desc/qw_sign
ln -s configs/c.1 os_desc

echo 300000.gadget > UDC

ifconfig usb0 up

echo "" > /sys/kernel/config/usb_gadget/g1/UDC
sleep 1
echo $(ls /sys/class/udc | head -n 1) > /sys/kernel/config/usb_gadget/g1/UDC

