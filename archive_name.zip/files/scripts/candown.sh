#!/bin/sh
echo can0 can1 down
ip link set can0 down
ip link set can1 down
echo "networkdown completed!"

exit 0
