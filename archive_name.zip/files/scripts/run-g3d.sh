#!/bin/sh

echo "Running hid.sh..."
/etc/init.d/hid.sh
echo "Running wifi.sh..."
#/etc/init.d/run_wifi.sh &
update-rc.d unload_wifi_modules.sh defaults &
bitrate=500000

ifconfig usb0 down

# for CAN_STD
# echo "Setting CAN bitrate to $bitrate"
# ip link set can0 type can bitrate $bitrate
# echo "can0 up"
# ip link set can0 up

# for CAN_FD ( + CAN_STD)
echo "Setting CAN_FD features: Bitrate = $bitrate"
ip link set can0 up type can bitrate $bitrate dbitrate 2000000 sample-point 0.792 dsample-point 0.833 fd on fd-non-iso off
ip link set can1 up type can bitrate $bitrate dbitrate 2000000 sample-point 0.792 dsample-point 0.833 fd on fd-non-iso off

# Set the environment variables
export PLATFORM="sama5-evk1"
export NXPWIFI_PRESENT=n

# Run the application
echo "Run g3d..."
/usr/sbin/g3d &

