#!/bin/sh

G3UPDATE=g3update
TAR_FILE="/tmp/${G3UPDATE}-*.tgz"

# Check if the tar file exists
if [ ! -f $TAR_FILE ]; then
  echo "Error: Garuda upgrade file ($TAR_FILE) not found."
  exit 1
fi
# Extract the tar file to a temporary location
TMP_DIR=$(mktemp -d)
#echo "$TMP_DIR" > /tmp/tmp_dir_path.txt
echo "Extracting '$TAR_FILE' to '$TMP_DIR'..."
tar xf $TAR_FILE -C $TMP_DIR

export G3ROOT=$TMP_DIR/${G3UPDATE}

if [ ! -f "$G3ROOT/installer" ]; then
    echo "Error: Installer does not exists!"
    exit 1
fi

chmod +x $G3ROOT/installer
cd $G3ROOT
./installer

cd ../..

rm -rf "$TMP_DIR"

echo "Update completed!"

exit 0

