#!/bin/sh
### BEGIN INIT INFO
# Provides:          my_script
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Description:       My custom script to unload WiFi drivers at reboot.
### END INIT INFO

LOG_FILE="/tmp/my_script.log"

case "$1" in
    stop)
        echo "$(date): Removing modules..." >> $LOG_FILE
        rmmod -f moal >> $LOG_FILE 2>&1
        sleep 2
        rmmod -f mlan >> $LOG_FILE 2>&1
        sleep 2
        echo "$(date): Modules removed." >> $LOG_FILE
        ;;
    *)
        echo "Usage: $0 stop" >> $LOG_FILE
        exit 1
        ;;
esac
exit 0

