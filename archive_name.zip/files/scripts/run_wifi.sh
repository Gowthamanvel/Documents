#!/bin/sh                                                                  

# g3d-starthostif.sh                                                       
# This script checks if the USB host interface is up.                      
# If it is not up - it brings up the Wi-Fi interface in the configured mode
                                                                           
#source /etc/g3-eth.config                                                                                 
                                                                                      
source /etc/g3-wlan.config                                                                            
SLEEP_INTERVAL=5                                                         
# Time to wait for wpa_supplicant to connect to AP                 
SLEEP_FOR_CONNECT=5                                                        
                                                       
function is_usb_connected_to_host()                                      
{                                                                                          
        # Forcing no USB Host interface 
        if [ "$(cat /sys/devices/platform/ahb/300000.gadget/udc/300000.gadget/is_selfpowered)" = "0" ]; then
        	return 1;                                   
        else
        	echo "WiFi: USB not connected"
        	return 0; 
        fi                                                          
}                                                                                          
check_wifi_connected() {               
        if ip addr show mlan0 | grep -q "inet "; then
                echo "INET:Wi-Fi is connected."
        return 0                                     
        else                                         
                echo "INET:Wi-Fi is not connected."  
        return 1                                  
        fi                                         
}                                                    
                                                     
is_sta_connected() {                                 
        if iw dev uap0 station dump | grep -q "Station"; then
                        return 0                     
        else                                                 
                echo "INET:Station is not Connected to AP"   
        fi                                                   
}                                                                                            
function is_wifi_sta_up()                                                  
{                                                      
        if [ "$(cat /sys/class/net/mlan0/operstate)" = "up" ]; then                           
                return 0                                                                   
        else                                                       
                return 1                                                                      
        fi                                                         
}                                                                  
   
  function is_wifi_ap_up()                                                   
{                                                                          
        if [ "$(cat /sys/class/net/uap0/operstate)" = "up" ]; then         
                return 1                                                 
        else                                                               
                return 0                                 
        fi                                                                 
}                                                    
                                                                         
function stop_wifi_ap()                                            
{                                                                          
        # Reset interface before switching mode        
        ip link set $WLAN_AP_IF down                                     
}                                                                                          
                                                                           
function stop_wifi_sta()                                                   
{                                                                                          
        # Reset interface before switching mode                                               
        ip link set $WLAN_STA_IF down                                      
}                                                                  
                                                                                              
function stop_wifi()                                                                          
{                                                                                          
	if [ is_wifi_ap_up ]; then                                 
		stop_wifi_ap                                                                  
	fi                                                         
	if [ is_wifi_sta_up ]; then                                
                stop_wifi_sta                                                                 
	fi                                                         
}                                                                                             
   
    # Function to run hostapd (AP mode)                                        
function start_wifi_ap()                                                   
{                                                                        
	if [ is_wifi_sta_up ]; then                                        
		stop_wifi_sta                            
	fi
	HOST_PID=$(pgrep hostapd)
	if [ $HOST_PID ]; then
		echo "WiFi: hostapd runing ..."
	else                                                                 
		echo "WiFi: Starting hostapd ..."                            
		ip addr flush dev uap0                             
		ifconfig $WLAN_AP_IF up                                    
		ip addr flush dev uap0                 
		# Assign static IP for AP mode                           
		ip addr add 192.168.1.1/24 dev $WLAN_AP_IF                                 
		hostapd -i $WLAN_AP_IF $HOSTAPD_CONF -B                    
      
	fi
	while is_sta_connected; do            
                sleep 60                                           
        done                                              
        echo "Wifi:Sta leave ap"
}                                                                                             
                                                                           
function start_wifi_sta()                                          
{                                                                                             
        if [ is_wifi_ap_up ]; then                                             
                stop_wifi_ap                                 
        fi                                                                                    
        if ! is_wifi_sta_up; then                                                             
		echo "WiFI: Starting wpa_supplicant ... " 
        ifconfig $WLAN_STA_IF up                                   
		wpa_supplicant -B -i $WLAN_STA_IF -c $WPA_SUPPLICANT_CONF  
		sleep $SLEEP_FOR_CONNECT                                   
		if [ $WLAN_STA_IP_MODE == "Auto" ]; then                   
                           # Obtain an IP address via DHCP
			udhcpc -i $WLAN_STA_IF                           
		else                                                       
                        # Setup the IP address statically
                        ip addr add $WLAN_STA_IP/24 dev $WLAN_AP_IF      
		fi                                   
	ifconfig                                           
	fi
	while check_wifi_connected; do                             
		echo "WiFi:Connected to Wi-Fi in STA mode. Sleeping until connection is dropped."
		sleep 60  # Check every 5 seconds         
        done                                             
        echo "WiFi:Wi-Fi STA connection dropped"                                                          
}                                                      

								

TIMESTAMP_FILE="/tmp/g3_wifi_last_mod_time"                                
CURRENT_TIME=$(stat -c %Y%m%d%H%M "/etc/g3-wlan.config")
source /etc/g3-dhcpconfig.sh

#CREATE WLAN CONFIGURATIONS                                           
run_config
sleep 5
NET_PID=$(pgrep NetworkManager)
WPA_PID=$(pgrep wpa_supplicant)
kill "$NET_PID"  
kill "$WPA_PID"	
                                                  
while true; do
	if [ $CURRENT_TIME != $TIMESTAMP_FILE ]; then                  
         	stop_wifi                                          
         	source /etc/g3-wlan.config                                                   
         	MODIFIED_TIME=$TIMESTAMP_FILE                                                      
	fi       
	if ! is_usb_connected_to_host ; then
		stop_wifi		                                                            
	elif [ $WLAN_MODE = "AP" ]; then                                                        
         	start_wifi_ap                    
	elif [ $WLAN_MODE = "STA" ]; then                                                     
		start_wifi_sta                                     
	fi                                           
        sleep $SLEEP_INTERVAL                                                                 
done 
