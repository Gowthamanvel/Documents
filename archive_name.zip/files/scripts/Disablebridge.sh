#!/bin/sh

ip link set eth0 nomaster
ip link set usb0 nomaster

ip link delete br0 type bridge

ifconfig usb0 down
