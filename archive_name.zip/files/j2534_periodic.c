/**
 * @file J2534_periodic.c
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <linux/can.h>
#include "j2534_periodic.h"
#include "j2534_filter.h"
#include "hfcp.h"
#include "can.h"
#ifdef BCM_SUPPORT
#include "can_if.h"
#include <linux/can/bcm.h>
#include "g3d.h"
#endif

#define UNUSED_VAR(x) (void)(x)

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
#define    c_MAX_PERIODIC_MSG          10
#define    c_TX_IMMEDIATE_CNT          1
#define    PERIODIC_STEPVAL            1000
#define    TICK_PERIOD_MS              1 /* 1000/1000 */ 

/******************************************************************************
*         P R I V A T E    F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
#ifndef BCM_SUPPORT
static void can_handle_periodic_msg(uint8_t i, uint8_t p_ch_index);
#endif
static uint8_t startnew_pmsg (PERIODIC_MSG  *);
static uint8_t stop_pmsg( uint8_t , uint32_t );

static uint8_t update_new_pmsg (PERIODIC_MSG  *p_msg_ptr);
extern void Garuda_Tx_data_on_USB(char *p_data_U8, uint16_t p_length, uint8_t release);
extern uint32_t GarudaProID_Used[NO_OF_CHANNEL_USED];
#ifdef BCM_SUPPORT
#define ONE_MICRO_SECOND (1000)
#define ONE_MILLI_SECOND (1000000)
static void periodic_handler(uint8_t chan_num, int msg_idx);
static void periodic_msg_delete(int bcmfd, uint32_t canid);
static int bcm_can_open(int chan_num);
#endif

/****************************************************************************************/

extern char *CAN_CHA1;
extern char *CAN_CHA2;


/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/* The Constant data array of Protocols IDs which need are enabled
by Garuda - Re-arange GARUDA_ChannelNum_t(.h file) in same order*/

static uint8_t l_pmsg_count_hold[NO_OF_CHANNEL_USED]={0};
static uint8_t periodic_cnt=0;

/* Holds the structure of periodic messages that are to be transmitted */
static PERIODIC_MSG l_pmsg_buf[NO_OF_CHANNEL_USED][c_MAX_PERIODIC_MSG];


/******************************************************************************
* Function name : static BYTE update_new_pmsg (PERIODIC_MSG  *p_msg_ptr,
*                  BYTE *p_pmsg_id)
*    returns    : Returns PERIODIC_SUCCESS if it is success or
*                         else returns PERIODIC_EXCEEDED_LIMIT.
*    *p_msg_ptr : new periodic message pointer that has to
*                                 be transmitted.
* Description   : update the periodic msg into the periodic msg buffer
*******************************************************************************/

static uint8_t update_new_pmsg(PERIODIC_MSG *p_msg_ptr)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i,j;
    
    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_msg_ptr->protocol_id==GarudaProID_Used[fl_ProtoIndex])
        {
            /* The Protocol ID Matched @fl_ProtoIndex*/
            break;
        }
    }
    
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex == NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        if((p_msg_ptr->prmsg_id < 1) || (p_msg_ptr->prmsg_id > c_MAX_PERIODIC_MSG))
        {
            fl_ret_val = PERIODIC_INVALID_MSG_ID;
        }
        else
        {
            /**< Disable Timer Interrupt */
            /**< __disable_interrupt(); */
            //Disable_Timer_Irq();
            
            for(i=0; i<c_MAX_PERIODIC_MSG; i++)
            {
                if(l_pmsg_buf[fl_ProtoIndex][i].prmsg_id == p_msg_ptr->prmsg_id)
                {
                    /**< Copy Tx Flags */
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.tx_flags =
                    p_msg_ptr->proto_msg.tx_flags;
                    
                    /**< Copy Message Length */
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length =
                    p_msg_ptr->proto_msg.length;
                    
                    /**< Copy Data */
                    for(j = 0; j < l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length; j++)
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[j] =
                    p_msg_ptr->proto_msg.data[j];
                    
                    /**< Copy Periodicity and local Periodicity */
                    l_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * portTICK_PERIOD_MS);
                    /* l_pmsg_buf[fl_ProtoIndex][i].local_periodicity = l_pmsg_buf[fl_ProtoIndex][i].periodicity; */
                    l_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT; 
                    
                    /**< Handling required */
#ifndef BCM_SUPPORT
                    //PERIODIC_handler();
#else
                    periodic_handler(fl_ProtoIndex, i);
#endif
                    fl_ret_val = PERIODIC_SUCCESS;
                }
            }
            /**< Enable Timer Interrupt */
            /**< __enable_interrupt(); */
            //Enable_Timer_Irq();
        }
    }
    return fl_ret_val;
}


/******************************************************************************
* Function name : static BYTE startnew_pmsg (PERIODIC_MSG  *p_msg_ptr,
*                  BYTE *p_pmsg_id)
*    returns    : Returns PERIODIC_SUCCESS if it is success or
*                         else returns PERIODIC_EXCEEDED_LIMIT.
*    *p_msg_ptr : new periodic message pointer that has to
*                                 be transmitted.
* Description   : adds the periodic msg into the periodic msg buffer
* Notes         : if a periodic message comes after timer started then
*                         for first time it will transmit mesg after 1msec of
*                   timeout
*******************************************************************************/
static uint8_t startnew_pmsg(PERIODIC_MSG *p_msg_ptr)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i,j;
#ifdef BCM_SUPPORT
    int bcmfd;
#endif

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_msg_ptr->protocol_id == GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex == NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        /*
        * verify for buffer full
        */

        if(l_pmsg_count_hold[fl_ProtoIndex] == 10)
        {
            fl_ret_val = PERIODIC_EXCEEDED_LIMIT;
        }
        else
        {

            for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
            {
                /*
                * search fr free buffer
                */

                if(l_pmsg_buf[fl_ProtoIndex][i].prmsg_id == 0)
                {
                    /* Store the Free Id  (1 to 10) */
                    l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = i + 1;

                    /* Update Id for response */
                    p_msg_ptr->prmsg_id = l_pmsg_buf[fl_ProtoIndex][i].prmsg_id;

                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.tx_flags =
                        p_msg_ptr->proto_msg.tx_flags;
                    l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length =
                        p_msg_ptr->proto_msg.length;
                    for(j = 0; j < l_pmsg_buf[fl_ProtoIndex][i].proto_msg.length; j++)
                            l_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[j] =
                                p_msg_ptr->proto_msg.data[j];

                    /* l_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * 1000) / PERIODIC_STEPVAL; */
                    l_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * TICK_PERIOD_MS);
                    /* Transmit first message immediately, so local periodicity shd be c_TX_IMMEDIATE_CNT */
                    l_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT;
                    (l_pmsg_count_hold[fl_ProtoIndex])++;
                    periodic_cnt++;
                    fl_ret_val = PERIODIC_SUCCESS;
#ifndef BCM_SUPPORT
                    //PERIODIC_handler();
#else
                    bcmfd = bcm_can_open(fl_ProtoIndex);
                    if (bcmfd == -1) {
                        ERR("Unable to open bcmfd");
                        l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
                        break;
                    }
                    l_pmsg_buf[fl_ProtoIndex][i].bcmfd = bcmfd;
                    periodic_handler(fl_ProtoIndex, i);
#endif
                    /* Increment the count of periodic message for the channel */
                    break;
                }
            }
        }
    }
    return fl_ret_val;
}



/******************************************************************************
* Function name    : static BYTE stop__pmsg( BYTE p_pmsg_id, BYTE p_protocol_id)
*    returns       : returns PERIODIC_SUCCESS, if success else
*                         returns PERIODIC_INVALID_MSG_ID.
*    p_pmsg_id          : periodic message id
*    p_protocol_id : protocol id
* Description      : removes the particular periodic message from
*                         the periodic message buffer
* Notes            :
*******************************************************************************/

static uint8_t stop_pmsg(uint8_t p_pmsg_id, uint32_t p_protocol_id)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i;
#ifdef BCM_SUPPORT
    uint32_t canid;
#endif

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
	DBG("Manage_Session - SESSION_CLOSE0");
        if(p_protocol_id == GarudaProID_Used[fl_ProtoIndex])
	    {
             DBG("Manage_Session - SESSION_CLOSE1");
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex == NO_OF_CHANNEL_USED)
    {
	DBG("Manage_Session - SESSION_CLOSE2");
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        /*
         * verifies for valid periodic msg id
         */

        if((p_pmsg_id < 1) || (p_pmsg_id > 10))
        {
	    DBG("Manage_Session - SESSION_CLOSE3");
            fl_ret_val = PERIODIC_INVALID_MSG_ID;
        }
        else
        {
            for(i=0; i<c_MAX_PERIODIC_MSG; i++)
            {
                 if(l_pmsg_buf[fl_ProtoIndex][i].prmsg_id == p_pmsg_id)
                 {
                    l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
                    (l_pmsg_count_hold[fl_ProtoIndex])--;
                    if(periodic_cnt)
                        periodic_cnt--;
#ifdef BCM_SUPPORT
		    DBG("Manage_Session - SESSION_CLOSE");
                    canid = CANID_FROM_DATA(&(l_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[0]));
                    periodic_msg_delete(l_pmsg_buf[fl_ProtoIndex][i].bcmfd, canid);
                    l_pmsg_buf[fl_ProtoIndex][i].bcmfd = -1;
#endif
                    fl_ret_val = PERIODIC_SUCCESS;
                 }
            }
            if( fl_ret_val!= PERIODIC_SUCCESS)
            {
                fl_ret_val = PERIODIC_INVALID_MSG_ID;
            }
        }
    }
    return fl_ret_val;
}


/******************************************************************************
* Function name : static BYTE suspend_pmsg (BYTE p_protocol_id)
*    returns        : returns PERIODIC_SUCCESS, if success else
*                         returns PERIODIC _FAILED.
*    p_protocol_id      : protocol id
* Description       : clears the periodic message buffer
* Notes         :
*******************************************************************************/

uint8_t suspend_pmsg(uint32_t p_protocol_id)
{
    uint8_t fl_ret_val = PERIODIC_FAILED, fl_ProtoIndex, i;
#ifdef BCM_SUPPORT
    uint32_t canid;
#endif

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_protocol_id == GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex == NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        if((l_pmsg_count_hold[fl_ProtoIndex]) != 0)
        {
            for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
            {
                l_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
         
#ifdef BCM_SUPPORT
                canid = CANID_FROM_DATA(&(l_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[0]));
                periodic_msg_delete(l_pmsg_buf[fl_ProtoIndex][i].bcmfd, canid);
                l_pmsg_buf[fl_ProtoIndex][i].bcmfd = -1;
#endif
            }
            l_pmsg_count_hold[fl_ProtoIndex] = 0;
            fl_ret_val = PERIODIC_SUCCESS;
        }
        else
        {
            fl_ret_val = PERIODIC_FAILED;
        }
    }
    return fl_ret_val;
}

#ifndef BCM_SUPPORT

static void periodic_14230(uint8_t index)
{/*
    ISO9141_14230_TxMsg_S fl_App_ISO9141_14230TxMsg_S;
    ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus;
    uint16_t loop_cnt;

    // Determine the Tx message 
    fl_App_ISO9141_14230TxMsg_S.Flags  = l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.tx_flags;
    fl_App_ISO9141_14230TxMsg_S.Length =l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.length;

    for(loop_cnt = 0;
    loop_cnt < fl_App_ISO9141_14230TxMsg_S.Length;
    loop_cnt++)
    {
        fl_App_ISO9141_14230TxMsg_S.Data[loop_cnt] = l_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.data[loop_cnt];
    }
    // Call the Write Message function
    fl_ISO9141_14230RetStatus =
                               ISO9141_14230_WriteMsg(&fl_App_ISO9141_14230TxMsg_S);
    if(NO_ERROR != fl_ISO9141_14230RetStatus)
    {
      // Q Full - Discard Message
    }
*/
}

static void can_handle_periodic_msg(uint8_t i, uint8_t p_ch_index)
{
    uint8_t loop_cnt;
    struct can_frame frame;
    Mid_API_Status_t fl_Q_Status;

    /* TODO: The below code is unused
     * CAN_tx_flags = l_pmsg_buf[p_ch_index][i].proto_msg.tx_flags;
     */
	memset((void *)&frame, 0, sizeof(frame));
	frame.can_id = CANID_FROM_DATA(&(l_pmsg_buf[p_ch_index][i].proto_msg.data[0]));
	frame.can_dlc = l_pmsg_buf[p_ch_index][i].proto_msg.length - 4;
	for(loop_cnt=0; loop_cnt < frame.can_dlc; loop_cnt++) {
        frame.data[loop_cnt] =
            l_pmsg_buf[p_ch_index][i].proto_msg.data[4 + loop_cnt];
    }
    /**< fl_msg.is_periodic_msg = TRUE; */ //IMPORTANT ?? IS THIS REQUIRED ???
    
    if(GARUDA_CAN_CH1 == p_ch_index)
    {
        fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &frame);
    }
    else if(GARUDA_CAN_CH2 == p_ch_index)
    {
        fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &frame);
    }
    else
    {
        /* Do Nothing */
    }
    if (fl_Q_Status == MID_FAIL)
    {
        /* Queue is Full -- Not Decided the Action next */
    }
}

static void J1939_handle_periodic_msg(uint8_t i, uint8_t p_ch_index)
{
	uint8_t loop_cnt;
	struct can_frame frame;
	Mid_API_Status_t fl_Q_Status;

	memset((void *)&frame, 0, sizeof(frame));
	frame.can_id = CANID_FROM_DATA(&(l_pmsg_buf[p_ch_index][i].proto_msg.data[0]));
	frame.can_dlc = l_pmsg_buf[p_ch_index][i].proto_msg.length - 4;
	for(loop_cnt=0; loop_cnt < frame.can_dlc; loop_cnt++) {
        frame.data[loop_cnt] =
				l_pmsg_buf[p_ch_index][i].proto_msg.data[4 + loop_cnt];
    }
	
	if(GARUDA_J1939_CH1==p_ch_index)
	{
		fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &frame);
	}
	else if(GARUDA_J1939_CH2==p_ch_index)
	{
      fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &frame);
	}
	else
	{
		/* Do Nothing */
	}
	if (fl_Q_Status == MID_FAIL)
	{
		/* Queue is Full -- Not Decided the Action next */
	}
}

#endif /* BCM_SUPPORT */

uint8_t PERIODIC_msg_cmd (PERIODIC_MSG *p_msg_ptr, uint8_t p_periodic_cmd)
{
    uint8_t fl_ret_val = PERIODIC_FAILED;

    switch(p_periodic_cmd)
    {
        case PERIODIC_STARTNEW_PMSG :
        {
            if ((p_msg_ptr->periodicity >= 5) &&
                (p_msg_ptr->periodicity <= 65535))
            {
              fl_ret_val = startnew_pmsg(p_msg_ptr);
            }
            else
            {
                fl_ret_val = PERIODIC_INVALID_TIME_INTERVAL;
            }
              break;
        }

        case PERIODIC_STOP_PMSG :
        {
              DBG("Manage_Session - SESSION_CLOSE");
	      fl_ret_val = stop_pmsg(p_msg_ptr->prmsg_id, p_msg_ptr->protocol_id);
              break;
        }

        case PERIODIC_SUSPEND_PMSG:
        {
              fl_ret_val = suspend_pmsg(p_msg_ptr->protocol_id);
              break;
        }

        case PERIODIC_UPDATE_PMSG:
        {
              if ((p_msg_ptr->periodicity >= 5) &&
              (p_msg_ptr->periodicity <= 65535))
              {
                  fl_ret_val = update_new_pmsg(p_msg_ptr);
              }
              else
              {
                  fl_ret_val = PERIODIC_INVALID_TIME_INTERVAL;
              }
              break;              
        }

        case PERIODIC_CHANGE_PERIOD_PMSG :
        {
              /* Do nothing */
              break;
        }
        default :
        {
              fl_ret_val = PERIODIC_FAILED;
              break;
        }
    }
    return fl_ret_val;
}

#ifndef BCM_SUPPORT
void PERIODIC_handler(void)
{
    uint8_t i,j;

    if(periodic_cnt)
    {
        for(j=0;j<NO_OF_CHANNEL_USED;j++)
        {
            if(l_pmsg_count_hold[j] != 0)
            {
                for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
                {
                    if(l_pmsg_buf[j][i].prmsg_id != 0)
                    {
                        l_pmsg_buf[j][i].local_periodicity--;
                        
                        /**< Added to just update the local periodicity in case of overrun : AMIT */ 
                        if(l_pmsg_buf[j][i].local_periodicity > l_pmsg_buf[j][i].periodicity)
                        {
                            l_pmsg_buf[j][i].local_periodicity = l_pmsg_buf[j][i].periodicity;
                        }
                        if(l_pmsg_buf[j][i].local_periodicity == 0)
                        {
                            switch(j)
                            {
                            case GARUDA_CAN_CH1:
                                {
                                    can_handle_periodic_msg(i, GARUDA_CAN_CH1);
                                    break;
                                }
                            case GARUDA_KWP_CH1:
                                {
                                    /* Call transmit function for 9141 / 14230 */
                                    periodic_14230(i);
                                    break;
                                }
                            case GARUDA_CAN_CH2:
                                {
                                    can_handle_periodic_msg(i, GARUDA_CAN_CH2);
                                    break;
                                }
                            case GARUDA_J1939_CH1:
                            {
                                    J1939_handle_periodic_msg(i, GARUDA_J1939_CH1);
                                    break;
                            }
                            case GARUDA_J1939_CH2:
                            {
                                    J1939_handle_periodic_msg(i, GARUDA_J1939_CH2);
                                    break;
                            }
								
                            default :
                                {
                                    /* Do nothing */
                                    break;
                                }
                            }
                            l_pmsg_buf[j][i].local_periodicity = l_pmsg_buf[j][i].periodicity;
                        }
                    }
                }
            }
        }
    }
}
#endif

#ifdef BCM_SUPPORT
extern char *get_interface_name(int ch);

static int bcm_can_open(int chan_num)
{
    int bcmfd, ch;
    char *ifname;
    struct ifreq ifr;
    struct sockaddr_can addr;

    if ((chan_num == GARUDA_CAN_CH1) || (chan_num == GARUDA_CAN_FD_CH1)){
	    ch = 0;
    } else if (chan_num == GARUDA_CAN_CH2) {
        ch = 1;
    } else {
        /* TODO : Handle other cases */
        ERR("unhandled channel number %d\n", (int)chan_num);
        return -1;
    }

    DBG("ch=%d\n", ch);
    ifname = get_interface_name(ch);
	DBG("ifname = %s",ifname);
	if (ifname == NULL) {
	ERR("Invalid ifname\n");
		return -1;
	}

    bcmfd = socket(PF_CAN, SOCK_DGRAM, CAN_BCM);
    if (bcmfd < 0) {
        ERR("Could not open %s BCM socket!", ifname);
        return -1;
    }

    strcpy(ifr.ifr_name, ifname);
    if (ioctl(bcmfd, SIOCGIFINDEX, &ifr) < 0) {
        ERR("Could not get %s interface index!", ifname);
        goto reterr;
    }

    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;
    if (connect(bcmfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        ERR("Failed to connect to %s socket!", ifname);
        goto reterr;
    }

    return bcmfd;
reterr:
    close(bcmfd);
    ERR("bcmfd ret=-1\n");
    return -1;
}

static void periodic_msg_delete(int bcmfd, uint32_t canid)
{
	struct bcm_msg_head *pmsg;
	uint32_t size, cnt;

	size = sizeof(struct bcm_msg_head);
	pmsg = (struct bcm_msg_head *) malloc(size);
	if (pmsg == NULL) {
		ERR("malloc: no buffer\n");
		return;
	}
	memset((void *)pmsg, 0, size);
	pmsg->opcode = TX_DELETE;
	pmsg->can_id = canid;
	cnt = can_if_bcm_write(bcmfd, pmsg, size);

	if (cnt != size) {
//		ERR("bcm_can_write failed\n");
	} 
	close(bcmfd);
	free(pmsg);
	return;
}

/*
 * This function uses the 'bcmfd' to configure periodic transmission
 *
 */
 
#if 0
static void periodic_handler(uint8_t chan_num, int msg_idx)
{
	uint32_t canid, t, size, bytes;
	struct can_frame *frm;
	struct bcm_msg_head *pmsg;
	int i;

	size = sizeof(struct bcm_msg_head) + sizeof(struct can_frame);
	pmsg = (struct bcm_msg_head *) malloc(size);
	if (pmsg == NULL) {
		ERR("No buffer\n");
		return;
	}
	memset((void *)pmsg, 0, size);
	pmsg->opcode = TX_SETUP;	/* Create (cyclic) transmission task */
	pmsg->flags = SETTIMER 		/* Set the values of ival1, ival2 and count */
				| STARTTIMER	/* Start the timer with the actual values of ival1, ival2 and count.
								 * Starting the timer leads simultaneously to emit a CAN frame */
				| TX_CP_CAN_ID  /* Copies the can_id from the message header to each subsequent frame in frames */
				| TX_COUNTEVT;  /* Create the message TX_EXPIRED when count expires */
	pmsg->count = 0; /* continous transmission */
	t = l_pmsg_buf[chan_num][msg_idx].periodicity * ONE_MICRO_SECOND;
	pmsg->ival2.tv_sec = t / ONE_MILLI_SECOND;
	pmsg->ival2.tv_usec = (t - (pmsg->ival2.tv_sec * ONE_MILLI_SECOND));
	pmsg->ival1.tv_sec = 0;
	pmsg->ival1.tv_usec = 0;
	pmsg->nframes = 1;
	frm = pmsg->frames;
	canid = CANID_FROM_DATA(&(l_pmsg_buf[chan_num][msg_idx].proto_msg.data[0]));
	pmsg->can_id = canid;
	frm->can_id = canid;
	frm->can_dlc = l_pmsg_buf[chan_num][msg_idx].proto_msg.length - 4;

	for (i = 0; i < frm->can_dlc; i++) {
		frm->data[i] = l_pmsg_buf[chan_num][msg_idx].proto_msg.data[4+i];
	}

	DBG("canid 0x%x, adding %u periodic msgs\n", canid, pmsg->nframes);
	bytes = can_if_bcm_write(l_pmsg_buf[chan_num][msg_idx].bcmfd,
						pmsg, size);
	if (bytes != size) {
		ERR("bcm_can_write failed");
	}

	DBG("bcm_sent %d bytes", bytes);

	free(pmsg);

	return;
}
#else
static void periodic_handler(uint8_t chan_num, int msg_idx)
{
	uint32_t canid, t, size, bytes;
	struct can_frame *CAN_frm;
	struct canfd_frame *CANFD_frm;
	struct bcm_msg_head *pmsg;
	int i;

	DBG("Inside periodic_handler\n");
	if(chan_num == GARUDA_CAN_FD_CH1) {
		/* for CAN-FD frames*/
		DBG("CAN_FD periodic is on\n");
		size = sizeof(struct bcm_msg_head) + sizeof(struct canfd_frame);
		pmsg = (struct bcm_msg_head *) malloc(size);
		if (pmsg == NULL) {
			ERR("No buffer\n");
			return;
		}
		memset((void *)pmsg, 0, size);
		
		pmsg->opcode = TX_SETUP;	/* Create (cyclic) transmission task */
		pmsg->flags = SETTIMER 		/* Set the values of ival1, ival2 and count */
					| STARTTIMER	/* Start the timer with the actual values of ival1, ival2 and count.
									 * Starting the timer leads simultaneously to emit a CAN frame */
					| TX_CP_CAN_ID  /* Copies the can_id from the message header to each subsequent frame in frames */
					| TX_COUNTEVT  /* Create the message TX_EXPIRED when count expires */
					| CAN_FD_FRAME; /* CAN FD Frames*/
		
		pmsg->count = 0; /* continous transmission */
		t = l_pmsg_buf[chan_num][msg_idx].periodicity * ONE_MICRO_SECOND;
		pmsg->ival2.tv_sec = t / ONE_MILLI_SECOND;
		pmsg->ival2.tv_usec = (t - (pmsg->ival2.tv_sec * ONE_MILLI_SECOND));
		pmsg->ival1.tv_sec = 0;
		pmsg->ival1.tv_usec = 0;
		pmsg->nframes = 1;
		
		CANFD_frm = pmsg->frames;
		canid = CANID_FROM_DATA(&(l_pmsg_buf[chan_num][msg_idx].proto_msg.data[0]));
		pmsg->can_id = canid;
		CANFD_frm->can_id = canid;
		//if(l_pmsg_buf[chan_num][msg_idx].proto_msg.tx_flags == BRS_FLAG) {
			CANFD_frm->flags |= CANFD_BRS;
		//}
		CANFD_frm->len = l_pmsg_buf[chan_num][msg_idx].proto_msg.length - 4;
		
		for (i = 0; i < CANFD_frm->len; i++) {
			CANFD_frm->data[i] = l_pmsg_buf[chan_num][msg_idx].proto_msg.data[4+i];
		}
	} else {
		/* for CAN frames*/
		size = sizeof(struct bcm_msg_head) + sizeof(struct can_frame);
		pmsg = (struct bcm_msg_head *) malloc(size);
		if (pmsg == NULL) {
			ERR("No buffer\n");
			return;
		}
		memset((void *)pmsg, 0, size);
		
		pmsg->opcode = TX_SETUP;	/* Create (cyclic) transmission task */
		pmsg->flags = SETTIMER 		/* Set the values of ival1, ival2 and count */
					| STARTTIMER	/* Start the timer with the actual values of ival1, ival2 and count.
									 * Starting the timer leads simultaneously to emit a CAN frame */
					| TX_CP_CAN_ID  /* Copies the can_id from the message header to each subsequent frame in frames */
					| TX_COUNTEVT;  /* Create the message TX_EXPIRED when count expires */
		
		pmsg->count = 0; /* continous transmission */
		t = l_pmsg_buf[chan_num][msg_idx].periodicity * ONE_MICRO_SECOND;
		pmsg->ival2.tv_sec = t / ONE_MILLI_SECOND;
		pmsg->ival2.tv_usec = (t - (pmsg->ival2.tv_sec * ONE_MILLI_SECOND));
		pmsg->ival1.tv_sec = 0;
		pmsg->ival1.tv_usec = 0;
		pmsg->nframes = 1;
		
		CAN_frm = pmsg->frames;
		canid = CANID_FROM_DATA(&(l_pmsg_buf[chan_num][msg_idx].proto_msg.data[0]));
		pmsg->can_id = canid;
		CAN_frm->can_id = canid;
		CAN_frm->can_dlc = l_pmsg_buf[chan_num][msg_idx].proto_msg.length - 4;

		for (i = 0; i < CAN_frm->can_dlc; i++) {
			CAN_frm->data[i] = l_pmsg_buf[chan_num][msg_idx].proto_msg.data[4+i];
		}
	}

//	printf("Before can_if_bcm_write\n");
	bytes = can_if_bcm_write(l_pmsg_buf[chan_num][msg_idx].bcmfd,
						pmsg, size);
	if (bytes != size) {
		ERR("bcm_can_write failed");
	}

	DBG("bcm_sent %d bytes", bytes);

	free(pmsg);

	return;
}
#endif
void bcm_pmsg_deinit(void)
{
	int ch, midx, bcmfd;
	uint32_t canid;

	for(ch=0; ch<NO_OF_CHANNEL_USED; ch++) {
		for(midx=0; midx<c_MAX_PERIODIC_MSG; midx++) {
			bcmfd = l_pmsg_buf[ch][midx].bcmfd;
			if (bcmfd != -1) {
				canid = CANID_FROM_DATA(&(l_pmsg_buf[ch][midx].proto_msg.data[0]));
				periodic_msg_delete(bcmfd, canid);
				l_pmsg_buf[ch][midx].bcmfd = -1;
			}
		}
	}
	return;
}

void bcm_pmsg_init(void)
{
	int ch, midx;

	for(ch=0; ch<NO_OF_CHANNEL_USED; ch++) {
		for(midx=0; midx<c_MAX_PERIODIC_MSG; midx++) {
			l_pmsg_buf[ch][midx].bcmfd = -1;
		}
	}
	return;
}

#endif /* BCM_SUPPORT */
