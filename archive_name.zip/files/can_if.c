/**
 *	@file can_if.c
 *
 *	Copyright (c) 2023-2024, Capgemini - Intelligent Devices
 */

#include	<unistd.h>
#include	<glib.h>
#include	<net/if.h>
#include	<sys/socket.h>
#include	<sys/ioctl.h>
#include	<linux/can.h>
#include	<linux/can/raw.h>
#include	<linux/can/netlink.h>
#ifdef BCM_SUPPORT
#include	<linux/can/bcm.h>
#endif
#include	"g3d.h"
#include	"can_if.h"
#include	"can_nl_if.h"
#include	"data_logger.h"
#include	"j2534_periodic.h"

static CANContext_t canctx;
CAN_Init_Info_t gstrCANInitInfo[CANn];
uint32_t g_can_bitrate = 0;

#ifdef BCM_SUPPORT
//static gboolean bcm_can_handler(GIOChannel *channel,
//              GIOCondition cond, gpointer data);
//static int bcm_can_open(int ch, int *fd);
#endif

uint32_t valid_can_bitrate(uint32_t br)
{
	int i;

	static const uint32_t valid_br[] = {
		100000, 125000, 250000, 500000, 800000, 1000000
	};

	for (i = 0; i < ARRAY_SIZE(valid_br); i++) {
		if (br == valid_br[i])
			return br;
	}

	return CAN_DEFAULT_BITRATE;
}

ssize_t can_if_read(int ch, void *buf, size_t count)
{
	int canfd;
	ssize_t ret;

	canfd = canctx.can[ch].rfd;
	if (canfd < 0) {
		DBG("ERROR : canfd is %d\n", canfd);
		return -1;
	}

	if (buf == NULL || count <= 0) {
		DBG("Invalid parameters!");
		return -2;
	}

	for (;;) {
		ret = read(canfd, buf, count);

		if (ret > 0)
			return ret;

		if (ret == 0) {
			can_if_reinit();
			return ret;
		}

		DBG("Read error: %s", strerror(errno));

		switch (errno) {
		case EINTR:
			continue;
		case EAGAIN:
			//ERR("CAN device is in NON-BLOCKING mode!");
			/* Fall through */
		case EBADF:
		case EINVAL:
		case EIO:
		default:
			/* NOTE: Do call can_if_reinit on read() failure.
			 * During bitrate change, it is observed that
			 * can_if_data_handler() is getting invoked
			 * by glib. However, read() call blocks and does not
			 * return.
			 *
			 * To avoid this case, the socket (canfd) is made
			 * NON-BLOCKING. Now the read() call returns with -1.
			 * But the bitrate setting is successful and the data
			 * read / write proceeds without error
			 */
			//can_if_reinit();
			return -1;
		}
	}
}

static ssize_t _can_if_write(int canfd, const void *buf, size_t count)
{
	ssize_t ret;
	ssize_t wrote;
	int retry_limit = 1;

	if (canfd < 0)
		return -1;

//	DBG("canfiledis=%d, count=%lu\n", canfd, count);
	wrote = 0;

	for (;;) {
		ret = write(canfd, buf, count);

		if (ret >= 0) {
			wrote += ret;

			if (ret < count) {
				buf += ret;
				count -= ret;
				continue;
			}

			hexdump("CAN-WR", (uint8_t *) buf, count, 1);
			return wrote;
		}

		DBG("Write error: %s\n", strerror(errno));

		switch (errno) {
		case EINTR:
			continue;
		case EAGAIN:
			ERR("CAN device is in NON-BLOCKING mode!");
			/* Fall through */
		case EBADF:
		case EINVAL:
		case EIO:
		default:
			can_if_reinit();
			if (retry_limit--) {
				continue;
			}
			return -1;
		}
	}
}

ssize_t can_if_write(int ch, const void *buf, size_t count)
{
	return _can_if_write(canctx.can[ch].wfd, buf, count);
}

#if 0
ssize_t can_if_fd_write(int ch, const void *buf, size_t count)
{
	int s, i, j, ret;
	struct sockaddr_can addr;
	struct ifreq ifr;
	int socks;
	int enable_socket = 1;

	if ((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
		perror("socket:");
		return 1;
	}
	strcpy(ifr.ifr_name, "can0");
	ioctl(s, SIOCGIFINDEX, &ifr);
	ret = setsockopt(s, SOL_CAN_RAW, CAN_RAW_FD_FRAMES,
			 &enable_socket, sizeof(enable_socket));
	if (ret < 0) {
		perror("setsockopt error:");
		goto err;
	}

	addr.can_family = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;
	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		perror("bind:");
		goto err;
	}
	struct canfd_frame frame = {
		.can_id = 0x7E0,
		.len = sizeof(frame.data),
		.flags = CANFD_BRS | CANFD_ESI
	};
	for (j = 0; j < sizeof(frame.data); j++) {
		frame.data[j] = 0xA0 + j;
	}
	ret = send(s, buf, count, 0);
	printf("Wrote %d bytes on can bus.\n", ret);
	if (ret != count) {
		perror("SEND:");
		printf("failed to send the frame %d\n", i);
	}
	return ret;
 err:
	close(s);
	return -1;
}
#else
ssize_t can_if_fd_write(int ch, const void *buf, size_t count)
{
	return _can_if_write(canctx.can[ch].wfd, buf, count);
}
#endif

static gboolean can_if_data_handler(GIOChannel * channel,
				 GIOCondition cond, gpointer data)
{
	int count;
	CANChannel_t *ch = (CANChannel_t *) data;

	DBG("cond 0x%x\n", cond);
	memset((void *)(ch->canbuf), 0, sizeof(ch->canbuf));
	count = can_if_read(ch->channelno, ch->canbuf, sizeof(ch->canbuf));

	if (count < 0) {
		//ERR("can_if_read() failed\n");
		/* NOTE: Do not return FALSE */
		return TRUE;
	}

	DBG("Received from CAN_BUS : %d Bytes.\tPrinting them------>", count);
	hexdump("CAN_DATA_HANDLER", ch->canbuf, count, 1);

	(void)can_rx_handler(ch->channelno, ch->canbuf, count);

	return TRUE;
}

#if 0
static int can_if_open(int ch, uint32_t bitrate, int *fd, int *wfd)
{
	int canfd, ret = -1;
	char *ifname;
	struct ifreq ifr;
	struct sockaddr_can addr;
	int enable_socket = 1;

#ifdef CAN_RAW_RECV_OWN_MSGS_ENABLE
	int loopback;
#endif

	*fd = *wfd = -1;
	ifname = canctx.can[ch].ifname;
	if (can_if_setbitrate(ifname, bitrate) < 0) {
		ERR("Could not set bitrate for %s!", ifname);
		goto reterr;
	}
//      DBG("can_setbitrate ch=%d, bitrate=%d\n", ch, bitrate);

	canfd = socket(PF_CAN, SOCK_RAW | SOCK_NONBLOCK, CAN_RAW);
	if (canfd < 0) {
		ERR("Could not open %s socket!", ifname);
		goto reterr;
	}

	strncpy(ifr.ifr_name, ifname, sizeof(ifr.ifr_name));
	if (ioctl(canfd, SIOCGIFINDEX, &ifr) < 0) {
		ERR("Could not get %s interface index!", ifname);
		goto reterr;
	}

	ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_FD_FRAMES,
			 &enable_socket, sizeof(enable_socket));
	if (ret < 0) {
		perror("setsockopt error:");
		goto reterr;
	} else if (ret == 0) {
		// DBG("Setsockopt Success");
	}
#ifdef CAN_RAW_RECV_OWN_MSGS_ENABLE
	loopback = 0;
	ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_LOOPBACK,
			 &loopback, sizeof(loopback));
	if (ret < 0) {
		ERR("Could not set to loopback on %s interface!", ifname);
		goto reterr;
	}

	printf("CAN_RAW_LOOPBACK %d\n", loopback);
	ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_RECV_OWN_MSGS,
			 &loopback, sizeof(loopback));
	if (ret < 0) {
		ERR("CAN_RAW_RECV_OWN_MSGS failed on %s interface!", ifname);
		goto reterr;
	}
	printf("CAN_RAW_RECV_OWN_MSGS %d\n", loopback);
#endif
	canctx.can[ch].ifindex = ifr.ifr_ifindex;

	addr.can_family = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;
	if (bind(canfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		ERR("Failed to bind to %s socket!", ifname);
		goto reterr;
	}
	//DBG("CAN_Read_File_Descriptor=%d",canfd);//comment by Satyendra
	*fd = canfd;

	/* CAN write file discriptor */
	//INFO("open wfd [%s]\n", ifname);
	canfd = socket(PF_CAN, SOCK_RAW, CAN_RAW);
	if (canfd < 0) {
		ERR("Could not open %s socket!", ifname);
		goto reterr;
	}

	if (ioctl(canfd, SIOCGIFINDEX, &ifr) < 0) {
		ERR("Could not get %s interface index!", ifname);
		goto reterr;
	}

	ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_FD_FRAMES,
			 &enable_socket, sizeof(enable_socket));
	if (ret < 0) {
		perror("setsockopt error:");
		goto reterr;
	}

	if (bind(canfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		ERR("Failed to bind to %s socket!", ifname);
		goto reterr;
	}
//      DBG("CAN_Write_File_Descriptor=%d",canfd);//comment by Satyendra
	*wfd = canfd;

	return 0;

 reterr:

	/** TODO: Error handling not taking care of the *fd and *wfd if they
	 * were successfully opened.
	 */
	if (*fd != -1)
		close(*fd);
	if (*wfd != -1)
		close(*wfd);
	ERR("ERROR ret=%d\n", ret);
	return ret;
}
#else
static int can_if_open(int ch, uint32_t bitrate, int *fd, int *wfd)
{
	int canfd, ret = -1;
	char *ifname;
	struct ifreq ifr;
	struct sockaddr_can addr;
	int loopback = 0, enable_socket = 1;
       
	ifname = canctx.can[ch].ifname;
	if(bitrate != 500000)
	{
		if (can_if_setbitrate(ifname, bitrate) < 0) {
			ERR("Could not set bitrate for %s!", ifname);
			goto reterr;
		}
	}

	if ((canfd = socket(PF_CAN, SOCK_RAW | SOCK_NONBLOCK, CAN_RAW)) < 0) {
		ERR("Socket");
		ERR("Could not open %s socket!", ifname);
		goto reterr;
	}

	DBG("Initializing chan = %d\n",ch);
	if(ch){
		strcpy(ifr.ifr_name, "can1");
	} else {
		strcpy(ifr.ifr_name, "can0");
	}
	if(ioctl(canfd, SIOCGIFINDEX, &ifr) < 0) {
		ERR("ioctl");
		ERR("Could not get %s interface index!", ifname);
                goto reterr;
	}

	ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_FD_FRAMES,
			 &enable_socket, sizeof(enable_socket));
	if (ret < 0) {
		ERR("Setsockopt");
		goto reterr;
	}
#ifdef CAN_RAW_RECV_OWN_MSGS_ENABLE
	loopback = 1;
#endif
	ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_LOOPBACK,
			 &loopback, sizeof(loopback));
	if (ret < 0) {
		ERR("Could not set to loopback on %s interface!", ifname);
		goto reterr;
	}
	addr.can_family = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;
	if (bind(canfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		ERR("Bind");
		ERR("Failed to bind to %s socket!", ifname);
                goto reterr;
	}
	*fd = canfd;
	

	if ((canfd = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
		ERR("Socket");
                ERR("Could not open %s socket!", ifname);
                goto reterr;
        }

        DBG("Initializing chan = %d\n",ch);
        if(ch){
                strcpy(ifr.ifr_name, "can1");
        } else {
                strcpy(ifr.ifr_name, "can0");
        }
        if(ioctl(canfd, SIOCGIFINDEX, &ifr) < 0) {
                ERR("ioctl");
                ERR("Could not get %s interface index!", ifname);
                goto reterr;
        }

        ret = setsockopt(canfd, SOL_CAN_RAW, CAN_RAW_FD_FRAMES,
                         &enable_socket, sizeof(enable_socket));
        if (ret < 0) {
                ERR("Setsockopt");
                goto reterr;
        }
        addr.can_family = AF_CAN;
        addr.can_ifindex = ifr.ifr_ifindex;
        if (bind(canfd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
                ERR("Bind");
		ERR("Failed to bind to %s socket!", ifname);
                goto reterr;
        }
        *wfd = canfd;
	DBG("CAN_FD Initialised successfully.\n");
	return 0;

 reterr:
	close(canfd);
	ERR("ERROR ret=%d\n", ret);
	return ret;
}
#endif

static int can_if_init_chan(uint32_t ch, uint32_t bitrate)
{
	GIOChannel *gch;
	int rfd, wfd, ret;

	memset(&gstrCANInitInfo[ch], 0, sizeof(CAN_Init_Info_t));
	if (CAN_CH1 == ch) {
		gstrCANInitInfo[ch].u32Baudrate = bitrate;
	}

	if (CAN_CH2 == ch) {
		gstrCANInitInfo[ch].u32Baudrate = bitrate;
	}

	if (ch > CAN_CHANNELS) {
		ERR("Invalid CAN channel %u specified!", ch);
		return -1;
	}

	canctx.can[ch].channelno = ch;
	canctx.can[ch].rfd = -1;
	canctx.can[ch].wfd = -1;
	canctx.can[ch].state = CAN_DISCONNECTED;
	canctx.can[ch].cond = G_IO_PRI | G_IO_IN;
	canctx.can[ch].ifname = CfgInfo[CFG_CAN0 + ch].value;
	canctx.can[ch].bitrate = bitrate;

	ret = can_if_open(ch, canctx.can[ch].bitrate, &rfd, &wfd);
	if (ret < 0) {
		/* On error goto next CAN channel */
		ERR("can_if_open %d, error\n", ch);
		return -1;
	}

	canctx.can[ch].rfd = rfd;
	canctx.can[ch].wfd = wfd;

	//INFO("Opened CAN Channel %s", canctx.can[ch].ifname);

	gch = g_io_channel_unix_new(rfd);
	if (!gch) {
		ERR("Failed to create g_io_channel for CAN%d!", ch);
		can_if_deinit();
		return -1;
	}

	g_io_channel_set_close_on_unref(gch, TRUE);
	g_io_channel_set_encoding(gch, NULL, NULL);
	g_io_channel_set_buffered(gch, FALSE);

	canctx.can[ch].watch_source = g_io_add_watch(gch,
						     canctx.can[ch].cond,
						     can_if_data_handler,
						     &canctx.can[ch]);

	g_io_channel_unref(gch);

	canctx.can[ch].state = CAN_CONNECTED;
	canctx.can[ch].gch = gch;

	return 0;
}

uint32_t LowLevel_CAN_get_loopback_status(uint8_t p_channel_no_U8)
{

	uint8_t fl_ret_status_U8 = ERR_INVALID_CHANNEL_ID;

	if (1 == p_channel_no_U8) {
		fl_ret_status_U8 = gstrCANInitInfo[0].u8LoopBackMode;
	} else if (2 == p_channel_no_U8) {
		fl_ret_status_U8 = gstrCANInitInfo[1].u8LoopBackMode;
	} else {
		/* Do Nothing */
	}

	return (fl_ret_status_U8);
}

uint32_t LowLevel_CAN_get_current_sampling_mode(uint32_t p_channel_no_U8)
{

	uint8_t fl_current_SAM_U8 = 0;

	if ((p_channel_no_U8 == 1) && (0 != gstrCANInitInfo[0].u32Baudrate)) {
		fl_current_SAM_U8 = gstrCANInitInfo[0].u8SamplingMode;
	} else if ((p_channel_no_U8 == 2)
		   && (0 != gstrCANInitInfo[1].u32Baudrate)) {
		fl_current_SAM_U8 = gstrCANInitInfo[1].u8SamplingMode;
	} else {
		fl_current_SAM_U8 = ERR_INVALID_CHANNEL_ID;
	}

	return (fl_current_SAM_U8);
}

uint32_t CAN_Mid_get_current_baudrate(uint8_t p_channel_no_U8)
{
	uint32_t f1_current_baudtrate_U32;

	if ((p_channel_no_U8 == 1) && (0 != gstrCANInitInfo[0].u32Baudrate)) {
		f1_current_baudtrate_U32 = gstrCANInitInfo[0].u32Baudrate;
	} else if ((p_channel_no_U8 == 2)
		   && (0 != gstrCANInitInfo[1].u32Baudrate)) {
		f1_current_baudtrate_U32 = gstrCANInitInfo[1].u32Baudrate;
	} else {
		f1_current_baudtrate_U32 = 0xFFFFFFFF;
	}

	return (f1_current_baudtrate_U32);
}

uint8_t LowLevel_CAN_get_current_SJW(uint8_t p_channel_no_U8)
{

	uint8_t fl_current_SJW_U8 = 0;

	if ((p_channel_no_U8 == 1) && (0 != gstrCANInitInfo[0].u32Baudrate)) {
		fl_current_SJW_U8 = gstrCANInitInfo[0].u8SJW;
	} else if ((p_channel_no_U8 == 2)
		   && (0 != gstrCANInitInfo[1].u32Baudrate)) {
		fl_current_SJW_U8 = gstrCANInitInfo[1].u8SJW;
	} else {
		fl_current_SJW_U8 = ERR_INVALID_CHANNEL_ID;
	}

	return (fl_current_SJW_U8);
}

uint8_t LowLevel_CAN_enable_loopback(uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;

	if (1 == p_channel_no_U8) {
		gstrCANInitInfo[0].u8LoopBackMode = TRUE;
	} else if (2 == p_channel_no_U8) {
		gstrCANInitInfo[1].u8LoopBackMode = TRUE;
	} else {
		fl_error_status_U8 = ERR_INVALID_CHANNEL_ID;
	}

	return (fl_error_status_U8);
}

uint8_t LowLevel_CAN_disable_loopback(uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;

	if (1 == p_channel_no_U8) {
		gstrCANInitInfo[0].u8LoopBackMode = FALSE;
	} else if (2 == p_channel_no_U8) {
		gstrCANInitInfo[1].u8LoopBackMode = FALSE;
	} else {
		fl_error_status_U8 = ERR_INVALID_CHANNEL_ID;
	}

	return (fl_error_status_U8);
}

uint32_t CAN_Mid_set_baudrate(uint32_t p_baud_rate_U32, uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;

	if (1 == p_channel_no_U8) {
		gstrCANInitInfo[0].u32Baudrate = p_baud_rate_U32;
	} else if (2 == p_channel_no_U8) {
		gstrCANInitInfo[1].u32Baudrate = p_baud_rate_U32;
	} else {
		fl_error_status_U8 = ERR_INVALID_CHANNEL_ID;
	}

	return (fl_error_status_U8);
}

uint32_t CAN_Mid_set_datarate(uint32_t p_data_rate_U32, uint8_t p_channel_no_U8)
{
	uint8_t fl_error_status_U8 = STATUS_NOERROR;
	char chan[5];

	if (p_channel_no_U8 == 1) {
		//strcpy();
	} else if (p_channel_no_U8 == 2) {
		//strcpy();
	} else {
	}

	if (can_if_setdbitrate(chan, p_data_rate_U32) < 0) {
		fl_error_status_U8 = ERR_FAILED;
	}

	return (fl_error_status_U8);
}

int can_if_init(uint32_t can_bitrate)
{
	uint32_t i;

	g_can_bitrate = valid_can_bitrate(can_bitrate);

	//DBG("bitrate from user %d, valid bitrate set %d",
	//                      can_bitrate, g_can_bitrate);

	for (i = 0; i < CAN_CHANNELS; i++) {
		if (can_if_init_chan(i, g_can_bitrate) == 0) {
			// DBG("Garuda3 CAN%d connection established!", i);
		}
	}

#ifdef BCM_SUPPORT
	bcm_pmsg_init();
#endif

	mode2_create_process();

	return 0;
}

static void can_if_deinit_chan(uint32_t chan)
{
	GIOChannel *gch;

	canctx.can[chan].state = CAN_DISCONNECTED;
	gch = canctx.can[chan].gch;
	g_io_channel_shutdown(gch, TRUE, NULL);

	if (canctx.can[chan].rfd >= 0) {
		close(canctx.can[chan].rfd);
		canctx.can[chan].rfd = -1;
	}

	if (canctx.can[chan].wfd >= 0) {
		close(canctx.can[chan].wfd);
		canctx.can[chan].wfd = -1;
	}
}

void can_if_deinit(void)
{
	uint32_t i;

#ifdef BCM_SUPPORT
	bcm_pmsg_deinit();
#endif
	for (i = 0; i < CAN_CHANNELS; i++) {
		can_if_deinit_chan(i);
		DBG("Garuda3 can%d disconnted!", i);
	}
}

int can_if_reinit_chan(uint32_t chan, uint32_t bitrate)
{
	can_if_deinit_chan(chan);
	return can_if_init_chan(chan, bitrate);
}

/*
 * Re-init the CAN channels with DEFAULT bit rate or
 * the bit-rate provided during the start of the application.
 */
int can_if_reinit(void)
{
	uint32_t i, ret;

	for (i = 0; i < CAN_CHANNELS; i++) {
		ret = can_if_reinit_chan(i, g_can_bitrate);
		if (ret < 0) {
			DBG("Failed to re-init chan %d\n", i);
			return ret;
		}
	}
	return 0;
}

/*static gboolean bcm_can_handler(GIOChannel *channel,
		GIOCondition cond, gpointer data)
{
	return 0;
}*/

#ifdef BCM_SUPPORT
char *get_interface_name(int ch)
{
	if ((ch != 0) && (ch != 1))
		return NULL;

	return canctx.can[ch].ifname;
}

#ifdef DEBUG
static void PRINT_BCM_TX_BUF(void *buf, int count)
{
	int i, j;
	struct bcm_msg_head *bcm;

	(void)count;

	bcm = (struct bcm_msg_head *)buf;
	printf("opcode  0x%x\n", bcm->opcode);
	printf("flags   0x%x\n", bcm->flags);
	printf("count   0x%x\n", bcm->count);
	printf("can_id  0x%x\n", bcm->can_id);
	printf("nframes 0x%x\n", bcm->nframes);
	printf("ival1 (%ld sec, %ld ms)\n",
	       bcm->ival1.tv_sec, bcm->ival1.tv_usec);
	printf("ival2 (%ld sec, %ld ms)\n",
	       bcm->ival2.tv_sec, bcm->ival2.tv_usec);

	for (i = 0; i < bcm->nframes; i++) {
		printf("\t-------- frame[%d] ---------\n", i);
		printf("\tcan_id  0x%x\n", bcm->frames[i].can_id);
		printf("\tcan_dlc 0x%x\n", bcm->frames[i].can_dlc);
		printf("\tDATA   :");
		for (j = 0; j < bcm->frames[i].can_dlc; j++) {
			printf("0x%x ", bcm->frames[i].data[j]);
		}
		printf("\n\n");
	}
}
#endif

ssize_t can_if_bcm_write(int bcmfd, const void *buf, size_t count)
{
#ifdef DEBUG
	PRINT_BCM_TX_BUF((void *)buf, count);
#endif
	return _can_if_write(bcmfd, buf, count);
}

#endif	/* BCM_SUPPORT */

