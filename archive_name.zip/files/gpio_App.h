/**
 * @file gpio.h
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _GPIO_APP_H_
#define	_GPIO_APP_H_

#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <pthread.h>
#include <linux/gpio.h>

#include <sys/ioctl.h>


#define	GPIO_DIRECTION_IN	1
#define	GPIO_DIRECTION_OUT	2

#define GPIO_EDGE_NONE		0
#define	GPIO_EDGE_RISING	1
#define	GPIO_EDGE_FALLING	2
#define	GPIO_EDGE_BOTH		3

#define	GPIO_PORT(n)		(n * 32)
#define	GPIO_PA			GPIO_PORT(0)
#define	GPIO_PB			GPIO_PORT(1)
#define	GPIO_PC			GPIO_PORT(2)
#define	GPIO_PD			GPIO_PORT(3)

#define	PA(n)			(GPIO_PA + n)
#define	PB(n)			(GPIO_PB + n)
#define	PC(n)			(GPIO_PC + n)
#define	PD(n)			(GPIO_PD + n)

#define	GPIO_USB_LED		PA(11)	/* output */
#define	GPIO_LINK_LED		PA(12)	/* output */
#define	GPIO_ETH_LED		PC(4)	/* output */
#define	GPIO_ERROR_LED		PC(5)	/* output */
#define	GPIO_MODEM_LED		PD(0)	/* output */
#define	GPIO_DATA_LED		PD(1)	/* output */
#define	GPIO_WLANBT_LED		PD(6)	/* output */

#define	GPIO_KLINE_GPIO1	PB(0)	/* output */
#define	GPIO_KLINE_GPIO2	PB(1)	/* output */
#define	GPIO_KLINE_GPIO3	PB(2)	/* output */
#define	GPIO_KLINE_GPIO4	PB(11)	/* output */
#define	GPIO_KLINE_GPIO5	PB(12)	/* output */

#define	GPIO_LAN_ENABLE		PB(13)	/* output */

#define	GPIO_ETH_INT		PB(24)	/* input */
#define	GPIO_LAN_WAKE_IN	PB(25)	/* input */

#define	GPIO_WLAN_RESET		PC(17)	/* output */

struct GPIOContext {
	int gpio;
	unsigned int cond;
	int direction;
	int edge;
	int valfd;
	guint watch_source;
};


struct T_GPIO_context
{
	int fd;
	int gpio_number;
	int direction;
	
};

int openreadclose(const char *fn, char *s, int len);
int openwriteclose(const char *fn, const char *s, int len);
int gpio_init(void);
void gpio_deinit(void);
int gpio_get(int gpio);
int gpio_set(int gpio, int val);
int gpio_setup(int gpio, int dir, int edge, int val);
int gpio_export(int gpio);

void T_gpio_PIN_config(struct T_GPIO_context *gpio_context);
void T_gpio_PIN_set(struct T_GPIO_context *gpio_context, int value);
void T_gpio_PIN_clear_config(struct T_GPIO_context *gpio_context);

#endif /* _GPIO_H_ */

