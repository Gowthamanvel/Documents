/**
 * @file gpio.c
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include "g3d.h"
#include "gpio_App.h"
#include <linux/gpio.h>



static struct GPIOContext gpio_ethint, gpio_lanwake;

static const char CSZ_gpio_export_file[] = "/sys/class/gpio/export";
static const char CSZ_gpio_unexport_file[] = "/sys/class/gpio/unexport";
static const char CSZ_gpio_sys_path[] = "/sys/class/gpio";


static const char * const CSZ_Edge[] = {
	"none",
	"rising",
	"falling",
	"both"
};

int openreadclose(const char *fn, char *s, int len)
{
	int fd;
	int ret;

	fd = open(fn, O_RDONLY|O_NONBLOCK);
	if (fd < 0) {
		ERR("Cannot open %s", fn);
		return -1;
	}

	ret = read(fd, s, len);
	if (ret < 0) {
		ERR("Read failed (%s)! (req=%d:ret=%d)",
				strerror(errno), len, ret);
		ret = -1;
	} else
		ret = 0;

	close(fd);

	return ret;
}

int openwriteclose(const char *fn, const char *s, int len)
{
	int fd;
	int ret;

	fd = open(fn, O_WRONLY);
	if (fd < 0) {
		//ERR("Cannot open %s", fn);
		return -1;
	}

	if (len < 0)
		len = strlen(s);

	ret = write(fd, s, len);
	if (ret != len) {
		ERR("Write failed (%s)! (req=%d:ret=%d)",
				strerror(errno), len, ret);
		ret = -1;
	} else
		ret = 0;

	close(fd);

	return ret;
}

int gpio_export(int gpio)
{
	char buf[32];

	SNP(buf, "%s/P%c%d", CSZ_gpio_sys_path,
			((gpio / 32) + 'A'), (gpio % 32));
	if (!access(buf, F_OK)) {
		DBG("%s already exists!", buf);
		return 0;
	}

	SNP(buf, "%d", gpio);
	if (openwriteclose(CSZ_gpio_export_file, buf, -1) < 0)
		return -1;

	return 0;
}

static int gpio_unexport(int gpio)
{
	char buf[8];

	SNP(buf, "%d", gpio);
	if (openwriteclose(CSZ_gpio_unexport_file, buf, -1) < 0)
		return -1;

	return 0;
}

int gpio_get(int gpio)
{
	char	fn[64];
	char	value[8];

	memset(value, 0, sizeof(value));

	SNP(fn, "%s/gpio%d/value", CSZ_gpio_sys_path, gpio);
	if (openreadclose(fn, value, sizeof(value)) < 0) {
		ERR("Could not read gpio(%d) value!", gpio);
		return -1;
	}

	value[1] = '\0';

	return atoi(value);
}

int gpio_set(int gpio, int val)
{
	char	fn[64];

	SNP(fn, "%s/gpio%d/value", CSZ_gpio_sys_path, gpio);
	if (openwriteclose(fn, (val ? CSZ_1 : CSZ_0), -1) < 0) {
		ERR("Could not write gpio value!");
		return -1;
	}

	return 0;
}

int gpio_setup(int gpio, int dir, int edge, int val)
{
	char	fn[64];
	char	buf[8];

	if (gpio_export(gpio) < 0)
		return -1;

	/* set the direction */
	SNP(fn, "%s/P%c%d/direction", CSZ_gpio_sys_path,
			((gpio / 32) + 'A'), (gpio % 32));
	SNP(buf, "%s",
		(dir == GPIO_DIRECTION_IN) ? "in" : val ? "high" : "low");
	if (openwriteclose(fn, buf, -1) < 0) {
		ERR("Could not write gpio direction!");
		return -1;
	}

	/* set the edge */
	SNP(fn, "%s/P%c%d/edge", CSZ_gpio_sys_path,
			((gpio / 32) + 'A'), (gpio % 32));
	SNP(buf, "%s", (edge < 0 || edge > GPIO_EDGE_BOTH) ?
			CSZ_Edge[0] : CSZ_Edge[edge]);
	if (openwriteclose(fn, buf, -1) < 0) {
		ERR("Could not write gpio edge!");
		return -1;
	}

	return 0;
}

static int gpio_setup_monitor(struct GPIOContext *gpioctx, GIOFunc gpiocb)
{
	int fd;
	char fn[64];
	GIOChannel *channel;

	if (gpio_setup(gpioctx->gpio, gpioctx->direction, gpioctx->edge, 0) < 0)
		return -1;

	SNP(fn, "%s/gpio%d/value", CSZ_gpio_sys_path, gpioctx->gpio);
	fd = open(fn, O_RDONLY|O_NONBLOCK);
	if (fd < 0) {
		ERR("Cannot open %s file for reading!", fn);
		return -1;
	}

	channel = g_io_channel_unix_new(fd);
	if (!channel) {
		ERR("Failed to create netlink channel!");
		close(fd);
		return -1;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);

	gpioctx->watch_source = g_io_add_watch(channel, gpioctx->cond,
			gpiocb, gpioctx);

	g_io_channel_unref(channel);

	gpioctx->valfd = fd;

	return 0;
}

static int gpio_release_monitor(struct GPIOContext *gpioctx)
{
	if (gpioctx->valfd >= 0) {
		close(gpioctx->valfd);
		gpioctx->valfd = -1;
	}

	g_source_remove(gpioctx->watch_source);

	gpio_unexport(gpioctx->gpio);

	return 0;
}

static int gpio_process_value(struct GPIOContext *gpioctx, int value)
{
	switch (gpioctx->gpio) {
	case GPIO_ETH_INT:
		DBG("Got ETH_INT Event");
		break;
	case GPIO_LAN_WAKE_IN:
		DBG("Got LAN_WAKE Event!");
		break;

	default:
		WARN("Unknown GPIO (%d) event received!", gpioctx->gpio);
		break;
	}

	return 0;
}

static gboolean gpio_event_handler(GIOChannel *channel,
		GIOCondition cond, gpointer data)
{
	register int ret = 0;
	int fd;
	struct GPIOContext *gpioctx = (struct GPIOContext *)data;
	char value[8];

	DBG("Got a GPIO Event: 0x%08x", cond);

	/*
	 * G_IO_IN   = 0x01
	 * G_IO_PRI  = 0x02
	 * G_IO_OUT  = 0x04
	 * G_IO_ERR  = 0x08
	 * G_IO_HUP  = 0x10
	 * G_IO_NVAL = 0x20
	 */
	if (cond & (G_IO_NVAL | G_IO_ERR | G_IO_HUP)) {
		ERR("GPIO Error Condition: 0x%08x", cond);
		return FALSE;
	}

	fd = g_io_channel_unix_get_fd(channel);
	if (fd < 0) {
		ERR("g_io_channel_unix_get_fd failed!");
		return FALSE;
	}

	for (;;) {

		if (lseek(fd, 0L, SEEK_SET) < 0) {
			ERR("lseek failed! Reason '%s'", strerror(errno));
			return FALSE;
		}

		memset(value, 0, sizeof(value));

		ret = read(fd, value, sizeof(value));
		if (ret < 0) {
			ERR("Read error '%s'", strerror(errno));

			if (errno == EINTR) {
				DBG("Read interrupted!");
				continue;
			}
		}

		break;
	}

	if (ret > 0) {
		value[1] = '\0'; /* remove trailing '\n' */

		DBG("GPIO%d value='%s'\n", gpioctx->gpio, value);

		gpio_process_value(gpioctx, atoi(value));
	}

	return TRUE;
}

int gpio_init(void)
{
	/* Monitor the ETH_INT for input */
	gpio_ethint.gpio = GPIO_ETH_INT;
	gpio_ethint.cond = G_IO_PRI;
	gpio_ethint.direction = GPIO_DIRECTION_IN;
	gpio_ethint.edge = GPIO_EDGE_BOTH;
	gpio_ethint.valfd = -1;

	if (gpio_setup_monitor(&gpio_ethint, gpio_event_handler) < 0)
		return -1;

	/* Monitor the LAN_WAKE IN for input */
	gpio_lanwake.gpio = GPIO_LAN_WAKE_IN;
	gpio_lanwake.cond = G_IO_PRI;
	gpio_lanwake.direction = GPIO_DIRECTION_IN;
	gpio_lanwake.edge = GPIO_EDGE_BOTH;
	gpio_lanwake.valfd = -1;

	if (gpio_setup_monitor(&gpio_lanwake, gpio_event_handler) < 0)
		return -1;

	/* Configure outputs */
#ifdef LEDS_ON_GPIO
	gpio_setup(GPIO_USB_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
	gpio_setup(GPIO_LINK_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
	gpio_setup(GPIO_ETH_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
	gpio_setup(GPIO_ERROR_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
	gpio_setup(GPIO_MODEM_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
	gpio_setup(GPIO_DATA_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
	gpio_setup(GPIO_WLANBT_LED, GPIO_DIRECTION_OUT, GPIO_EDGE_NONE, 1);
#endif

	return 0;
}

void gpio_deinit(void)
{
#ifdef LEDS_ON_GPIO
	gpio_unexport(GPIO_USB_LED);
	gpio_unexport(GPIO_LINK_LED);
	gpio_unexport(GPIO_ETH_LED);
	gpio_unexport(GPIO_ERROR_LED);
	gpio_unexport(GPIO_MODEM_LED);
	gpio_unexport(GPIO_DATA_LED);
	gpio_unexport(GPIO_WLANBT_LED);
#endif

	gpio_release_monitor(&gpio_lanwake);

	gpio_release_monitor(&gpio_ethint);
}


void T_gpio_PIN_config(struct T_GPIO_context *gpio_context)
{
	int fd;
       	int ret;

        struct gpiohandle_request req;
	struct gpiohandle_data data;
	memset(&req, 0 ,sizeof(req));
	
	fd = open("/dev/gpiochip0", O_RDWR);

	if(fd < 0){
		 perror("File open failed");
        }
		
//	ioctl(fd, GPIO_GET_LINEHANDLE__IOCTL , &data);
		
        req.lineoffsets[0] = gpio_context->gpio_number;  //82
        req.lines = 1;
	if(gpio_context->direction == GPIO_DIRECTION_OUT)
        	req.flags = GPIOHANDLE_REQUEST_OUTPUT;
	else
		req.flags = GPIOHANDLE_REQUEST_INPUT;
        strcpy(req.consumer_label, "RST_mBUS1");

//	req.default_values[0] = 1;//data.values[0];
	
	int lhfd = ioctl(fd, GPIO_GET_LINEHANDLE_IOCTL , &req);
        if (lhfd < 0) {
		printf("ERROR get line handle lhdf=%d\n", lhfd);
               	return -1;
        }

	gpio_context->fd = req.fd;
	close(fd);
}


 void T_gpio_PIN_set(struct T_GPIO_context *gpio_context, int value)
{
	static struct gpiohandle_data data;
	int ret;
        data.values[0] = value;
        ret = ioctl(gpio_context->fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &data);
        if (ret < 0) {
		printf("ERROR set line value ret=%d\n", ret);
                return -1;
        }

	
}


void T_gpio_PIN_clear_config(struct T_GPIO_context *gpio_context)
{
	close(gpio_context->fd);
}

