/**
 * @file network.h
 *
 * Copyright (c) 2020-2024, Capgemini - Intelligent Devices
 */

#ifndef _G3D_NET_H_
#define	_G3D_NET_H_

#include	<linux/netlink.h>
#include	<linux/rtnetlink.h>

#include	<glib.h>

#define	MAX_G3D_INTERFACES	32

#define	S_NET_EVENT_BUF		(8 * 1024)

#ifndef IFF_LOWER_UP
#define	IFF_LOWER_UP		(1 << 16)
#endif

#ifndef IFF_DORMANT
#define	IFF_DORMANT		(1 << 17)
#endif

#ifndef IFF_ECHO
#define	IFF_ECHO		(1 << 18)
#endif

#define	NET_LINK_UP		(IFF_LOWER_UP | IFF_RUNNING)


struct net_event_cbs {
	/* Network link status changed */
	void (*link_status)(int if_index, gboolean status);
	/* Netword address changed */
	void (*addr_status)(int if_index, gboolean status);
};

typedef struct net_event_cbs	net_event_cbs_t;

struct net_ctrl_context {
	int nlsock;		/* netlink socket */
	int ifsock;		/* socket to get network interface status */
	struct sockaddr_nl nladdr;
	guint watch_source;
	net_event_cbs_t necbs;
};

static inline int getifinfomsgindex(struct ifinfomsg *msg)
{
	return msg->ifi_index;
}

static inline int getifaddrmsgindex(struct ifaddrmsg *msg)
{
	return msg->ifa_index;
}

int net_init(net_event_cbs_t *necbs);
void net_deinit(void);

int net_get_ip_addr(char *iface, struct in_addr *ip4_addr);
int net_set_ip_addr(char *iface, const char *ipaddr, const char *netmask);
int net_set_gw_addr(const char *dstaddr, const char *gwaddr);
int net_get_bcast_addr(char *iface, struct in_addr *ip4_bcastaddr);
int net_get_mac_addr(char *iface, unsigned char *mac);
int net_get_link_status(char *ifname);
int net_get_addr_status(char *ifname);
int net_nametoindex(char *ifname);

int set_if_up(char *ifname, short flags);
int set_if_down(char *ifname, short flags);
int set_if_flags(char *ifname, short flags);
int validate_ip(char* ipaddr);
int validate_ip_range(char* ipaddr);
#endif /* _G3D_NET_H_ */

