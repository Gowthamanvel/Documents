/**
 *  @file doip_if.c
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 *
 *  This file provides the interface APIs that are invoked by the HFCP / other
 *  applications using DoIP client
 */

#include "doip_if.h"
#include "g3d.h"
#include "hfcp.h"
#include "net.h"
char server_ip_addr[16];
int doip_cli_cmd_start_session(doip_cli_cmd_start_session_t *psession)
{
	(void) doip_cli_set_logical_address(psession->logical_addr);

	return STATUS_NOERROR;
}

/*
 * This function receives the server information like VIN, logical addr, EID,
 * GID IP address and returns a 'handle' which is used to identify the server.
 *
 * Everytime this function is called a 'server node' is created and added to
 * the connection-list
 */
int doip_cli_add_server(doip_cli_cmd_add_doip_server_t *sinfo)
{
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head();
	doip_conn_table_t *connlist;
	int ret;

	DBG("In %s", __func__);

	connlist = (doip_conn_table_t *) malloc(sizeof(doip_conn_table_t));
	if (connlist == NULL) {
		DBG("malloc failed - add_server");
		return ERR_BUFFER_FULL;
	}
	memcpy(&connlist->sinfo, &sinfo->sinfo, sizeof(sinfo->sinfo));
	strncpy(connlist->ipaddr, sinfo->ipaddr, IPV4_STR_ADDR_LEN);
	connlist->ipaddr[IPV4_STR_ADDR_LEN-1] = '\0';
	connlist->nodelist = NULL;

	DBG("After connlist...");
	ret = validate_ip(sinfo->ipaddr);
	if(ret != 1){
		ERR("Validate IP failed");
		*head_connlist = NULL;
                return ERR_FAILED;
	}

	DBG("Aftr validation ip address...");
	connlist->next = NULL;
	if (*head_connlist == NULL) {
		*head_connlist = connlist;
	} else {
		doip_conn_table_t *tmp = *head_connlist;

		while (tmp->next != NULL){
			tmp = tmp->next;
		}
		tmp->next = connlist;
	}
	DBG("After connlist...");
	/*
	 * Initiate TCP connection with the DoIP server
	 * Change the connection status
	 */
	ret = doip_cli_start_tcp_connection(connlist);
	if (ret < 0) {
		DBG("Failed to connect to %s", sinfo->ipaddr);
		/* TODO: Retry the connection */
		return ERR_FAILED;
	}
	else
	{
		led_set(LED_LINK_LED, LED_ON);
	}
	/* TCP connection is established */
	connlist->conn_state = DOIP_CONN_STATE_ACTIVE;
	//printf("debug ==> func =%s line =%d, sock =%d\n", __func__, __LINE__, connlist->tcpsock);
	ret = doip_cli_send_routing_act_req(connlist, doip_cli_get_logical_address());
	//printf("debug ==> func =%s line =%d, sock =%d\n", __func__, __LINE__, connlist->tcpsock);

	if (ret < 0) {
		DBG("Failed to send %s", sinfo->ipaddr);
		/* TODO: Retry the connection */
		return ERR_FAILED;
	}

	return STATUS_NOERROR;
}

doip_conn_table_t *doip_cli_ipaddr_to_conn_table(char *ip)
{
	struct in_addr sin_addr;
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head(), *conn;
	char *ipaddr;

	sin_addr.s_addr = inet_addr(ip);

	conn = *head_connlist;
	/* Identify the DoIP server */

	if (conn == NULL) {
		DBG("No servers found with IP %s\n", ip);
		return NULL;
	}

	while (conn) {
		ipaddr = conn->ipaddr;
		if (sin_addr.s_addr == inet_addr(ipaddr)) {
			DBG("Found the server with %s", ipaddr);
			break;
		}
		conn = conn->next;
	}

	if (conn == NULL) {
		DBG("No servers found with IP %s\n", ip);
		return NULL;
	}
	return conn;
}

int doip_cli_del_server(doip_cli_cmd_del_doip_server_t *sdel)
{
	doip_conn_table_t *conn, *tmp;
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head();
	int ret;
	memcpy((void*)server_ip_addr,sdel->ipaddr,16);
	conn = doip_cli_ipaddr_to_conn_table(sdel->ipaddr);
	if (conn == NULL) {
		ERR("No server with %p is added", sdel->ipaddr);
		return ERR_FAILED;
	}
	ret = doip_cli_stop_tcp_connection(conn);
	DBG("Returned from doip_cli_stop_tcp_connection with ret=%d!", ret);
	if (ret < 0) {
		ERR("Failed to stop TCP connection for %s\n", conn->ipaddr);
		/* fall-through */
	} else {
		led_set(LED_LINK_LED, LED_OFF);
		DBG("After led_set...");
	}

	/* Free the node list. connlist */
	doip_cli_remove_all_nodes(conn);

	/* Remove the 'connection table' from doip_clist */
	tmp = *head_connlist;
	if (tmp == conn) {
//		printf("%s: ### List is NULL ####\n", __func__);
		*head_connlist= NULL;
	} else {
		while(tmp->next != conn) {
			tmp = tmp->next;
		}
		tmp->next = conn->next;
	}

	free(conn);

	DBG("At the end of doip_cli_del_server...");

	return STATUS_NOERROR;
}

/*
 * For a given IP address, add the list of DoIP node
 *
 */
int doip_cli_add_node(doip_cli_cmd_add_node_t *en)
{
	char *ip = en->ipaddr;
	struct in_addr sin_addr;
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head(), *conn;
	uint16_t cnt;
	int ret;

	sin_addr.s_addr = inet_addr(ip);

	conn = *head_connlist;
	/* Identify the DoIP server */
	if (conn == NULL) {
		DBG("No servers found with IP %s\n", en->ipaddr);
		return ERR_FAILED;
	}
	while (conn) {
		ip = conn->ipaddr;
		if (sin_addr.s_addr == inet_addr(ip)) {
			DBG("Found the server with %s", ip);
			break;
		}
		conn = conn->next;
	}
	if (conn == NULL) {
		DBG("No servers found with IP %s\n", en->ipaddr);
		return ERR_FAILED;
	}
	/* Add the node to the server */
	for (cnt = 0; cnt < en->node_cnt; cnt++) {
		ret = doip_cli_add_node_tolist(conn, en->laddr[cnt]);
		if (ret < 0) {
			DBG("Cannot add laddr %d to node %s", en->laddr[cnt], conn->ipaddr);
			break;
		}
	}
	return STATUS_NOERROR;
}

int doip_cli_del_node(doip_cli_cmd_del_node_t *en)
{
	char *ip = en->ipaddr;
	struct in_addr sin_addr;
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head(), *conn;
	uint16_t cnt;
	int ret;

	sin_addr.s_addr = inet_addr(ip);

	conn = *head_connlist;
	/* Identify the DoIP server */
	if (conn == NULL) {
		DBG("No servers found with IP %s\n", en->ipaddr);
		return ERR_FAILED;
	}
	while (conn) {
		ip = conn->ipaddr;
		if (sin_addr.s_addr == inet_addr(ip)) {
			DBG("Found the server with %s", ip);
			break;
		}
		conn = conn->next;
	}
	if (conn == NULL) {
		DBG("No servers found with IP %s", en->ipaddr);
		return ERR_FAILED;
	}
	/* Delete the nodes from the list */
	for (cnt = 0; cnt < en->node_cnt; cnt++) {
		ret = doip_cli_remove_node_fromlist(conn, en->laddr[cnt]);
		if (ret < 0) {
			DBG("Cannot remove laddr %d to node %s", en->laddr[cnt], conn->ipaddr);
			break;
		}
	}
	return STATUS_NOERROR;
}

/*
 * Transmit Diagnostic message to DoIP server
 */
int doip_cli_cmd_send_diag_msg(doip_cli_cmd_diag_msg_t *dmsg)
{
	doip_conn_table_t *conn;
	int ret;
	char ipaddr[IPV4_STR_ADDR_LEN];

	memcpy(ipaddr, dmsg->ipaddr, sizeof(ipaddr));
	ipaddr[IPV4_STR_ADDR_LEN-1] = 0;

	conn = doip_cli_ipaddr_to_conn_table(ipaddr);
	if (conn == NULL) {
		DBG("No server with %s is added", ipaddr);
		return ERR_FAILED;
	}

	ret = doip_cli_send_diag_msg(conn, dmsg->dst_laddr, dmsg->seqNum,
					dmsg->lastpkt, dmsg->msg_len, dmsg->diag_data);
	if (ret < 0) {
		DBG("DiagMsg send failed");
		return ERR_FAILED;
	}
	return STATUS_NOERROR;
}

int doip_ioctl_handling(doip_ioctl_handle_t *en)
{
	return STATUS_NOERROR;
}

int doip_client_details(doip_client_details_t *dclient)
{ 
	int ret;
        struct doip_conn_table **head_connlist = doip_get_connecton_list_head();
        char ipaddr[IPV4_STR_ADDR_LEN];
        char subnetaddr[IPV4_STR_ADDR_LEN];
        char Gwaddr[IPV4_STR_ADDR_LEN];
        uint16_t logicaladdr;

	memcpy(ipaddr, dclient->ipaddr, sizeof(ipaddr));
	ipaddr[IPV4_STR_ADDR_LEN-1] = 0;
	memcpy(subnetaddr, dclient->subnetaddr, sizeof(subnetaddr));
	subnetaddr[IPV4_STR_ADDR_LEN-1] =0;
	memcpy(Gwaddr, dclient->Gwaddr, sizeof(Gwaddr));
	Gwaddr[IPV4_STR_ADDR_LEN-1] = 0;
	logicaladdr = dclient->logical_addr;

	ret = validate_ip(dclient->ipaddr);
	if(ret != 1){
		ERR("Validate IP failed");
printf("debug line=%d func=%s ipaddr=%s subnetadddr=%s Gwaddr=%s logicaladdr=%x\n",
			__LINE__, __func__, dclient->ipaddr, subnetaddr,dclient->Gwaddr,logicaladdr); 
		*head_connlist = NULL;
	       return ERR_FAILED;
	}

	ret = validate_ip(dclient->Gwaddr);
	if(ret != 1){
		ERR("Validate IP failed");
	printf("debug line=%d func=%s ipaddr=%s subnetadddr=%s Gwaddr=%s logicaladdr=%x\n",
			__LINE__, __func__, dclient->ipaddr, subnetaddr, dclient->Gwaddr,logicaladdr); 
		*head_connlist = NULL;
	       return ERR_FAILED;
	}

//	printf("debug line=%d func=%s ipaddr=%s subnetadddr=%s Gwaddr=%s logicaladdr=%x\n",
//			__LINE__, __func__, ipaddr, subnetaddr, Gwaddr,	logicaladdr); 
   
	if (ipaddr ==NULL || subnetaddr == NULL || Gwaddr == NULL) {
		ERR("NULL pointer detected!");
		return ERR_FAILED;
	}
/*
#define	IFACE_DOWN	0
#define	IFACE_UP	1

	set_if_state("eth0", IFACE_DOWN);
	set_if_state("eth0", IFACE_UP);
*/
	ret = net_set_ip_addr("eth0", ipaddr, subnetaddr);
	if (ret < 0) {
		ERR("Set ip address failed");
		return ERR_FAILED;
	}


	ret = net_set_gw_addr(ipaddr, Gwaddr); 
	if (ret < 0) {
		ERR("Set Gateway address failed");
		return ERR_FAILED;
	}

	return STATUS_NOERROR;
}
void doip_cli_delete_server()
{
	doip_conn_table_t *conn, *tmp;
	struct doip_conn_table **head_connlist = doip_get_connecton_list_head();
	int ret;

	conn = doip_cli_ipaddr_to_conn_table(server_ip_addr);
	if (conn == NULL) {
		ERR("No server with %p is added", server_ip_addr);
		return ERR_FAILED;
	}

	ret = doip_cli_stop_tcp_connection(conn);
	DBG("Returned from doip_cli_stop_tcp_connection with ret=%d!", ret);
	if (ret < 0) {
		ERR("Failed to stop TCP connection for %s\n", conn->ipaddr);
		/* fall-through */
	} else {
		led_set(LED_LINK_LED, LED_OFF);
		DBG("After led_set...");
	}

	/* Free the node list. connlist */
	doip_cli_remove_all_nodes(conn);

	/* Remove the 'connection table' from doip_clist */
	tmp = *head_connlist;
	if (tmp == conn) {
//		printf("%s: ### List is NULL ####\n", __func__);
		*head_connlist= NULL;
	} else {
		while(tmp->next != conn) {
			tmp = tmp->next;
		}
		tmp->next = conn->next;
	}

	free(conn);

	DBG("At the end of doip_cli_del_server...");
}
/*
 * TODO: Need a mechanism to send Async events to the application
 * Eg. Veh-annon-resp results
 */
