/**
 *  @file doip_cli.c
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 *
 * TODO:
 * 1. Table-12:
 *     - A_DoIP_Ctrl
 *     - A_DoIP_Announce_Wait
 *     - A_DoIP_Announce_Interval
 *     - A_DoIP_Diagnostic_Message
 *     - T_TCP_General_Inactivity
 *     - A_Processing_Time
 *     - A_Vehicle_Discovery_Timer
 * 2. send(), recv() errors : Close and open the sockets again
 */

#include <unistd.h>
#include <glib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "g3d.h"
#include "doip_cli.h"
#include <endian.h>
#include <sys/select.h>
#define IS_ROUTING_ACTIVATED(conn) \
		((conn->routing_act_status == DOIP_CLI_ROUT_ACT_RESP_SUCCESS) ? 1 : 0)

#define MAX_RETRIES 3   // Maximum retry attempts for receiving data

enum DOIP_PROTO_VER {
	DOIP_PROTO_13400_2_RSVD = 0,
	DOIP_PROTO_13400_2_2010 = 1,
	DOIP_PROTO_13400_2_2012 = 2,
	DOIP_PROTO_13400_2_2019 = 3,
	DOIP_PROTO_13400_3_DEFAULT = 0xFF,
};

static doip_cli_context_t doip_cli_ctx;
static uint16_t doip_cli_sourceaddr;

static int doip_cli_reset_udp_server(doip_cli_context_t *ctx);
extern int doip_cli_rx_diag_response(uint8_t *pbuf, uint32_t len);

void doip_cli_set_logical_address(uint16_t laddr)
{
	doip_cli_ctx.logical_address = laddr;
//	printf("doip_cli_ctx.logical_address=%d\n",doip_cli_ctx.logical_address);
}

uint16_t doip_cli_get_logical_address(void)
{
	return doip_cli_ctx.logical_address;
}

doip_node_t *doip_cli_find_node(doip_conn_table_t *conn, uint16_t laddr)
{
	doip_node_t *node = conn->nodelist;

	while(node) {
		if (node->laddr == laddr)
			return node;
		node = node->next;
	}
	return NULL;
}

int doip_cli_add_node_tolist(doip_conn_table_t *conn, uint16_t laddr)
{
	doip_node_t *p, *start;

	p = (doip_node_t *) malloc(sizeof(doip_node_t));
	if (p == NULL) {
		DBG("malloc failed");
		return -1;
	}
	memset(p, 0, sizeof(doip_node_t));
	p->laddr = laddr;
	p->next = NULL;

	if (conn->nodelist == NULL) {
		conn->nodelist = p;
		return 0;
	}
	start = conn->nodelist;
	while(start->next != NULL)
		start = start->next;
	start->next = p;

	return 0;
}

int doip_cli_remove_node_fromlist(doip_conn_table_t *conn, uint16_t laddr)
{
	doip_node_t *prev, *node;

	node = conn->nodelist;
	if (node == NULL) {
		DBG("List is empty");
		return 0;
	}
	prev = node;
	while(node) {
		if(node->laddr == laddr) {
			DBG("Found %d in list", laddr);
			break;
		}
		prev = node;
		node = node->next;
	}
	if (node) {
		if (prev == node) {
			conn->nodelist = NULL;
		} else {
			prev->next = node->next;
		}
		free(node);
	}
	return 0;
}

void doip_cli_remove_all_nodes(doip_conn_table_t *conn)
{
	doip_node_t *node, *prev;

	node = conn->nodelist;
	while (node) {
		prev = node;
		node = node->next;
		free(prev);
	}

	conn->nodelist = NULL;
}

static inline int doip_cli_supported_version(gen_doip_hdr_t *hdr)
{

//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr->proto_ver, hdr->inv_proto_ver, hdr->payload_type, hdr->payload_len);
	if ((hdr->proto_ver >= DOIP_PROTO_13400_2_RSVD)
			&& (hdr->proto_ver <= DOIP_PROTO_13400_2_2019)) {
		/* supported version */
		if (hdr->inv_proto_ver == (hdr->proto_ver ^ 0xFF)) {
			/* Valid gen_doip_hdr_t is received */
//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr->proto_ver, hdr->inv_proto_ver, hdr->payload_type, hdr->payload_len);
			return 1;
		}
	}
	return 0;
}

int doip_cli_handle_tcp_rx_routing_activation(doip_conn_table_t *conn, gen_doip_hdr_t *hdr)
{
	routing_act_resp_t ra_resp;
	int ret;
	//int len = MIN(sizeof(ra_resp), hdr->payload_len);

//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%d\n",__LINE__,__func__,hdr->proto_ver, hdr->inv_proto_ver, hdr->payload_type, hdr->payload_len);
	ret = recv(conn->tcpsock, &ra_resp, hdr->payload_len, 0);
//	printf("Recv failed %d", ret);
	if (ret == 0) {
		DBG("recv error");
		return -1;
	}
	conn->routing_act_status = ra_resp.resp_code;
	if (conn->routing_act_status != DOIP_CLI_ROUT_ACT_RESP_SUCCESS) {
		DBG("RoutAct failed for laddr %u", conn->laddr);
	} else {
		DBG("Routing Activated for %u", conn->laddr);
	}
        free(hdr);
	return 0;
}

int doip_cli_handle_tcp_rx_alive_check(doip_conn_table_t *conn, gen_doip_hdr_t *hdr)
{
	uint16_t srcaddr;

//      printf("debug line=%d func=%s \n",__LINE__,__func__);
	int ret;

	if (hdr->payload_len > sizeof(srcaddr)) {
		DBG("Err: Received more bytes");
		return -1;
	}

	ret = recv(conn->tcpsock, &srcaddr, sizeof(srcaddr), 0);
	if (ret == 0) {
		DBG("Err: recv() failed");
		return -1;
	}

	if (conn->sinfo.laddr != srcaddr) {
		ERR("Got K-Alive resp with wrong srcaddr");
		/* TODO: Handle the error case */
		return 0;
	}
	/* Do not stop the keep-Alive timer */
	conn->keep_alive_got_resp = TRUE;
	free(hdr);
	return 0;
}

int doip_cli_handle_tcp_tx_alive_check(doip_conn_table_t* conn)
{
	gen_doip_hdr_t* hdr;
	check_alive_resp_t* pReq;
	uint32_t len;

	len = sizeof(gen_doip_hdr_t) + sizeof(check_alive_resp_t);//reserved 4 bytes(-4 is deleted because its throwing warnings)
	hdr = (gen_doip_hdr_t*)malloc(len);
	if (hdr == NULL) {
		DBG("malloc failed");
		return -1;
	}
//	len -= 4;//reservd 4 bytes
	hdr->proto_ver = DOIP_PROTO_13400_2_2012;//DOIP_PROTO_13400_2_2019;
	hdr->inv_proto_ver = DOIP_PROTO_13400_2_2012 ^ 0xFF;//(DOIP_PROTO_13400_2_2019 ^ 0xFF);
	hdr->payload_type = __bswap_16(PL_TYPE_ALIVE_CHECK_RSP);
	hdr->payload_len = __bswap_32(sizeof(check_alive_resp_t));
	pReq = (routing_act_req_t*)(hdr->payload);
	pReq->src_addr = __bswap_16(doip_cli_sourceaddr);

	len = send(conn->tcpsock, hdr, len, 0);
	free(hdr);

	return 0;
}

/*
 *   Table-21: PL_TYPE_DIAG_MSG; Also Table-13, 22
 *  ---------------------------------------------------------------------------------------------------------------
 *  | proto_id | command  | status   | seqNum    | lastpkt   | curlen = n | Src Addr  | Dst Addr  | user data     |
 *  | (1 byte) | (1 byte) | (1 byte) | (2 bytes) | (2 bytes) | (4 bytes)  | (2 bytes) | (2 bytes) | (n - 4) bytes |
 *  ---------------------------------------------------------------------------------------------------------------
 *
 *  |<------------------------------------------------------------------->|<------------------------------------->|
 *                             HFCP Response Header                        	  Diagnostic Response from DoIP server
 *
 *
 *   Table-23: PL_TYPE_DIAG_MSG_ACK; Also Table-13, 24
 * --------------------------------------------------------------------------------------------------------------------------------
 * | proto_id | co0mmand  | status   | seqNum    | lastpkt   | curlen = n | Src Addr  | Dst Addr  | ACK code | Previous diagnostic |
 * | (1 byte) | (1 byte) | (1 byte) | (2 bytes) | (2 bytes) | (4 bytes)  | (2 bytes) | (2 bytes) | (1 byte) | data (n - 5) bytes  |
 * --------------------------------------------------------------------------------------------------------------------------------
 *
 *   Table-25: PL_TYPE_DIAG_MSG_NAK; Also Table-13, 26
 * --------------------------------------------------------------------------------------------------------------------------------
 * | proto_id | command  | status   | seqNum    | lastpkt   | curlen = n | Src Addr  | Dst Addr  | NAK code | Previous diagnostic |
 * | (1 b)yte) | (1 byte) | (1 byte) | (2 bytes) | (2 bytes) | (4 bytes)  | (2 bytes) | (2 bytes) | (1 byte) | data (n - 5) bytes  |
 * --------------------------------------------------------------------------------------------------------------------------------
 */
static int doip_cli_rx_tcp_pending_data(doip_conn_table_t *conn)
{
	hfcpReq_t *req;
	hfcpResp_t *resp;
	uint32_t overhead, readlen;
	uint8_t pbuf[USB_PKT_SIZE]; /* Table-16: payload_len can be 0 to 4GB */
	int ret = -1;
	int retries = 0;
	memset(pbuf, 0, USB_PKT_SIZE);
	int bytesRead;
	int retryCounter = 0;
	int max_retries = 3;
	//printf("%s\n", __func__);
	overhead = sizeof(hfcpReq_t) - sizeof(req->u)
				+ sizeof(resp->status) + sizeof(doip_big_data_t);

//	printf("%d\n",overhead);
//	printf("debug line=%d func=%s rx command=%x payload_len=%x\n",__LINE__,__func__,conn->rxCommand, conn->rxPendingReadLen);
	if (conn->rxPendingReadLen > (USB_PKT_SIZE - overhead)) {
		readlen = USB_PKT_SIZE - overhead;
	} else {
		readlen = conn->rxPendingReadLen;
	}
//	printf("debug line=%d func=%s rx command=%x readlen=%d\n",__LINE__,__func__,conn->rxCommand, readlen);
/*	ret = recv(conn->tcpsock,&pbuf[overhead], readlen, 0);
	if (ret <= 0) {
		DBG("recv() failed");
		return -1;
	}*/
    bytesRead = 0;
//	while (retryCounter < max_retries)
	while (bytesRead < readlen)
	{
		fd_set rd;
		struct timeval tv;
		int err;

		FD_ZERO(&rd);
		FD_SET(conn->tcpsock, &rd);

		tv.tv_sec = 0;
		tv.tv_usec = 500 * 1000;//500*1000 
		err = select(conn->tcpsock + 1, &rd, NULL, NULL, &tv);
		if (err == 0) //timeout
		{
		}
		else if (err > 0) //actual data
		{
			ret = recv(conn->tcpsock, &pbuf[overhead + bytesRead], readlen - bytesRead, 0);
			//printf("debug line=%d func=%s rx command=%x payload_len=%x\n",_LINE,func_,conn->rxCommand, conn->rxPendingReadLen);
			if (ret <= 0) {
				DBG("recv() failed");
				return -1;
			}
			bytesRead += ret;
			if(bytesRead == readlen){
				break;
			}
		}
		else
		{
			//Error
			DBG("recv() failed");
			return -1;
		}

//		retryCounter++;
	}

//	printf("debug line=%d func=%s ret=%d\n",__LINE__,__func__,ret);
	req = (hfcpReq_t *)pbuf;//resp
	req->proto_id = DOIP_PROTOCOL_ID;
	if(conn->rxCommand == PL_TYPE_DIAG_MSG_ACK)
	{
		req->command = DOIP_CLI_CMD_DIAG_ACK_RESP;
	}	
	if (conn->rxCommand == PL_TYPE_DIAG_MSG) {
		req->command = DOIP_CLI_CMD_DIAG_RESP;//conn->rxCommand == PL_TYPE_DIAG_MSG_NAK
	} else {
		/* Update the correct command */
		req->command = conn->rxCommand;
	}
	ret = sizeof(hfcpReq_t) - sizeof(req->u); /* sizeof proto_id, command */
 //       printf( "ret = %d\n",ret);
		
	pbuf[ret++] = STATUS_NOERROR;

	resp = (hfcpResp_t *)((uint8_t *)pbuf + ret);
	hexdump("doip-recv", pbuf, 14, 1);
	//printf("debug line=%d",__LINE__);
	//resp->status = 0x05;//STATUS_NOERROR;
	hexdump("doip-recv", pbuf, 14, 1);
	//printf("debug line=%d",__LINE__);
	if ((conn->rxPendingReadLen - bytesRead) == 0) {
		resp->u.d.lastpktt = 1;
	} else {
		resp->u.d.lastpktt = 0;
	}
	resp->u.d.seqNumm = conn->rxSeqNum;
	hexdump("doip-recv", pbuf, 14, 1);
	//printf("debug line=%d",__LINE__);
	resp->u.d.curlen = bytesRead;
	hexdump("doip-recv", pbuf, 14, 1);
	//printf("debug line=%d",__LINE__);

	if(conn->rxCommand == PL_TYPE_DIAG_MSG)
	{
		ret = host_write((void *)pbuf, (overhead + readlen ));
		if (ret <= 0) {
			DBG("USB write failed: %s", strerror(errno));
		}
	}
	
	conn->rxPendingReadLen -= bytesRead;
	conn->rxSeqNum++;
	if (conn->rxPendingReadLen == 0) {
		DBG("Rx: Last fragment");
		conn->rxProto = 0;
		conn->rxCommand = 0;
		conn->rxTotalLen = 0;
		conn->rxSeqNum = 0;
	}
	return ret;
}

/*
 * Process the TCP packets received from DoIP server
 */
static int doip_cli_rx_tcp_doiphdr(doip_conn_table_t *conn)
{
	int ret = -1 ;
	uint32_t len;
	gen_doip_hdr_t *hdr;
   
	//hdr = (gen_doip_hdr_t*)calloc(1,sizeof(gen_doip_hdr_t)+256);


	/* TODO: Free the buffer */
	hdr = (gen_doip_hdr_t *) malloc(sizeof(gen_doip_hdr_t));
	if (hdr == NULL) {
		DBG("malloc failed");
		return -1;	
	}

	len = recv(conn->tcpsock, hdr, sizeof(gen_doip_hdr_t), 0); 

	if (len <= 0) {
		if (len == 0) {
			DBG("TCP connection closed by peer");
		} else {
			DBG("recv error");
			/* TODO: close the TCP socket and re-open it */
		}
		free(hdr);
		return -1;
	}

	hdr->payload_type = __bswap_16(hdr->payload_type);
	hdr->payload_len = __bswap_32(hdr->payload_len); 
	//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr->proto_ver, hdr->inv_proto_ver, hdr->payload_type, hdr->payload_len);
      /*  for(int i = 0 ; i < hdr->payload_len ; i++)
               printf("%x ", hdr->payload[i]);*/

	if (doip_cli_supported_version(hdr) == 0) {
		DBG("Invalid protocol version");
		//return -1; //commented for testing
	}

	//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr->proto_ver, hdr->inv_proto_ver, hdr->payload_type, hdr->payload_len); 
	switch(hdr->payload_type) {
		case PL_TYPE_ROUTING_ACT_RSP:
			ret = doip_cli_handle_tcp_rx_routing_activation(conn, hdr);
			return ret;
		case PL_TYPE_ALIVE_CHECK_RSP:
			ret = doip_cli_handle_tcp_rx_alive_check(conn, hdr);
			return ret;
		case PL_TYPE_ALIVE_CHECK_REQ:
			ret = doip_cli_handle_tcp_tx_alive_check(conn);
			free(hdr);
			return ret;
		case PL_TYPE_DIAG_MSG:
		case PL_TYPE_DIAG_MSG_ACK:
		case PL_TYPE_DIAG_MSG_NAK:
			break;
		default:
			DBG("Invalid payload_type");
			return -1;
	}

	conn->rxProto = DOIP_PROTOCOL_ID;
	conn->rxCommand = hdr->payload_type;
	conn->rxTotalLen = hdr->payload_len;
	conn->rxPendingReadLen = hdr->payload_len;
	conn->rxSeqNum = 1;//0
	memset(conn->rxDiagBuf, 0, sizeof(conn->rxDiagBuf));

	DBG("diag msg, recv() %d bytes", hdr->payload_len);
        free(hdr);
	ret = doip_cli_rx_tcp_pending_data(conn);

	return ret;
}

static gboolean doip_cli_tcp_rx_handler(GIOChannel *channel, GIOCondition cond,
					gpointer data)
{
	doip_conn_table_t *conn = (doip_conn_table_t *) data;

//	printf("%s: cond 0x%x\n", __func__, cond);
	switch (cond) {
		case G_IO_IN:
		//	printf("%s: rxPendingReadLen 0x%x\n", __func__, conn->rxPendingReadLen);
			if (conn->rxPendingReadLen) {
				/* Continue to read the data bytes */
				(void) doip_cli_rx_tcp_pending_data(conn);
				break;
			} else {
				/* Read the header */
				(void) doip_cli_rx_tcp_doiphdr(conn);
			}
			break;
		default:
			return FALSE;
	}
	return TRUE;
}

int doip_cli_send_diag_msg(doip_conn_table_t *conn, uint16_t dst_laddr,
				uint16_t seqNum, uint16_t lastpkt,
				uint32_t msglen, uint8_t *msg)
{
	gen_doip_hdr_t *hdr;
	diag_msg_t *pdiag;
	doip_node_t *node __attribute__((unused));
	uint32_t len;
        uint16_t src_laddr;
#if 0
	node = doip_cli_find_node(conn, dst_laddr);
	if (node == NULL) {
		DBG("RoutActResp for a non-existing laddr %u", dst_laddr);
		return -1;
	}
#endif
	if (IS_ROUTING_ACTIVATED(conn) == 0) {
		DBG("Routing status for %u is disabled", dst_laddr);
		return -1;
	}

	hdr = (gen_doip_hdr_t *)conn->txDiagBuf;
	if (seqNum == 1) {
		memset(conn->txDiagBuf, 0, sizeof(conn->txDiagBuf));
		len = sizeof(gen_doip_hdr_t) + sizeof(diag_msg_t) + msglen;
		hdr->proto_ver = DOIP_PROTO_13400_2_2012;//DOIP_PROTO_13400_2_2019;
		hdr->inv_proto_ver = DOIP_PROTO_13400_2_2012 ^ 0xFF;//(DOIP_PROTO_13400_2_2019 ^ 0xFF);
		hdr->payload_type = __bswap_16(PL_TYPE_DIAG_MSG);
		hdr->payload_len =  len - sizeof(gen_doip_hdr_t);

		pdiag = (diag_msg_t *)(hdr->payload);
		//pdiag->srcaddr = doip_cli_get_logical_address();// __bswap_16(laddr)
		src_laddr=doip_cli_get_logical_address();
		pdiag->srcaddr =  __bswap_16(src_laddr);
		pdiag->dstaddr =  __bswap_16(dst_laddr);// __bswap_16(laddr)
		hexdump("doip-send", hdr, 15, 1);
	   // printf("debug line=%d",__LINE__);
		memcpy(pdiag->diag_data, msg, msglen);
		conn->txTotalLen = len ;
		conn->txPrevSeqNum = 1;//0
	} else {
		if ((conn->txPrevSeqNum + 1) != seqNum) {
			DBG("Invalid SeqNum %d, expected %d\n", seqNum, conn->txPrevSeqNum+1);
			DBG("ERR: Pkt dropped");
			conn->txTotalLen = 0;
			conn->txPrevSeqNum = 0;
			return -1;
		}
		if ((conn->txTotalLen + msglen) > sizeof(conn->txDiagBuf)) {
			DBG("ERR: truncate the pkt to avoid buffer overrun !");
			DBG("Increase 'txDiagBuf'");
			msglen = sizeof(conn->txDiagBuf) - conn->txTotalLen;
		}
		memcpy(&(conn->txDiagBuf[conn->txTotalLen]), msg, msglen);
		hdr->payload_len += msglen;
		conn->txTotalLen += msglen;
		conn->txPrevSeqNum += 1;
	}

	len = 0;
	if (lastpkt) {

		hdr->payload_len =  __bswap_32(hdr->payload_len);//__bswap_32(7)
		//len = send(conn->tcpsock, (uint8_t *)&hdr, conn->txTotalLen, 0);
	
		//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr->proto_ver, hdr->inv_proto_ver, hdr->payload_type, hdr->payload_len);
	
		len = send(conn->tcpsock, hdr, conn->txTotalLen, 0);
		if (len <= 0) {
			DBG("send Diag Msg Req failed");
		} else {
			len = 0;
			DBG("Sent diag message %u len", conn->txTotalLen);
 
		}
		hexdump("doip-send", hdr, 14, 1);
	   // printf("debug line=%d",__LINE__);
		conn->txTotalLen = 0;
		conn->txPrevSeqNum = 0;
	}
	return len;
}

int doip_cli_send_routing_act_req(doip_conn_table_t *conn, uint16_t laddr)
{
	gen_doip_hdr_t *hdr;
	routing_act_req_t *pReq;
	uint32_t len;

	doip_cli_sourceaddr = laddr; //Set Source Address
	len = sizeof(gen_doip_hdr_t) + sizeof(routing_act_req_t);//reserved 4 bytes(-4 is deleted because its throwing warnings)
	hdr =(gen_doip_hdr_t *)malloc(len);
	if (hdr == NULL) {
		DBG("malloc failed");
		return -1;
	}
	len -= 4;//reservd 4 bytes
	hdr->proto_ver = DOIP_PROTO_13400_2_2012;//DOIP_PROTO_13400_2_2019;
	hdr->inv_proto_ver = DOIP_PROTO_13400_2_2012 ^ 0xFF;//(DOIP_PROTO_13400_2_2019 ^ 0xFF);
	hdr->payload_type = __bswap_16(PL_TYPE_ROUTING_ACT_REQ);
	hdr->payload_len = __bswap_32(7); 
	pReq = (routing_act_req_t *)(hdr->payload);
	pReq->src_addr = __bswap_16(laddr);
	pReq->act_type = (uint8_t)DOIP_CLI_ROUT_ACT_REQ_TYPE_DEFAULT;//DOIP_CLI_ROUT_ACT_REQ_TYPE_COMM_REQ;
	pReq->rsvd1 = 0;
	pReq->rsvd2 = 0;
/*printf("debug ==> func =%s line =%d sock =%d, len=%d, payload_type=%x, proto_ver =%d inv_proto_ver =%d src_addr=%x act_type=%d\n",__func__, __LINE__,conn->tcpsock,len,hdr->payload_type,hdr->proto_ver,hdr->inv_proto_ver,pReq->src_addr,pReq->act_type);
	//len = send(conn->tcpsock, (uint8_t *)&hdr, len, 0);*/
	hexdump("routing-data", hdr, len, 1);
	len = send(conn->tcpsock,hdr, len, 0);
//printf("debug ==> func =%s line =%d sock =%d, len=%d, payload_type=%x\n",__func__, __LINE__,conn->tcpsock,len,hdr->payload_type);
	if (len < 0) {
		DBG("send Routing Act Req failed");
	} else {
		len = 0;
	}
	free(hdr);
	return len;
}

static gboolean doip_cli_send_keep_alive(gpointer data)
{
	doip_conn_table_t *conn = (doip_conn_table_t *)data;
	gen_doip_hdr_t hdr = {
		.proto_ver = DOIP_PROTO_13400_2_2012,//DOIP_PROTO_13400_2_2019,		/* Table-16 */
		.inv_proto_ver = DOIP_PROTO_13400_2_2012 ^ 0xFF,//(DOIP_PROTO_13400_2_2019 ^ 0xFF),
		.payload_type = __bswap_16(PL_TYPE_ALIVE_CHECK_REQ),
		.payload_len = 0
	};

//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr.proto_ver, hdr.inv_proto_ver, hdr.payload_type, hdr.payload_len);
	uint32_t len;
	static int k_alive = 0;

	if (conn->keep_alive_got_resp == FALSE) {
		DBG("No k-Alive resp got");
		k_alive++;
	} else {
		k_alive = 0;
	}
	if (k_alive >= DOIP_CLI_MAX_K_ALIVE_MISS) {
		/* Stop sending keep-alive */
		/* TODO: Reset the connection */
		return G_SOURCE_REMOVE;
	}

//printf("debug line=%d func=%s proto=%x inv_proto=%x payload_type=%x payload_len=%x\n",__LINE__,__func__,hdr.proto_ver, hdr.inv_proto_ver, hdr.payload_type, hdr.payload_len);

	len = send(conn->tcpsock, &hdr, sizeof(hdr), 0);

	if (len < 0) {
		DBG("keep-alive send failed");
		return G_SOURCE_REMOVE;
	}

	conn->keep_alive_got_resp = FALSE;
	return G_SOURCE_CONTINUE;
}

int doip_cli_start_tcp_connection(doip_conn_table_t *conn)
{
	int sock, ret;
	struct sockaddr_in saddr;
	GIOChannel *channel;

	DBG("In %s", __func__);
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock < 0) {
		DBG("Failed to open tcp sock");
		return -1;
	}

	memset(&saddr, 0, sizeof(saddr));
	saddr.sin_family = AF_INET;
#if 0
	inet_aton(conn->ipaddr, &saddr.sin_addr);
	saddr.sin_port = htons(SOCK_TCP_DATA);
#else
	/* 192.168.1.30 ... C0A8011E */
	saddr.sin_addr.s_addr = inet_addr(conn->ipaddr);
//	printf("connect(%s), 0x%04x\n", conn->ipaddr, saddr.sin_addr.s_addr);
#endif
	saddr.sin_port = htons(SOCK_SEC_TCP_DATA);

	DBG("after adding the port.no");
	ret = connect(sock, (struct sockaddr *)&saddr, sizeof(saddr));
	if (ret < 0) {
		DBG("TCP conn failed");
		close(sock);
		perror("connect");
		return -1;
	}

	conn->tcpsock = sock;

	channel = g_io_channel_unix_new(conn->tcpsock);

	if (!channel) {
		ERR("Failed to create tcpsock for %s\n", conn->ipaddr);
		close(conn->tcpsock);
		return -1;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);
	conn->cond = G_IO_PRI | G_IO_IN;
	conn->tcp_watch_source = g_io_add_watch(channel, conn->cond,
		doip_cli_tcp_rx_handler, (gpointer) conn);

	g_io_channel_unref(channel);
	conn->tcp_channel = channel;

	/* Start the Keep-Alive timer and transmit AL Alive Check Request */
/*	conn->keep_alive_watch_source = g_timeout_add_seconds(T_TCP_Alive_Check,
			doip_cli_send_keep_alive, (gpointer)conn);*/
/*	conn->keep_alive_watch_source = g_timeout_add(T_TCP_Alive_Check,
			doip_cli_send_keep_alive, (gpointer)conn);
	if (conn->keep_alive_watch_source < 0) {
		ERR("Failed to create keep alive timer source!");
		g_io_channel_shutdown(conn->tcp_channel, TRUE, NULL);
		close(conn->tcpsock);
		return -1;
	}*/
	return 0;
}

int doip_cli_stop_tcp_connection(doip_conn_table_t *conn)
{
	DBG("In %s", __func__);

	/* Stop the AL Alive Check Request timer */
	if (conn->keep_alive_watch_source >= 0) {
		g_source_remove(conn->keep_alive_watch_source);
		conn->keep_alive_watch_source = -1;
	}
	DBG("After g_source_remove(conn->keep_alive_watch_source)...");

	if (conn->tcp_watch_source >= 0) {
		g_source_remove(conn->tcp_watch_source);
		conn->tcp_watch_source = -1;
	}
	DBG("After g_source_remove(conn->tcp_watch_source)...");

/*
	if (conn->tcp_channel != NULL) {
		g_io_channel_shutdown(conn->tcp_channel, TRUE, NULL);
		conn->tcp_channel = NULL;
	}
	DBG("After g_io_channel_shutdown");
*/

	if (conn->tcpsock >= 0) {
		close(conn->tcpsock);
		conn->tcpsock = -1;
	}
	DBG("After close(conn->tcpsock)...");

	return 0;
}

doip_conn_table_t **doip_get_connecton_list_head(void)
{
	return &doip_cli_ctx.doip_clist;
}

/* VEH_IDENTIFICATION_REQ */
static gboolean doip_cli_vehicle_discovery_timer(gpointer data)
{
	int len;
	struct sockaddr_in baddr;
	doip_cli_context_t *ctx = (doip_cli_context_t *)data;

	gen_doip_hdr_t hdr = {
		.proto_ver = DOIP_PROTO_13400_2_2012,//DOIP_PROTO_13400_2_2019, 	/* Table-16 */
		.inv_proto_ver = DOIP_PROTO_13400_2_2012 ^ 0xFF,//(DOIP_PROTO_13400_2_2019 ^ 0xFF),
		.payload_type = PL_TYPE_VIN_REQ,
		.payload_len = 0
	};

	if (ctx->stop_veh_discovery == DOIP_CLI_TIMER_STOPED) {
		DBG("Veh discovery timer stoped");
		return G_SOURCE_REMOVE;
	}

	memset((void *)&baddr, 0, sizeof(baddr));
	baddr.sin_family = AF_INET;
	net_get_bcast_addr(ctx->ifname, &baddr.sin_addr);
	baddr.sin_port = htons(SOCK_UDP_DISCOVERY);

	len = sendto(ctx->udpsock, (void *)&hdr, sizeof(hdr), 0,
			(struct sockaddr *)&baddr, sizeof(baddr));

	if (len < 0) {
		DBG("send VEH-ANN-REQ failed");
		return G_SOURCE_CONTINUE;
	}
	ctx->veh_announce_cnt++;

	return G_SOURCE_CONTINUE;
}

static int doip_cli_start_discovery(doip_cli_context_t *ctx)
{
	ctx->veh_announce_cnt = 0;

	ctx->discovery_timersource =
		g_timeout_add_seconds(A_Vehicle_Discovery_Timer,
				doip_cli_vehicle_discovery_timer, ctx);

	if (ctx->discovery_timersource < 0) {
		ERR("Failed to create VEH_IDENTIFICATION timer source!");
		return -1;
	}

	DBG("Veh discovery timer started");
	ctx->stop_veh_discovery = DOIP_CLI_TIMER_STARTED;
	return 0;
}

static int doip_cli_stop_discovery(doip_cli_context_t *ctx)
{
	ctx->stop_veh_discovery = DOIP_CLI_TIMER_STOPED;
	return 0;
}

/* TODO: Identify the ethernet interface for vehicle side
 * (cdc-ethernet and wifi events to be ignored)
 */
gboolean doip_cli_addr_status_changed(int if_idx, gboolean state)
{
	doip_cli_ctx.if_state = state;
	doip_cli_ctx.if_idx = if_idx;

	if (state == 0) {
		DBG("Link down");
		/* TODO: close any TCP sockets and disconnect with the DoIP
		 * servers
		 */
		return 0;
	}

	if (if_indextoname(if_idx, doip_cli_ctx.ifname) == NULL) {
		doip_cli_ctx.ifname[0] = 0;
		ERR("ifname is unknown!");
		return 1;
	}

	/* TODO: Validate that we have got a valid address - if not get out */
	net_get_ip_addr(doip_cli_ctx.ifname, &doip_cli_ctx.myip);

	doip_cli_start_discovery(&doip_cli_ctx);

	return 0;
}

static uint32_t doip_udp_read(int sock, uint8_t *rbuf, uint32_t rlen,
			struct sockaddr_in *addr, socklen_t *addrlen)
{
	uint8_t *p;
	int len = 0;
	uint32_t totallen = 0;

	p = rbuf;
	do {
		p += totallen;
		len = recvfrom(sock, p, rlen-totallen, 0,
					(struct sockaddr *)addr, addrlen);

		if (len < 0) {
			totallen = 0;
			break;
		}

		totallen += len;

	} while (totallen < rlen);

	return totallen;
}

/*
 * Table-19
 */
int doip_cli_handle_udp_nack(doip_cli_context_t *ctx, uint8_t *resp)
{
	uint8_t nack = *resp;

	DBG("nack 0x%x\n", nack);
	switch(*resp) {
		case DOIP_HDR_NACK_INCORRECT_PATTERN:
		case DOIP_HDR_NACK_INVALID_PAYLOAD_LEN:
			doip_cli_reset_udp_server(ctx);
			break;
		case DOIP_HDR_NACK_UNKNOWN_PAYLOAD:
		case DOIP_HDR_NACK_MSG_TOO_LARGE:
		case DOIP_HDR_NACK_OUT_OF_MEMORY:
		default:
			/* Discard the DoIP message */
			DBG("Unknown nack value");
			break;
	}

	return 0;
}

static int doip_cli_add_doip_serv_list(doip_cli_context_t *ctx, veh_anno_msg_t *resp)
{
	doip_server_list_t *list = ctx->doip_slist, *ser, *tmp;

	ser = (doip_server_list_t *) malloc(sizeof(doip_server_list_t));
	if (ser == NULL) {
		DBG("malloc failed");
		return -1;
	}
	ser->next = NULL;
	memcpy(&ser->sinfo, &resp->sinfo, sizeof(ser->sinfo));
	if (list == NULL) {
		ctx->doip_slist = ser;
		return 0;
	}
	tmp = list;
	while(tmp->next != NULL)
		tmp = tmp->next;
	tmp->next = ser;

	return 0;
}

static void doip_cli_removeall_serv_list(doip_cli_context_t *ctx)
{
	doip_server_list_t *list = ctx->doip_slist, *temp;

	if (list == NULL)
		return;

	while(list) {
		temp = list;
		list = list->next;
		free((void *)temp);
	}
	return;
}


/* This function handles two messages from DoIP server
 * - Vehicle Announcement message
 * - Vehicle Identity response
 *
 * TODO:
 * Start a timer with a timeout of 'A_DoIP_Ctrl' after sending Veh-Idenity-Req
 * Create a list of these messages until the timer expires
 * Create a HSCP message and send it to the host
 * Free the messages in the list
 * Ingore this message if it got:
 * 		- Unknown DoIP server
 * 		- Timeout has expired for Veh-Identity-Resp
 */
int doip_cli_handle_udp_veh_anno_msg(doip_cli_context_t *ctx, uint8_t *resp)
{
	veh_anno_msg_t *pVAM;
	int ret;

	/* Table-5 */
	pVAM = (veh_anno_msg_t *)resp;

	/* TODO: the list should be updated only if the timer is running */
	ret = doip_cli_add_doip_serv_list(ctx, pVAM);
	if (ret < 0) {
		DBG("Unable to udpate VEH-ANNO list");
		return -1;
	}

	return 0;
}

/*
 * Handle Entity Status Response from DoIP server
 */
static int doip_cli_handle_udp_esr(doip_cli_context_t *ctx, doip_conn_table_t *conn, uint8_t *resp)
{
	entity_status_resp_t *pESR;

	pESR = (entity_status_resp_t *)resp;

	conn->node_type = pESR->node_type;
	conn->msts = pESR->msts;
	conn->mcts = pESR->mcts;
	conn->ncts = pESR->ncts;
	conn->mds = pESR->mds;
	return 0;
}

/*
 * Send a Diagnostic Power Mode Request
 * Wait a maximum of A_DoIP_Ctrl duration for a response
 * power_mode
 * 		0x00 : Not ready
 *		0x01 : Ready
 *		0x02 : Not supported
 *		0x03 - 0xFF : RSVD
 */
static int doip_cli_handle_udp_pwr_mode_resp(doip_cli_context_t *ctx,
		uint8_t *resp)
{
	uint8_t pm = *resp;

	DBG("Power mode 0x%x", pm);
	switch(pm) {
		case DOIP_CLI_PM_NOT_READY:
			break;

		case DOIP_CLI_PM_READY:
			break;

		case DOIP_CLI_PM_NOT_SUPPORTED:
			break;

		default:
			break;
	}
	return 0;
}

/*
 * Receive UDP packets from DoIP server
 */
static int doip_cli_handle_udp_rx(doip_cli_context_t *ctx, gen_doip_hdr_t *hdr,
			struct sockaddr_in *saddr, socklen_t *alen)
{
	int ret = -1;
	uint8_t *resp;
	char *ip;
	doip_conn_table_t *conn;

	if (doip_cli_supported_version(hdr) == 0) {
		DBG("Invalid protocol version");
		//return -1; //commented for testing
	}

	/* Table-16: payload_len can be 0 to 4GB */
	resp = (uint8_t *) malloc(hdr->payload_len);
	if (resp == NULL) {
		DBG("malloc failed");
		return ret;
	}
	ret = doip_udp_read(ctx->udpsock, resp, hdr->payload_len, saddr, alen);
	if (ret == 0) {
		free(resp);
		return -1;
	}

	ip = inet_ntoa(saddr->sin_addr);
	conn = doip_cli_ipaddr_to_conn_table(ip);
	if (conn == NULL) {
		DBG("UDP Rx from unknown IP src %s", ip);
		free(resp);
		return -1;
	}

#if 0
	/* Table-17:
	 * The valid port numbers are UDP_DISCOVERY and
	 * UDP_TEST_EQUIPMENT_REQUEST
	 */
	if ((saddr->sin_port != htons(SOCK_UDP_DISCOVERY)) ||
			((saddr->sin_port >= htons(SOCK_UDP_TEST_EQUIPMENT_REQ_MIN)) &&
			 (saddr->sin_port <= htons(SOCK_UDP_TEST_EQUIMPENT_REQ_MAX)))) {
		DBG("Recevied UDP packet on a invalid port %d\n", saddr->port);
		free(resp);
		return -1;
	}
#endif
	switch(hdr->payload_type) {
		case PL_TYPE_NEG_ACK:
			ret = doip_cli_handle_udp_nack(ctx, resp);
			break;
		case PL_TYPE_VIN_RSP: /* Also PL_TYPE_VEH_ANN_MSG */
			ret = doip_cli_handle_udp_veh_anno_msg(ctx, resp);
			break;
		case PL_TYPE_ENTITY_STATUS_RSP:
			ret = doip_cli_handle_udp_esr(ctx, conn, resp);
			break;
		case PL_TYPE_DIAG_PWR_MODE_RSP:
			ret = doip_cli_handle_udp_pwr_mode_resp(ctx, resp);
			break;
		default:
			ERR("Invalid payload type in DoIP response");
	}

	free(resp);
	return ret;
}

static gboolean doip_cli_udp_rx_handler(GIOChannel *channel, GIOCondition cond,
					gpointer data)
{
	struct sockaddr_in serv_addr;
	socklen_t addrlen;
	uint32_t len;
	gen_doip_hdr_t hdr;
	doip_cli_context_t *ctx = (doip_cli_context_t *)data;

	switch (cond) {
	case G_IO_IN:
		/* TODO: Perform 2 recvfrom()
		 * 1. Read the full header to know the length
		 * 2. Read the payload
		 */
		len = doip_udp_read(ctx->udpsock, (uint8_t *)&hdr,
				sizeof(hdr), &serv_addr, &addrlen);

		if (len != sizeof(hdr)) {
			ERR("failed to read DoIP header");
		}
		len = doip_cli_handle_udp_rx(ctx, &hdr, &serv_addr, &addrlen);
		if (len < 0) {
			ERR("failed to handle req %x", hdr.payload_type);
		}

		break;
	default:
		return FALSE;
	}

	return TRUE;
}

static int doip_cli_open_udp_server(doip_cli_context_t *ctx)
{
	GIOChannel *channel;

	/* UDP socket to :
	 * - Send Vehicle Identification request
	 * - Receive Vehicle Identification response
	 * - Receive Vehicle Announcement message
	 */
	ctx->udpsock = socket(PF_INET, SOCK_DGRAM, 0);
	if (ctx->udpsock < 0) {
		DBG("send VEH-ANN-REQ failed");
		return -1;
	}

	channel = g_io_channel_unix_new(ctx->udpsock);

	if (!channel) {
		ERR("Failed to create g_io_channel for USBHID!\n");
		close(ctx->udpsock);
		return -1;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);
	ctx->cond = G_IO_PRI | G_IO_IN;

	ctx->watch_source = g_io_add_watch(channel, ctx->cond,
					doip_cli_udp_rx_handler, (gpointer) ctx);

	g_io_channel_unref(channel);

	ctx->udp_channel = channel;
	return 0;
}

static int doip_cli_close_udp_server(doip_cli_context_t *ctx)
{
	GIOChannel *gch;

	doip_cli_removeall_serv_list(ctx);
	gch = ctx->udp_channel;
	g_io_channel_shutdown(gch, TRUE, NULL);
	ctx->udp_channel = NULL;
	close(ctx->udpsock);
	ctx->udpsock = -1;
	ctx->watch_source = 0; /* TODO: Review: Can this be set to 0 */

	return 0;
}

static int doip_cli_reset_udp_server(doip_cli_context_t *ctx)
{
	int ret;

	ret = doip_cli_close_udp_server(ctx);
	if (ret < 0) {
		DBG("DoIP failed to close udp_server");
		return ret;
	}

	ret = doip_cli_open_udp_server(ctx);
	if (ret < 0) {
		DBG("DoIP failed to open udp_server");
		return ret;
	}

	DBG("DoIP cli udp socket reset");

	return ret;
}

/*
 * NOTE: This API should be invoked after the device has acquired the
 * IP address and the DoIP server address is known.
 * ie, ctx->doip_gw_ip[] and ctx->myip[] is updated
 */

int doip_cli_init(void)
{
	int ret;

	/* TODO: This is not required as doip_cli_ctx is declared as static */
	memset(&doip_cli_ctx, 0, sizeof(doip_cli_ctx));

	//doip_cli_ctx.cli_state = DOIP_CONN_STATE_INITIAL;

	ret = doip_cli_open_udp_server(&doip_cli_ctx);
	if (ret < 0) {
		DBG("Failed to open UDP socket");
		return -1;
	}

	/* TODO: This should be started only if the address is set.
	 * 	We may have missed the event as we may be permanently
	 * 	connected. So will need to get the address and see if it is
	 * 	valid and then start the discovery process.
	 * 	All this can be done in the doip_cli_start_discovery()
	 * 	function so that the same code can be used when we get
	 * 	the address set event.
	 */
	if (DOIP_CLI_IF_STATE_UP()) {
		doip_cli_start_discovery(&doip_cli_ctx);
	}

	return 0;
}

int doip_cli_deinit(void)
{
	/* TODO: stop discovery if it is in progress */
	doip_cli_stop_discovery(&doip_cli_ctx);

	doip_cli_close_udp_server(&doip_cli_ctx);

	memset(&doip_cli_ctx, 0, sizeof(doip_cli_ctx));

	return 0;
}

