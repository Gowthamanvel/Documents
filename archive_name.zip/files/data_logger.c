/**
 *  @file data_logger.c
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include <stdint.h>
#include "data_logger.h"

#ifdef DEBUG_HEXDUMP_TO_FILE

#define HEXDUMP_FILE "/home/root/hexdump_file.txt"

static FILE *pfile;

void DEBUG_init(void)
{
	printf("%s, %d: enter\n", __func__, __LINE__);

	pfile = fopen(HEXDUMP_FILE, "w");
	if (pfile == NULL) {
		printf("unable to open file frames.txt\n");
		return;
	}

	printf("frames.txt opened\n");
}

void DEBUG_deinit(void)
{
	fflush(pfile);
	fclose(pfile);
	DBG("%s closed\n", HEXDUMP_FILE);
}

#endif	/* DEBUG_HEXDUMP_TO_FILE */

#ifdef DEBUG
void hexdump(char *prompt, void *ptr, int len, int file)
{
	int i;
	uint8_t *p = ptr;

#define CHAR_PER_LINE (16)
	printf("%s, len=%d\n\t", prompt, len);
	for (i = 0; i < len; i++) {
		if ((i != 0) && !(i % CHAR_PER_LINE))
			printf("\n\t");
		printf("0x%02x ", p[i]);
		}

	printf("\n");
#ifdef DEBUG_HEXDUMP_TO_FILE
	if (pfile && file) {
		fprintf(pfile, "%s, len=%d\n\t", prompt, len);
		for (i = 0; i < len; i++) {
			if ((i != 0) && !(i % CHAR_PER_LINE))
				fprintf(pfile, "\n\t");
			fprintf(pfile, "0x%02x ", p[i]);
		}
		fprintf(pfile, "\n");
		fflush(pfile);
	}
#else
	(void) file;
#endif
}
#else
#define hexdump(a, b, c, d)
#endif
