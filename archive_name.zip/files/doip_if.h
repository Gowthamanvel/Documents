/**
 *  @file doip_if.h
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _DOIP_IF_H_
#define _DOIP_IF_H_

#include "doip_cli.h"

#define MAX_LADDR_CNT (64)

enum doip_cli_if_commands {
	DOIP_CLI_CMD_START_SESSION = 0,
	DOIP_CLI_CMD_ADD_DOIP_SERVER = 1,
	DOIP_CLI_CMD_REMOVE_DOIP_SERVER = 2,
	DOIP_CLI_CMD_ADD_NODE = 3,
	DOIP_CLI_CMD_DEL_NODE = 4,
	DOIP_CLI_CMD_SEND_DIAG_MSG = 5,
	DOIP_IOCTL_HANDLING = 6,
	DOIP_CLIENT_DETAILS = 7,
	/* Async Response */
	DOIP_CLI_CMD_DIAG_RESP = 0x0A, //0x80

	DOIP_CLI_CMD_DIAG_ACK_RESP = 0x08,

	DOIP_CLI_CMD_UNKNOWN = 0xFF
};

/*
 * Command to configure the DOIP client
 *     - Logical Address of the DoIP client
 *     - TODO: add any other DoIP client as part of this command
 */
struct doip_cli_cmd_start_session {
	uint16_t logical_addr; /* This value will be used as 'srcaddr' in Diag messages */
} PACKED;

typedef struct doip_cli_cmd_start_session doip_cli_cmd_start_session_t;

struct doip_cli_cmd_add_doip_server {
	char ipaddr[IPV4_STR_ADDR_LEN]; /* Eg. "192.168.1.20" */
	doip_serv_info_t sinfo;
} PACKED;

typedef struct doip_cli_cmd_add_doip_server doip_cli_cmd_add_doip_server_t;

struct doip_cli_cmd_del_doip_server {
	char ipaddr[IPV4_STR_ADDR_LEN];
} PACKED;

typedef struct doip_cli_cmd_del_doip_server doip_cli_cmd_del_doip_server_t;

struct doip_cli_cmd_add_node {
	char ipaddr[IPV4_STR_ADDR_LEN];
	uint16_t node_cnt;
	uint16_t laddr[MAX_LADDR_CNT];
} PACKED;

typedef struct doip_cli_cmd_add_node doip_cli_cmd_add_node_t;
typedef struct doip_cli_cmd_add_node doip_cli_cmd_del_node_t;

struct doip_cli_cmd_diag_msg {
	char ipaddr[IPV4_STR_ADDR_LEN];
	uint16_t seqNum; /* starts from 0 and increases by 1 for every packet */
	uint16_t lastpkt; /* 0 = More packets, 1 = last packet */
	uint16_t dst_laddr;
	uint32_t msg_len;
	uint8_t diag_data[0];
} PACKED;

typedef struct doip_cli_cmd_diag_msg doip_cli_cmd_diag_msg_t;

struct doip_ioctl_handle {

}PACKED;
typedef struct doip_ioctl_handle doip_ioctl_handle_t;

struct doipclientdetails {
     char ipaddr[IPV4_STR_ADDR_LEN];
     char subnetaddr[IPV4_STR_ADDR_LEN];
     char Gwaddr[IPV4_STR_ADDR_LEN];
     uint16_t logical_addr;
} PACKED;

typedef struct doipclientdetails doip_client_details_t;

/* Function declarations */
int doip_cli_add_server(doip_cli_cmd_add_doip_server_t *sinfo);
int doip_cli_del_server(doip_cli_cmd_del_doip_server_t *sdel);
int doip_cli_add_node(doip_cli_cmd_add_node_t *en);
int doip_cli_del_node(doip_cli_cmd_del_node_t *en);
int doip_cli_cmd_start_session(doip_cli_cmd_start_session_t *psession);
int doip_cli_cmd_send_diag_msg(doip_cli_cmd_diag_msg_t *dmsg);
doip_conn_table_t *doip_cli_ipaddr_to_conn_table(char *ip);
int doip_ioctl_handling(doip_ioctl_handle_t *en);
int doip_client_details(doip_client_details_t *dclient);
void doip_cli_delete_server();
#endif /* _DOIP_IF_H_ */
