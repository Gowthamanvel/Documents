
#ifndef _J2534_PERIODIC_H_
#define _J2534_PERIODIC_H_

#include <stdint.h>
#include "hfcp.h"
#include "j2534_filter.h"


#define configTICK_RATE_HZ	1000

/* Architecture specifics. */
#define portSTACK_GROWTH	(-1)
#define portTICK_PERIOD_MS	((uint32_t)1000 / configTICK_RATE_HZ)
#define portBYTE_ALIGNMENT	8
#ifndef TRUE
#define TRUE			1
#define FALSE			0
#endif

/* Maximum length for Tx and Rx frame
 * #define ISO9141_14230_MAXRXMSGLEN 260
 * #define ISO9141_14230_MAXTXMSGLEN 260
 */

/* Enums defined for Error Handling */
typedef enum {
	/* Defines error not supported */
	PERIODIC_FAILED,

	/* Defines error for invalid protocol id */
	PERIODIC_INVALID_PROTOCOL_ID,

	/* Defines error for invalid periodicity*/
	PERIODIC_INVALID_TIME_INTERVAL,

	/* Defines error for exceeded maximum number of periodic message id */
	PERIODIC_EXCEEDED_LIMIT,

	/* Defines error for invalid message id */
	PERIODIC_INVALID_MSG_ID,

	/* Defines function call success */
	PERIODIC_SUCCESS

} PERIODIC_ERROR_STATUS;


/* Enums defined for the periodic message commands */
typedef enum {
	/* Defined for starting a new periodic message */
	PERIODIC_STARTNEW_PMSG = 1,

	/* Defined for updating periodic message */
	PERIODIC_UPDATE_PMSG,

	/* Defined for stopping a particular periodic message */
	PERIODIC_STOP_PMSG,

	/* Defined for suspending all periodic message */
	PERIODIC_SUSPEND_PMSG,

	/* Defined for changind periodicity of periodic message */
	PERIODIC_CHANGE_PERIOD_PMSG

} PERIODIC_COMMAND;

/* Structure to hold the message transmitted periodically */
typedef struct {
	uint32_t tx_flags; /* Transmit flags */
	uint8_t length;    /* Length of data field */
	uint8_t data[12];  /* Data field maximum 12 byets as per J2534 */
} proto_msg_TYPE;

/* Structure defined for handling periodic messages */
typedef struct {
	/* Periodic message id given for each periodic message (1-10) */
	uint8_t   prmsg_id;

	/* Protocol identifier */
	uint32_t protocol_id;

	/* 12 bytes of data that is to be transmitted periodically */
	proto_msg_TYPE proto_msg;

	/* Periodicity ranges between 5- 65535 */
	uint16_t periodicity;

	/* Periodicity used to handle transmission periodically */
	uint16_t local_periodicity;

#ifdef BCM_SUPPORT
	int bcmfd;
#endif
} PERIODIC_MSG;

/* ISO9141_14230 Tx message structure */
/*
 * typedef struct {
 *	uint32_t Timestamp;		// Timestamp for the received msg
 *	uint32_t Flags;			// Tx flags
 *	uint16_t Length;		// Tx message length
 *	uint8_t Data[ISO9141_14230_MAXTXMSGLEN]; // Tx data bytes
 * } ISO9141_14230_TxMsg_S;
 */

/* enum for ISO9141_14230 return code */

/*
 * typedef enum {
 *	NO_ERROR,
 *	INVALID_COMMAND,
 *	INVALID_PARAMETERID,
 *	ISO9141_14230_TXQ_FULL,
 *	ISO9141_14230_RXQ_EMPTY
 * } ISO9141_14230_RETCODE;
 */

uint8_t suspend_pmsg(uint32_t p_protocol_id);
uint8_t PERIODIC_msg_cmd(PERIODIC_MSG *p_msg_ptr, uint8_t p_periodic_cmd);
#ifdef BCM_SUPPORT
void bcm_pmsg_deinit(void);
void bcm_pmsg_init(void);
#endif /* BCM_SUPPORT */

#endif  /* _J2534_PERIODIC_H_ */

