/*
 * @file g3d.h
 *
 * Copyright (c) 2023, Capgemini, Intelligent Devices
 */

#ifndef _G3D_H_
#define	_G3D_H_

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include	<glib.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<unistd.h>
#include	<syslog.h>
#include	<fcntl.h>
#include	<errno.h>
#include	<dirent.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	<sys/time.h>
#include	<sys/socket.h>
#include	<sys/un.h>
#include	<sys/ioctl.h>
#include	<netinet/in.h>
#include	<net/if.h>
#include	<arpa/inet.h>
#include	<ctype.h>
#include	<linux/gpio.h>

#ifdef CONFIG_USBHID
#include	"usbhid.h"
#endif
#ifdef CONFIG_NETIF
#include	"net_if.h"	/** TODO: Integrate this into single net related file */
#endif
#ifdef CONFIG_CAN
#include	"can_if.h"
#endif
#ifdef CONFIG_NET
#include	"net.h"
#endif
#ifdef CONFIG_DOIP
#include	"doip_cli.h"
#endif
#ifdef CONFIG_BT
#include	"bt.h"
#endif
#ifdef CONFIG_GPIO
#include	"gpio_App.h"
#endif
#ifdef CONFIG_LED
#include	"led.h"
#endif
#ifdef CONFIG_KWP
#include	"kwp_if.h"
#endif
#include	"data_logger.h"

#define _GNU_SOURCE

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(x)		(sizeof(x)/sizeof((x)[0]))
#endif

#define LOG_TAG			"g3d"

#define	xLOG_ERROR		(LOG_DAEMON | LOG_ERR)
#define	xLOG_WARN		(LOG_DAEMON | LOG_WARNING)
#define	xLOG_INFO		(LOG_DAEMON | LOG_INFO)
#define	xLOG_DEBUG		(LOG_DAEMON | LOG_DEBUG)

#define LOG(t, p, f, a...)	g3dlog(t, p, f, ##a)

#define ERR(f, a...)		LOG(LOG_TAG, xLOG_ERROR, "%s:%s():%d "f,\
					__FILE__, __func__, __LINE__, ##a)

#define WARN(f, a...)		LOG(LOG_TAG, xLOG_WARN, "%s:%s():%d "f,\
					__FILE__, __func__, __LINE__, ##a)

#define INFO(f, a...)		LOG(LOG_TAG, xLOG_INFO, "%s:%s():%d "f,\
					__FILE__, __func__, __LINE__, ##a)

#ifdef DEBUG
#define DBG(f, a...)		LOG(LOG_TAG, xLOG_DEBUG, "%s:%s():%d "f,\
					__FILE__, __func__, __LINE__, ##a)
#else
#define DBG(...)
#endif

#define SNP(b, f, arg...)	snprintf(b, sizeof(b), f, ##arg)

#define S_MACADDR		6
#define MACFMT			"%02x:%02x:%02x:%02x:%02x:%02x"

#ifdef UBUNTU_MACHINE
#define	LOCK_FILE		"/tmp/g3d.lock"
#else
#define	LOCK_FILE		"/var/run/g3d.lock"
#endif

enum {
	PLATFORM_SAMA5_EVK1,
	PLATFORM_SAMA5_EVK2,
	PLATFORM_SAMA5_GARUDA3_A,
	PLATFORM_UBUNTU,
};

#define	DAEMON_ENABLE	0x01
#define	DAEMON_SYSLOG	0x02

struct G3dContext {
	gboolean	Platform;
	gboolean	NxpWifi;	/* NXP Wifi module present or not */
	gboolean	Terminate;
	gchar		*configfile;
	GMainLoop	*main_loop;
	GList		*ctrl_list;
	uint32_t	Daemon;		/* Bit0: daemon mode: disable/enable */
					/* Bit1: syslog: disable/enable */
	uint32_t	can_bitrate;
};

typedef struct G3dContext G3dContext_t;

struct ConfigInfo {
	char *name;
	char *value;
};

enum ConfigInfoIndex {
	CFG_USBHID_IF,
	CFG_CAN0,
	CFG_CAN1,
	CFG_WIFI_IF,
};

typedef struct ConfigInfo ConfigInfo_t;

#define	G3BI_MAGIC		0x6A80DA03
#define	G3_S_SERIAL_NO		11	/* Actual size (11) */

struct G3BoardInfo {
	uint32_t magic;
	uint32_t version;	/* structure version */
	uint32_t g3version;	/* g3 version */
	uint32_t g3_rsvd1;

	uint8_t sno[16];
};

typedef struct G3BoardInfo G3BoardInfo_t;

extern gboolean G3_board_info_valid;
extern G3BoardInfo_t G3BI;
extern G3dContext_t G3dCtx;

extern ConfigInfo_t CfgInfo[];

extern const char *CSZ_0;
extern const char *CSZ_1;
extern const char *CSZ_logpriority[8];

static inline void g3dlog(const char *tag, int priority, const char *fmt, ...)
{
	va_list	ap;

	va_start(ap, fmt);

	if (G3dCtx.Daemon & DAEMON_SYSLOG) {
		vsyslog(priority, fmt, ap);
	} else {
		char *p;

		p = CSZ_logpriority[LOG_PRI(priority)];
	//	p = logpriority[LOG_PRI(priority)];

		fprintf(stderr, "%s:%s ", tag, p);
		vfprintf(stderr, fmt, ap);
		fprintf(stderr, "\n");
	}

	va_end(ap);
}

#endif /* _G3D_H_ */

