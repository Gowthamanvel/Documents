/**
 *	@file net.c
 *
 *	Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include	<unistd.h>
#include	<ifaddrs.h>
#include	<net/if.h>
#include	<net/route.h>
#include	<linux/if_addr.h>
#include	<sys/ioctl.h>
#include	"led.h"
#include	"g3d.h"

static struct net_ctrl_context net_ctrl_ctx;

#ifdef NET_DEBUG

static void show_infomsg(struct ifinfomsg *msg)
{
	char ifn[IF_NAMESIZE];

	DBG("[1/2] ifi_family=%02x ifi_name=%s ifi_type=%04x ",
			msg->ifi_family,
			if_indextoname(msg->ifi_index, ifn), /* index->name */
			msg->ifi_type);		/* ARPHRD_* */
	DBG("[2/2] ifi_change=%08x ifi_flags=%08x",
			msg->ifi_change,	/* IFF_* change mask */
			msg->ifi_flags);	/* IFF_* flags  */
}

static void show_addrmsg(struct ifaddrmsg *msg)
{
	char ifn[IF_NAMESIZE];

	DBG("[1/2] ifa_family=%02x ifa_name=%s ifa_flags=%02x",
			msg->ifa_family,	/* Address type */
			if_indextoname(msg->ifa_index, ifn), /* index->name */
			msg->ifa_flags);	/* IFA_* flags  */
	DBG("[2/2] ifa_prefixlen=%02x ifa_scope=%02x",
			msg->ifa_prefixlen,	/* Prefix length of address */
			msg->ifa_scope);	/* Address scope */
}

#endif /* NET_DEBUG */

#ifndef IFI_CHANGE_SUPPORTED
static char local_ifi_first[MAX_G3D_INTERFACES]; /* 1st time force a change */
static int local_ifi_flags[MAX_G3D_INTERFACES];
#endif

int process_nlevent_newlink(struct ifinfomsg *im)
{
#ifdef IFI_CHANGE_SUPPORTED
	if (im->ifi_change & (NET_LINK_UP))
		net_ctrl_ctx.necbs.link_status(im->ifi_index,
					(im->ifi_flags & NET_LINK_UP) ? 1 : 0);
#else
	if (im->ifi_index < 0 || im->ifi_index >= MAX_G3D_INTERFACES) {
		ERR("ifi_index (%d) exceeded MAX_G3D_INTERFACES (%d)!",
				im->ifi_index, MAX_G3D_INTERFACES);
		return -1;
	}

	/* Detect change in status */
	if (!local_ifi_first[im->ifi_index] ||
		(im->ifi_flags ^ local_ifi_flags[im->ifi_index]) &
		NET_LINK_UP) {

		net_ctrl_ctx.necbs.link_status(im->ifi_index,
				(im->ifi_flags & NET_LINK_UP) ? 1 : 0);

		local_ifi_first[im->ifi_index] = 1;
	}

	local_ifi_flags[im->ifi_index] = im->ifi_flags;
#endif

	return 0;
}

int net_process_nlevent(struct nlmsghdr *nlmsg)
{
#ifdef NET_DEBUG
	char *estr;

	switch (nlmsg->nlmsg_type) {
	/* AF_NETLINK */
	case RTM_NEWLINK:
		estr = "NEWLINK";
		break;
	case RTM_NEWADDR:
		estr = "NEWADDR";
		break;
	case RTM_DELADDR:
		estr = "DELADDR";
		break;
	default:
		estr = "Unhandled";
		break;
	}

	INFO("Network Event %d: %s (len=%u f=%04x s=%u pid=%u)",
						nlmsg->nlmsg_type, estr,
						nlmsg->nlmsg_len,
						nlmsg->nlmsg_flags,
						nlmsg->nlmsg_seq,
						nlmsg->nlmsg_pid);

	switch (nlmsg->nlmsg_type) {
	case RTM_NEWLINK:
	case RTM_DELLINK:
	case RTM_GETLINK:
	case RTM_SETLINK:
		show_infomsg(NLMSG_DATA(nlmsg));
		break;

	case RTM_NEWADDR:
	case RTM_DELADDR:
	case RTM_GETADDR:
		show_addrmsg(NLMSG_DATA(nlmsg));
		break;
	}
#endif /* NET_DEBUG */

	switch (nlmsg->nlmsg_type) {
	/* AF_NETLINK */
	case RTM_NEWLINK:
		process_nlevent_newlink(NLMSG_DATA(nlmsg));
		break;
	case RTM_NEWADDR:
		net_ctrl_ctx.necbs.addr_status(
				getifaddrmsgindex(NLMSG_DATA(nlmsg)), 1);
		break;
	case RTM_DELADDR:
		net_ctrl_ctx.necbs.addr_status(
				getifaddrmsgindex(NLMSG_DATA(nlmsg)), 0);
		break;
	}

	return 0;
}

int net_process_nlmsg(struct nlmsghdr *msg, int msglen)
{
	struct nlmsghdr *nh;

	for (nh = msg; NLMSG_OK(nh, msglen); nh = NLMSG_NEXT(nh, msglen)) {
		/* end of multipart message */
		if (nh->nlmsg_type == NLMSG_DONE)
			return 0;

		if (nh->nlmsg_type == NLMSG_NOOP)
			continue;

		if (nh->nlmsg_type == NLMSG_ERROR) {
			struct nlmsgerr *msgerr = NLMSG_DATA(nh);

			INFO("Received Nework Error Message: %d",
					msgerr->error);
		} else
			net_process_nlevent(nh);
	}

	return 0;
}

static gboolean net_event_handler(GIOChannel *channel,
						GIOCondition cond,
						gpointer data)
{
	register int ret = 0;
	int fd;
	struct iovec iov;
	struct sockaddr_nl nladdr;
	unsigned char *buf;

	if (cond & (G_IO_NVAL | G_IO_ERR | G_IO_HUP))
		return FALSE;

	fd = g_io_channel_unix_get_fd(channel);
	if (fd < 0) {
		ERR("g_io_channel_unix_get_fd failed");
		return FALSE;
	}

	buf = malloc(S_NET_EVENT_BUF);
	if (buf == NULL) {
		ERR("Failed event buffer allocation!");
		return FALSE;
	}

	iov.iov_base = buf;
	iov.iov_len = S_NET_EVENT_BUF;

	struct msghdr msg = { &nladdr, sizeof(nladdr), &iov, 1, NULL, 0, 0 };

	memset(&nladdr, 0, sizeof(nladdr));
	nladdr.nl_family = AF_NETLINK;
	nladdr.nl_pid = 0;
	nladdr.nl_groups = 0;

	for (;;) {
		ret = recvmsg(fd, &msg, MSG_DONTWAIT);
		if (ret < 0) {
			if (errno == EINTR) {
				DBG("Network receive interrupted!");
				continue;
			} else if (errno == EAGAIN)
				break;
		}

		if (ret == 0) {
			DBG("Network receive completed!");
			break;
		}

		if (msg.msg_namelen != sizeof(nladdr)) {
			INFO("Unexpected sender address: got %u, expected %ld",
					msg.msg_namelen, sizeof(nladdr));
			break;
		}

		if (((struct sockaddr_nl *)msg.msg_name)->nl_pid != 0) {
			DBG("message received from pid %d, not from kernel",
				((struct sockaddr_nl *)msg.msg_name)->nl_pid);
			break;
		}

		net_process_nlmsg((struct nlmsghdr *)buf, ret);
	}

	free(buf);

	return TRUE;
}

int net_open_ctrl_connection(struct net_ctrl_context *net_ctx)
{
	int	nlsock;
	socklen_t nladdr_len;

	nlsock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (nlsock < 0) {
		ERR("Cannot open netlink socket!");
		return -1;
	}

	memset(&net_ctx->nladdr, 0, sizeof(net_ctx->nladdr));
	net_ctx->nladdr.nl_family = AF_NETLINK;
	net_ctx->nladdr.nl_groups = RTMGRP_LINK | RTMGRP_IPV4_IFADDR;

	if (bind(nlsock, (struct sockaddr *)&net_ctx->nladdr,
					sizeof(net_ctx->nladdr)) < 0) {
		ERR("Cannot bind to netlink address!");
		close(nlsock);
		return -1;
	}

	/* Validate the Netlink kernel / user space interface */
	nladdr_len = sizeof(net_ctx->nladdr);

	if (getsockname(nlsock, (struct sockaddr *)&net_ctx->nladdr,
						&nladdr_len) < 0) {
		ERR("Did not get netlink socket name!");
		close(nlsock);
		return -1;
	}

	if (nladdr_len != sizeof(net_ctx->nladdr) ||
				net_ctx->nladdr.nl_family != AF_NETLINK) {
		ERR("Mismatch in user and kernel netlink interface!");
		close(nlsock);
		return -1;
	}

	net_ctx->nlsock = nlsock;

	return 0;
}

void net_close_ctrl_connection(struct net_ctrl_context *net_ctx)
{
	if (net_ctx->nlsock >= 0) {
		close(net_ctx->nlsock);
		net_ctx->nlsock = -1;
	}
        led_set(LED_ETH_LED, LED_OFF);
}

int net_init_ctrl_interface(struct net_ctrl_context *net_ctx,
		GIOFunc netcb)
{
	GIOChannel *channel;

	if (net_open_ctrl_connection(net_ctx) < 0) {
		DBG("Could not open network control connection!");
		return -1;
	}else{
		led_set(LED_ETH_LED, LED_ON);
	}

	channel = g_io_channel_unix_new(net_ctx->nlsock);
	if (!channel) {
		ERR("Failed to create netlink channel!");
		net_close_ctrl_connection(net_ctx);
		return -1;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);

	net_ctx->watch_source = g_io_add_watch(channel,
			G_IO_IN | G_IO_HUP | G_IO_ERR | G_IO_NVAL,
			netcb, net_ctx);

	g_io_channel_unref(channel);

	return 0;
}

void net_deinit_ctrl_interface(struct net_ctrl_context *net_ctx)
{
	net_close_ctrl_connection(net_ctx);

	g_source_remove(net_ctx->watch_source);
}

int net_init(net_event_cbs_t *necbs)
{
	net_init_ctrl_interface(&net_ctrl_ctx, net_event_handler);

	net_ctrl_ctx.ifsock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
	if (net_ctrl_ctx.ifsock < 0) {
		ERR("Cannot open network interface socket!");
		return -1;
	}

	net_ctrl_ctx.necbs = *necbs;

	return 0;
}

void net_deinit(void)
{
	net_deinit_ctrl_interface(&net_ctrl_ctx);

	close(net_ctrl_ctx.ifsock);
	net_ctrl_ctx.ifsock = -1;

	memset(&net_ctrl_ctx.necbs, 0, sizeof(net_event_cbs_t));
}

/**
 * Get the IP address associated with the specified interface.
 */

int net_get_ip_addr(char *iface, struct in_addr *ip4_addr)
{
	struct ifreq ifr;
	struct sockaddr_in *sin;

	/* Get an IPv4 IP address */
	memset(&ifr, 0, sizeof(ifr));
	ifr.ifr_addr.sa_family = AF_INET;
	strncpy(ifr.ifr_name, iface, IFNAMSIZ-1);

	if (ioctl(net_ctrl_ctx.ifsock, SIOCGIFADDR, &ifr) < 0) {
		DBG("Failed to get IP address for %s!", iface);
		return -1;
	}

	sin = (struct sockaddr_in *)&ifr.ifr_addr;
	memcpy(ip4_addr, &sin->sin_addr, sizeof(struct in_addr));

	DBG("IP Address on %s: %s\n", iface,
		inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));

	return 0;
}

int net_get_bcast_addr(char *iface, struct in_addr *ip4_bcastaddr)
{
	struct ifreq ifr;
	struct sockaddr_in *sin;

	/* Get an IPv4 Broadcast IP address */
	memset(&ifr, 0, sizeof(ifr));
	ifr.ifr_addr.sa_family = AF_INET;
	strncpy(ifr.ifr_name, iface, IFNAMSIZ-1);

	if (ioctl(net_ctrl_ctx.ifsock, SIOCGIFBRDADDR, &ifr) < 0) {
		DBG("Failed to get broadcast IP address for %s!", iface);
		return -1;
	}

	sin = (struct sockaddr_in *)&ifr.ifr_addr;
	memcpy(ip4_bcastaddr, &sin->sin_addr, sizeof(struct in_addr));

	DBG("Broadcast IP Address on %s: %s\n", iface,
		inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));

	return 0;
}

/**
 * Set the IP address associated with the specified interface.
 */

int net_set_ip_addr(char *iface, const char *ipaddr, const char *netmask)
{
	struct ifreq ifr;
	struct sockaddr_in *sin;

	/* Get an IPv4 IP address */
	memset(&ifr, 0, sizeof(ifr));
	ifr.ifr_addr.sa_family = AF_INET;
	strncpy(ifr.ifr_name, iface, IFNAMSIZ-1);

	sin = (struct sockaddr_in *)&ifr.ifr_addr;

	/* Set the IP Address */
	sin->sin_addr.s_addr = inet_addr(ipaddr);

	if (ioctl(net_ctrl_ctx.ifsock, SIOCSIFADDR, &ifr) < 0) {
		ERR("Failed to set IP address for %s!", iface);
		return -1;
	}

	/* Set the Netmask */
	sin->sin_addr.s_addr = inet_addr(netmask);

	if (ioctl(net_ctrl_ctx.ifsock, SIOCSIFNETMASK, &ifr) < 0) {
		ERR("Failed to set Netmask for %s!", iface);
		return -1;
	}

	return 0;
}

/**
 * Add a Gateway route
 */

int net_set_gw_addr(const char *dstaddr, const char *gwaddr)
{
	struct rtentry rt;
	struct sockaddr_in *sin;

	memset(&rt, 0, sizeof(rt));

	sin = (struct sockaddr_in *)&rt.rt_gateway;
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = inet_addr(gwaddr);

	sin = (struct sockaddr_in *)&rt.rt_dst;
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = INADDR_ANY; //inet_addr(dstaddr);

	sin = (struct sockaddr_in *)&rt.rt_genmask;
	sin->sin_family = AF_INET;
	sin->sin_addr.s_addr = INADDR_ANY;

	rt.rt_flags = RTF_UP | RTF_GATEWAY;
	rt.rt_metric = 100;
        rt.rt_dev = "eth0";

	if (ioctl(net_ctrl_ctx.ifsock, SIOCDELRT, &rt) < 0) {
		perror("Failed to delete route to gateway!");
	}

	if (ioctl(net_ctrl_ctx.ifsock, SIOCADDRT, &rt) < 0) {
		perror("Failed to add route to gateway!");
		return -1;
	}

	return 0;
}

/*int set_if_state(char *ifname, short upordown)
{
	return set_if_flags(ifname, upordown ? IFF_UP : 0);
}

int set_if_flags(char *ifname, short flags)
{

	int skfd = -1;      /* AF_INET socket for ioctl() calls.*/
/*	struct ifreq ifr;
	int res = 0;

	ifr.ifr_flags = flags;
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ);

	if ((skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		printf("socket error %s\n", strerror(errno));
		res = 1;
		goto out;
	}

	res = ioctl(skfd, SIOCSIFFLAGS, &ifr);
	if (res < 0) {
		printf("Interface '%s': Error: SIOCSIFFLAGS failed: %s\n",
				ifname, strerror(errno));
	} 
out:

	return res;
}*/
int validate_ip(char* ipaddr)
{
   int num, dots = 0;
   char *ptr;
   if (ipaddr== NULL)
      return 0;
   ptr = strtok(ipaddr, "."); //cut the string using dor delimiter
      if (ptr == NULL){
	 printf("### %s, %d", __func__, __LINE__);
         return 0;
      }
   while (ptr) {
      if (!validate_ip_range(ptr)) //check whether the sub string i holding only number or not
         return 0;
         num = atoi(ptr); //convert substring to number
         if (num >= 0 && num <= 255) {
            ptr = strtok(NULL, "."); //cut the next part of the string
            if (ptr != NULL)
               dots++; //increase the dot count
         } else{
           printf("### %s, %d\n", __func__, __LINE__);
            return 0;
	 }
    }
    if (dots != 3){ //if the number of dots are not 3, return false
  	printf("### %s, %d\n", __func__, __LINE__);
       	    return 0;
    }
  return 1;
}

int validate_ip_range(char* ipaddr)
{

  while (*ipaddr) {
/*     if(*ipaddr >= '0' && *ipaddr <= '9'){
	    ++ipaddr;
      }
      else{  
         printf("### %s, %d ,%s\n", __func__, __LINE__,ipaddr);
	      return 0;
      }*/
     if(!isdigit(*ipaddr)){
         return 0;
     }	 
      ipaddr++; //point to next character
   }
   return 1;
}     
/**
 * Get the network link status of the interface specified in ifname.
 *
 * @param ifname Name of interface whose status is to be checked.
 *
 * @return Returns a 0 if the interface link is down and a 1 if the interface
 * link is up.  On error a -1 is returned.
 */

int net_get_link_status(char *ifname)
{
	struct ifreq	ifr;

	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ-1);

	if (ioctl(net_ctrl_ctx.ifsock, SIOCGIFFLAGS, &ifr) < 0) {
		DBG("Failed to get interface '%s' flags! Reason: %s", ifname,
				strerror(errno));

		return -1;
	}

	DBG("Interface=%s ifi_flags=%08x Link Status: %s",
			ifname, ifr.ifr_flags,
			(ifr.ifr_flags & NET_LINK_UP) ? "UP" : "DOWN");

	return (ifr.ifr_flags & NET_LINK_UP) ? 1 : 0;
}

/**
 * Get the Network Interface MAC address of the specified ifname.
 */

int net_get_mac_addr(char *ifname, unsigned char *mac)
{
	struct ifreq	ifr;

	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ-1);

	if (ioctl(net_ctrl_ctx.ifsock, SIOCGIFHWADDR, &ifr) < 0) {
		DBG("Failed to get interface '%s' MAC address! Reason: %s",
				ifname, strerror(errno));

		return -1;
	}

	memcpy(mac, ifr.ifr_hwaddr.sa_data, S_MACADDR);

	DBG("Interface=%s MAC:" MACFMT, ifname, mac[0], mac[1], mac[2],
				mac[3], mac[4], mac[5]);

	return 0;
}

/**
 * Get the network address status of the interface specified in ifname.
 *
 * @param ifname Name of interface whose status is to be checked.
 *
 * @return Returns a 0 if the interface does not have an IP address and a 1 if
 * the interface has an IP address.  On error a -1 is returned.
 */

int net_get_addr_status(char *ifname)
{
	struct ifaddrs *ifaddrs, *ifa;
	int ret = 0;

	if (getifaddrs(&ifaddrs) < 0) {
		ERR("Failed to get address list!");
		return -1;
	}

	for (ifa = ifaddrs; ifa != NULL; ifa = ifa->ifa_next) {
		if (ifa->ifa_name == NULL) {
			WARN("Interface with no name found!");
			continue;
		}

		if (!strcmp(ifname, ifa->ifa_name)) {

			if (!(ifa->ifa_flags & IFF_UP) ||
					!(ifa->ifa_flags & NET_LINK_UP) ||
					!(ifa->ifa_flags & IFF_DORMANT) ||
					ifa->ifa_addr == NULL)
				ret = 0;
			else
				ret = 1;
			break;
		}
	}

	freeifaddrs(ifaddrs);

	return ret;
}

int net_nametoindex(char *ifname)
{
	int ret;
	struct if_nameindex *ni, *i;

	ni = if_nameindex();
	if (ni == NULL) {
		ERR("Unable to get network nameindex table!");
		return -1;
	}

	for (i = ni; !(i->if_index == 0 && i->if_name == NULL); i++) {
		if (!strcmp(ifname, i->if_name))
			break;
	}

	ret = (i->if_name == NULL) ? -1 : i->if_index;

	if_freenameindex(ni);

	return ret;
}
