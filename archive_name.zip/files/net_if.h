/**
 * @file net_if.h
 *
 * Copyright (c) 2020, Global Edge Software Ltd.
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _G3D_NET_IF_H_
#define	_G3D_NET_IF_H_

#include	<glib.h>
#include	<gio/gio.h>

#include	"g3d.h"

#define	NET_IF_PORT		9000
#define	MAX_NET_IF_CONNECTIONS	1

#ifndef HFCP_PKT_SIZE
#define HFCP_PKT_SIZE		512
#endif

struct net_if_context {
#if NO_GSOCKET_AVAILABLE
	int ifsock;		/* net_if server socket */
	struct sockaddr_in ifaddr;	/* server address */
#endif

	GSocketService *ifservice;
	GSocketConnection *connection;

	GIOChannel *client_channel;	/* Connected Client channel */
	guint watch_source;		/* watch_source Connected Client */
	int rxbytes;
	guint8 rxbuf[HFCP_PKT_SIZE];
};

typedef struct net_if_context net_if_context_t;

int net_if_init(void);
void net_if_deinit(void);
ssize_t net_if_write(const void *, size_t );

#endif /* _G3D_NET_IF_H_ */

