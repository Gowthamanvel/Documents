/**
 * @file g3d.c
 *
 * Garuda3 Interface Daemon.
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include	<stdio.h>
#include	<stdlib.h>
#include	<errno.h>
#include	<unistd.h>
#include	<glib.h>
#include	<sys/signalfd.h>

#include	"g3d.h"
#include	"net_if.h"
#include	"data_logger.h"
#include	"led.h"
#include 	"kwp_if.h"
/* Global G3d board information and context */
gboolean G3_board_info_valid;
G3BoardInfo_t G3BI;
G3dContext_t G3dCtx;

const char *CSZ_0 = "0";
const char *CSZ_1 = "1";
const char *CSZ_logpriority[8] = {
	"EMERG:",
	"ALERT:",
	"CRIT:",
	"ERROR:",
	"WARN:",
	"NOTICE:",
	"INFO:",
	"DEBUG:"
};

ConfigInfo_t CfgInfo[] = {
	{ "USBHID_IF",		"/dev/hidg0" },
	{ "CAN0_IF",		"can0"	},
	{ "CAN1_IF",		"can1"	},
};

#define	MAX_CONFIGINFO		ARRAY_SIZE(CfgInfo)

/* Module declarations */
static int G3dLock = -1;
static guint SignalSource;

void undaemonize(void)
{
	if (G3dLock >= 0) {
		close(G3dLock);
		G3dLock = -1;
		unlink(LOCK_FILE);
	}

	if (G3dCtx.Daemon & DAEMON_SYSLOG) {
		closelog();
	}
}

#define	S_IRDWR		00600

static int daemonize(void)
{
	int syslog = (G3dCtx.Daemon & DAEMON_SYSLOG) ? 1 : 0;

	/* If syslog is enabled - close stdio */
	if (daemon(0, syslog ? 0 : 1)) {
		fprintf(stderr, "daemon: %s", strerror(errno));
		exit(1);
	}

	if (syslog)
		openlog(LOG_TAG, 0, LOG_DAEMON);

	INFO("Starting g3d...");

	G3dLock = open(LOCK_FILE, O_CREAT|O_EXCL|O_WRONLY, S_IRDWR);
	if (G3dLock < 0) {
		INFO("Cannot open lock file %s: %s",
				LOCK_FILE, strerror(errno));
		exit(1);
	}

	atexit(undaemonize);

	return 0;
}

static void display_usage(char *cmd)
{
	fprintf(stderr, "Usage: %s [-C configfile -b bitrate -d|D]\n", cmd);
	fprintf(stderr, "\tconfigfile : specify config file to use\n");
	fprintf(stderr, "\tbitrate : 100000, 125000, 250000, 500000, "\
			"800000, 1000000\n");
	fprintf(stderr, "\t-d\t: run as daemon with stderr logging\n");
	fprintf(stderr, "\t-D\t: run as daemon with syslog logging\n");
}

int process_command_line(int argc, char *argv[], char *arge[])
{
	int opt;
	char *opts = "C:b";

	G3dCtx.Daemon = 0;
	G3dCtx.can_bitrate = 0;

	while ((opt = getopt(argc, argv, opts)) != -1) {
		switch (opt) {
		case 'C': /* config file */
			G3dCtx.configfile = optarg;
			break;
		case 'b':
			G3dCtx.can_bitrate = atol(optarg);
			break;
		case 'D' : /* daemonize - with syslog enabled */
			G3dCtx.Daemon |= DAEMON_SYSLOG;
			/* FALL THROUGH */
		case 'd' : /* damonize - with stdio logging */
			G3dCtx.Daemon |= DAEMON_ENABLE;
			break;
		default:
			display_usage(argv[0]);
			exit(1);
		}
	}

	return 0;
}

static const char * const Platforms[] = {
	"sama5-evk1",
	"sama5-evk2",
	"sama5-garuda3-revA",
	"ubuntu",
};

#define	MAX_PLATFORMS	ARRAY_SIZE(Platforms)

/**
 * Setup the PLATFORM and WIFI PRESENT values in code.
 */

int process_environment(void)
{
	int i;
	char *p, *nw;

	p = getenv("PLATFORM");
	if (p == NULL) {
		ERR("Environment variable PLATFORM not set!");
		exit(1);
	}

	nw = getenv("NXPWIFI_PRESENT");
	if (nw == NULL) {
		ERR("Environment variable NXPWIFI_PRESENT not set!");
		exit(1);
	}

	//INFO("PLATFORM=%s\nNXPWIFI_PRESENT=%s\n", p, nw);

	for (i = 0; i < MAX_PLATFORMS; i++) {
		if (!strcmp(p, Platforms[i]))
			break;
	}

	if (i == MAX_PLATFORMS) {
		ERR("PLATFORM set to unknown platform (%s)!", p);
		exit(1);
	}

	G3dCtx.Platform = i;

	if (*nw == 'y' || *nw == 'Y')
		G3dCtx.NxpWifi = 1;
	else
		G3dCtx.NxpWifi = 0;

	for (i = 0; i < MAX_CONFIGINFO; i++) {
		p = getenv(CfgInfo[i].name);

		if (p)
			CfgInfo[i].value = p;
	}

	return 0;
}

static gboolean signal_handler(GIOChannel *channel, GIOCondition cond,
				gpointer user_data)
{
	struct signalfd_siginfo si;
	ssize_t result;
	int fd;

	if (cond & (G_IO_NVAL | G_IO_ERR | G_IO_HUP))
		return FALSE;

	fd = g_io_channel_unix_get_fd(channel);
	if (fd < 0) {
		ERR("g_io_channel_unix_get_fd failed");
		return FALSE;
	}
	result = read(fd, &si, sizeof(si));
	if (result != sizeof(si)) {
		ERR("g_io_channel_unix_get_fd failed READ");
		return FALSE;
	}

	switch (si.ssi_signo) {
	case SIGINT:
	case SIGTERM:
	case SIGHUP:
		if (!G3dCtx.Terminate) {
			DBG("Received Signal - Terminating...");
			g_main_loop_quit(G3dCtx.main_loop);
			G3dCtx.Terminate = TRUE;
		}
		break;
	default:
		INFO("Unhandled signal %d", si.ssi_signo);
		break;
	}

	return TRUE;
}

static guint signals_init(void)
{
	int		sigfd;
	GIOChannel	*channel;
	sigset_t	sigmask;
	guint		signal_watch_source;

	sigemptyset(&sigmask);
	sigaddset(&sigmask, SIGINT);
	sigaddset(&sigmask, SIGTERM);
	sigaddset(&sigmask, SIGHUP);

	if (sigprocmask(SIG_BLOCK, &sigmask, NULL) < 0) {
		perror("Failed to initialize signals");
		return -1;
	}

	sigfd = signalfd(-1, &sigmask, 0);
	if (sigfd < 0) {
		perror("signalfd() failed!");
		return -1;
	}

	channel = g_io_channel_unix_new(sigfd);
	if (!channel) {
		fprintf(stderr, "Failed to create signal channel!");
		return -1;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);

	signal_watch_source = g_io_add_watch(channel,
			G_IO_IN | G_IO_HUP | G_IO_ERR | G_IO_NVAL,
			signal_handler, NULL);

	g_io_channel_unref(channel);

	return signal_watch_source;
}

static void signals_deinit(guint SigalSource)
{
	g_source_remove(SigalSource);
}

static void net_link_status_changed(int if_idx, gboolean state)
{
	DBG("Network %d link status changed - %d!", if_idx, state);
	if(state == 1)
	{
		led_set(LED_ETH_LED,LED_ON);
	}
	else
	{
		led_set(LED_ETH_LED, LED_OFF);
	}
}

static void net_addr_status_changed(int if_idx, gboolean state)
{
	DBG("Network %d address changed - %d!", if_idx, state);

	doip_cli_addr_status_changed(if_idx, state);
}

#define	FIRST_BINFO_MTD		5

static gboolean get_g3_board_info(void)
{
	int i, count;
	int bifd;
	char bidev[16];

	memset(&G3BI, 0, sizeof(G3BI));

	i = FIRST_BINFO_MTD;

	for (i = FIRST_BINFO_MTD; ; i++) {
		snprintf(bidev, sizeof(bidev), "/dev/mtd%d", i);
		if ((bifd = open(bidev, O_RDONLY)) < 0) {
			ERR("Failed to open Board Information device %s!", bidev);
			break;
		}

		count = read(bifd, &G3BI, sizeof(G3BI));

		close(bifd);

		if (count != sizeof(G3BI)) {
			ERR("Failed to read Board Information on %s!", bidev);
			continue;
		}

		if (G3BI.magic == G3BI_MAGIC) {
			INFO("SVersion: %08x G3Version: %08x", G3BI.version, G3BI.g3version);
			INFO("Serial No: %.11s", G3BI.sno);
			return TRUE;
		}
	}

	return FALSE;
}

static int program_init(void)
{
#ifdef CONFIG_NET
	net_event_cbs_t necbs;

	necbs.link_status = net_link_status_changed;
	necbs.addr_status = net_addr_status_changed;
#endif

	if ((G3_board_info_valid = get_g3_board_info())) {
		//ERR("Failed to read G3 Board information!");
		/** @TODO: Continue for now.  Later abort here. */
	}
	if (
#ifdef CONFIG_USBHID
		usbhid_init() ||
#endif
#ifdef CONFIG_CAN
		can_if_init(G3dCtx.can_bitrate) ||
#endif
#ifdef CONFIG_DOIP
		doip_cli_init() ||
#endif
#ifdef CONFIG_NETIF
		net_if_init() ||
#endif
#ifdef CONFIG_BT
		bt_init() ||
#endif
#ifdef CONFIG_NET
		net_init(&necbs) ||
#endif
//#ifdef CONFIG_GPIO
//		gpio_init() ||
//#endif

#ifdef CONFIG_KWP
		kwp_init() ||
#endif

#ifdef CONFIG_LED
		led_init() ||
#endif
		0
				) {
		ERR("Initialization!");
		return -1;
	}

//	g_timeout_add(2000, periodic_timer_handler, NULL);


	//INFO("done");
	return 0;
}

/*
periodic_timer_handler(gpointer data)

{
	g_print("Periodic Timer Handler\n");
}

*/
void program_deinit(void)
{
#ifdef CONFIG_LED
	led_deinit();
#endif
//#ifdef CONFIG_GPIO
//	gpio_deinit();
//#endif
#ifdef CONFIG_NET
	net_deinit();
#endif
#ifdef CONFIG_BT
	bt_deinit();
#endif
#ifdef CONFIG_DOIP
	doip_cli_deinit();
#endif
#ifdef CONFIG_CAN
	can_if_deinit();
#endif
#ifdef CONFIG_NETIF
	net_if_deinit(); 
#endif
#ifdef CONFIG_USBHID
	usbhid_deinit();
#endif
#ifdef CONFIG_KWP
        kwp_deinit();
#endif

}

int main(int argc, char *argv[], char *arge[])
{
//	process_environment();

	process_command_line(argc, argv, arge);

	SignalSource = signals_init();
	if (!SignalSource) {
		fprintf(stderr, "Signal Initialization failed!\n");
		exit(1);
	}

	if (G3dCtx.Daemon & DAEMON_ENABLE)
		daemonize();

	DEBUG_init();

	g_log_set_debug_enabled(TRUE);

	G3dCtx.main_loop = g_main_loop_new(NULL, FALSE);
	if (!G3dCtx.main_loop) {
		fprintf(stderr, "Mainloop creation failed!\n");
		exit(1);
	}

	if (program_init()) {
		DBG("Program initialization failed!\n");
		exit(1);
	}

	DBG("Entering g3d loop...");
//	g_timeout_add(2000, periodic_timer_handler, NULL);


	g_main_loop_run(G3dCtx.main_loop);

	program_deinit();

	DEBUG_deinit();

	/* undemonize() - is called using atexit() */

	signals_deinit(SignalSource);

	exit(0);
}

