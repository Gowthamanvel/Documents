/**
 * @file j2534_filter.h
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _J2534_FILTER_H_
#define _J2534_FILTER_H_

#include	<stdint.h>
#include	"hfcp.h"

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* Number of J2534 PASSTHRU Message Filters */
#define J2534_NUM_FILTER      10

/* = (Number of byte that will be verified  by the J2534 filters)/4 */
/* As per the present configuration 12 bytes are verified by the J2534 filters */
#define J2534_MSGLEN          12

/* Determine Minimum */

#ifndef MIN
#define MIN(x, y) (((x) < (y)) ? (x) : (y))
#endif

/* Number of Channels Used in Garuda */
//#define NO_OF_CHANNEL_USED 7   // 4 + 2 (for J1939 protocol CH1 and CH2) + 1 (9141)

/* J2534 filter types */
typedef enum {
	J2534_PASS_FILTER = 1,
	J2534_BLOCK_FILTER
} J2534_filterType_t;

/* J2534 filter structure */
typedef struct {
	uint32_t Protocol_ID;		/* Protocol ID as Per J2534 */
	J2534_filterType_t filterType;	/* J2534 filter type */
	uint8_t MaskLen;		/* Mask message length */
	uint8_t maskMsg[12];		/* Mask message */
	uint8_t PatternLen;		/* Pattern message length */
	uint8_t patternMsg[12];		/* Pattern message */
} J2534_filter_t;

/* Error encountered while J2534 filter configuration */
typedef enum {
	J2534_NO_ERROR,		/* Desire operation is done successfully */
	J2534_FLT_NOT_FREE,	/* All j2534 filters are in use */
	J2534_INVLD_FLTID,	/*
				 * Invalid filter ID (either the filter ID
				 * is out of the permissible range or the
				 * filter isn't configured)
				 */
	J2534_INVLD_FLT_TYPE,	/* Invalid filtertype */
	J2534_INVLD_PRID	/* The Wrong Protocol ID */
} J2534_stError_t;

/* Resultant action of J2534 filtering */
typedef enum {
	J2534_BLOCK,		/* Message is blocked by j2534 filters */
	J2534_PASS,		/* Message is passed through j2534 filters  */
	GARUDA_INVALID_CH	/* Channel is not Used */
} J2534_rsltFilter_t;


J2534_stError_t J2534_ClearAllFilter(uint32_t p_J2534PrID);
#if 0
J2534_rsltFilter_t J2534_checkFilter(uint8_t *, uint16_t, GARUDA_ChannelNum_t);
#else
J2534_rsltFilter_t J2534_checkFilter(uint8_t *p_pJ2534Msg, uint8_t *pNameId,
		uint16_t p_MsgLen, GARUDA_ChannelNum_t GarudaChannel);
#endif
J2534_stError_t J2534_ConfigFilter(const J2534_filter_t *p_pFilter,
		uint8_t *p_pFilterID);
J2534_stError_t J2534_ClearFilter(uint32_t p_filterID, uint16_t p_J2534PrID);

#endif /* _J2534_FILTER_H_ */
