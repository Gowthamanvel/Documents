/*
 * @file doip_cli.h
 *
 * Copyright (c) 2023, Capgemini, Intelligent Devices
 */

#ifndef _DOIP_CLI_H_
#define _DOIP_CLI_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <glib.h>
#include "doip.h"

#define DOIP_CLI_IF_STATE_UP() (doip_cli_ctx.if_state == 1)

/* Including '\0' in the end of the string */
#define IPV4_STR_ADDR_LEN (16)
#define DOIP_CLI_MAX_K_ALIVE_MISS (10) /* TODO: check the spec */

/*
 * NOTE: As per spec this value should be 4 GB. Configure this based on the
 * requirement
 */
#define DOIP_DIAG_MSG_MAX_SIZE (8*1024)

typedef uint32_t DOIP_CLI_HANDLE;

/* TODO: Re-arrange the variables, if required */
struct doip_cli_context {
	uint8_t proto_ver;
	uint8_t inv_proto_ver;
	uint16_t logical_address;
	int if_idx;
	int if_state;
	char ifname[16];
	struct in_addr myip;
	int udpsock;
	uint16_t laddr; /* logical address of the DoIP client */
	GIOCondition cond;
	guint watch_source;
	GIOChannel *udp_channel;
	guint discovery_timersource;
	int stop_veh_discovery;
	doip_server_list_t *doip_slist; /* Filled from VEH-ANNO-Resp */
	uint32_t veh_announce_cnt; /* Table-12 : Number of Vehicle announcement messages sent */

	struct doip_conn_table *doip_clist;  /* DoIP server list added by HFCP */
};

typedef struct doip_cli_context doip_cli_context_t;

/* Section: 12.6.1.3 NL connection states. Fig 25 */
enum doip_cli_tcp_conn_states {
	DOIP_CONN_STATE_INITIAL = 0,
	DOIP_CONN_STATE_LISTEN = 1,
	DOIP_CONN_STATE_INITIALIZED = 2,
	DOIP_CONN_STATE_REG_PENDING_AUTH = 3,
	DOIP_CONN_STATE_REG_PENDING_CONFIRM = 4,
	DOIP_CONN_STATE_REG_PENDING_ACTIVE = 5,
	DOIP_CONN_STATE_ACTIVE = 6
};

struct doip_node {
	struct doip_node *next;
	uint16_t laddr;
};
typedef struct doip_node doip_node_t;

/* REQ: 3.DoIP-127 NL - Handling of connection table */
/* One table entry for each DoIP open session		*/
struct doip_conn_table {
	struct doip_conn_table *next; /* Next DoIP server in the list */

	doip_serv_info_t sinfo;
	char ipaddr[IPV4_STR_ADDR_LEN]; /* TODO: convert this to struct sockaddr_in */
	int tcpsock;
	int conn_state;
	GIOChannel *tcp_channel;
	GIOCondition cond;
	guint tcp_watch_source;
	uint16_t laddr; /* logical address of the DoIP client */
	uint16_t routing_act_status;

	/* Keep-Alive */
	guint keep_alive_watch_source;
	uint8_t keep_alive_got_resp;
	doip_node_t *nodelist;

	/* Filled by entity-status response */
	uint8_t node_type;
	uint8_t msts;
	uint8_t mcts;
	uint8_t ncts;
	uint32_t mds;

	uint16_t txPrevSeqNum;
	uint32_t txTotalLen;
	uint8_t txDiagBuf[DOIP_DIAG_MSG_MAX_SIZE];

	/* These variables are used in case the received data is more than 64 bytes */
	uint32_t rxProto;
	uint32_t rxCommand;   //uint32_t
	uint32_t rxTotalLen; /* Total bytes to receive */
	uint32_t rxPendingReadLen;  /* Number of bytes received */
	uint16_t rxSeqNum; /* Seq number of the last 64 byte chunk sent to app */
	uint8_t rxDiagBuf[DOIP_DIAG_MSG_MAX_SIZE];
};

typedef struct doip_conn_table doip_conn_table_t;

enum doip_cli_timer_status {
	DOIP_CLI_TIMER_STOPED = 0,
	DOIP_CLI_TIMER_STARTED = 1,
};

/* Function declarations */
int doip_cli_init(void);
int doip_cli_deinit(void);

gboolean doip_cli_addr_status_changed(int if_idx, gboolean state);
doip_conn_table_t **doip_get_connecton_list_head(void);
int doip_cli_start_tcp_connection(doip_conn_table_t *conn);
int doip_cli_stop_tcp_connection(doip_conn_table_t *conn);
int doip_cli_add_node_tolist(doip_conn_table_t *conn, uint16_t laddr);
int doip_cli_remove_node_fromlist(doip_conn_table_t *conn, uint16_t laddr);
void doip_cli_remove_all_nodes(doip_conn_table_t *conn);
int doip_cli_send_routing_act_req(doip_conn_table_t *conn, uint16_t laddr);
int doip_cli_send_diag_msg(doip_conn_table_t *conn, uint16_t dst_laddr,
				uint16_t seqNum, uint16_t lastpkt,
				uint32_t msglen, uint8_t *msg);
void doip_cli_set_logical_address(uint16_t laddr);
uint16_t doip_cli_get_logical_address(void);

#endif /* _DOIP_CLI_H_ */
