/**
 *	@file usbhid.c
 *
 *	Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include	<unistd.h>
#include	<glib.h>

#include	"g3d.h"
#include	"usbhid.h"
#include	"hfcp.h"
#include	"data_logger.h"

#ifdef USB_CHUNK_RDWR
#define USB_HID_READ_SIZE   (8)
#define USB_HID_READ_COUNT  (8)
#define USB_HID_WRITE_SIZE  (8)
#define USB_HID_WRITE_COUNT (8)
#endif

#define USB_PKT_SIZE       (512)

static USBHIDContext_t usbhidctx;

ssize_t usbhid_read(void *buf, size_t count)
{
	ssize_t ret;

	if (usbhidctx.hidfd < 0)
		return -1;

	if (buf == NULL || count <= 0) {
		DBG("Invalid parameters!");
		return -2;
	}

	for (;;) {
		ret = read(usbhidctx.hidfd, buf, count);

		if (ret > 0)
			return ret;

		if (ret == 0) {
			usbhid_reinit();
			return ret;
		}

		DBG("Read error: %s\n", strerror(errno));

		switch (errno) {
		case EINTR:
			continue;
		case EAGAIN:
			ERR("USBHID device is in NON-BLOCKING mode!");
			/* Fall through */
		case EBADF:
		case EINVAL:
		case EIO:
		default:
			usbhid_reinit();
			return -1;
		}
	}
}

static ssize_t _usbhid_write(int wfd, const void *buf, size_t count)
{
	ssize_t ret;
	ssize_t wrote;

	wrote = 0;

	for (;;) {
		ret = write(wfd, buf, count);

		if (ret >= 0) {
			wrote += ret;

			if (ret < count) {
				buf += ret;
				count -= ret;
				continue;
			}

			return wrote;
		}

		DBG("Write error: %s\n", strerror(errno));

		switch (errno) {
		case EINTR:
			continue;
		case EAGAIN:
			ERR("USBHID device is in NON-BLOCKING mode!");
			/* Fall through */
		case EBADF:
		case EINVAL:
		case EIO:
		default:
			usbhid_reinit();
			return -1;
		}
	}
}

ssize_t usbhid_write(const void *buf, size_t count)
{
/*	printf("Entered_usbhid\n");
	printf("Usbhid[4]:%d\n",*((int*)(buf+4)));
	printf("Usbhid[5]:%d\n",*((int*)(buf+5)));
	printf("Usbhid[6]:%d\n",*((int*)(buf+6)));
*/
//	printf("Usbhid[5]:%d",(int*)(buf[5]));
//	printf("Usbhid[6]:%d",(int*)(buf[6]));
	int i, npkts, bytes, ret;
	uint8_t *pkt;

	if (usbhidctx.hidfd < 0)
		return -1;

	bytes = 0;
	pkt = (uint8_t *)buf;
	npkts = (count / USB_PKT_SIZE) + 1;  /* Number of 64 byte USB frames */
#ifdef USB_CHUNK_RDWR
	/* Each USB frame of 64 bytes are transmitted 'USB_HID_WRITE_COUNT'
	 * bytes each
	 */
	npkts = npkts * USB_HID_WRITE_COUNT;
#endif

#ifdef USB_CHUNK_RDWR
	// hexdump("USB-WR", pkt, USB_PKT_SIZE, 1);
	hexdump("USB-WR", pkt, count, 1);
	for (i = 0; i < npkts; i++) {
		ret = _usbhid_write(usbhidctx.hidfd, &pkt[i*USB_HID_WRITE_SIZE],
						USB_HID_WRITE_SIZE);
		if (ret < 0) {
			ERR("_usbhid_write failed %d bytes\n", count);
			break;
		}
		bytes += USB_HID_WRITE_SIZE;
	}
#else
	for (i = 0; i < npkts; i++) {
		//hexdump("USB-WR", &pkt[i*USB_PKT_SIZE], USB_PKT_SIZE, 1);
		hexdump("USB-WR", &pkt[i*USB_PKT_SIZE], count, 1);
		ret = _usbhid_write(usbhidctx.hidfd, &pkt[i*USB_PKT_SIZE],
				USB_PKT_SIZE);
		if (ret < 0) {
			ERR("_usbhid_write failed %lu bytes\n", count);
			break;
		}
		bytes += USB_PKT_SIZE;
	}
#endif

	return bytes;
}

static gboolean usbhid_data_handler(GIOChannel *channel,
		GIOCondition cond, gpointer data)
{
	USBHIDContext_t *ctx = (USBHIDContext_t *)data;
	int len;
#ifdef USB_CHUNK_RDWR
	int ret, i;
#endif

	/* TODO: Validate usbhidctx.state */

	switch (cond) {
	case G_IO_IN:
		/* Read from USB */
		memset(ctx->buf, 0, sizeof(ctx->buf));

		/* read 64 bytes */
#ifdef USB_CHUNK_RDWR
		len = 0;
		/** @TODO: If this is never going to be used remove it */
		for (i = 0; i < USB_HID_READ_COUNT; i++) {
			ret = usbhid_read(&ctx->buf[i*USB_HID_READ_SIZE],
						USB_HID_READ_SIZE);
			if (ret != USB_HID_READ_SIZE) {
				ERR("USB Read failed!");
				break;
			}
			len += USB_HID_READ_SIZE;
		}
#else
		len = usbhid_read(&ctx->buf[0], USB_PKT_SIZE);
		if (len != USB_PKT_SIZE) {
			ERR("USB Read failed!");
			break;
		}
#endif
		if (len) {
#if 0
			led_set(LED_USB_LED, LED_OFF);
			led_set(LED_WLANBT_LED, LED_OFF);
			led_set(LED_USB_LED, LED_ON);
#endif
			hexdump("USB-RD", ctx->buf, len, 1);
			handle_hfcp_rx(ctx->buf, len);
		}
		break;
	case G_IO_OUT:
	case G_IO_PRI:
	case G_IO_ERR:
	case G_IO_HUP:
	case G_IO_NVAL:
		return FALSE;
	}

	return TRUE;
}

static gboolean usbhid_timer_handler(gpointer data)
{
	int fd;
	USBHIDContext_t *ctx = (USBHIDContext_t *)data;
	GIOChannel *channel;

	if (G3dCtx.Terminate)
		return G_SOURCE_REMOVE;

	/* If not opened - open the usbhid device */
	if (ctx->hidfd < 0)
		ctx->hidfd = open(ctx->hiddevname, O_RDWR);

	fd = ctx->hidfd;
	if (fd < 0) {
		DBG("Garuda3 not connected to host! Will retry later...(%s)\n",
				ctx->hiddevname);
		ctx->state = USBHID_DISCONNECTED;
		return G_SOURCE_CONTINUE;
	}

	channel = g_io_channel_unix_new(fd);
	if (!channel) {
		ERR("Failed to create g_io_channel for USBHID!\n");
		usbhid_deinit();
		return G_SOURCE_CONTINUE;
	}

	g_io_channel_set_close_on_unref(channel, TRUE);
	g_io_channel_set_encoding(channel, NULL, NULL);
	g_io_channel_set_buffered(channel, FALSE);

	ctx->watch_source = g_io_add_watch(channel, ctx->cond,
				usbhid_data_handler, ctx);

	g_io_channel_unref(channel);

	ctx->state = USBHID_CONNECTED;

	//INFO("Garuda3 HID connection established! Stopping timer...\n");
	/* Once the HID is connected then remove the timer and restart	*/
	/* it when HID connect loss is detected.			*/
	return G_SOURCE_REMOVE;
}

int usbhid_init(void)
{
	/**
	 * TODO: check if this can be replaced by udev monitoring of
	 * the gadget driver getting triggered.
	 * https://www.collabora.com/news-and-blog/blog/2019/02/18/modern-usb-gadget-on-linux-and-how-to-integrate-it-with-systemd-part-1/
	 */
	guint timersource;

	usbhidctx.hidfd = -1;
	usbhidctx.state = USBHID_DISCONNECTED;
	usbhidctx.cond = G_IO_PRI | G_IO_IN;
	usbhidctx.hiddevname = CfgInfo[CFG_USBHID_IF].value;
	timersource = g_timeout_add_seconds(USBHID_MONITOR_PERIOD,
			usbhid_timer_handler, &usbhidctx);

	if (timersource < 0) {
		ERR("Failed to create USBHID timer source!");
		return -1;
	}

	usbhidctx.timersource = timersource;

	HFCP_setApplicationMode(GARUDA_IN_USB_MODE);

	return 0;
}

int usbhid_reinit(void)
{
	usbhid_deinit();
	return usbhid_init();
}

void usbhid_deinit(void)
{
	close(usbhidctx.hidfd);
	usbhidctx.hidfd = -1;

	usbhidctx.state = USBHID_DISCONNECTED;
}


