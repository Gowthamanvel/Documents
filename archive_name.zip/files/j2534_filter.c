/**
 * @file j2534_filter.c
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include <stdio.h>
#include "j2534_filter.h"
#include "g3d.h"

/******************************************************************************
*               I N T E R N A L   D E F I N I T I O N S
*******************************************************************************/
/* A local structure to uphold J2534 filters and their status */
typedef struct
{
  J2534_filter_t filter;
  uint8_t        inUse;           /* If inUse = FALSE --> filter is cleared   */
                                  /* If inUse = TRUE --> filter is configured */
} J2534_filterTable_t;


/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
/* J2534 filter table for no of Garuda Channels */
J2534_filterTable_t  l_filterTable[NO_OF_CHANNEL_USED][J2534_NUM_FILTER];


extern uint32_t GarudaProID_Used[NO_OF_CHANNEL_USED];

/******************************************************************************
*                   E X P O R T E D   VARIABLES
*******************************************************************************/

extern uint8_t AdressClaimInitiated;
extern uint8_t AdressClaimStatus;


/******************************************************************************
* Function name   : J2534_stError_t J2534_ConfigFilter(J2534_filter_t* p_pFilter,uint8_t* p_pFilterID)
* returns         : J2534_stError_t:
*                         - J2534_NO_ERROR: j2534 filter is configured successfuly
*                         - J2534_FLT_NOT_FREE: All j2534 filters are in use.
*                         - J2534_INVLD_FLT_TYPE : The Filter type passed is not Block/Pass
*                         - J2534_INVLD_PRID  : The Protocol ID Unknown to Filter Module
* p_pFilter       : Pointer to a j2534 filter structure
* p_pFilterID     : To Hold the Filter ID
* Description     : This function configures a j2534 filter (Pass or Block).
* Notes           :
*******************************************************************************/

J2534_stError_t J2534_ConfigFilter(const J2534_filter_t* p_pFilter,
                                   uint8_t* p_pFilterID)
{
    uint8_t fl_numFilter = 0;
    uint8_t fl_CheckIndex;
    /* find the Protocol Table Index using the Protocol ID */
    
    for(fl_CheckIndex=0;fl_CheckIndex<NO_OF_CHANNEL_USED;fl_CheckIndex++)
    {
	DBG("Current_ID(0x%x) == IDfrom_List(0x%x)\n",p_pFilter->Protocol_ID,GarudaProID_Used[fl_CheckIndex]);
        if(p_pFilter->Protocol_ID==GarudaProID_Used[fl_CheckIndex])
	    {
	        /* The Protocol ID Matched @fl_CheckIndex*/
			DBG("Protocol ID matched.\n");
            break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_CheckIndex==NO_OF_CHANNEL_USED) {
		DBG("Invalid protocol ID.\n");
		return J2534_INVLD_PRID;
	}
DBG("l_filterTable[%d]",fl_CheckIndex);
    /* Look for an unused filter */
    while((fl_numFilter < J2534_NUM_FILTER) &&
         (FALSE != l_filterTable[fl_CheckIndex][fl_numFilter].inUse))
    {
        fl_numFilter++;
    }
    /* The Maximum No of Filters Used */
    if(fl_numFilter >= J2534_NUM_FILTER)
    {
        return J2534_FLT_NOT_FREE;    /* All filters are in use */
    }
    else
    {
        /* Check for PASS or BLOCK */
        if((p_pFilter->filterType == J2534_PASS_FILTER) ||
           (p_pFilter->filterType == J2534_BLOCK_FILTER))
        {
            /* Configure a j2534 filter */
            l_filterTable[fl_CheckIndex][fl_numFilter].filter = *p_pFilter;

            l_filterTable[fl_CheckIndex][fl_numFilter].inUse = TRUE;
            *p_pFilterID = fl_numFilter + 1;
        }
        /* Filtertype is not PASS/BLOCK */
        else
        {
            return J2534_INVLD_FLT_TYPE;
        }

    }
    return J2534_NO_ERROR;
}


/******************************************************************************
* Function name   : J2534_stError_t J2534_ClearFilter(uint32_t p_filterID,uint8_t p_J2534PrID)
* returns         : J2534_stError_t:
*                         - J2534_NO_ERROR: j2534 fiter is cleared successfuly
*                         - J2534_INVLD_FLTID: Invalid filter ID (either the
*                           filter ID is out of the permissible range or the
*                           filter isn't configured)
*                         - J2534_INVLD_PRID  : The Protocol ID Unknown to Filter Module
* p_filterID      : J2534 filter identifier
* p_J2534PrID     : J2534 Protocol ID
* Description     : This function releases the j2534 filter with the given
*                     filter ID.
* Notes           :
*******************************************************************************/
J2534_stError_t J2534_ClearFilter(uint32_t p_filterID,uint16_t p_J2534PrID)
{
  J2534_stError_t fl_stError;
  uint8_t         fl_numFilter;
  uint8_t         fl_CheckIndex;
  /* find the Protocol Table Index using the Protocol ID */
  for(fl_CheckIndex=0;fl_CheckIndex<NO_OF_CHANNEL_USED;fl_CheckIndex++)
  {
	  DBG("Current_ID=0x%x\tID_fromList=0x%x\n",p_J2534PrID,GarudaProID_Used[fl_CheckIndex]);
      if(p_J2534PrID==GarudaProID_Used[fl_CheckIndex])
	  {
	       /* The Protocol ID Matched @fl_CheckIndex*/
            break;
	  }
  }
  /* The Protocol ID is not in the Table */
  if(fl_CheckIndex==NO_OF_CHANNEL_USED) {
      DBG("Invalid Protocol ID.\n"); 
	  return J2534_INVLD_PRID;
  }
  /* Check for The Filter ID in the Range */
  if((p_filterID < 1) || (p_filterID > J2534_NUM_FILTER))
  {
    /* The filter ID is out of the permissible range */
    fl_stError = J2534_INVLD_FLTID;
  }
  else
  {
    fl_numFilter = p_filterID-1;

    if(FALSE != l_filterTable[fl_CheckIndex][fl_numFilter].inUse)
    {
      /* Release the j2534 filter */
      l_filterTable[fl_CheckIndex][fl_numFilter].inUse = FALSE;

      fl_stError = J2534_NO_ERROR;
    }
    else
    {
      /* The filter isn't configured */
      fl_stError = J2534_INVLD_FLTID;
    }
  }
  return fl_stError;
}


/******************************************************************************
* Function name   : J2534_stError_t J2534_ClearAllFilter(uint32_t p_J2534PrID)
*    returns      : J2534_stError_t:
*                         - J2534_NO_ERROR: j2534 fiter is cleared successfuly
*                         - J2534_INVLD_PRID  : The Protocol ID Unknown to Filter Module
*    p_filterID      : J2534 filter identifier
* Description      : This function releases the j2534 filter with the given
*                     filter ID.
* Notes         :
*******************************************************************************/
J2534_stError_t J2534_ClearAllFilter(uint32_t p_J2534PrID)
{
    uint8_t         fl_numFilter;
    uint8_t         fl_CheckIndex;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_CheckIndex=0;fl_CheckIndex<NO_OF_CHANNEL_USED;fl_CheckIndex++)
    {
        /* The Protocol ID Matched @fl_CheckIndex*/
        if(p_J2534PrID==GarudaProID_Used[fl_CheckIndex])
        {
            break;
        }
    }
    /* The Protocol ID is not in the Table */
    if(fl_CheckIndex==NO_OF_CHANNEL_USED)
        return J2534_INVLD_PRID;
    /* Release All Filters for the Protocol */
    for(fl_numFilter=0;fl_numFilter<J2534_NUM_FILTER;fl_numFilter++)
    {
        l_filterTable[fl_CheckIndex][fl_numFilter].inUse = FALSE;
    }
    return J2534_NO_ERROR;
}


/******************************************************************************
* Function name   : J2534_rsltFilter_t J2534_checkFilter(uint32_t *p_pJ2534Msg,
                                                        uint16_t p_MsgLen,
                                                        GARUDA_ChannelNum_t GarudaChannel)
* returns         : fl_rsltFilter:
*                         - J2534_BLOCK: Message is blocked by j2534 filters
*                         - J2534_PASS: Message is passed through j2534 filters
*                         - GARUDA_INVALID_CH : The Garuda Channel passed is Wrong
* p_pJ2534Msg     : Pointer to the 12 bytes (array of 3 elements of uint32_t
*                     type) of message that has to validated against j2534
*                     filters.
* p_MsgLen        : Message length
* Description     : This function validates a given 12 bytes message against
*                     j2534 filters.
* Notes           :

CAN EXT MSG ID = 0x12345678x 
				  CAN	J1939		Eg.0xCF00401	
p_pJ2534Msg[0] =  0x78	PRI3_R1_D1	0x0C
p_pJ2534Msg[1] =  0x56	PF			0xF0	
p_pJ2534Msg[2] =  0x34	PS			0x04
p_pJ2534Msg[3] =  0x12	SA			0x01

*******************************************************************************/
extern uint8_t device_claimed_Address;
extern ADDRESS_CLAIM AdressClaim;
uint64_t receivedNameIdentifier;
uint64_t configuredNameIdentifier;

#if 1
J2534_rsltFilter_t J2534_checkFilter(uint8_t *p_pJ2534Msg, uint8_t *pNameId, uint16_t p_MsgLen,
                                     GARUDA_ChannelNum_t GarudaChannel)
#else
J2534_rsltFilter_t J2534_checkFilter(uint8_t *p_pJ2534Msg, uint16_t p_MsgLen,
                                     GARUDA_ChannelNum_t GarudaChannel)
#endif
{
	J2534_rsltFilter_t  fl_rsltFilter = J2534_BLOCK;
	J2534_filterTable_t *fl_pFilterTable;
	uint8_t             fl_ctTmp;
	uint8_t             fl_FilterLen;
	uint8_t				PDU_Format_PF;
	uint8_t				PDU_Specific_PS;
	uint8_t				Dest_Addr;

    /* Check for the Channel within limit */
    if(GarudaChannel>=NO_OF_CHANNEL_USED)
    {
        return GARUDA_INVALID_CH;
    }
    
    if( (GARUDA_J1939_CH1 == GarudaChannel) || (GARUDA_J1939_CH2 == GarudaChannel)) //GARUDA_J1939_CH1
	{
		PDU_Format_PF = p_pJ2534Msg[1];
		PDU_Specific_PS = p_pJ2534Msg[2];
	
		if(PDU_Format_PF < 0xF0 )
		{
			Dest_Addr = PDU_Specific_PS;
		}
		else
		{
			Dest_Addr = GLOBAL_ADDRESS;
		}
	
		if( (TP_CON_MANAGEMENT == PDU_Format_PF) || (TP_DATA_TRANSFER == PDU_Format_PF) )					
		{
			if( (device_claimed_Address != 0xFE ) && ((GLOBAL_ADDRESS == Dest_Addr) || (device_claimed_Address == Dest_Addr)))
			{			
				fl_rsltFilter = J2534_PASS;
				return fl_rsltFilter;
			}
			else
			{
				fl_rsltFilter = J2534_BLOCK;
				return fl_rsltFilter;
			}
		}					
		else if(AdressClaimInitiated && (PDU_FORMAT_ADDRESS_CLAIM == PDU_Format_PF))	
		{
			/**< compare the Name Field and decide on the priority, for AdressClaimStatus */
#if 0
			receivedNameIdentifier =	(uint64_t)p_pJ2534Msg[4] | p_pJ2534Msg[5] << 8	| (uint64_t)p_pJ2534Msg[6] << 16  | (uint64_t)p_pJ2534Msg[7] << 24 	|
										(uint64_t)p_pJ2534Msg[8] << 32	| (uint64_t)p_pJ2534Msg[9] << 40  | (uint64_t)p_pJ2534Msg[10] << 48 	| (uint64_t)p_pJ2534Msg[11] << 56;
#else
			receivedNameIdentifier = (uint64_t)pNameId[0] |
				   					 ((uint64_t)pNameId[1] << 8) |
				   					 ((uint64_t)pNameId[2] << 16) |
				   					 ((uint64_t)pNameId[3] << 24)|
				   					 ((uint64_t)pNameId[4] << 32)|
				   					 ((uint64_t)pNameId[5] << 40)|
				   					 ((uint64_t)pNameId[6] << 48)|
				   					 ((uint64_t)pNameId[7] << 56);
#endif
			
			configuredNameIdentifier =	(uint64_t)AdressClaim.nameIdentifier[0] | (uint64_t)AdressClaim.nameIdentifier[1] << 8	| (uint64_t)AdressClaim.nameIdentifier[2] << 16  | (uint64_t)AdressClaim.nameIdentifier[3] << 24 	|
										(uint64_t)AdressClaim.nameIdentifier[4] << 32	| (uint64_t)AdressClaim.nameIdentifier[5] << 40  | (uint64_t)AdressClaim.nameIdentifier[6] << 48 	| (uint64_t)AdressClaim.nameIdentifier[7] << 56;
			
			if(configuredNameIdentifier < receivedNameIdentifier)
			{
				AdressClaimStatus = 1;
			}
			else if(configuredNameIdentifier >= receivedNameIdentifier)	
			{
				AdressClaimStatus = 2;
			}								
			else
			{
				
			}
			fl_rsltFilter = J2534_BLOCK;
			return fl_rsltFilter;
		}
        else if ( (AdressClaimInitiated==0) && (PDU_FORMAT_ADDRESS_CLAIM == PDU_Format_PF)) /**< Broadcast address request message */
        {
	        if(device_claimed_Address != 0xFE )
	        {
		        J1939_AddressClaim_Global_Response(p_pJ2534Msg,p_MsgLen, GarudaChannel);
		        /* Send the address and name on to the network */
		        // TO BE IMPLEMENTED
	        }
	        fl_rsltFilter = J2534_BLOCK;
	        return fl_rsltFilter;
        }
		else if(PDU_Format_PF < 0xF0 )
		{
			if((GLOBAL_ADDRESS == Dest_Addr) || (device_claimed_Address == Dest_Addr))
			{
				fl_rsltFilter = J2534_BLOCK;
			}
			else
			{
				fl_rsltFilter = J2534_BLOCK;
				return fl_rsltFilter;
			}			
		}
		else if(PDU_Format_PF >= 0xF0)
		{
			fl_rsltFilter = J2534_BLOCK;
		}
		else
		{	
					
		}						
	}
#ifdef DEBUG
	for (int i=0; i<J2534_NUM_FILTER; i++) {
		uint8_t *p;

DBG("l_filterTable[%d]",GarudaChannel);
		fl_pFilterTable = &(l_filterTable[GarudaChannel][i]);
		if (fl_pFilterTable->inUse == TRUE) {
			p = fl_pFilterTable->filter.patternMsg;
			DBG("patternMsg = 0x%x 0x%x 0x%x 0x%x\n", p[0], p[1], p[2], p[3]);
			DBG("p_pJ2534Msg= 0x%x 0x%x 0x%x 0x%x\n", p_pJ2534Msg[0], p_pJ2534Msg[1], p_pJ2534Msg[2], p_pJ2534Msg[3]);
		}
	}
#endif
    for(fl_pFilterTable = &(l_filterTable[GarudaChannel][0]);fl_pFilterTable < (&(l_filterTable[GarudaChannel][0]) + J2534_NUM_FILTER);fl_pFilterTable++)
    {
        if(FALSE != fl_pFilterTable->inUse)
        {
            fl_FilterLen = MIN(MIN(fl_pFilterTable->filter.MaskLen, fl_pFilterTable->filter.PatternLen), p_MsgLen );

            /* Check if the given message maches with the j2534 filter */
            for(fl_ctTmp = 0; fl_ctTmp < fl_FilterLen; fl_ctTmp++)
            {
                if( (p_pJ2534Msg[fl_ctTmp] & fl_pFilterTable->filter.maskMsg[fl_ctTmp]) ==
                    fl_pFilterTable->filter.patternMsg[fl_ctTmp])
                {
                    /* do nothing */
                }

                else                 /* Message doesn't match with the j2534 filter */
                {
                    break;
                }

            }

            if(fl_ctTmp >= fl_FilterLen)   /* Message matches with the j2534 filter */
            {
                if(J2534_PASS_FILTER == fl_pFilterTable->filter.filterType)
                {
                    /* Pass filter */
                    fl_rsltFilter = J2534_PASS;
                }
                else
                {
                    /* Block filter */
                    fl_rsltFilter = J2534_BLOCK;
                    break;
                }
            }
        }
    }
    DBG("Filter [0x%x 0x%x 0x%x 0x%x] is %s\n",
			p_pJ2534Msg[0], p_pJ2534Msg[1], p_pJ2534Msg[2], p_pJ2534Msg[3],
			(fl_rsltFilter == J2534_PASS) ? "J2534_PASS" : "J2534_BLOCK");
    return fl_rsltFilter;
}

/******************************************************************************
* Function name   : J2534_ExclusiveFilter
* returns         : NULL
* Description     : This function validates a given 12 bytes message against
*                     j2534 filters.
* Notes           : needed for J1708
*******************************************************************************/

J2534_stError_t J2534_ExclusiveFilter (void)
{
  uint8_t fl_numFilter = 0;
  J2534_stError_t fl_status_U8 = J2534_NO_ERROR;

  while((fl_numFilter < J2534_NUM_FILTER) &&
         (FALSE != l_filterTable[GARUDA_J1708][fl_numFilter].inUse))
    {
        if(l_filterTable[GARUDA_J1708][fl_numFilter].filter.filterType == J2534_PASS_FILTER)
        {
            /* Invert a j2534 PASS filter to BLOCK filter */
            l_filterTable[GARUDA_J1708][fl_numFilter].filter.filterType = J2534_BLOCK_FILTER;
            l_filterTable[GARUDA_J1708][fl_numFilter].inUse = TRUE;

            fl_status_U8 = J2534_NO_ERROR;
        }
        fl_numFilter++;
    }
    return  fl_status_U8;
}

/******************************************************************************
* Function name   : J2534_InclusiveFilter
* returns         : NULL
* Description     : This function validates a given 12 bytes message against
*                     j2534 filters.
* Notes           : needed for J1708
*******************************************************************************/

J2534_stError_t J2534_InclusiveFilter (void)
{
  uint8_t fl_numFilter = 0;
  J2534_stError_t fl_status_U8 = J2534_NO_ERROR;

  while((fl_numFilter < J2534_NUM_FILTER) &&
         (FALSE != l_filterTable[GARUDA_J1708][fl_numFilter].inUse))
    {
        if (l_filterTable[GARUDA_J1708][fl_numFilter].filter.filterType == J2534_BLOCK_FILTER)
        {
            /* Invert a j2534 BLOCK filter to PASS filter */
            l_filterTable[GARUDA_J1708][fl_numFilter].filter.filterType = J2534_PASS_FILTER;
            l_filterTable[GARUDA_J1708][fl_numFilter].inUse = TRUE;

            fl_status_U8 = J2534_NO_ERROR;
        }
        fl_numFilter++;
    }
    return  fl_status_U8;
}
