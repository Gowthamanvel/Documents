/**
 *  @file usbhid.h
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _USBHID_H_
#define	_USBHID_H_

#include	<glib.h>

#include	"g3d.h"

#define BYTE_MAX(a, b) ((a) > (b) ? (a) : (b))		/** TODO: Can this be removed.	*/

#define	USBHID_MONITOR_PERIOD	1
#define USB_PKT_SIZE		(512)
#define USB_READ_BYTES          BYTE_MAX(1024, USB_PKT_SIZE)

enum USBHID_States {
	USBHID_DISCONNECTED,
	USBHID_CONNECTED,
};

typedef enum USBHID_States USBHID_States_t;

struct USBHIDContext {
	int hidfd;
	int timeout;
	gboolean state;
	GIOCondition cond;
	guint timersource;
	guint watch_source;
	gchar *hiddevname;
	guint8 buf[USB_READ_BYTES];
};

typedef struct USBHIDContext USBHIDContext_t;

ssize_t usbhid_read(void *buf, size_t count);
ssize_t usbhid_write(const void *buf, size_t count);
int usbhid_init(void);
int usbhid_reinit(void);
void usbhid_deinit(void);

#endif /* _USBHID_H_ */

