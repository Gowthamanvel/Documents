/**
 * @file led.h
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _LED_H_
#define	_LED_H_

#define	LED_ON			1
#define	LED_OFF			0

enum LEDS {
	LED_USB_LED,
	LED_LINK_LED,
	LED_ETH_LED,
	LED_ERROR_LED,
	LED_MODEM_LED,
	LED_DATA_LED,
	LED_WLANBT_LED,
	LED_MAX_LEDS
};

int led_set(int led, int brightness);
int led_init(void);
void led_deinit(void);

#endif /* _LED_H_ */

