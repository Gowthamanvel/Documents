/**
 *  @file data_logger.h
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#ifndef _DATA_LOGGER_H_
#define _DATA_LOGGER_H_

#include <stdio.h>
#include <time.h>

#ifdef DEBUG
void hexdump(char *prompt, void *ptr, int len, int file);
#else
#define hexdump(a, b, c, d)
#endif

#ifdef DEBUG_HEXDUMP_TO_FILE
void DEBUG_init(void);
void DEBUG_deinit(void);
#else
#define DEBUG_init()
#define DEBUG_deinit()
#endif

#endif /* _DATA_LOGGER_H_ */
