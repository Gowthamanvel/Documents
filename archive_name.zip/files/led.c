/**
 * @file led.c
 *
 * Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include "g3d.h"

static const char CSZ_led_sys_path[] = "/sys/class/leds";

static const char *const LEDNames[] = {
	"usb-led",
	"link-led",
	"ethernet-led",
	"error-led",
	"modem-led",
	"datalog-led",
	"wlanbt-led"
};

int led_set(int led, int brightness)
{
	char    fn[64];

	if (led >= LED_MAX_LEDS) {
		ERR("Invalid LED number (%d)!", led);
		return -2;
	}

	SNP(fn, "%s/%s/brightness", CSZ_led_sys_path, LEDNames[led]);
	if (openwriteclose(fn, (brightness ? CSZ_1 : CSZ_0), -1) < 0) {
		//ERR("Could not write led value!");
		return -1;
	}

	return 0;
}

static int led_all_off(void)
{
	int i;

	for (i = 0; i < LED_MAX_LEDS; i++) {
		led_set(i, LED_OFF);
	}

	return 0;
}

int led_init(void)
{
	led_all_off();

	return 0;
}

void led_deinit(void)
{
	led_all_off();
}

