/**
 *  @file can_nl_if.c
 *
 *  Copyright (c) 2023, Capgemini - Intelligent Devices
 */

#include	<linux/netlink.h>
#include	<linux/can/netlink.h>

#include	"g3d.h"
#include	"can_nl_if.h"

#define IF_UP    1
#define IF_DOWN  0

#define NLMSG_TAIL(nmsg) \
		((struct rtattr *) (((void *) (nmsg)) + NLMSG_ALIGN((nmsg)->nlmsg_len)))

static int send_nl_request(int nl_sock, struct nlmsghdr *nlhdr)
{
	struct nlmsghdr *phdr;
	char r_buf[128];
	int len;
	struct sockaddr_nl addr = {
		.nl_family = AF_NETLINK,
	};
	struct iovec iov = {
		.iov_base = (void *)nlhdr,
		.iov_len  = nlhdr->nlmsg_len,
	};
	struct msghdr msg = {
		.msg_name = &addr,
		.msg_namelen = sizeof(addr),
		.msg_iov = &iov,
		.msg_iovlen = 1,
	};

	len = sendmsg(nl_sock, &msg, 0);
	if (len < 0) {
		ERR("NL: sendmsg failed - %s", strerror(errno));
		return -1;
	}

	iov.iov_base = r_buf;
	iov.iov_len = sizeof(r_buf);
	msg.msg_name = &addr;
	msg.msg_namelen = sizeof(addr);
	msg.msg_iov = &iov,
	msg.msg_iovlen = 1,
	len = recvmsg(nl_sock, &msg, 0);
	if (len < 0) {
		ERR("NL: recvmsg failed - %s", strerror(errno));
		return -1;
	}

	phdr = (struct nlmsghdr *)r_buf;
	while (len > sizeof(struct nlmsghdr)) {
		if (phdr->nlmsg_type == NLMSG_ERROR) {
			struct nlmsgerr *err = NLMSG_DATA(phdr);
			if (err->error == 0) {
				return 0;
			}
			return -1;
		}

		phdr = (struct nlmsghdr *)(phdr + NLMSG_ALIGN(phdr->nlmsg_len));
		len -= NLMSG_ALIGN(phdr->nlmsg_len);
	}

	return 0;
}

/*
 * Set the interface state to IF_UP or IF_DOWN
 *
 */
static int can_if_set_if_state(int nl_sock, char *ifname, int state)
{
	struct nl_if_state req = {
		.nlhdr.nlmsg_len   = NLMSG_LENGTH(sizeof(struct ifinfomsg)),
		.nlhdr.nlmsg_type  = RTM_NEWLINK,
		.nlhdr.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK,
		.nlhdr.nlmsg_seq   = 0,
		.nlhdr.nlmsg_pid   = 0,

		.if_info.ifi_family = 0,
		.if_info.__ifi_pad  = 0,
		.if_info.ifi_type   = 0,
		.if_info.ifi_index  = 0,
		.if_info.ifi_flags  = 0,
		.if_info.ifi_change = IFF_UP,
	};

	req.if_info.ifi_index = if_nametoindex(ifname);
	if (req.if_info.ifi_index == 0) {
		ERR("NL: invalid ifname %s", ifname);
		return -1;
	}

	if (state == IF_UP) {
		req.if_info.ifi_flags |= IFF_UP;
	} else if (state == IF_DOWN) {
		req.if_info.ifi_flags &= ~IFF_UP;
	} else {
		ERR("NL: Invalid IF state");
		return -1;
	}

	return send_nl_request(nl_sock, &req.nlhdr);
}

/*
 * Set the interface state to IF_UP or IF_DOWN
 *
 */
static int can_nl_set_bittiming(int nl_sock, char *ifname,
					unsigned long bittiming)
{
	struct rtattr *linkinfo, *rta, *data;
	struct nl_bt_req req = {
		.nlhdr.nlmsg_len   = NLMSG_LENGTH(sizeof(struct ifinfomsg)),
		.nlhdr.nlmsg_type  = RTM_NEWLINK,
		.nlhdr.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK,
		.nlhdr.nlmsg_seq   = 0,
		.nlhdr.nlmsg_pid   = 0,

		.if_info.ifi_family = 0,
		.if_info.__ifi_pad  = 0,
		.if_info.ifi_type   = 0,
		.if_info.ifi_index  = 0,
		.if_info.ifi_flags  = 0,
		.if_info.ifi_change = IFF_UP,
	};
	struct can_bittiming bt = { 0 };
	const char *type = "can";
	int avail_len = sizeof(req.buf);

	req.if_info.ifi_index = if_nametoindex(ifname);
	if (req.if_info.ifi_index == 0) {
		ERR("interface %s error", ifname);
		return -1;
	}
	rta = NLMSG_TAIL(&req.nlhdr);
	linkinfo = rta;

	if (avail_len < RTA_ALIGN(RTA_LENGTH(0))) {
		return -1;
	}
	rta->rta_type = IFLA_LINKINFO;
	rta->rta_len = RTA_LENGTH(0);
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + RTA_ALIGN(rta->rta_len);
	avail_len -= RTA_ALIGN(rta->rta_len);

	if (avail_len < RTA_ALIGN(RTA_LENGTH(strlen(type)))) {
		return -1;
	}
	rta = NLMSG_TAIL(&req.nlhdr);
	rta->rta_type = IFLA_INFO_KIND;
	rta->rta_len = RTA_LENGTH(strlen(type));
	memcpy(RTA_DATA(rta), type, strlen(type));
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + RTA_ALIGN(rta->rta_len);
	avail_len -= RTA_ALIGN(rta->rta_len);

	if (avail_len < RTA_LENGTH(0)) {
		return -1;
	}
	data = NLMSG_TAIL(&req.nlhdr);
	data->rta_type = IFLA_INFO_DATA;
	data->rta_len = RTA_LENGTH(0);
	/* NOTE: avoid RTA_ALIGN(data->rta_len) */
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + data->rta_len;
	avail_len -= rta->rta_len;

	if (avail_len < RTA_ALIGN(RTA_LENGTH(sizeof(struct can_bittiming)))) {
		return -1;
	}
	bt.bitrate = bittiming;
	rta = NLMSG_TAIL(&req.nlhdr);
	rta->rta_type = IFLA_CAN_BITTIMING;
	rta->rta_len = RTA_LENGTH(sizeof(struct can_bittiming));
	memcpy(RTA_DATA(rta), (void *)&bt, sizeof(struct can_bittiming));
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + RTA_ALIGN(rta->rta_len);

	data->rta_len = (void *)NLMSG_TAIL(&req.nlhdr) - (void *)data;
	linkinfo->rta_len = (void *)NLMSG_TAIL(&req.nlhdr) - (void *)linkinfo;

	return send_nl_request(nl_sock, &req.nlhdr);
}

int can_if_setbitrate(char *ifname, uint32_t bitrate)
{
	int ret = -1;
	int nl_sock;
	struct sockaddr_nl addr;

	nl_sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (nl_sock < 0) {
		ERR("NL: socket error");
		return -1;
	}

	memset((void *)&addr, 0, sizeof(addr));
	addr.nl_family = AF_NETLINK;
	if (bind(nl_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		ERR("NL: bind failed");
		goto err;
	}

//	DBG("Set %s IF_DOWN", ifname);
	ret = can_if_set_if_state(nl_sock, ifname, IF_DOWN);
	if (ret != 0) {
		ERR("NL: set IF_DOWN failed");
		ret = -1;
		goto err;
	}

	DBG("Set bitrate %u", bitrate);
	ret = can_nl_set_bittiming(nl_sock, ifname, bitrate);
	if (ret != 0) {
		ERR("NL: set bittiming failed");
		ret = -1;
		goto err;
	}

	DBG("Set %s IF_UP", ifname);
	ret = can_if_set_if_state(nl_sock, ifname, IF_UP);
	if (ret != 0) {
		ERR("NL: set IF_DOWN failed");
		ret = -1;
		goto err;
	}

	ret = 0;
err:
	close(nl_sock);
	return ret;
}

#if 1
/* CAN-FD set dbitrate (datarate) by Satyendra*/
static int can_set_dbittiming(int nl_sock, char *ifname, unsigned long dbittiming)
{
	struct rtattr *linkinfo, *rta, *data;
	struct nl_bt_req req = {
		.nlhdr.nlmsg_len   = NLMSG_LENGTH(sizeof(struct ifinfomsg)),
		.nlhdr.nlmsg_type  = RTM_NEWLINK,
		.nlhdr.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK,
		.nlhdr.nlmsg_seq   = 0,
		.nlhdr.nlmsg_pid   = 0,

		.if_info.ifi_family = 0,
		.if_info.__ifi_pad  = 0,
		.if_info.ifi_type   = 0,
		.if_info.ifi_index  = 0,
		.if_info.ifi_flags  = 0,
		.if_info.ifi_change = IFF_UP,
	};
	struct can_bittiming bt = { 0 };
	const char *type = "can";
	int avail_len = sizeof(req.buf);

	req.if_info.ifi_index = if_nametoindex(ifname);
	if (req.if_info.ifi_index == 0) {
		ERR("interface %s error", ifname);
		return -1;
	}
	rta = NLMSG_TAIL(&req.nlhdr);
	linkinfo = rta;

	if (avail_len < RTA_ALIGN(RTA_LENGTH(0))) {
		return -1;
	}
	rta->rta_type = IFLA_LINKINFO;
	rta->rta_len = RTA_LENGTH(0);
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + RTA_ALIGN(rta->rta_len);
	avail_len -= RTA_ALIGN(rta->rta_len);

	if (avail_len < RTA_ALIGN(RTA_LENGTH(strlen(type)))) {
		return -1;
	}
	rta = NLMSG_TAIL(&req.nlhdr);
	rta->rta_type = IFLA_INFO_KIND;
	rta->rta_len = RTA_LENGTH(strlen(type));
	memcpy(RTA_DATA(rta), type, strlen(type));
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + RTA_ALIGN(rta->rta_len);
	avail_len -= RTA_ALIGN(rta->rta_len);

	if (avail_len < RTA_LENGTH(0)) {
		return -1;
	}
	data = NLMSG_TAIL(&req.nlhdr);
	data->rta_type = IFLA_INFO_DATA;
	data->rta_len = RTA_LENGTH(0);
	// NOTE: avoid RTA_ALIGN(data->rta_len) 
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + data->rta_len;
	avail_len -= rta->rta_len;

	if (avail_len < RTA_ALIGN(RTA_LENGTH(sizeof(struct can_bittiming)))) {
		return -1;
	}
	bt.bitrate = dbittiming;
	rta = NLMSG_TAIL(&req.nlhdr);
	rta->rta_type = IFLA_CAN_DATA_BITTIMING;
	rta->rta_len = RTA_LENGTH(sizeof(struct can_bittiming));
	memcpy(RTA_DATA(rta), (void *)&bt, sizeof(struct can_bittiming));
	req.nlhdr.nlmsg_len = NLMSG_ALIGN(req.nlhdr.nlmsg_len) + RTA_ALIGN(rta->rta_len);

	data->rta_len = (void *)NLMSG_TAIL(&req.nlhdr) - (void *)data;
	linkinfo->rta_len = (void *)NLMSG_TAIL(&req.nlhdr) - (void *)linkinfo;

	return send_nl_request(nl_sock, &req.nlhdr);
}

int can_if_setdbitrate(char *ifname, uint32_t dbitrate)
{
	int ret = -1;
	int nl_sock;
	struct sockaddr_nl addr;

	nl_sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (nl_sock < 0) {
		ERR("NL: socket error");
		return -1;
	}
	memset((void *)&addr, 0, sizeof(addr));
	addr.nl_family = AF_NETLINK;
	if (bind(nl_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		ERR("NL: bind failed");
		goto err;
	}
	DBG("Set %s IF_DOWN\n", ifname);
	ret = can_if_set_if_state(nl_sock, ifname, IF_DOWN);
	if (ret != 0) {
		ERR("NL: set IF_DOWN failed");
		ret = -1;
		goto err;
	}

	DBG("Set bitrate %u", dbitrate);
	ret = can_nl_set_bittiming(nl_sock, ifname, dbitrate);
	if (ret != 0) {
		ERR("NL: set bittiming failed");
		ret = -1;
		goto err;
	}

	DBG("Set %s IF_UP\n", ifname);
	ret = can_if_set_if_state(nl_sock, ifname, IF_UP);
	if (ret != 0) {
		ERR("NL: set IF_DOWN failed");
		ret = -1;
		goto err;
	}

	ret = 0;
err:
	close(nl_sock);
	return ret;
}
#endif

