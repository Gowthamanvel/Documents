/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : timer.c
** Description    :
** Date			  : 11 Nov, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "timer.h"


/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
//! [module_inst]
struct tc_module Timer_Instance;
struct tc_config Timer_Config;
volatile bool Time_Out = false;

void on_timer_expire(struct tc_module *const module_inst);
void configure_tc_callbacks(void);


/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/


/*******************************************************************************
* Function Name  : init_timer
* Description    : configure timer parameters
* Input          :
* Output         :
* Return         :
*******************************************************************************/
void init_timer(void)
{
	tc_get_config_defaults(&Timer_Config);

	//! [setup_change_config]
	Timer_Config.counter_size = TC_COUNTER_SIZE_16BIT;
	Timer_Config.clock_source = GCLK_GENERATOR_1;
	Timer_Config.counter_16_bit.value = 0;
	Timer_Config.clock_prescaler = TC_CLOCK_PRESCALER_DIV16;//TC_CLOCK_PRESCALER_DIV1;//
	//Timer_Config.counter_16_bit.period = 20;
	//Timer_Config.counter_16_bit.compare_capture_channel[0] = 20;
	//! [setup_change_config]

	//! [setup_set_config]
	//tc_init(&Timer_Instance, TC0, &Timer_Config);
	
	//tc_register_callback(&Timer_Instance, on_timer_expire,TC_CALLBACK_CC_CHANNEL0);
	//tc_enable_callback(&Timer_Instance, TC_CALLBACK_CC_CHANNEL0);
	
}


/*******************************************************************************
* Function Name  : on_timer_expire
* Description    : Callback function which gets invoked once the timer expires
* Input          : struct tc_module *
* Output         :
* Return         :
*******************************************************************************/
void on_timer_expire(struct tc_module *const module_inst)
{
	Time_Out = true;
	
	//Disable the timer otherwise it will keep on interrupting for the timer set
	tc_disable(&Timer_Instance);
}


/*******************************************************************************
* Function Name  : Sleep
* Description    : wait for timer to expire
* Input          : time in mili seconds
* Output         :
* Return         :
*******************************************************************************/
void Sleep(uint16_t mSeconds )
{
	//Timer_Config.counter_16_bit.period = mSeconds*2;
	Timer_Config.counter_16_bit.compare_capture_channel[0] = mSeconds*2;
	Time_Out = false;
	tc_init(&Timer_Instance, TC0, &Timer_Config);
	tc_register_callback(&Timer_Instance, on_timer_expire,TC_CALLBACK_CC_CHANNEL0);
	tc_enable_callback(&Timer_Instance, TC_CALLBACK_CC_CHANNEL0);
	//configure_tc_callbacks();
	tc_enable(&Timer_Instance);
	
	while(!Time_Out);
}
