/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : aes_ctr.h
** Description    :	Contains the AES API declarations 
** Date           : 10 OCT, 2019
** Version        : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef AES_CTR_MODE_H_
#define AES_CTR_MODE_H_

/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "aes.h"
#include "GarudaLite_config.h"



/*******************************************************************************
* Function Name  : initialize_aes
* Description    : Initializes the AES Drivers with the default static key and IV
* Input          : None
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t initialize_aes(void);

/*******************************************************************************
* Function Name  : change_encryption_key
* Description	 : Sets the given key for AES encryption and Decryption
* Input          : Pointer to key variable
* Output         : None
* Return         : None
*******************************************************************************/
void change_encryption_key(uint32_t *key);

/*******************************************************************************
* Function Name  : change_encryption_iv
* Description	 : Sets the given IV for AES encryption and Decryption
* Input          : pointer to IV variable
* Output         : None
* Return         : None
*******************************************************************************/
void change_encryption_iv(uint32_t *iv);

/*******************************************************************************
* Function Name  : encrypt_data
* Description	 : Encrypts or decrypts byte w.r.t KEY and IV set for AES
* Input          : pointer to data buffer
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t encrypt_data(uint8_t * data);

/*******************************************************************************
* Function Name  : Set_AES_To_Default_Config
* Description	 : Changes the KEY and IV to default for AES
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
void Set_AES_To_Default_Config(void);


#endif /* AES_CTR_MODE_H_ */