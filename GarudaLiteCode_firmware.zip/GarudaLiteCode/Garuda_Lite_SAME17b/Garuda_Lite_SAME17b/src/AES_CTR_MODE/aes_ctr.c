/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : aes_ctr.c
** Description    : Initializes AES and encrypts/decrypts data
** Date           : 10 OCT, 2019
** Version        : 0.1
** Author         : Chethankumar M S
******************************************************************************/ 

/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "aes_ctr.h"


/******************************************************************************
*                   I N T E R N A L   V A R I A B L E S
*******************************************************************************/
struct aes_config encryption_config;
struct aes_module aes_instance;
//uint32_t Input_Data[4];

/*This will be the default keys and IV used fore encryption and decryption 
Note:Choose a Random KEY and IV */

uint32_t default_key[4] = {
	0x88924883,
	0x26886195,
	0x27683648,
	0x41104110
};

uint32_t default_iv[4] = {
	0x88619527,
	0x68889248,
	0x83263648,
	0x41104110
};

/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/

Status_t initialize_aes(void)
{
	/***************** Configure the AES. ********************/
	aes_get_config_defaults(&encryption_config);
	encryption_config.encrypt_mode = AES_PROCESS_MODE;
	encryption_config.key_size = AES_CTR_KEY_SIZE;
	/*Auto start method is taking too much time so do it manually*/
	encryption_config.start_mode = AES_CTR_START_MODE;//AES_AUTO_START;
	encryption_config.opmode = ASE_OPERATING_MODE;
	encryption_config.cfb_size = AES_CFB_SIZE_128;
	encryption_config.lod = false;
	
	/*Set the configuration to AES engine*/
	aes_set_config(&aes_instance,AES, &encryption_config);
	
	/*Initialize the AES module with given configuration*/
	aes_init(&aes_instance,AES, &encryption_config);
	
	/*Enable the AES engine*/
	aes_enable(&aes_instance);
	
	/*Write the AE_key and IV for cryptography*/
	aes_write_key(&aes_instance,default_key);
	aes_write_init_vector(&aes_instance, default_iv);
	
	/*Note: The KEY and IV can be changed by user using GT commands*/
	
	return ERR_SUCCESS;
	
}

void Set_AES_To_Default_Config(void)
{
	/*Write the AE_key and IV for cryptography*/
	aes_write_key(&aes_instance,default_key);
	aes_write_init_vector(&aes_instance, default_iv);
}


void change_encryption_key(uint32_t *key)
{
	/*Write the AE_key and IV for cryptography*/
	aes_write_key(&aes_instance,key);
	
}


void change_encryption_iv(uint32_t *iv)
{
	aes_write_init_vector(&aes_instance, iv);
}


Status_t encrypt_data(uint8_t * data)
{
	/****************Manual start AES*************/
	aes_instance.hw->CTRLB.reg |= AES_CTRLB_NEWMSG;
	aes_instance.hw->DATABUFPTR.reg = 0;
	aes_instance.hw->INDATA.reg = *data;// Input_Data[0];
	aes_instance.hw->CTRLB.reg = aes_instance.hw->CTRLB.reg | 0x01; // to start aes manually

	/*It has been assumed that the below code will never enter into blocking state*/
	while (!(aes_instance.hw->INTFLAG.reg & AES_INTFLAG_ENCCMP));
	
	/*read the encrypted data*/
	aes_instance.hw->DATABUFPTR.reg = 0;
	*data = (uint8_t) aes_instance.hw->INDATA.reg ;
	
	/*****************Important Note***************************/
	/*Don't encrypt full packets because in monitor all mode the BT module may club
	two or more packets and send it over air*/
	
	return ERR_SUCCESS;
	
}

