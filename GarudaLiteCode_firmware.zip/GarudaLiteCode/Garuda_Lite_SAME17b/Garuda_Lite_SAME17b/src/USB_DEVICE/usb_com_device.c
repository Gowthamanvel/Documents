/*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : usb_com_device.c
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/



/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "usb_com_device.h"
#include "Queue/queue.h"
#include "conf_usb.h"
#include "Bluetooth/BT_909.h"
#include "LED_STATUS/LedStatus.h"


bool usb_enabled = false;

void initialize_usb_com(void)
{
	// Start USB stack to authorize VBus monitoring
	udc_start();
}

void disable_usb_com(void)
{
	udc_stop();
}

bool Usb_Device_Opened(uint8_t port1)
{
	usb_enabled = true;
	disable_bt_com();
	clear_queue(APP_RX);
	clear_queue(STN_RX);
	usb_led(TURN_ON);
	bluetooth_led(TURN_OFF);
	return true;
}



void Usb_Device_Closed(uint8_t port1)
{
	clear_queue(APP_RX);
	clear_queue(STN_RX);
	usb_enabled = false;
	enable_bt_com();
	bluetooth_led(TURN_ON);
	usb_led(TURN_OFF);
}


void rx_callback_usb(uint8_t port1)
{
	uint8_t firstdata;
	firstdata = udi_cdc_getc();
	//AES_CTR_Encrypt_Data((uint8_t *)&tx_data);
	send_data_to_app_queue(firstdata);
}



bool user_callback_sof_action(void)
{
	return true;
}