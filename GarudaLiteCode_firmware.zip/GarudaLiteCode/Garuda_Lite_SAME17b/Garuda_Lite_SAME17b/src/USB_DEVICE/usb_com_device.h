/*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : usb_com_device.h
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef USB_COM_DEVICE_H_
#define USB_COM_DEVICE_H_


#include <asf.h>
#include <stdio.h>
#include "conf_usb.h"


/*******************************************************************************
* Function Name  : initialize_usb_com()
* Description    : Enables the USB stack
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void initialize_usb_com(void);

/*******************************************************************************
* Function Name  : rx_callback_usb
* Description    : This function gets called when there is any start of data 
				   reception on USB
* Input          : port number
* Output         : None
* Return         : None
*******************************************************************************/
void rx_callback_usb(uint8_t port1);


/*******************************************************************************
* Function Name  : user_callback_sof_action
* Description    : This function gets called when the SOF is received
* Input          :
* Output         : None
* Return         : bool
*******************************************************************************/
bool user_callback_sof_action(void );


/*********************************************************************************
* Function Name  : Usb_Device_Opened
* Description    : When the USB connected this function gets called from USB stack
					clears the queue and disables the BT module
* Input          : The port number
* Output         : None
* Return         : bool
*********************************************************************************/
bool Usb_Device_Opened(uint8_t port1);


/*******************************************************************************
* Function Name  : Usb_Device_Closed
* Description    : When the USB is disconnected this gets called from 
				   USB stack, clears the queue and enables the BT module
* Input          : port number
* Output         : None
* Return         : None
*******************************************************************************/
void Usb_Device_Closed(uint8_t port1);


/*******************************************************************************
* Function Name  : disable_usb_com
* Description    : 
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
void disable_usb_com(void);

#endif /* USB_COM_DEVICE_H_ */