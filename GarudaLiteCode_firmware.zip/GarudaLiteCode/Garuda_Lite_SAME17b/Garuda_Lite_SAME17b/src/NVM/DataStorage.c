/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : 
** Description    :
** Date			  : 6 Nov, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "DataStorage.h"
#include "Bluetooth/BT_909.h"



void initialize_nvm(void)
{
	struct nvm_config config_nvm;

	nvm_get_config_defaults(&config_nvm);
	
	config_nvm.manual_page_write = false;

	nvm_set_config(&config_nvm);
}



void update_bt_config_in_nvm(uint8_t * buf)
{
	enum status_code error_code;
	do
	{
		error_code = nvm_erase_row(bt_config_NVM_ADDR);
	} while (error_code != STATUS_OK);

	do
	{
		error_code = nvm_write_buffer(bt_config_NVM_ADDR,buf, sizeof(struct bt_config));
	} while (error_code != STATUS_OK);
	
}



void get_bt_config_from_nvm(uint8_t * buf)
{
	enum status_code error_code;
	
	do
	{
		error_code = nvm_read_buffer(bt_config_NVM_ADDR,buf, sizeof(struct bt_config));
	} while (error_code != STATUS_OK);
	
}


void update_app_entry_point(uint8_t * buf)
{
	enum status_code error_code;
	do
	{
		error_code = nvm_erase_row(BOOTLOADER_JUMP_ADDR);
	} while (error_code != STATUS_OK);

	do
	{
		error_code = nvm_write_buffer(BOOTLOADER_JUMP_ADDR,buf, 4);
	} while (error_code != STATUS_OK);
	
}

void get_app_entry_point(uint8_t * buf)
{
	enum status_code error_code;
	
	do
	{
		error_code = nvm_read_buffer(BOOTLOADER_JUMP_ADDR,buf, 4);
	} while (error_code != STATUS_OK);
}



