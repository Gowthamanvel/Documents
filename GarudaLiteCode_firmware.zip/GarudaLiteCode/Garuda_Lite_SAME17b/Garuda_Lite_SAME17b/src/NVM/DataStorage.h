/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      :
** Description    :
** Date			  : 6 Nov, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef DATASTORAGE_H_
#define DATASTORAGE_H_


#include <asf.h>


/*******************************************************************************
* Function Name  : Configue_NVM
* Description    : To configure the NVM drivers
* Input          :
* Output         :
* Return         : 
*******************************************************************************/
void initialize_nvm(void);


/*******************************************************************************
* Function Name  : update_bt_config_in_nvm
* Description    : To update the BT configurations in NVM
* Input          : pointer to a buffer containing BT config
* Output         :
* Return         :
*******************************************************************************/
void update_bt_config_in_nvm(uint8_t * buf);


/*******************************************************************************
* Function Name  : get_bt_config_from_nvm
* Description    : To fetch the BT configurations from NVM
* Input          : pointer to a buffer to hold the BT config
* Output         :
* Return         :
*******************************************************************************/
void get_bt_config_from_nvm(uint8_t * buf);

/*******************************************************************************
* Function Name  : update_app_entry_point
* Description    :
* Input          :
* Output         :
* Return         :
*******************************************************************************/
void update_app_entry_point(uint8_t * buf);


/*******************************************************************************
* Function Name  : get_app_entry_point
* Description    :
* Input          :
* Output         :
* Return         :
*******************************************************************************/
void get_app_entry_point(uint8_t * buf);



#endif /* DATASTORAGE_H_ */