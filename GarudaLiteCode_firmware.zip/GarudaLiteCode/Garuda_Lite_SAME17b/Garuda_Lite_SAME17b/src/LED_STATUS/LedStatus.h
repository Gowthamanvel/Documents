/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : LedStatus.h
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef LEDSTATUS_H_
#define LEDSTATUS_H_

/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "port.h"

//The pins are active low
#define TURN_ON		false
#define TURN_OFF	true

/*******************************************************************************
* Function Name  : bluetooth_led
* Description    : To turn On /Off the link status LED 
* Input          : bool
* Output         :
* Return         :
*******************************************************************************/
void bluetooth_led(bool value);


/*******************************************************************************
* Function Name  : usb_led
* Description    : To turn On /Off the error status LED 
* Input          : bool
* Output         :
* Return         :
*******************************************************************************/
void usb_led(bool value);


/*******************************************************************************
* Function Name  : initialize_gpio
* Description    : To initialize the GPIO pins and LED pins
* Input          :
* Output         :
* Return         :
*******************************************************************************/
void initialize_gpio(void);

#endif /* LEDSTATUS_H_ */