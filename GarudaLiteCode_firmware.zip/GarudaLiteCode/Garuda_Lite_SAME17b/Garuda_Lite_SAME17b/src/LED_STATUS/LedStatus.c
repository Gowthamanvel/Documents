/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : LedStatus.c
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/



/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "LedStatus.h"
#include "GarudaLite_config.h"


void initialize_gpio(void)
{
	//For GPIO pins
	struct port_config Link_Status_Config;
	struct port_config Err_Status_Config;

	struct port_config Mcu_Reset_Pin;
	struct port_config Usb_Detect_Pin;
	struct port_config Shutdown_Pin;
	struct port_config Usb_Dp_Min;
	struct port_config Usb_Dp_Plus;
	struct port_config BT_Led_Status_Pin;

	port_get_config_defaults(&Link_Status_Config);
	port_get_config_defaults(&Err_Status_Config);
	/*As per the requirement from Hardware Team*/
	port_get_config_defaults(&Mcu_Reset_Pin);
	port_get_config_defaults(&Usb_Detect_Pin);
	port_get_config_defaults(&Shutdown_Pin);
	
	//pins direction w.r.t inputs from hardware team
	Mcu_Reset_Pin.direction  = PORT_PIN_DIR_OUTPUT;
	Usb_Detect_Pin.direction  = PORT_PIN_DIR_INPUT;
	Usb_Detect_Pin.input_pull =  PORT_PIN_PULL_UP;
	Shutdown_Pin.direction  = PORT_PIN_DIR_OUTPUT;
	Link_Status_Config.direction  = PORT_PIN_DIR_OUTPUT;
	Err_Status_Config.direction  = PORT_PIN_DIR_OUTPUT;

	/*As per the requirement from Hardware Team*/
	port_pin_set_config(MCU_REST_PIN, &Mcu_Reset_Pin);
	port_pin_set_config(USB_DETECT_PIN, &Usb_Detect_Pin);
	port_pin_set_config(SHUTDOWN_PIN, &Shutdown_Pin);
	port_pin_set_output_level(MCU_REST_PIN,true);
	port_pin_set_output_level(SHUTDOWN_PIN,true);

	
	port_pin_set_config(LINK_STATUS_LED, &Link_Status_Config);
	port_pin_set_config(ERR_STATUS_LED, &Err_Status_Config);
	
	bluetooth_led(true);
	usb_led(true);
	
	/************************************************************/
}



void bluetooth_led(bool value)
{
	port_pin_set_output_level(LINK_STATUS_LED,value);
}



void usb_led(bool value)
{
	port_pin_set_output_level(ERR_STATUS_LED,value);
}