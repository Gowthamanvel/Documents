/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : ISR_UART.c
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "main.h"
#include "sercom.h"
#include "usart.h"
#include "LED_STATUS/LedStatus.h"
#include "Queue/queue.h"
#include "Bluetooth/BT_909.h"

//The instance has been created in BT_909.c and STN2120.c
extern struct usart_module UART_BT_Module;
extern struct usart_module UART_STN_Module;
extern volatile bool Echo_Enabled;


/*******************************************************************************
* Function Name  : SERCOM2_Handler
* Description    : Interrupt handler for Bluetooth UART which handles RX and TX
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SERCOM2_Handler(void)
{
	
	/* Temporary variables */
	uint16_t interrupt_status;
	uint16_t callback_status;
	uint8_t error_code;

	struct usart_module *module = &UART_BT_Module;

	/* Pointer to the hardware module instance */
	SercomUsart *const usart_hw = &(module->hw->USART);

	/* Wait for the synchronization to complete */
	_usart_wait_for_sync(module);

	/* Read and mask interrupt flag register */
	interrupt_status = usart_hw->INTFLAG.reg;
	interrupt_status &= usart_hw->INTENSET.reg;
	callback_status = module->callback_reg_mask & module->callback_enable_mask;

	//Chethan: Currently the below method is not used for transmitting data, The TX part is handled in BT909.c
	if(interrupt_status & SERCOM_USART_INTFLAG_DRE)
	{
		/*uint8_t tx_data ;
		if(ReadFromQ(BT_TX,&tx_data) == QUEUE_EMPTY)
			usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_DRE;
		else
		{
			usart_hw->DATA.reg = ((uint16_t)tx_data & SERCOM_USART_DATA_MASK);
			usart_hw->INTENSET.reg = SERCOM_USART_INTFLAG_TXC;
			usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_DRE;
		}*/
		
	}
	
	
	/* Check if the Transmission Complete interrupt has occurred and
	 * that the transmit buffer is empty */
	if (interrupt_status & SERCOM_USART_INTFLAG_TXC) 
	{
		/*uint8_t tx_data;
		//usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_TXC;
		//usart_hw->INTFLAG.reg = usart_hw->INTFLAG.reg & SERCOM_USART_INTFLAG_TXC;
			
		if(ReadFromQ(BT_TX,&tx_data) != QUEUE_EMPTY)
		{
			usart_hw->DATA.reg = ((uint16_t)tx_data & SERCOM_USART_DATA_MASK);
			//usart_hw->INTENSET.reg = SERCOM_USART_INTFLAG_TXC;
		}
		else
			usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_TXC;
		*/
	}

	/* Check if the Receive Complete interrupt has occurred, and that
	 * there's more data to receive */
	if (interrupt_status & SERCOM_USART_INTFLAG_RXC) 
	{
		uint16_t received_data = (usart_hw->DATA.reg & SERCOM_USART_DATA_MASK);
		usart_hw->INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
				
		//Store the received data in BT_RX buffer
		send_data_to_app_queue((uint8_t)received_data);	
		//encrypt_data((uint8_t *)&received_data);
		//if(Echo_Enabled)
			//send_data_to_stn_queue((uint8_t)received_data);
	} 
	else
	{
			/* This should not happen. Disable Receive Complete interrupt. */
			
			//Chethan: commented the below line to keep RXC flag set permanently
			
			//usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	}
	
}


/*******************************************************************************
* Function Name  : SERCOM4_Handler
* Description    : Interrupt handler for STN2120 which handles TX and RX
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void SERCOM3_Handler(void)
{
	
	/* Temporary variables */
	uint16_t interrupt_status;
	uint16_t callback_status;
	uint8_t error_code;

	
	struct usart_module *module = &UART_STN_Module;

	/* Pointer to the hardware module instance */
	SercomUsart *const usart_hw = &(module->hw->USART);

	/* Wait for the synchronization to complete */
	_usart_wait_for_sync(module);

	/* Read and mask interrupt flag register */
	interrupt_status = usart_hw->INTFLAG.reg;
	interrupt_status &= usart_hw->INTENSET.reg;
	callback_status = module->callback_reg_mask & module->callback_enable_mask;
	
	//Chethan: Currently the below method is not used for transmitting , The TX is handled in STN2120.c		
	if(interrupt_status & SERCOM_USART_INTFLAG_DRE)
	{
		/*uint8_t tx_data ;
		if(SendToQ(STN_TX,tx_data) == QUEUE_EMPTY)
			usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_DRE;
		else
		{
			usart_hw->DATA.reg = ((uint16_t)tx_data & SERCOM_USART_DATA_MASK);
			usart_hw->INTENSET.reg = SERCOM_USART_INTFLAG_TXC;
			usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_DRE;
		}
		*/
	}

	/* Check if the Transmission Complete interrupt has occurred and
	 * that the transmit buffer is empty */
	if (interrupt_status & SERCOM_USART_INTFLAG_TXC) 
	{
		/*uint8_t tx_data;
		//usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_TXC;
		usart_hw->INTFLAG.reg = usart_hw->INTFLAG.reg & SERCOM_USART_INTFLAG_TXC;
		
		if(ReadFromQ(STN_TX,&tx_data) != QUEUE_EMPTY)
		{
			usart_hw->DATA.reg = ((uint16_t)tx_data & SERCOM_USART_DATA_MASK);
		}
		else
			usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_TXC;
		//usart_hw->DATA.reg = tx_data;
		*/
	}

	/* Check if the Receive Complete interrupt has occurred, and that
	 * there's more data to receive */
	if (interrupt_status & SERCOM_USART_INTFLAG_RXC) 
	{
		uint16_t received_data = (usart_hw->DATA.reg & SERCOM_USART_DATA_MASK);
		
		//Store the received data in STN_RX buffer 
		//SendToQ(STN_RX,(uint8_t )received_data);
		
		//bluetooth_led(false);
		/*if(indx == 300)
			indx = 0;
		
		stn_local_buf[indx++] = (uint8_t)received_data;*/
		send_data_to_stn_queue((uint8_t)received_data);
		//usb_led(TURN_ON);
		
		//rx_count = rx_count + 1;
		//chethan: to set the rxc flag through out the session
		usart_hw->INTENSET.reg = SERCOM_USART_INTFLAG_RXC;	
	} 
	else 
	{
			/* This should not happen. Disable Receive Complete interrupt. */
			//usart_hw->INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	}
	
	
}
