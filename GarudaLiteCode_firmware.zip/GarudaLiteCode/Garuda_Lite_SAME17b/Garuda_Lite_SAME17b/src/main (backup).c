/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : main.c
** Description    : Mediator between the BT module/USB and STN2120
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "Bluetooth/BT_909.h"
#include "AES_CTR_MODE/aes_ctr.h"
#include "STN2120/stn2120.h"
#include "Queue/queue.h"
#include "GarudaLite_config.h"
#include "LED_Status/LedStatus.h"
#include "USB_DEVICE/usb_com_device.h"
#include "NVM/DataStorage.h"
#include "Timer/timer.h"
#include "main.h"
#include <string.h>
#include <math.h>
#include "ASF/sam0/drivers/usb/usb.h"		/*Added a function to get USB disconnected status in usb.h*/


/*#define TEST_SETUP*/



/******************************************************************************
**               I N T E R N A L     V A R I A B L E S
******************************************************************************/
volatile GarudaLite_States_t Opt_State = ERR_STATE;
volatile bool Usb_Enabled = false;
static uint8_t Gt_Cmnd[STN_MAX_CMND_SIZE];
volatile int Cmd_Idx = 0;
static bool Cmnd_Overflow = false;
bool ISO15765_Frame =false;
static int32_t Stn_Baud_Rate = 0;
static int32_t Stn_Old_BaudRate = 9600;
volatile bool Aes_Enabled = false;
volatile bool Echo_Enabled = true;
uint32_t  Aes_Session_Key[4];
uint32_t Aes_Session_Iv[4];
struct BT_Config Bt_Nvm_Config;
static uint32_t App_Entry_Buffer = 0x00000000;



#ifdef TEST_SETUP
	volatile int App_Tx_Count = 0;
	uint32_t Clock_Value = 0;
#endif


void Stn_Tx_Task(void);
void App_Tx_Task(void);
Status_t Send_Response_To_App(const char * );
Status_t ASCII_To_Decimal(uint8_t * , uint8_t * );
void Received_Bad_Cmnd(void);
long Get_BaudRate_Value(uint8_t * );
bool Get__AES_Key_Value(uint8_t * ,uint8_t *);
bool Get_AES_IV_Value(uint8_t * , uint8_t * );
void Send_Ack_To_App(void);



/*********************************************************************************
* Function Name  : Usb_Device_Opened
* Description    : When the USB connected this function gets called from USB stack
					clears the queue and disables the BT module
* Input          : The port number
* Output         : None
* Return         : bool
*********************************************************************************/
bool Usb_Device_Opened(uint8_t port1)
{
	Usb_Enabled = true;
	Disable_BT_Module();
	ClearQueue(APP_RX);
	LED_Error_Status(LED_ON);
	LED_Link_Status(LED_OFF);
	return true;
}


/*******************************************************************************
* Function Name  : Usb_Device_Closed
* Description    : When the USB is disconnected this gets called from 
				   USB stack, clears the queue and enables the BT module
* Input          : port number
* Output         : None
* Return         : None
*******************************************************************************/
void Usb_Device_Closed(uint8_t port1)
{
	ClearQueue(APP_RX);
	Usb_Enabled = false;
	Enable_BT_Module();	
	LED_Link_Status(LED_ON);
	LED_Error_Status(LED_OFF);
}


/*******************************************************************************
* Function Name  : main
* Description    : Initializes the peripherals and parses the data between STN 
				   and BT/USB
* Input          : None
* Output         : None
* Return         : int
*******************************************************************************/
int main(void)
{
	short Init_Err_Cnt = 0;
	
	system_init();

#ifdef TEST_SETUP
	Clock_Value = system_cpu_clock_get_hz();
#endif
	
	/************Enable interrupt********************/
	system_interrupt_enable_global();

	
	Opt_State = INIT_STATE;
	
	while(1)
	{
		switch (Opt_State)
		{
			case INIT_STATE:	
				GPIO_Init();
				Configure_NVM();
				Init_Timer();
				LED_Error_Status(LED_ON);
				
				/*Update App entry point in the NVM*/
				Update_App_Entry_Point(&App_Entry_Buffer);
				
				Init_Err_Cnt = 0;
				while((AES_CTR_Init() != ERR_SUCCESS) && Init_Err_Cnt < 10)
					 if((--Init_Err_Cnt) <= 0) { Opt_State = ERR_STATE; break; }
				
				Init_Err_Cnt = 0;			
				while((BT_UART_Init() != ERR_SUCCESS) && Init_Err_Cnt <10)
					if((--Init_Err_Cnt) <= 0) { Opt_State = ERR_STATE; break; }
				
				Init_Err_Cnt = 0;
				while((STN_UART_Init() != ERR_SUCCESS) && Init_Err_Cnt < 10)
					if((--Init_Err_Cnt) <= 0) { Opt_State = ERR_STATE; break; }
							
				USB_CDC_Init();
				if(Opt_State == ERR_STATE)
					break;
				else
					Opt_State = PARSING_STATE;
							
				ClearQueue(APP_RX);
				ClearQueue(STN_RX);
				memset(Gt_Cmnd,0,STN_MAX_CMND_SIZE);
				LED_Error_Status(LED_OFF);
				LED_Link_Status(LED_ON);			
				break;
			
			case PARSING_STATE:	
				if(Usb_Enabled)
					if(usb_disconnected())
						Usb_Device_Closed(0);
					
				App_Tx_Task();
				Stn_Tx_Task();
				break;
			
			case RECOVER_STATE:
				/*If initialization fails try to recover it, If not go to error state*/
				break;
			
			case ERR_STATE:
				while(1)
				{
					/*Blink ERR_STATUS LED*/
					/*LED_Error_Status(false);*/
					LED_Error_Status(LED_ON);
					Sleep(1000);
					LED_Error_Status(LED_OFF);
					Sleep(1000);
				}
				break;
			
			default :
				/*do nothing*/
				break;
		}
	}
}


/*******************************************************************************
* Function Name  : App_Tx_Task
* Description    : polls queue for data and transmits over bt_usart
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void App_Tx_Task(void)
{
	uint8_t Tx_Buf[64];
	uint8_t Tx_Data = 0;
	uint8_t Tx_Count = 0;

	/*Continue to parse until STN_RX queue becomes empty*/
	while(Read_From_Stn_Queue(&Tx_Data) != UART_LOW_Q_EMPTY)
	{		
		/*Note:It is assumed that AES encryption will never go into blocking state*/
		if(Aes_Enabled)
			AES_CTR_Encrypt_Data(&Tx_Data);
		
		if(Usb_Enabled)
		{
			Tx_Buf[Tx_Count] = Tx_Data;
			Tx_Count = Tx_Count + 1;
			
			if(Tx_Count >=64)
				break;
		}
		else
		{
			Write_Byte_To_BT(Tx_Data);
		}
			
		/*Chethan: In monitor all mode the application has to get chance to terminate the mode*/
		/*if(Get_Queue_Status(APP_RX) != UART_LOW_Q_EMPTY)
			break;*/
	}
	
	if(Usb_Enabled && (Tx_Count > 0)) 
		while(udi_cdc_write_buf(Tx_Buf,Tx_Count) != 0);
	
	return;
}



/*******************************************************************************
* Function Name  : Stn_Tx_Task
* Description    : polls queue for data and transmits over stn_usart
* Input          :
* Output         : None
* Return         : None
********************************************************************************/
void Stn_Tx_Task(void)
{
	uint8_t Tx_Data = 0;

	/*Continue to send data until the BT_RX queue become empty*/
	while(Read_From_App_Queue(&Tx_Data) != UART_LOW_Q_EMPTY )
	{
		/*Note:It is assumed that AES encryption will never go into blocking state*/
		if(Aes_Enabled)
			AES_CTR_Encrypt_Data(&Tx_Data);
			
		if(ISO15765_Frame)
		{
			LED_Link_Status(LED_ON);
			Write_To_STN(Tx_Data);
			
			if(Tx_Data == '\r')
			{
				LED_Link_Status(LED_OFF);
				ISO15765_Frame =false;
			}
		}
		else
		{
			
		/***************** Applyied the same logic as STN*****************************/
		/*Remove spaces here itself*/
		if(Tx_Data != ' ')  
		{
			/*Note: it has been assumed that there is no command with >100 bytes*/
			if(Cmd_Idx >= STN_MAX_CMND_SIZE)
				Cmnd_Overflow = true;
			else
			{
				Gt_Cmnd[Cmd_Idx] = Tx_Data;
				Cmd_Idx++;
			}
		}
		
		/*Check whether we have received full command because response is sent after receiving '\r'*/
		if(Tx_Data == '\r')
		{
			if(Cmnd_Overflow)
			{
				Cmd_Idx = 0;
				Cmnd_Overflow = false;
				/*Note: it has been assumed that there is no command with >100 bytes*/
				Received_Bad_Cmnd();
				memset(Gt_Cmnd,0,STN_MAX_CMND_SIZE);
				break;
			}
			
			Cmd_Idx = 0;
			
			switch(Gt_Cmnd[0])
			{
				case 'A':
				case 'a':
					if(strncasecmp("ATPP",(const char *)Gt_Cmnd,6) == 0)
					{
						Send_Response_To_App("?\r>");
					}
					else if(strncasecmp(ELM_CHANGE_BAUD,(const char *)Gt_Cmnd,5) == 0)
					{
						Send_Response_To_App("?\r>");
					}
					else if(strncasecmp(STN_ECHO_OFF,(const char *)Gt_Cmnd,5)==0)
					{
						Echo_Enabled = false;
						Send_Command_To_STN((const char *)Gt_Cmnd);
					}
					else if(strncasecmp(STN_ECHO_ON,(const char *)Gt_Cmnd,5)==0)
					{
						Echo_Enabled = true;
						Send_Command_To_STN((const char *)Gt_Cmnd);
						//Send_Response_To_App("OK\r>");
					}
					else if(strncasecmp(ELM_RESET_CMD,(const char *)Gt_Cmnd,3)==0)
					{
						Send_Command_To_STN((const char *)Gt_Cmnd);
						Sleep(100);
						Set_Baud_For_STN_UART(9600);
						Stn_Old_BaudRate = 9600;
					}
					else if (strncasecmp("ATMA",(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App("?\r>");
					}
					else if(strncasecmp("ATMP",(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App("?\r>");
					}
					else if (strncasecmp("ATMR",(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App("?\r>");
					}
					else if (strncasecmp("ATMR",(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App("?\r>");
					}
					else if (strncasecmp("ATMT",(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App("?\r>");
					}
					else if (strncasecmp("ATDM",(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App("?\r>");
					}
					else
						Send_Command_To_STN((const char *)Gt_Cmnd);
					
					break;
				
				case 'S':
				case 's':
					if(strncasecmp(STN_CHANGE_BAUD,(const char *)Gt_Cmnd,5) == 0)
					{
						Stn_Baud_Rate = Get_BaudRate_Value(&Gt_Cmnd[5]);
						if((Stn_Baud_Rate > 3000000) || (Stn_Baud_Rate == -1))
							Received_Bad_Cmnd();
						else
						{
							if(Set_Baud_For_STN_UART(Stn_Baud_Rate) != ERR_FAILED)
							{
								Set_Baud_For_STN_UART(Stn_Old_BaudRate);
								Send_Command_To_STN((const char *)Gt_Cmnd);
								/*ClearQueue(STN_RX);*/
								Sleep(500);
								Send_To_STN_Queue('>');
								uint8_t Rx_Data = 0;
								while(Rx_Data != '>')
								{
									if(Read_From_Stn_Queue(&Rx_Data) != UART_LOW_Q_EMPTY)
									{
										if(Rx_Data == 'O' || Rx_Data == '?')
											break;
									}
								}
								if(Rx_Data != '?')
								{
									Set_Baud_For_STN_UART(Stn_Baud_Rate);
									Stn_Old_BaudRate = Stn_Baud_Rate;
									ClearQueue(STN_RX);
									Send_To_STN_Queue('O');
									Send_To_STN_Queue('K');
									Send_To_STN_Queue('\r');
									Send_To_STN_Queue('>');
								}
								else
								{
									Sleep(200);
									ClearQueue(STN_RX);
									Received_Bad_Cmnd();
								}
								
							}
							else
								Received_Bad_Cmnd();
						}
					}
					else if(strncasecmp(STN_SAVE_BAUD,(const char *)Gt_Cmnd,6)==0)
					{
						/*if((Stn_Baud_Rate != -1) && (Stn_Baud_Rate <= 3000000))
						{
							if(Set_Baud_For_STN_UART(Stn_Baud_Rate) != ERR_FAILED)
								Send_Ack_To_App();
							else
								Send_Response_To_App("FAILED\r>");
						}
						else
							Send_Response_To_App("FAILED\r>");*/
						Received_Bad_Cmnd();	
					}
					else if(strncasecmp("STBR",(const char *)Gt_Cmnd,4) == 0)
					{
						Received_Bad_Cmnd();
					}
					else if(strncasecmp("STMA",(const char *)Gt_Cmnd,4) == 0)
					{
						Received_Bad_Cmnd();
					}
					else if (strncasecmp("STM",(const char *)Gt_Cmnd,3) == 0)
					{
						Received_Bad_Cmnd();
					}
					else if(strncasecmp("STMFR\r",(const char *)Gt_Cmnd,6) == 0)
					{
						Send_Response_To_App("GLOBAL EDGE SOFTWARE LTD\r\r>");
					}
					else if(strncasecmp("STSL",(const char *)Gt_Cmnd,4) == 0)
						Received_Bad_Cmnd();
					else if(strncasecmp("STGP",(const char *)Gt_Cmnd,4) == 0)
						Received_Bad_Cmnd();
					else if(strncasecmp("STPX",(const char *)Gt_Cmnd,4) == 0)
					{
						Send_Command_To_STN((const char *)Gt_Cmnd);
						ISO15765_Frame = true;
					}
					else
						Send_Command_To_STN((const char *)Gt_Cmnd);
				
					break;
					
				case 'G':
				case 'g':
					if(strncasecmp(AES_ON,(const char *)Gt_Cmnd,8) == 0)
					{
						Send_Ack_To_App();
						Aes_Enabled = true;
					}
					else if(strncasecmp(AES_OFF,(const char *)Gt_Cmnd,9)==0)
					{
						Send_Ack_To_App();
						Aes_Enabled = false;
					}
					else if(strncasecmp(CHANGE_AES_IV,(const char *)Gt_Cmnd,4) == 0)
					{	
						if(Get_AES_IV_Value(&Gt_Cmnd[4],(uint8_t*)Aes_Session_Iv))
						{
							Set_IintVec_For_AES(Aes_Session_Iv);
							Send_Ack_To_App();
						}
						else
							Received_Bad_Cmnd();
					}
					else if(strncasecmp(CHANGE_AES_KEY,(const char *)Gt_Cmnd,5) == 0)
					{
						if(Get__AES_Key_Value(&Gt_Cmnd[5],(uint8_t*)Aes_Session_Key))
						{
							Set_Key_For_AES(Aes_Session_Key);
							Send_Ack_To_App();
						}
						else
							Received_Bad_Cmnd();
					}
					else if(strncasecmp(GL_FIRMWARE_ID,(const char *)Gt_Cmnd,4)==0)
					{
						Send_Response_To_App(GARUDA_LITE_FIRMWARE_VERSION);
					}
					else if (strncasecmp((const char *)CHANGE_BT_NAME,(const char *)Gt_Cmnd,6)==0)
					{
						/*Get the configurations and flag from NVM*/
						Get_BT_Config_From_NVM((uint8_t*)&Bt_Nvm_Config);
						int len = 0;
						for (int j = 6;Gt_Cmnd[j] != '\r';j++,len++);
						if(len < 20)
						{
							memcpy(Bt_Nvm_Config.name,&Gt_Cmnd[6],len+1);
							Bt_Nvm_Config.flag &= (~BT_NAME_CHANGED);
							Update_BT_Config_To_NVM((uint8_t *)&Bt_Nvm_Config);
							Send_Ack_To_App();
						}
						else
							Received_Bad_Cmnd();
							
					}
					else if (strncasecmp((const char *)CHANGE_BT_PIN,(const char *)Gt_Cmnd,5)==0)
					{
						/*Get the configurations and flag from NVM*/
						Get_BT_Config_From_NVM((uint8_t*)&Bt_Nvm_Config);
						int len = 0;
						for (int j = 5;Gt_Cmnd[j] != '\r';j++,len++);
						if(len < 9)
						{
							memcpy(Bt_Nvm_Config.pin,&Gt_Cmnd[5],len+1);
							Bt_Nvm_Config.flag &= (~BT_PIN_CHANGED);
							Update_BT_Config_To_NVM((uint8_t *)&Bt_Nvm_Config);
							Send_Ack_To_App();
						}
						else
							Received_Bad_Cmnd();
					}
					else if (strncasecmp((const char *)UPDATE_BT_FW,(const char *)Gt_Cmnd,6) == 0)
					{
						/*Get the configurations and flag from NVM*/
						//Get_BT_Config_From_NVM((uint8_t*)&Bt_Nvm_Config);
						//Update_BT_Config_To_NVM((uint8_t *)&Bt_Nvm_Config);
					}
					else if (strncasecmp((const char *)UPDATE_GL_FW,(const char *)Gt_Cmnd,6) == 0)
					{
						/*Change the entry point address and set everything to defaults*/
						App_Entry_Buffer = 0xFFFFFFFF;
						Update_App_Entry_Point(&App_Entry_Buffer);
						App_Entry_Buffer = 0x00000000;
						Send_Ack_To_App();
					}
					else
						Received_Bad_Cmnd();
						
					break;
					
				default:
					Send_Command_To_STN((const char *)Gt_Cmnd);
					break;
			}
			memset(Gt_Cmnd,0,STN_MAX_CMND_SIZE);
		}
		
		}
		
		/*Below code is only for USB, Because we have to read manually every byte from USB*/
		if(Usb_Enabled)
		{
			if(udi_cdc_is_rx_ready())
			{
				Tx_Data = udi_cdc_getc();
				/*Note: It is assumed that AES_CTR_Encrypt_Data will never enter into blocking state*/
				//if(Aes_Enabled)
				//	AES_CTR_Encrypt_Data((uint8_t *)&Tx_Data);
				
				Send_To_App_Queue(Tx_Data);
			}
		}
	}
	
	return;
}


/*******************************************************************************
* Function Name  : Received_Bad_Cmnd
* Description    : If Invalid command is requested then it sends Negative response
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void Received_Bad_Cmnd(void)
{
	Send_Response_To_App("?\r\r>");
	
}


/*******************************************************************************
* Function Name  : Send_Ack_To_App
* Description    : This function sends the Postivie ACK to application
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void Send_Ack_To_App(void)
{
	Send_Response_To_App("OK\r\r>");
}

/*******************************************************************************
* Function Name  : Send_Response_To_App
* Description    : This function sends the response to STN Queue which gets 
				   transmitted to Application
* Input          : Pointer to the data buffer
* Output         : None
* Return         : None
*******************************************************************************/
Status_t Send_Response_To_App(const char * Buf)
{
	while(*Buf != '>')
	{
		Send_To_STN_Queue(*Buf);
		Buf++;
	}
	Send_To_STN_Queue(*Buf);
	
	return ERR_SUCCESS;
}


/*******************************************************************************
* Function Name  : Get__AES_Key_Value
* Description    : Fetches the Key value from the Command buffer
* Input          : pointer to key buffer and key variable
* Output         : key
* Return         : bool
*******************************************************************************/
bool Get__AES_Key_Value(uint8_t * Aes_Key_Cmnd, uint8_t * Aes_Key)
{
	short Length = 0;
	uint8_t * Temp_Cmnd = NULL;
	short indx = 0;
	Temp_Cmnd = Aes_Key_Cmnd;
	
	while(*Aes_Key_Cmnd != '\r')
	{
		/*if((*Aes_Key_Cmnd >= '0') || (*Aes_Key_Cmnd <='9'))
		{
			*Aes_Key_Cmnd = *Aes_Key_Cmnd - '0';
			Aes_Key_Cmnd++;
			Length++;
		}
		else if ((*Aes_Key_Cmnd >= 'A') || (*Aes_Key_Cmnd <='F'))
		{
			*Aes_Key_Cmnd = *Aes_Key_Cmnd - 'A'+10;
			Aes_Key_Cmnd++;
			Length++;
		}
		else if ((*Aes_Key_Cmnd >= 'a') || (*Aes_Key_Cmnd <='f'))
		{
			*Aes_Key_Cmnd = *Aes_Key_Cmnd - 'a'+10;
			Aes_Key_Cmnd++;
			Length++;
		}
		else
		return false;
		*/
		Aes_Key_Cmnd++;
		Length++;
	}
	
	if(Length != 16)
		return false;
	
	memcpy(Aes_Key,Temp_Cmnd,16);
	/*while(indx < 16)
	{
		Aes_Key[indx++] = (Temp_Cmnd[Length-2] << 4) + Temp_Cmnd[Length-1] ;
		Length = Length -2;
	}*/

	return true;
}

/*******************************************************************************
* Function Name  : Get_AES_IV_Value
* Description    : Fetches the IV value from the command buffer
* Input          : pointer to IV buffer and IV variable
* Output         : IV variable
* Return         : bool
*******************************************************************************/
bool Get_AES_IV_Value(uint8_t * Aes_Iv_Cmnd, uint8_t * Aes_Iv)
{
	short Length = 0;
	uint8_t * Temp_Cmnd = NULL;
	short indx = 0;
	Temp_Cmnd = Aes_Iv_Cmnd;
	
	while(*Aes_Iv_Cmnd != '\r')
	{/*
		if((*Aes_Iv_Cmnd >= '0') || (*Aes_Iv_Cmnd <='9'))
		{
			*Aes_Iv_Cmnd = *Aes_Iv_Cmnd - '0';
			Aes_Iv_Cmnd++;
			Length++;
		}
		else if ((*Aes_Iv_Cmnd >= 'A') || (*Aes_Iv_Cmnd <='F'))
		{
			*Aes_Iv_Cmnd = *Aes_Iv_Cmnd - 'A'+10;
			Aes_Iv_Cmnd++;
			Length++;
		}
		else if ((*Aes_Iv_Cmnd >= 'a') || (*Aes_Iv_Cmnd <='f'))
		{
			*Aes_Iv_Cmnd = *Aes_Iv_Cmnd - 'a'+10;
			Aes_Iv_Cmnd++;
			Length++;
		}
		else
			return false;*/
		Aes_Iv_Cmnd++;
		Length++;
	}
	
	if(Length != 16)
		return false;
		
	memcpy(Aes_Iv,Temp_Cmnd,16);
	
	/*while(indx < 16)
	{
		Aes_Iv[indx++] = (Temp_Cmnd[Length-2] << 4) + Temp_Cmnd[Length-1] ;
		Length = Length -2;
	}*/

	return true;
}


/*******************************************************************************
* Function Name  : Get_BaudRate_Value
* Description    : Fetches the baud rate from the command buffer
* Input          : pointer to command buffer
* Output         : 
* Return         : baud rate
*******************************************************************************/
long Get_BaudRate_Value(uint8_t * Baud_Rate_Cmnd)
{
	long Baud_Rate = 0;
	short Length = 0;
	uint8_t *Temp_Cmnd = NULL;
	Temp_Cmnd = Baud_Rate_Cmnd;
	
	while(*Baud_Rate_Cmnd != '\r')
	{
		if((*Baud_Rate_Cmnd < '0') || (*Baud_Rate_Cmnd >'9'))
			return -1;  
		Baud_Rate_Cmnd++;
		Length++;
	}
	
	if(Length > 7)
		return -1;
	
	while(*Temp_Cmnd != '\r')
	{
		Length--;
		Baud_Rate = Baud_Rate + ((*Temp_Cmnd) - '0') * (pow(10,Length));
		Temp_Cmnd++;
	}
	
	return Baud_Rate;
}