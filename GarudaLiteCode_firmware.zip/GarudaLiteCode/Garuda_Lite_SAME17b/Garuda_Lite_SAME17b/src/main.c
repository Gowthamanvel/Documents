/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : main.c
** Description    : Mediator between the BT module/USB and STN2120
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "Bluetooth/BT_909.h"
#include "AES_CTR_MODE/aes_ctr.h"
#include "STN2120/stn2120.h"
#include "Queue/queue.h"
#include "GarudaLite_config.h"
#include "LED_Status/LedStatus.h"
#include "USB_DEVICE/usb_com_device.h"
#include "NVM/DataStorage.h"
#include "Timer/timer.h"
#include "main.h"
#include <string.h>
#include <math.h>
#include "ASF/sam0/drivers/usb/usb.h"		/*Added a function to get USB disconnected status in usb.h*/


/*#define TEST_SETUP*/



/******************************************************************************
**               I N T E R N A L     V A R I A B L E S
******************************************************************************/
GarudaLite_States_t garuda_lite_state = ERR_STATE;
extern bool usb_enabled;
static uint8_t stn_cmd[50];
static volatile uint8_t stn_cmd_indx = 0;
static int32_t stn_baudrate = 0;
static int32_t stn_old_baudrate = 9600;
bool aes_enabled = false;
bool echo_enabled = true;
uint32_t  aes_session_key[4];
uint32_t aes_session_init_vec[4];
struct bt_config bt_nvm_config;
static uint32_t app_entry_buffer = 0x00000000;



#ifdef TEST_SETUP
	volatile int App_tx_count = 0;
	uint32_t Clock_Value = 0;
#endif

bool init_peripherals(void);
void process_app_request(void);
void process_stn_response(void);
void handle_at_cmd(const char *);
void handle_st_cmd(const char *);
void handle_gt_cmd(const char *);
Status_t send_response_to_app(const char * );
Status_t ASCII_To_Decimal(uint8_t * , uint8_t * );
void received_bad_stn_cmd(void);
long get_baudrate_from_commmand(uint8_t * );
bool get_key_from_stn_cmd(uint8_t * ,uint8_t *);
bool get_initvec_from_stn_cmd(uint8_t * , uint8_t * );
void send_ack_to_app(void);



/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/


int main(void)
{	
	system_init();

#ifdef TEST_SETUP
	Clock_Value = system_cpu_clock_get_hz();
#endif
	
	/************Enable interrupt********************/
	system_interrupt_enable_global();

	
	garuda_lite_state = INIT_STATE;
	
	while(1)
	{
		switch (garuda_lite_state)
		{
			case INIT_STATE:	
				initialize_gpio();
				initialize_nvm();
				init_timer();
				usb_led(TURN_ON);
				/*Update App entry point in the NVM*/
				get_app_entry_point((uint8_t * )&app_entry_buffer);
				if(app_entry_buffer == 0xFFFFFFFF)
				{
					Sleep(2000);
					app_entry_buffer = 0x00000000;
					update_app_entry_point((uint8_t * )&app_entry_buffer);
					get_bt_config_from_nvm((uint8_t*)&bt_nvm_config);
					bt_nvm_config.flag |= BT_BAUD_CHANGE;
					update_bt_config_in_nvm((uint8_t *)&bt_nvm_config);
				}
				init_peripherals();
				if(garuda_lite_state == ERR_STATE)
					break;
				else
					garuda_lite_state = PARSING_STATE;
							
				clear_queue(APP_RX);
				clear_queue(STN_RX);
				usb_led(TURN_OFF);
				bluetooth_led(TURN_ON);	
				break;
			
			case PARSING_STATE:	
				if(usb_enabled)
					if(usb_disconnected())
						Usb_Device_Closed(0);
					
				process_stn_response();
				process_app_request();
				break;
			
			case RECOVER_STATE:
				/*If initialization fails try to recover it, If not go to error state*/
				break;
			
			case ERR_STATE:
				while(1)
				{
					/*Blink ERR_STATUS LED*/
					/*usb_led(false);*/
					usb_led(TURN_ON);
					bluetooth_led(TURN_ON);
					Sleep(500);
					usb_led(TURN_OFF);
					bluetooth_led(TURN_OFF);
					Sleep(500);
				}
				break;
			
			default :
				/*do nothing*/
				break;
		}
	}
}



/*******************************************************************************
* Function Name  : init_pheripherals
* Description    : Initializes the required peripherals
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
bool init_peripherals(void)
{
	short int Init_Err_Cnt = 10;
	
	while((initialize_aes() != ERR_SUCCESS))
	if((--Init_Err_Cnt) <= 0) { garuda_lite_state = ERR_STATE; return false; }
	
	Init_Err_Cnt = 10;
	while((init_bluetooth() != ERR_SUCCESS))
	if((--Init_Err_Cnt) <= 0) { garuda_lite_state = ERR_STATE; return false; }
	
	Init_Err_Cnt = 10;
	while((initialize_stn_device() != ERR_SUCCESS))
	if((--Init_Err_Cnt) <= 0) { garuda_lite_state = ERR_STATE; return false; }
	
	initialize_usb_com();
	
	return true;
}


/*******************************************************************************
* Function Name  : process_stn_response
* Description    : polls queue for data and transmits over bt_usart
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void process_stn_response(void)
{
	uint8_t tx_buffer[64];
	uint8_t tx_data = 0;
	uint8_t tx_count = 0;

	/*Continue to parse until STN_RX queue becomes empty*/
	while(read_data_from_stn_queue(&tx_data) != QUEUE_EMPTY)
	{		
		/*Note:It is assumed that AES encryption will never go into blocking state*/
		if(aes_enabled)
			encrypt_data(&tx_data);
		
		if(usb_enabled)
		{
			tx_buffer[tx_count] = tx_data;
			tx_count = tx_count + 1;
			
			if(tx_count >=64)
				break;
		}
		else
		{
			write_byte_to_bluetooth(tx_data);
		}
			
		/*Chethan: In monitor all mode the application has to get chance to terminate the mode*/
		/*if(get_queue_status(APP_RX) != QUEUE_EMPTY)
			break;*/
	}
	
	if(usb_enabled && (tx_count > 0)) 
		while(udi_cdc_write_buf(tx_buffer,tx_count) != 0);
	
	return;
}



/*******************************************************************************
* Function Name  : process_app_request
* Description    : polls queue for data and transmits over stn_usart
* Input          :
* Output         : None
* Return         : None
********************************************************************************/
void process_app_request(void)
{
	uint8_t tx_data = 0;
	/*Continue to send data until the BT_RX queue become empty*/
	while(read_data_from_app_queue(&tx_data) != QUEUE_EMPTY )
	{
		/*Note:It is assumed that AES encryption will never go into blocking state*/
		if(aes_enabled)
			encrypt_data(&tx_data);
			
		if(tx_data != ' ')
		{
			if(stn_cmd_indx < 50)
				stn_cmd[stn_cmd_indx++] = tx_data;
			
			if(tx_data == DELIMITER)
				break;
		}	
		write_to_stn_device(tx_data);
		
		if(usb_enabled)
		{
			if(udi_cdc_is_rx_ready())
			{
				tx_data = udi_cdc_getc();
				send_data_to_app_queue(tx_data);
			}
		}
	}
	
	if(tx_data == DELIMITER)
	{	
		switch(stn_cmd[0])
		{
			case 'a':
			case 'A':
				handle_at_cmd((const char *)&stn_cmd);
				break;
			
			case 'S':
			case 's':
				handle_st_cmd((const char *)&stn_cmd);
				break;
				
			case 'G':
			case 'g':
				handle_gt_cmd((const char *)&stn_cmd);
				break;
				
			default:
				write_to_stn_device(tx_data);
				break;
		}
		
		memset(stn_cmd,0,50);
		stn_cmd_indx = 0;
	}
	
	return;
}


void handle_st_cmd( const char * cmnd)
{
	if(strncasecmp(STN_CHANGE_BAUD,cmnd,5) == 0)
	{
		stn_baudrate = get_baudrate_from_commmand(&stn_cmd[5]);
		if((stn_baudrate > 3000000) || (stn_baudrate == -1))
		{
			write_to_stn_device(BAD_CMD_CHAR);
			write_to_stn_device(DELIMITER);
		}
		else
		{
			if(change_stn_uart_baudrate(stn_baudrate) != ERR_FAILED)
			{
				change_stn_uart_baudrate(stn_old_baudrate);
				write_to_stn_device(DELIMITER);
				/*clear_queue(STN_RX);*/
				Sleep(300);
				
				uint8_t Rx_Data = 0;
				if(read_data_from_stn_queue(&Rx_Data) == QUEUE_EMPTY)
					send_data_to_stn_queue(READY_CHAR);
				
				while(Rx_Data != '>')
				{
					if(read_data_from_stn_queue(&Rx_Data) != QUEUE_EMPTY)
					{
						if(Rx_Data == 'O' || Rx_Data == BAD_CMD_CHAR)
							break;
					}
				}
				if(Rx_Data != '?')
				{
					Sleep(200);
					change_stn_uart_baudrate(stn_baudrate);
					stn_old_baudrate = stn_baudrate;
					clear_queue(STN_RX);
					send_data_to_stn_queue('O');
					send_data_to_stn_queue('K');
					send_data_to_stn_queue('\r');
					send_data_to_stn_queue('\r');
					send_data_to_stn_queue('>');
				}
				else
				{
					Sleep(200);
					clear_queue(STN_RX);
					received_bad_stn_cmd();
				}
			}
			else
			{
				write_to_stn_device(BAD_CMD_CHAR);
				write_to_stn_device(DELIMITER);
			}
		}
	}
	else if(strncasecmp("STMFR\r",cmnd,6) == 0)
	{
		write_to_stn_device(DELIMITER);
		Sleep(200);
		clear_queue(STN_RX);
		send_response_to_app("GLOBAL EDGE SOFTWARE LTD\r\r>");
	}
	else if(strncasecmp(STN_SAVE_BAUD_CMD,cmnd,6)==0 || \
			strncasecmp("STBR",cmnd,4) == 0      || \
			strncasecmp("STMA",cmnd,4) == 0      || \
			strncasecmp("STM",cmnd,3) == 0       || \
			strncasecmp("STSL",cmnd,4) == 0      || \
			strncasecmp("STGP",cmnd,4) == 0 )
	{
		write_to_stn_device(BAD_CMD_CHAR);
		write_to_stn_device(DELIMITER);
	}
	else
		write_to_stn_device(DELIMITER);
		
}


void handle_at_cmd(const char * cmnd)
{
	if( strncasecmp(PROGRAM_PARAMETER_CMD,cmnd,6) == 0 || \
		strncasecmp(ELM_CHANGE_BAUD_CMD,cmnd,5) == 0   || \
		strncasecmp(MONITOR_ALL_MSG_CMD,cmnd,4) == 0   || \
		strncasecmp(MONITOR_PGN_MSG_CMD,cmnd,4) == 0   || \
		strncasecmp(ELM_MONITOR_RX_CMD,cmnd,4) == 0    || \
		strncasecmp(ELM_MONITOR_TX_CMD,cmnd,4) == 0    || \
		strncasecmp(ELM_MONITOR_DM_CMD,cmnd,4) == 0  ) 
	{
		write_to_stn_device(BAD_CMD_CHAR);
		write_to_stn_device(DELIMITER);
	}
	else if(strncasecmp(ELM_RESET_CMD,cmnd,3)==0)
	{
		write_to_stn_device(DELIMITER);
		Sleep(500);
		change_stn_uart_baudrate(9600);
		stn_old_baudrate = 9600;
	}
	else
		write_to_stn_device(DELIMITER);
}



void handle_gt_cmd(const char * cmd)
{
	if(strncasecmp(AES_ON,cmd,8) == 0)
	{
		write_to_stn_device(DELIMITER);
		Sleep(100);
		clear_queue(STN_RX);
		send_ack_to_app();
		aes_enabled = true;
	}
	else if(strncasecmp(AES_OFF,cmd,9)==0)
	{
		write_to_stn_device(DELIMITER);
		Sleep(100);
		clear_queue(STN_RX);
		aes_enabled = false;
		send_ack_to_app();
	}
	else if(strncasecmp(CHANGE_AES_IV,cmd,4) == 0)
	{
		if(get_initvec_from_stn_cmd(&stn_cmd[4],(uint8_t*)aes_session_init_vec))
		{
			change_encryption_iv(aes_session_init_vec);
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			send_ack_to_app();
		}
		else
		{
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			received_bad_stn_cmd();
		}
	}
	else if(strncasecmp(CHANGE_AES_KEY,cmd,5) == 0)
	{
		if(get_key_from_stn_cmd(&stn_cmd[5],(uint8_t*)aes_session_key))
		{
			change_encryption_key(aes_session_key);
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			send_ack_to_app();
		}
		else
		{
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			received_bad_stn_cmd();
		}
	}
	else if(strncasecmp(GL_FIRMWARE_ID,cmd,4)==0)
	{
		write_to_stn_device(DELIMITER);
		Sleep(100);
		clear_queue(STN_RX);
		send_response_to_app(GARUDA_LITE_FIRMWARE_VERSION);
	}
	else if(strncasecmp(GL_MANUFACTURER,cmd,6)==0)
	{
		write_to_stn_device(DELIMITER);
		Sleep(100);
		clear_queue(STN_RX);
		send_response_to_app("GLOBAL EDGE SOFTWARE LTD\r\r>");
	}
	else if (strncasecmp(CHANGE_BT_NAME,cmd,6)==0)
	{
		/*Get the configurations and flag from NVM*/
		get_bt_config_from_nvm((uint8_t*)&bt_nvm_config);
		int len = 0;
		for (int j = 6;stn_cmd[j] != DELIMITER;j++,len++);
		if(len < 20)
		{
			memcpy(bt_nvm_config.name,&stn_cmd[6],len+1);
			bt_nvm_config.flag &= (~BT_NAME_CHANGED);
			update_bt_config_in_nvm((uint8_t *)&bt_nvm_config);
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			send_ack_to_app();
		}
		else
		{
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			received_bad_stn_cmd();
		}
		
	}
	else if (strncasecmp(CHANGE_BT_PIN,cmd,5)==0)
	{
		/*Get the configurations and flag from NVM*/
		get_bt_config_from_nvm((uint8_t*)&bt_nvm_config);
		int len = 0;
		for (int j = 5;stn_cmd[j] != DELIMITER;j++,len++);
		if(len < 9)
		{
			memcpy(bt_nvm_config.pin,&stn_cmd[5],len+1);
			bt_nvm_config.flag &= (~BT_PIN_CHANGED);
			update_bt_config_in_nvm((uint8_t *)&bt_nvm_config);
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			send_ack_to_app();
		}
		else
		{
			write_to_stn_device(DELIMITER);
			Sleep(100);
			clear_queue(STN_RX);
			received_bad_stn_cmd();
		}
	}
	else if (strncasecmp(UPDATE_BT_FW,cmd,6) == 0)
	{
		/*Get the configurations and flag from NVM*/
		//get_bt_config_from_nvm((uint8_t*)&bt_nvm_config);
		//update_bt_config_in_nvm((uint8_t *)&bt_nvm_config);
		
		write_to_stn_device(DELIMITER);
	}
	else if (strncasecmp((const char *)UPDATE_GL_FW,cmd,6) == 0)
	{
		/*Change the entry point address and set everything to defaults*/
		app_entry_buffer = 0xFFFFFFFF;
		update_app_entry_point((uint8_t *)&app_entry_buffer);
		app_entry_buffer = 0x00000000;
		write_to_stn_device(DELIMITER);
		Sleep(100);
		clear_queue(STN_RX);
		write_byte_to_bluetooth('O');
		write_byte_to_bluetooth('K');
		write_byte_to_bluetooth('\r');
		write_byte_to_bluetooth('\r');
		write_byte_to_bluetooth('>');
		Sleep(2000);
		//deinit_bluetooth();
		//disable_stn_uart();
		//usb_led(TURN_OFF);
		//bluetooth_led(TURN_OFF);
		//disable_usb_com();
		//write_to_stn_device(ELM_RESET_CMD"\r");
		/*send_ack_to_app();*/
		/*Update the bt_nvm_config and then restart*/
		NVIC_SystemReset();
		/* Re-base the Stack Pointer 
		__set_MSP(*(uint32_t *) 0x00000000);

		// Re-base the vector table base address 
		SCB->VTOR = ((uint32_t) 0x00000000 & SCB_VTOR_TBLOFF_Msk);

		//Jump to application Reset Handler in the application 
		asm("bx %0"::"r"(*(uint32_t *)(0x00000000 + 4)));*/
	}
	else
		write_to_stn_device(DELIMITER);
}


/*******************************************************************************
* Function Name  : received_bad_stn_cmd
* Description    : If Invalid stn_cmd is requested then it sends Negative response
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void received_bad_stn_cmd(void)
{
	send_response_to_app("?\r\r>");
	
}


/*******************************************************************************
* Function Name  : send_ack_to_app
* Description    : This function sends the Postivie ACK to application
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void send_ack_to_app(void)
{
	send_response_to_app("OK\r\r>");
}

/*******************************************************************************
* Function Name  : send_response_to_app
* Description    : This function sends the response to STN Queue which gets 
				   transmitted to Application
* Input          : Pointer to the data buffer
* Output         : None
* Return         : None
*******************************************************************************/
Status_t send_response_to_app(const char * Buf)
{
	while(*Buf != READY_CHAR)
	{
		send_data_to_stn_queue(*Buf);
		Buf++;
	}
	send_data_to_stn_queue(*Buf);
	
	return ERR_SUCCESS;
}


/*******************************************************************************
* Function Name  : get_key_from_stn_cmd
* Description    : Fetches the Key value from the stn_cmd buffer
* Input          : pointer to key buffer and key variable
* Output         : key
* Return         : bool
*******************************************************************************/
bool get_key_from_stn_cmd(uint8_t * Aes_Key_Cmnd, uint8_t * Aes_Key)
{
	short Length = 0;
	uint8_t * temp_cmd = NULL;
	/*short indx = 0;*/
	temp_cmd = Aes_Key_Cmnd;
	
	while(*Aes_Key_Cmnd != DELIMITER)
	{
		Aes_Key_Cmnd++;
		Length++;
	}
	
	if(Length != 16)
		return false;
	
	memcpy(Aes_Key,temp_cmd,16);
	return true;
}

/*******************************************************************************
* Function Name  : get_initvec_from_stn_cmd
* Description    : Fetches the IV value from the stn_cmd buffer
* Input          : pointer to IV buffer and IV variable
* Output         : IV variable
* Return         : bool
*******************************************************************************/
bool get_initvec_from_stn_cmd(uint8_t * Aes_Iv_Cmnd, uint8_t * Aes_Iv)
{
	short Length = 0;
	uint8_t * temp_cmd = NULL;
	temp_cmd = Aes_Iv_Cmnd;
	
	while(*Aes_Iv_Cmnd != DELIMITER)
	{
		Aes_Iv_Cmnd++;
		Length++;
	}
	
	if(Length != 16)
		return false;
		
	memcpy(Aes_Iv,temp_cmd,16);
	return true;
}


/*******************************************************************************
* Function Name  : get_baudrate_from_commmand
* Description    : Fetches the baud rate from the stn_cmd buffer
* Input          : pointer to stn_cmd buffer
* Output         : 
* Return         : baud rate
*******************************************************************************/
long get_baudrate_from_commmand(uint8_t * cmd)
{
	long baud_rate = 0;
	short Length = 0;
	uint8_t *temp_cmd = NULL;
	temp_cmd = cmd;
	
	while(*cmd != DELIMITER)
	{
		if((*cmd < '0') || (*cmd >'9'))
			return -1;  
		cmd++;
		Length++;
	}
	
	if(Length > 7)
		return -1;
	
	/*for(; *temp_cmd != '\r';Length--,temp_cmd++)
		baud_rate = (baud_rate * 10) + (*temp_cmd - '0');*/
		
	while(*temp_cmd != '\r')
	{
		Length--;
		baud_rate = baud_rate + ((*temp_cmd) - '0') * (pow(10,Length));
		temp_cmd++;
	}
	
	return baud_rate;
}