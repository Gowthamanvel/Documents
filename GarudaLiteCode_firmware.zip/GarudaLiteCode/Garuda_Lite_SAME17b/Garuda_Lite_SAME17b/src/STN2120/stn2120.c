/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : stn2120.c
** Description    :	
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/
 

/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "stn2120.h"
#include "GarudaLite_config.h"
#include "Queue/queue.h"

/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/
struct usart_module UART_STN_Module;
struct usart_config UART_STN_Config;
/*bool volatile response_received = false;*/
Status_t initialize_stn_module(void);

/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/

Status_t initialize_stn_module(void)
{
	uint8_t Rx_Count = 0;
	uint8_t Rx_data = 0;
	uint8_t Stn_Echo_Disable_Cmnd[] = {"ATE0\r\0"};

	uint8_t response[8];
	
	clear_queue(STN_RX);
	for(int i=0; i<5;i++)
		write_to_stn_device(Stn_Echo_Disable_Cmnd[i]);
	
	while(Rx_Count < 10)
	{
		if(read_data_from_stn_queue(&Rx_data) != QUEUE_EMPTY)
		{
			response[Rx_Count] = Rx_data;
			Rx_Count++;
			if(Rx_data == '>')
				break;
		}
	}
	
	return ERR_SUCCESS;
}



Status_t initialize_stn_device(void)
{
	
	usart_get_config_defaults(&UART_STN_Config);
	UART_STN_Config.baudrate = STN_DEFAULT_BAUD;
	UART_STN_Config.mux_setting = STN_UART_MUX_SETTING;
	
	//! initialize the UART
	if(usart_init(&UART_STN_Module,STN_MODULE, &UART_STN_Config) != STATUS_OK) {
		return ERR_FAILED;
	}
	
	usart_enable(&UART_STN_Module);
	
	//Chethan: This line is required to Enable the RXC interrupt and ISR_UART will handle the Rest.
	UART_STN_Module.hw->USART.INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
	
	//initialize_stn_module();
	
	return ERR_SUCCESS;
}



Status_t write_to_stn_device(uint8_t data)
{
	/****Manually write the data to data register and wait for DRE flag to enable*****/
	UART_STN_Module.hw->USART.DATA.reg = data;
	
	//Chethan: IT has been assumed that the below code will never enter into blocking state
	while (!(UART_STN_Module.hw->USART.INTFLAG.reg & SERCOM_USART_INTFLAG_DRE));
	
	return ERR_SUCCESS;
}


Status_t send_command_to_stn(const char * arr)
{
	while(*arr != '\r')
	{
		write_to_stn_device(*arr);
		arr++;
	}
	write_to_stn_device(*arr);
	
	return ERR_SUCCESS;
}



Status_t change_stn_uart_baudrate(long baud_rate)
{
	//disable the uart 
	UART_STN_Module.hw->USART.INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	usart_disable(&UART_STN_Module);
	
	//set new baud rate
	UART_STN_Config.baudrate = baud_rate;
	
	//! initialize the UART with new baud rate
	if(usart_init(&UART_STN_Module,STN_MODULE, &UART_STN_Config) != STATUS_OK) {
		return ERR_FAILED;
	}
	
	usart_enable(&UART_STN_Module);
	
	//Chethan: This line is required to Enable the RXC interrupt and ISR_UART will handle the Rest.
	UART_STN_Module.hw->USART.INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
	
	return ERR_SUCCESS;
	
}



void disable_stn_uart()
{
	UART_STN_Module.hw->USART.INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	usart_disable(&UART_STN_Module);
}


void enable_stn_uart()
{
	UART_STN_Module.hw->USART.INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
	usart_enable(&UART_STN_Module);
}