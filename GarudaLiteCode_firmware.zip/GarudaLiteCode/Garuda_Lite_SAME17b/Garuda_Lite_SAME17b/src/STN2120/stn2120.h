/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : stn2120.h
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef STN2120_H_
#define STN2120_H_


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include <asf.h>
#include "usart.h"
#include "GarudaLite_config.h"

/******************************************************************************
**               F U N C T I O N S	P R O T O T Y P E S
******************************************************************************/


/*******************************************************************************
* Function Name  : initialize_stn_device
* Description    : Initializes the STN UARTx peripheral
* Input          :
* Output         : None
* Return         : Status_t
*******************************************************************************/
Status_t initialize_stn_device(void);


/*******************************************************************************
* Function Name  : write_to_stn_device
* Description    : writes data to STN UART
* Input          : data to be sent 
* Output         : None
* Return         : Status_t
*******************************************************************************/
Status_t write_to_stn_device(uint8_t data);

/*******************************************************************************
* Function Name  : send_command_to_stn
* Description    : writes data buffer to STN UART
* Input          : buffer to be sent
* Output         : None
* Return         : Status_t
*******************************************************************************/
Status_t send_command_to_stn(const char * arr);


/*******************************************************************************
* Function Name  : change_stn_uart_baudrate
* Description    : Changes the baud rate of STN UART
* Input          : Baud rate 
* Output         : None
* Return         : Status_t
*******************************************************************************/
Status_t change_stn_uart_baudrate(long baud_rate);


/*******************************************************************************
* Function Name  : get_stn_response
* Description    : Reads the response from the STN queue
* Input          : pointer to the response variable
* Output         : None
* Return         : Status_t
*******************************************************************************/
Status_t get_stn_response(uint8_t *);

/*******************************************************************************
* Function Name  : disable_stn_uart
* Description    : 
* Input          : 
* Output         : None
* Return         : 
*******************************************************************************/
void disable_stn_uart(void);

/*******************************************************************************
* Function Name  : enable_stn_uart
* Description    :
* Input          :
* Output         : None
* Return         :
*******************************************************************************/
void enable_stn_uart(void);


#endif /* STN2120_H_ */