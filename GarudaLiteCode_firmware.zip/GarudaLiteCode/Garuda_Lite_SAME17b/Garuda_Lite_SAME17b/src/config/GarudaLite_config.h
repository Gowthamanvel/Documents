/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : GarudaLite_config.h
** Description    :	default configuration for GarudaLite
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef GARUDALITE_H_
#define GARUDALITE_H_


/******************************************************************************
**               D A T A
******************************************************************************/

//Project details
#define COMPANAY_NAME "Global Edge Software Ltd\r"
#define GARUDA_LITE_FIRMWARE_VERSION	"Garuda_Lite_V0.0.2\r>"

//EPROM address
#define bt_config_NVM_ADDR			0x400000
#define BOOTLOADER_JUMP_ADDR		0x400100



/*Queue configuration*/
#define APP_UART_RX_SIZE		500
#define STN_UART_RX_SIZE		4000	//Chethan: Changed from 2048 to 4000 to improve bus load


/*********************AES configuration***************************************/
#define AES_CTR_KEY_SIZE		AES_KEY_SIZE_128
#define AES_PROCESS_MODE		AES_ENCRYPTION
#define ASE_OPERATING_MODE		AES_CTR_MODE
#define AES_CTR_IV_SIZE			AES_CFB_SIZE_128
#define AES_LOD_MODE			false			
#define AES_CTR_START_MODE		AES_MANUAL_START



/***********************STN2120 configuration**********************************/
#define STN_DEFAULT_BAUD		9600 //for IC's and 115200 for OBD boards
#define STN_MAX_BAUD_RATE		921600
#define STN_UART_MUX_SETTING	USART_RX_1_TX_0_XCK_1
#define STN_MODULE				SERCOM3
#define STN_MAX_CMND_SIZE		1000
#define DELIMITER				'\r'
#define BAD_CMD_CHAR			'?'
#define READY_CHAR				'>'



/***************************STN Command Sets************************************/
//#define STN_RESET				"STZ\r".		//Not working
#define ELM_RESET_CMD			"ATZ\r"			//Reset and back to default , Version number will prompt
#define ELM_SOFT_RESET			"ATWS\r"
/*Don't support the Following commands if the queue OK condition is set using '>'*/
#define MONITOR_ALL_MSG_CMD		"ATMA"
#define ELM_MONITOR_RX_CMD		"ATMR"
#define ELM_MONITOR_TX_CMD		"ATMT"
#define ELM_MONITOR_DM_CMD		"ATDM"
#define MONITOR_PGN_MSG_CMD		"ATMP"
#define ELM_PROGRAM_PARA		"ATPP"
#define STN_MONITOR_FILTER		"STM"
#define STN_MONITOR_ALL			"STMA"
//#define STN_DEFAULT			"STD\r"			//Not working
#define ELM_DEFAULT_CMD			"ATD\r"			//Back to default values   --------- is not working for baud rate changes
#define STN_CHANGE_BAUD			"STSBR"			//change baud rate current session
#define STN_SAVE_BAUD_CMD		"STWBR\r"		//set current baud as default baud.
#define FIRMWARE_ID				"STI\r"
#define FIRMWARE_ID_ELM			"ATI\r"			//firmware ID
#define HARDWARE_ID				"STDI\r"
//#define HARDWRAE_ID_ELM		"ATDI\r"		//device Hardware ID
#define MANUFACTURE_ID			"STMFR\r"
//#define MANUFACTURE_ID_ELM	"ATMFR\r"		//device Manufacture ID.
#define SERIAL_NO				"STSN\r"
//#define SERIAL_NO_ELM			"ATSN\r"		//serial number.
#define DEVICE_DESCRIPTION		"AT@1\r"		//device description
//define DEVICE_ID				"AT@2\r"		//Not working
#define ELM_CHANGE_BAUD_CMD		"ATBRD\r"		//xx is id for baud rate.(Actual baud rate = 4000/xx)kbps. Don't allow this
#define PROGRAM_PARAMETER_CMD	"ATPP"			//change baud rate based on xx value. Don't support this



/******************FSC-BT909 configuration*******************************/
#define BT_DEFAULT_BAUD			115200
#define BT_MAX_BAUD				921600	//Always set the BT baud to max
#define BT_UART_MUX_SETTING		USART_RX_1_TX_0_RTS_2_CTS_3 //USART_RX_1_TX_0_XCK_1 //select RTS and CTS pin  
#define BT_MODULE				SERCOM2

/******************GT commands*******************************************/
#define CHANGE_AES_KEY		"GTKEY"
#define CHANGE_AES_IV		"GTIV"
#define AES_ON				"GTAESON\r"
#define AES_OFF				"GTAESOFF\r"
#define GL_FIRMWARE_ID		"GTI\r"
#define GL_MANUFACTURER		"GTMFR\r"
#define CHANGE_BT_PIN		"GTPIN"
#define CHANGE_BT_NAME		"GTNAME"
#define UPDATE_BT_FW		"GTBTFW"
#define UPDATE_GL_FW		"GTFWUP\r"

/*********************GPIO pins ****************************************/
#define LINK_STATUS_LED		PIN_PA27//PIN_PB16
#define ERR_STATUS_LED		PIN_PA23
#define MCU_REST_PIN		PIN_PA07
#define USB_DETECT_PIN		PIN_PA06
#define SHUTDOWN_PIN		PIN_PA04


typedef enum {
	ERR_SUCCESS,
	ERR_FAILED
}Status_t;


typedef enum{
	INIT_STATE,
	ERR_STATE,
	PARSING_STATE,
	RECOVER_STATE
}GarudaLite_States_t;



/*USB CDC configuration*/
//Currently config_usb.h contains all the required configuration


#endif /* GARUDALITE_H_ */