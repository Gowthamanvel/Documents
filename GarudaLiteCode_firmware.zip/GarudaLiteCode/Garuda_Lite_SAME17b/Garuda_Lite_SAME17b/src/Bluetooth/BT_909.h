/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : BT_909.h
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef BT_909_H_
#define BT_909_H_

/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include <asf.h>
#include "usart.h"
#include "GarudaLite_config.h"


/* Bluetooth configuration parameters*/ 
#define BT_BAUD_CHANGE			(0x01ul << 0)
#define BT_FRMWARE_UPDATED		(0x01ul << 1)
#define BT_IN_TPMODE			(0x01ul << 2)
#define BT_FC_ENABLED			(0x01ul << 3)
#define BT_PIN_CHANGED			(0x01ul << 4)
#define BT_NAME_CHANGED			(0x01ul << 5)
#define BT_COD_CHANGED			(0x01ul << 6)
#define GL_FW_UPDATE			(0x01ul << 7)


/*BT config structure to hold all the configurations required*/
struct bt_config {
	uint8_t flag;
	uint8_t device_class;
	uint32_t buad_rate;
	uint8_t pin[10];		//8 byte ascii characters
	uint8_t name[20];
	}; 


/******************************************************************************
**               F U N C T I O N S	P R O T O T Y P E S
******************************************************************************/


/*******************************************************************************
* Function Name  : init_bluetooth
* Description    : Initializes the BT UARTx peripheral
* Input          :
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t init_bluetooth(void);

/*******************************************************************************
* Function Name  : deinit_bluetooth
* Description    : disables the UART module
* Input          :
* Output         :
* Return         : none
*******************************************************************************/
void deinit_bluetooth(void);


/*******************************************************************************
* Function Name  : write_byte_to_bluetooth
* Description    : Sends data over BT_UART
* Input          : uint8_t
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t write_byte_to_bluetooth(uint8_t data);

/*******************************************************************************
* Function Name  : write_buffer_to_bluetooth
* Description    : Sends data over BT_UART
* Input          : uint8_t
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t write_buffer_to_bluetooth(uint8_t *data,uint8_t length);


/*******************************************************************************
* Function Name  : enable_bt_com
* Description    : Enables the BT Module
* Input          :
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t enable_bt_com(void );


/*******************************************************************************
* Function Name  : Disable_BT
* Description    : Disables the BT Module
* Input          :
* Output         :
* Return         : Status_t
*******************************************************************************/
Status_t disable_bt_com(void);




#endif /* BT_909_H_ */