/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : BT_909.c
** Description    : Initializes the UART for BT module
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include "BT_909.h"
#include "Queue/queue.h"
#include "GarudaLite_config.h"
#include "LED_STATUS/LedStatus.h"
#include "NVM/DataStorage.h"
#include "Timer/timer.h"
#include <string.h>


/* Feasycom "AT" commands to control BT module features*/

#define BT_TP_MODE_ON			"AT+TPMODE=1\r\n\0"
#define BT_TP_MODE_OFF			"AT+TPMODE=0\r\n\0"
#define	BT_RESTART				"AT+REBOOT\r\n0"
#define BT_DISABLE				"AT+BTEN=0\r\n\0"
#define BT_ENABLE				"AT+BTEN=1\r\n\0"
#define BT_RESTORE				"AT+RESTORE\r\n\0"
#define BT_UART_FC				"AT+UARTCFG=1\r\n\0"
#define BT_TEST_OK				"AT\r\n\0"
#define BT_DEFAULT_PIN			"12345678"
#define BT_SSP_OFF				"AT+SSP=0\r\n\0"


/*Private functions*/
Status_t enable_tp_mode(void);
Status_t is_bt_module_working(void);
Status_t set_uart_baudrate(long baud_rate);
Status_t send_max_baudrate_cmd(void);
Status_t send_default_baudrate_cmd(void);
Status_t enable_flow_control(void);
void send_restore_cmd(void);
Status_t change_pairing_pin(void);
void change_device_name(void);
Status_t get_bt_response(uint8_t *);
Status_t init_bt_module(void);
void enable_spp_profile(void);

/******************************************************************************
*                   I N T E R N A L   V A R I A B L E S
*******************************************************************************/
struct usart_module UART_BT_Module;
struct usart_config UART_bt_config;
struct bt_config nvm_bt_config;



/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/

Status_t init_bluetooth(void)
{	
	/*Get the configurations from NVM*/
	get_bt_config_from_nvm((uint8_t*)&nvm_bt_config);
	
	/*Get the default configuration for UART*/
	usart_get_config_defaults(&UART_bt_config);

	if(!(nvm_bt_config.flag & BT_BAUD_CHANGE))
	{
		UART_bt_config.baudrate = BT_MAX_BAUD; //  Currently in android app it is not supported
	}
	else
	{
		/*for testing the baud is set to max otherwise set it to default*/
		UART_bt_config.baudrate = BT_DEFAULT_BAUD;
	}
	
	UART_bt_config.mux_setting = BT_UART_MUX_SETTING;
	
	/* initialize the UART*/
	if(usart_init(&UART_BT_Module,BT_MODULE, &UART_bt_config) != STATUS_OK) {
		return ERR_FAILED;
	}
	usart_enable(&UART_BT_Module);
	
	/*To manually enable RXC interrupt */
	UART_BT_Module.hw->USART.INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
	
	/*Make sure whether the communication is working*/
	if (is_bt_module_working() != ERR_SUCCESS)
	{
		deinit_bluetooth();
		return ERR_FAILED;
	}
	
	/*To initialize the BT module to the user defined configuration*/
	if (init_bt_module() != ERR_SUCCESS)
	{
		deinit_bluetooth();
		return ERR_FAILED;
	}
	
	/* Update the configuration that has been change during initializing the feasycom module*/
	update_bt_config_in_nvm((uint8_t *)&nvm_bt_config);
	/*To remove any traces of response from feasycom module while initializing*/
	clear_queue(APP_RX);
	
	return ERR_SUCCESS;
}



void deinit_bluetooth(void)
{
	/*Clear RXC interrupt flag*/
	UART_BT_Module.hw->USART.INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	
	usart_disable(&UART_BT_Module);
	update_bt_config_in_nvm((uint8_t *)&nvm_bt_config);
}



Status_t init_bt_module(void)
{
	/*In case the feasycom module firmware is updated, We need to reboot the module,
	this may not happen regularly. Only when there is an update from the feasycom we 
	should flash BT module using feasycom android application*/
	if(!(nvm_bt_config.flag & BT_FRMWARE_UPDATED))
	{
		/*After rebooting the BT module will set its baud to 115200*/
		if(send_default_baudrate_cmd() != ERR_SUCCESS)
			return ERR_FAILED;
		else
			send_restore_cmd();
		
		/*give some time for BT to restore back to defaults*/
		Sleep(1500);
		/*Update the BT configuration flags*/
		nvm_bt_config.flag &= (~BT_FRMWARE_UPDATED);
		nvm_bt_config.flag &= (~BT_BAUD_CHANGE);
		set_uart_baudrate(115200);
		clear_queue(APP_RX);
	}
	
	if((nvm_bt_config.flag & BT_COD_CHANGED))
	{
		/*Change the Device class and disable all profiles apart from SPP*/
		enable_spp_profile();
		nvm_bt_config.flag &= (~BT_COD_CHANGED);
	}
	
	/*Change the pairing PIN*/
	if(!(nvm_bt_config.flag & BT_PIN_CHANGED))
	{
		change_pairing_pin();
		nvm_bt_config.flag |= BT_PIN_CHANGED ;
		Sleep(200);
	}
	
	/*Change the BT module display name*/
	if(!(nvm_bt_config.flag & BT_NAME_CHANGED))
	{
		change_device_name();
		nvm_bt_config.flag |= BT_NAME_CHANGED;
		Sleep(200);
	}

	/*Enable the flow control in BT module*/
	if((nvm_bt_config.flag & BT_FC_ENABLED))
	{
		enable_flow_control();
		nvm_bt_config.flag &= (~BT_FC_ENABLED);
	}
	
	/*Enter TPMODE: If the tpmode fails then the communication is lost with host device*/
	if((nvm_bt_config.flag & BT_IN_TPMODE))
	{
		if(enable_tp_mode() != ERR_SUCCESS)
		{
			deinit_bluetooth();
			return ERR_FAILED;
		}
		nvm_bt_config.flag &= (~BT_IN_TPMODE);
		Sleep(1000);
	}
	
	#if 1
	if((nvm_bt_config.flag & BT_BAUD_CHANGE))
	{
		//Note: sometimes the BT module responds OK and sometimes doesn't
		if(send_max_baudrate_cmd() != ERR_SUCCESS)
			return ERR_FAILED;
			
		nvm_bt_config.flag &= (~BT_BAUD_CHANGE);
		nvm_bt_config.buad_rate = 921600;
		for(int i = 0; i < 10 ;i++)
			if(set_uart_baudrate(921600) == ERR_SUCCESS)
				break;
		
		if (is_bt_module_working() != ERR_SUCCESS)
			return ERR_FAILED;
	}
	#endif
	return ERR_SUCCESS;
}





Status_t get_bt_response(uint8_t * response)
{
	/*Acknowledgment from BT_Module always has 6 characters*/
	uint8_t rx_count = 0;
	uint8_t rx_data = 0;
	uint32_t count = 8000000;
	while((count > 0) && (rx_count < 6) )
	{
		if(read_data_from_app_queue(&rx_data) != QUEUE_EMPTY) 
		{
			response[rx_count] = rx_data; 
			rx_count++;
		}
		count--;
	}
	
	/*If timer is used instead of polling then there is some misbehavior in BT UART interrupt*/
	
	return ERR_SUCCESS;
}



Status_t write_byte_to_bluetooth(uint8_t data)
{
	/****Manually write the data to data register and wait for DRE flag to enable*****/
	UART_BT_Module.hw->USART.DATA.reg = data;
	
	/*IT has been assumed that the below code will never enter into blocking state*/
	while (!(UART_BT_Module.hw->USART.INTFLAG.reg & SERCOM_USART_INTFLAG_DRE));
	
	return ERR_SUCCESS;
}



Status_t write_buffer_to_bluetooth(uint8_t *data,uint8_t length)
{
	/****Manually write the data to data register and wait for DRE flag to enable*****/
	for(int i = 0; i <length ; i++)
	{
		UART_BT_Module.hw->USART.DATA.reg = data[i];
		/*IT has been assumed that the below code will never enter into blocking state*/
		while (!(UART_BT_Module.hw->USART.INTFLAG.reg & SERCOM_USART_INTFLAG_DRE));
	}
	return ERR_SUCCESS;
}


Status_t enable_tp_mode(void)
{
	uint8_t tp_cmd[] = {BT_TP_MODE_ON};
	uint8_t reboot_cmd[] = {BT_RESTART};
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(tp_cmd,13);
	get_bt_response(response);
	
	if((response[2] == 'O') && (response[3] == 'K'))
	{
		//nvm_bt_config.flag &= (~BT_IN_TPMODE);
		clear_queue(APP_RX);
		write_buffer_to_bluetooth(reboot_cmd,11);
		get_bt_response(response);
		
		if((response[2] == 'O') && (response[3] == 'K'))
		{
			clear_queue(APP_RX);
			return ERR_SUCCESS;
		}
		else
		{
			clear_queue(APP_RX);
			return ERR_FAILED;
		}
	}
	
	clear_queue(APP_RX);
	return ERR_FAILED;
}




Status_t enable_bt_com(void)
{
	/*This below line is to enable RXC interrupt flag and rest is handled by ISR_UART.c*/
	UART_BT_Module.hw->USART.INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
	
	uint8_t bt_enable_cmd[] = {BT_ENABLE};
	//uint8_t response[6];
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(bt_enable_cmd,10);
	//get_bt_response(response);
	
	/*if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ERR_SUCCESS;
	}
	else
	{
		clear_queue(APP_RX);
		return ERR_FAILED;
	}*/
	
	return ERR_SUCCESS;
}




Status_t disable_bt_com(void)
{
	/*This below line is to clear RXC interrupt flag*/
	UART_BT_Module.hw->USART.INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	
	uint8_t bt_disable_cmd[] = {BT_DISABLE};
	//uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(bt_disable_cmd,10);
	//get_bt_response(response);
	
	/*if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ERR_SUCCESS;
	}
	else
	{
		clear_queue(APP_RX);
		return ERR_FAILED;
	}*/
	
	return ERR_SUCCESS;
}



Status_t is_bt_module_working(void)
{
	uint8_t test_cmd[] = {BT_TEST_OK};
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(test_cmd,4);
	get_bt_response(response);
	
	if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ERR_SUCCESS;
	}
	
	clear_queue(APP_RX);
	return ERR_FAILED;
}



Status_t set_uart_baudrate(long baud_rate)
{
	/*disable the uart*/
	UART_BT_Module.hw->USART.INTENCLR.reg = SERCOM_USART_INTFLAG_RXC;
	usart_disable(&UART_BT_Module);
	
	/*set new baud rate*/
	UART_bt_config.baudrate = baud_rate;
	
	/*initialize the UART with new baud rate*/
	if(usart_init(&UART_BT_Module,BT_MODULE, &UART_bt_config) != STATUS_OK) {
		return ERR_FAILED;
	}
	usart_enable(&UART_BT_Module);
	/*This line is required to Enable the RXC interrupt and ISR_UART will handle the Rest.*/
	UART_BT_Module.hw->USART.INTENSET.reg = SERCOM_USART_INTFLAG_RXC;
	
	return ERR_SUCCESS;
	
}



Status_t send_max_baudrate_cmd(void)
{
	/*The Max baud rate is hard coded to 921600 bps, change it and get it from NVM.*/
	uint8_t bt_baud_cmd[] = {"AT+BAUD=921600\r\n\0"};
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(bt_baud_cmd,16);
	get_bt_response(response);
	
	if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ERR_SUCCESS;
	}
	clear_queue(APP_RX);
	return ERR_FAILED;
}



Status_t send_default_baudrate_cmd(void)
{
	uint8_t Def_Baud_Cmd[] = {"AT+BAUD=115200\r\n\0"};
	uint8_t response[6] ;
	
	write_buffer_to_bluetooth(Def_Baud_Cmd,16);
	get_bt_response(response);
	
	if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ERR_SUCCESS;
	}
	
	clear_queue(APP_RX);
	return ERR_FAILED;
}




Status_t enable_flow_control(void)
{
	uint8_t bt_fc_cmd[] = {"AT+UARTCFG=1\r\n\0"};
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(bt_fc_cmd,14);
	get_bt_response(response);
	
	if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ERR_SUCCESS;
	}
	
	clear_queue(APP_RX);
	return ERR_FAILED;
}




void send_restore_cmd(void)
{
	uint8_t restore_cmd[] = {"AT+RESTORE\r\n\0"};
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(restore_cmd,12);
	/*get_bt_response(response);*/
	
	/*Note: No need to get the response just wait for few milli seconds*/
}



Status_t change_pairing_pin()
{
	uint8_t bt_pin_cmd[25] = "AT+PIN=";
	uint8_t cmnd_indx = 7;
	uint8_t simple_pair_off_cmd[] = BT_SSP_OFF;
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(simple_pair_off_cmd,10);
	get_bt_response(response);
	
	clear_queue(APP_RX);
	for(int i =0; nvm_bt_config.pin[i] != '\r';i++)
		bt_pin_cmd[cmnd_indx++] = nvm_bt_config.pin[i];
	
	bt_pin_cmd[cmnd_indx++] = '\r';
	bt_pin_cmd[cmnd_indx++] = '\n';
	write_buffer_to_bluetooth(bt_pin_cmd,cmnd_indx);
	get_bt_response(response);
	clear_queue(APP_RX);
	return ERR_FAILED;
}


void change_device_name()
{
	uint8_t bt_name_cmd[40] = {"AT+NAME="};
	uint8_t cmnd_indx = 8;
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	for(int i =0; nvm_bt_config.name[i] != '\r';i++)
		bt_name_cmd[cmnd_indx++] = nvm_bt_config.name[i];
		
	bt_name_cmd[cmnd_indx++] = '\r';
	bt_name_cmd[cmnd_indx++] = '\n';
	write_buffer_to_bluetooth(bt_name_cmd,cmnd_indx);
	get_bt_response(response);
	clear_queue(APP_RX);
}



void enable_spp_profile(void)
{
	uint8_t bt_profile_cmd[] = {"AT+PROFILE=1\r\n\0"};
	uint8_t bt_class_device_cmd[] = {"AT+COD=001F00\r\n\0"};
	uint8_t response[6] ;
	
	clear_queue(APP_RX);
	write_buffer_to_bluetooth(bt_class_device_cmd,15);
	get_bt_response(response);
	/* The response doesn't need to be evaluated, as this command is not important*/
	clear_queue(APP_RX);
	memset(response,0,6);
	write_buffer_to_bluetooth(bt_profile_cmd,14);
	get_bt_response(response);
	
	if((response[2] == 'O') && (response[3] == 'K'))
	{
		clear_queue(APP_RX);
		return ;
	}
	return ;
}