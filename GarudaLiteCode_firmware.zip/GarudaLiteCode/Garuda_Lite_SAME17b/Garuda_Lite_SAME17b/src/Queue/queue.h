/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : queue.h
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/


#ifndef QUEUE_H_
#define QUEUE_H_

/******************************************************************************
**               I N C L U D E S
******************************************************************************/
#include <stdio.h>
#include <asf.h>


/******************************************************************************
**               D A T A
******************************************************************************/

/* Exported constants, enums */
/* Queue status */
typedef enum
{
	QUEUE_EMPTY,
	QUEUE_FULL,
	QUEUE_OK
} UART_QStatus_t;

/* Queue Identifiers */
typedef enum
{
	STN_RX,
	APP_RX,
	STN_TX,
	BT_TX
} Q_ID_t;



/*******************************************************************************
* Function Name  : read_data_from_stn_queue
* Description    : Reads the data from STn Queue
* Input          : pointer to data variable
* Output         :
* Return         : UART_QStatus_t
*******************************************************************************/
UART_QStatus_t read_data_from_stn_queue(uint8_t * data);

/*******************************************************************************
* Function Name  : read_data_from_app_queue
* Description    : Reads the data from Application Queue
* Input          : pointer to data variable
* Output         :
* Return         : UART_QStatus_t
*******************************************************************************/
UART_QStatus_t read_data_from_app_queue(uint8_t * data);

/*******************************************************************************
* Function Name  : send_data_to_stn_queue
* Description    : Stores the data in STN Queue
* Input          : data to be stored
* Output         :
* Return         : UART_QStatus_t
*******************************************************************************/
UART_QStatus_t send_data_to_stn_queue(uint8_t  data);

/*******************************************************************************
* Function Name  : send_data_to_app_queue
* Description    : Stores the data in Application Queue
* Input          : data to be stored
* Output         :
* Return         : UART_QStatus_t
*******************************************************************************/
UART_QStatus_t send_data_to_app_queue(uint8_t  data);

/*******************************************************************************
* Function Name  : clear_queue
* Description    : Empty the queue
* Input          : Q_ID
* Output         :
* Return         : UART_QStatus_t
*******************************************************************************/
void clear_queue(Q_ID_t q_id);


/*******************************************************************************
* Function Name  : get_queue_status
* Description    : returns the status of the Queue
* Input          : Q_ID
* Output         :
* Return         : UART_QStatus_t
*******************************************************************************/
UART_QStatus_t get_queue_status(Q_ID_t q_id);



#endif /* QUEUE_H_ */