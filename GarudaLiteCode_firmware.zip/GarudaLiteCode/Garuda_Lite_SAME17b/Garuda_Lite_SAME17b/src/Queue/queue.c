/******************************************************************************
**               Global Edge Software Ltd
*******************************************************************************
** Project Name   : Garuda_Lite
** File Name      : queue.c
** Description    :
** Date			  : 10 OCT, 2019
** Version		  : 0.1
** Author         : Chethankumar M S
******************************************************************************/



/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/
#include "queue.h"
#include "GarudaLite_config.h"
#include "STN2120/stn2120.h"


/******************************************************************************
*                   I N T E R N A L   V A R I A B L E S
*******************************************************************************/

static uint8_t APP_UART_RXQ[APP_UART_RX_SIZE];
static uint8_t STN_UART_RXQ[STN_UART_RX_SIZE];
volatile unsigned short App_Queue_Front = 0;
volatile unsigned short STN_Queue_Front = 0;
volatile unsigned short App_Queue_Rear = 0;
volatile unsigned short STN_Queue_Rear = 0;
volatile UART_QStatus_t APP_Queue_Status = QUEUE_EMPTY;
volatile UART_QStatus_t STN_Queue_Status = QUEUE_EMPTY;


/******************************************************************************
*         F U N C T I O N    D E F I N A T I O N S
*******************************************************************************/

UART_QStatus_t get_queue_status(Q_ID_t q_id)
{
	Q_ID_t Q_ID ;
	
	Q_ID = q_id;
	/*
	return UART_Q_status[Q_ID];*/
	if(Q_ID == APP_RX)
	{
		return APP_Queue_Status;
	}
	else
	{
		return STN_Queue_Status;
	}

}


void clear_queue(Q_ID_t q_id)
{
	volatile Q_ID_t Q_ID;
	Q_ID = q_id;

	if(Q_ID == APP_RX)
	{
		App_Queue_Front = 0;
		App_Queue_Rear = 0;
		APP_Queue_Status = QUEUE_EMPTY;
	}
	else
	{
		STN_Queue_Front = 0;
		STN_Queue_Rear = 0;
		STN_Queue_Status = QUEUE_EMPTY;
	}

}




UART_QStatus_t read_data_from_stn_queue(uint8_t * data)
{
	
	if (STN_Queue_Status == QUEUE_EMPTY)
	{
		return QUEUE_EMPTY;
	}
	
	*data = STN_UART_RXQ[STN_Queue_Front];
	
	STN_UART_RXQ[STN_Queue_Front] = 0;
	if (STN_Queue_Front == STN_UART_RX_SIZE - 1)
		STN_Queue_Front = 0 ;
	else
		STN_Queue_Front = STN_Queue_Front + 1 ;
	
	//disable_stn_uart();	
	if (STN_Queue_Front == STN_Queue_Rear)
		STN_Queue_Status = QUEUE_EMPTY;
	else
		STN_Queue_Status = QUEUE_OK;
		
	//enable_stn_uart();

	return(QUEUE_OK);
}



UART_QStatus_t read_data_from_app_queue(uint8_t * data)
{
	if (APP_Queue_Status == QUEUE_EMPTY)
	{
		return QUEUE_EMPTY;
	}
	
	*data = APP_UART_RXQ[App_Queue_Front];
	
	APP_UART_RXQ[App_Queue_Front] = 0;
	if (App_Queue_Front == APP_UART_RX_SIZE - 1)
		App_Queue_Front = 0 ;
	else
		App_Queue_Front = App_Queue_Front + 1 ;
	
	if (App_Queue_Front == App_Queue_Rear)
		APP_Queue_Status = QUEUE_EMPTY;
	else
		APP_Queue_Status = QUEUE_OK;

	return(QUEUE_OK);
	
}



UART_QStatus_t send_data_to_stn_queue(uint8_t  data)
{
	if (STN_Queue_Status == QUEUE_FULL)
		return QUEUE_FULL;
	
	STN_UART_RXQ[STN_Queue_Rear] = data ;
	if (STN_Queue_Rear == STN_UART_RX_SIZE - 1)
		STN_Queue_Rear = 0 ;
	else
		STN_Queue_Rear = STN_Queue_Rear + 1 ;

	if ( STN_Queue_Front == STN_Queue_Rear)
		STN_Queue_Status = QUEUE_FULL;
	else if ((data == '>'))
		STN_Queue_Status = QUEUE_OK;
		
	
	return (STN_Queue_Status);
	
}



UART_QStatus_t send_data_to_app_queue(uint8_t  data)
{
	if (APP_Queue_Status == QUEUE_FULL)
		return QUEUE_FULL;
	
	APP_UART_RXQ[App_Queue_Rear] = data ;
	if (App_Queue_Rear == APP_UART_RX_SIZE - 1)
		App_Queue_Rear = 0 ;
	else
		App_Queue_Rear = App_Queue_Rear + 1 ;

	if ( App_Queue_Front == App_Queue_Rear)
		APP_Queue_Status = QUEUE_FULL;
	else
		APP_Queue_Status = QUEUE_OK;
	
	return (QUEUE_OK);
	
}