/**
//	l_TxComp = FALSE;
 *  @file hfcp.c
 *
 *  Copyright (c) 2023-2024, Capgemini - Intelligent Devices
 */

#include <stdio.h>

#include	"can.h"
#include	"j2534_filter.h"
#include	"j2534_periodic.h"
#include	"data_logger.h"

#include	"hfcp.h"
#include	"g3d.h"
#include	"net_if.h"
#include	"usbhid.h"
#include	"led.h"
#include        "kwp_if.h"
#include 	"bt_spp.h"

#include <linux/can.h>
#include <linux/can/isotp.h>

/* TODO: Move this to Makefile */
#define GARUDA_USB_DEBUG    0
#define USB_PKT_SIZE       (512)
#define CAN_DL_MIN_SIZE(a, b) (((a) < (b)) ? (a) : (b))
#define IN_BUFFER_SIZE 512

char *CAN_CHA1 = "can0";
char *CAN_CHA2 = "can1";
extern uint8_t USB_Device_Mode;
static uint8_t checkopendevice;
#if GARUDA_USB_DEBUG
extern Garuda_Debug_Info Garuda_Debug;
extern Garuda_Debug_Info Garuda_Debug_CAN2;
#endif
uint8_t HFCPComMode;
uint32_t GarudaProID_Used[NO_OF_CHANNEL_USED] = { 0x0005, 0x0004, 0x0090, 0x00C5, 0x00C6, 0x00C7, 0x8012, 0x9900, 0x0030, 0x0000,0x13400 };
uint8_t timestamp_id[NO_OF_CHANNEL_USED] =
{ 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
uint8_t AdressClaimInitiated = 0;
uint8_t AdressClaimStatus = 0;
uint8_t device_claimed_Address = 0xFE;
ADDRESS_CLAIM AdressClaim;
uint8_t l_connected_channels = 0;

uint8_t l_connected_channel_1 = 0;
uint8_t l_connected_channel_2 = 0;
uint8_t l_connected_channel_Kline = 0;
uint8_t l_connected_channel_J1939_1 = 0;
uint8_t l_connected_channel_J1939_2 = 0;

static uint8_t CAN_FD_PS_chan = 1;
static uint8_t CAN_active = 0;
static uint8_t CAN_CH1_active = 0;

static uint8_t KWP_active               = 0;
//static uint8_t J1708_active             = 0;
static uint8_t CAN_or_ISO = 0;
static uint8_t CAN1_or_ISO1 = 0;
static uint8_t CAN_or_ISO15765_J1939 = 0;
static uint32_t CAN_FD_or_ISO15765_FD = 0;
static uint8_t CANCH1_or_ISO15765CH1_J1939CH1 = 0;
static uint32_t CAN_FDCH1_or_ISO15765_FDCH1 = 0;
static uint32_t CAN_connect_flags = 0;

//static uint32_t KWP_connect_flags       = 0;
static uint8_t ISO_9141_OR_14230        = 0;

static uint32_t CAN_CH1_connect_flags = 0;
static uint32_t stored_msg_id_CAN = 0;
static uint32_t stored_tx_flags_CAN = 0;
static uint32_t stored_msg_id_CAN_CH1 = 0;
static uint8_t fd_frame_length = 64;

//static uint32_t stored_tx_flags_CAN_CH1    = 0;
//static uint8_t stored_is_ext_frm           = 0; // FALSE;
//static GARUDA_CommunicationMode_t appMode;

//static uint16_t hfcp_max_in_single_frame;
//static uint16_t hfcp_max_resp_size;

/* ECU_SendMessage shall use this buffer */
static ISO9141_14230_TxMsg_S l_App_ISO9141_14230TxMsg_S; // kwp_ch

/* Flags to Indicate the Segment Transfer */
static uint8_t l_KWPTX_SegTrnsfr=0;
static uint8_t hfcpTxSock;

uint16_t buff_size_in_MB = 0;

uint8_t CAN1_Vehicle_STMinValue = 0;
uint8_t CAN2_vehicle_STMinValue = 0;

static IsoTpSocketInfo isotp_table[MAX_ISOTP_SOCKETS];
static IsoTpSocketInfo isotp_CANFD_table[MAX_ISOTP_SOCKETS];

uint8_t SET_Force_STMIN = 0;

//size_t msg_lenth;
#if 0
mqd_t xHFCP_TX_Queue;
mqd_t mqd_HFCP_REC;
mqd_t mqd;
mqd_t que_ret1;
mqd_t que_ret2;
#endif
//uint8_t hfcpAckFrame[3];

uint16_t curr_index;
uint32_t data_len;
uint8_t senddata[8];
uint8_t sequenceCounter;

#define	HFCP_REASSEMBLY_BUF_SIZE	4096
uint8_t data_buffer[HFCP_REASSEMBLY_BUF_SIZE];

/*
 * Populate a J2534_filter_t from the host's length/value encoding.
 *
 * Both mask and pattern are fixed 12-byte arrays, but the copy loops were
 *	for (i = 0; i < plv->len; i++) fl_filter_config.maskMsg[i] = plv->buf[i];
 * with plv->len an unvalidated uint8_t straight off the wire.  A host sending
 * len = 255 therefore wrote 243 bytes past the end of a stack object in
 * process_CAN_command() / process_CAN_FD_command().
 */
static uint8_t hfcp_copy_filter_field(uint8_t *dst, size_t dstsize,
					const lv_t *plv, const char *what)
{
	uint8_t n = plv->len;

	if (n > dstsize) {
		ERR("J2534 %s length %u exceeds %zu-byte field - truncating",
				what, n, dstsize);
		n = (uint8_t)dstsize;
	}

	memcpy(dst, plv->buf, n);

	return n;
}

/*
 * Copy a periodic message payload.  proto_msg.data is 12 bytes (the J2534
 * maximum), but msglen arrives unvalidated from the host and the copy loop
 * trusted it.
 */
static uint8_t hfcp_copy_periodic_data(uint8_t *dst, size_t dstsize,
					const uint8_t *src, uint8_t msglen)
{
	if (msglen > dstsize) {
		ERR("Periodic msg length %u exceeds %zu-byte field - truncating",
				msglen, dstsize);
		msglen = (uint8_t)dstsize;
	}

	memcpy(dst, src, msglen);

	return msglen;
}

/*
 * Copy one host segment into data_buffer[] at `offset`, bounded by the real
 * size of the buffer.  Returns the number of bytes actually copied, which the
 * caller must use to advance data_idx.
 *
 * Totallen / currlen arrive straight off the USB, Wi-Fi or Bluetooth link with
 * no validation, and the CAN / CAN-FD send paths used to do a bare
 *	memcpy(&data_buffer[data_idx], src, len);
 *	data_idx += len;
 * with both the destination offset and the length host-controlled.  A host
 * sending Totallen = 0xFFFF (or simply more than 4096 bytes across segments)
 * wrote straight past the end of this global buffer.
 */
static uint16_t hfcp_copy_segment(uint16_t offset, const void *src, uint32_t len)
{
	if (offset >= HFCP_REASSEMBLY_BUF_SIZE ||
			len > (uint32_t)(HFCP_REASSEMBLY_BUF_SIZE - offset)) {
		ERR("HFCP segment off=%u len=%u exceeds %d-byte reassembly buffer - dropped",
				offset, len, HFCP_REASSEMBLY_BUF_SIZE);
		return 0;
	}

	memcpy(&data_buffer[offset], src, len);

	return (uint16_t)len;
}
uint32_t tx_flag;
uint32_t stored_CANID;
uint16_t data_idx = 0;
uint8_t get_CAN_or_ISO(void);
uint8_t get_CAN1_or_ISO1(void);

static void process_CAN_IOCTL_cmd(uint8_t *);
static void process_CAN_FD_IOCTL_cmd(uint8_t *);

static buffer_v buffer_t;
static void process_KWP_IOCTL_cmd(uint8_t *buffer);  

uint32_t current_bitrate[4] = {500000,500000,500000,500000} ;


//hfcpReq_t * delete_ip_addr;
/******************************************************************************
 * Function name         : Socket_To_Tx
 *    returns            : none
 *    parameters         : mode
 * Description           : Gets the Connection received Socket Number.
 *******************************************************************************/
void Socket_To_Tx(uint8_t sockNum)
{
	hfcpTxSock = sockNum;
}

/******************************************************************************
 * Function name     : HFCPRx_Task
 * returns           : None
 * parameters        : None
 * Description       : Handles WiFi Operations
 *******************************************************************************/
uint32_t HFCPTxCount = 0;
uint32_t HFCPQueueReceiveCount = 0;
uint32_t hfcpTaskTxLimit = 0;
uint32_t hfcpMaxTxPerSch = 0;
uint32_t ZeroCount;
uint32_t TwoCount;
uint32_t HFCPTxQueueDataPending;

#if HFCP_DEBUG
uint32_t hfcpTaskStart = 0;
uint32_t hfcpTaskStop = 0;
uint32_t hfcpTaskDiffTime = 0;

uint32_t HFCPTaskTickCount = 0;
#endif

uint32_t PrevHFCPTxQueueDataPending = 2;
uint32_t lesscount = 0;
uint32_t HFCPInitCount = 0;
static uint32_t ps_baud_rate = 500000;

VciTiming timelog;

uint64_t t_first_usb;
uint64_t t_write_start;
uint64_t t_write_end;
uint64_t t_response;
FILE *fp_timing;
#if 0

/*******************************************************************************
 * Function Name  : Get_Connect_Flags
 * Description    :
 * Input          : None.
 * Return         : None.
 *******************************************************************************/
uint32_t Get_Connect_Flags(uint8_t protocol_id)
{
	if ((protocol_id == CAN_PROTOCOL_ID)
			|| (protocol_id == ISO15765_PROTO_ID)) {
		return CAN_connect_flags;
	}
	if ((protocol_id == CAN_CH1_PROTO_ID)
			|| (protocol_id == ISO15765_CH1_PROTO_ID)) {
		return CAN_CH1_connect_flags;
	} else if (protocol_id == KWP_PROTOCOL_ID) {
		return KWP_connect_flags;
	} else {
		return UNINITIALIZED_PROTO_ID;
	}
}
#endif
/*
   uint64_t get_timing_us(void)
   {
   struct timespec ts;

   clock_gettime(CLOCK_MONOTONIC_RAW, &ts);

   return ((uint64_t)ts.tv_sec * 1000000ULL) +
   ((uint64_t)ts.tv_nsec / 1000ULL);
   }
 */
void HFCP_setApplicationMode(GARUDA_CommunicationMode_t mode)
{
	if (mode == GARUDA_IN_USB_MODE) {
		DBG("Garuda in USB Mode.");
		HFCPComMode = HFCP_COM_MODE_USB;
	} else if (mode == GARUDA_IN_WIFI_MODE) {
		DBG("Garuda in WiFi Mode.");
		HFCPComMode = HFCP_COM_MODE_WIFI;
	}else if (mode == GARUDA_IN_BT_MODE) {
		DBG("Garuda in BT Mode.");
		HFCPComMode = HFCP_COM_MODE_BT;
	}
	else {
		HFCPComMode = HFCP_COM_MODE_DEFAULT;
		DBG("Garuda in Default (ie. USB) Mode.");
	}
}

void process_Setup_command(uint8_t * buf)
{
	/* ReadBatteryVoltage() takes a uint16_t *, so this has to be a
	 * uint16_t.  It was a uint32_t, which is an incompatible pointer type
	 * and left the top two bytes of the local untouched.
	 */
	uint16_t BatteryVg = 0;
	uint8_t *buffer;
	hfcpResp_t *pResp;
	hfcpReq_t *pReq = (hfcpReq_t *) buf;
	int i, status;
	int cmd_len;

	DBG("Setup command %d", pReq->command);

	cmd_len = sizeof(hfcpReq_t) - sizeof(pReq->u);

	/* pResp was only assigned inside three of the case arms, but the
	 * Start_Data_logging arm and the default arm both wrote through it -
	 * i.e. a store through an uninitialised pointer.  Point it at the
	 * response area once, up front.
	 */
	pResp = (hfcpResp_t *) ((uint8_t *) buf + cmd_len);

	switch (pReq->command) {
		case Setup_FW_Version:
			pResp = (hfcpResp_t *) ((uint8_t *) buf + cmd_len);

			memset(pResp, 0, sizeof(hfcpResp_t));
			DBG("Setup_FW_Version");
			pResp->fw_ver.status = STATUS_NOERROR;
			pResp->fw_ver.buf[0] = 3;
			pResp->fw_ver.buf[1] = 2;
			pResp->fw_ver.buf[2] = 5;
			pResp->fw_ver.buf[3] = 'C';
			/* TODO: In the originial implementation 8 bytes are sent */
			(void)host_write((void *)pReq,
					cmd_len + sizeof(pResp->fw_ver));
			break;
		case GET_SERIAL_NO:
			pResp = (hfcpResp_t *) ((uint8_t *) buf + cmd_len);

			memset(pResp, 0, sizeof(hfcpResp_t));
			DBG("GET_SERIAL_NO");

			if (!G3_board_info_valid) {
				DBG("Failed to read the board info on startup!");
				pResp->serialno.status = ERR_FAILED;
				(void)host_write((void *)pReq,
						cmd_len + sizeof(pResp->serialno));
				return;		/* was `return EXIT_FAILURE`
						 * in a void function, and it
						 * left the host waiting with
						 * no response at all */
			}

			pResp->serialno.status = STATUS_NOERROR;	/** TODO: are we supposed to return success when there is a file error */

			memcpy(pResp->serialno.buf, G3BI.sno, G3_S_SERIAL_NO);

			/*Added null character at the end of serial number*/
			//pResp->serialno.buf[G3_S_SERIAL_NO - 1] = '\0'; //NULL character to end string

			(void)host_write((void *)pReq,
					cmd_len + sizeof(pResp->serialno)+G3_S_SERIAL_NO);
			break;
		case IOCTL_COMMAND:
			DBG("IOCTL_COMMAND");

			if (pReq->u.ioctl_cmd.read_vbatt == Read_VBATT) {
				pResp = (hfcpResp_t *) ((uint8_t *) buf + cmd_len);

				memset(pResp, 0, sizeof(hfcpResp_t));
				pResp->vbatt.status = STATUS_NOERROR;
				pResp->vbatt.response = 0x06 ;
				if (ReadBatteryVoltage(&BatteryVg))
				{	

					pResp->vbatt.BatteryVg = BatteryVg;
				}
				else
				{			
					pResp->vbatt.status = ERR_FAILED;

					pResp->vbatt.BatteryVg = 0;
				}
			}
			else {
				/*DO NOTHING*/

			}
			(void)host_write((void *)pReq,
					cmd_len + sizeof(pResp->vbatt));	
			break;
		case Start_Data_logging:
			DBG("Start_Data_logging");
			buffer = (uint8_t *) pReq;
			if ( /*buffer[12] == 0 */ 1) {
				for (i = 0; i < 9; i++) {
					// system_time_stamp[i] = buffer[3+i];
				}
				/* Possible values Datalog buffer size(buff_size_in_MB) are 32MB, 
				 * 64MB, 128MB, 256MB, 512MB, 1024MB, SD_CARD_SIZE_MAX.
				 * !!!Assumed that PC application does the validation of this value!!!
				 */
				buff_size_in_MB =
					(uint16_t) (buffer[13] | (buffer[14] << 8));

				/* delete the following line once PC app has the Buffer size selection implemented */
				if (buffer[12] == 0) {
					//gl_SDcard_full = 0; 
				}
#if 0
				if (AnyCardIsConnected()) {
					Start_DataLogging_Timestamp();
					Set_DatLog_Event();
				} else {
					FILE_GB_FULL_Led_ON();
				}
#endif
				status = 0;
				if (status) {
					pResp->status = status;
				} else {
					pResp->status = STATUS_NOERROR;
				}
				(void)host_write((void *)pReq, 3);
			}
			break;
		case Stop_Data_logging:
			DBG("Stop_Data_logging");
			buffer = (uint8_t *) pReq;
			if (buffer[2] == 0) {
				if (get_CAN_status() == 1) {
					hfcp_disable_CAN();
				}
				if (get_CAN_CH1_status() == 1) {
					hfcp_disable_CAN_CH1();
				}
				//Clear_DatLog_Event();       
				//Flush_Datalog();
				//Stop_DataLogging_Timestamp();
			} else if (buffer[2] == 1) {
				/* Nothing */
			} else if (buffer[2] == 2) {
				// Clear_DatLog_Event();
			}
			break;
		case Data_logging_mode_query:
			DBG("Data_logging_mode_query");
			(void)host_write((void *)pReq, 3);
			break;
		default:
			DBG("ERR_NOT_SUPPORTED");
			pResp->status = ERR_NOT_SUPPORTED;
			(void)host_write((void *)pReq, 6);
	}
	return;

}

void process_session_mgmt_command(uint8_t * buf)
{
	uint8_t command;
	hfcpResp_t *resp;
	hfcpReq_t *pRxPkt = (hfcpReq_t *) buf;

	//      resp = (hfcpResp_t *)((uint8_t *)buf + (sizeof(hfcpReq_t) - sizeof(pRxPkt->u)));
	//      resp->status = STATUS_NOERROR;

	command = pRxPkt->command;	/* J2534 Periodic messages */
	DBG("command 0x%x", command);
	DBG("protoid 0x%x", pRxPkt->proto_id);
	DBG("start 0x%x", pRxPkt->u.startsession.startsession);
	DBG("stop 0x%x", pRxPkt->u.stopsession.stopsession);
	switch (command) {
		case Manage_Session:
			if (pRxPkt->u.startsession.startsession == SESSION_OPEN) {
				/* OLD IMPLEMENTATION : start_and_sync_time_stamp(0); */
				// start_time_stamp();
				DBG("Manage_Session - SESSION_OPEN");
				led_set(LED_USB_LED, LED_ON);//REVC
#if GARUDA_USB_DEBUG

				memset(&Garuda_Debug, 0, sizeof(Garuda_Debug_Info));
				//memset(&Garuda_Debug_CAN2, 0, sizeof(Garuda_Debug_Info));
#endif
				if (checkopendevice) {
					//clear the doip server details
					doip_cli_delete_server();
				}
				pRxPkt->u.startsession.status = STATUS_NOERROR;

				if (get_connected_channels()) {
					DisconnectAllChanels();
				}
				checkopendevice = 1;
				(void)host_write((void *)pRxPkt, 4);
			} else if (pRxPkt->u.stopsession.stopsession == SESSION_CLOSE) {
				DBG("Manage_Session - SESSION_CLOSE");
				led_set(LED_USB_LED, LED_OFF);//REVC
				checkopendevice = 0;
				if (get_connected_channels()) {
					DisconnectAllChanels();
				}
#if GARUDA_USB_DEBUG
				Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
				//memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
#endif
				pRxPkt->u.stopsession.status = STATUS_NOERROR;

				led_set(LED_USB_LED, LED_OFF);//REVC
				led_set(LED_WLANBT_LED, LED_OFF);
				//(void)host_write((void *)pRxPkt, 4);
			} else {
				DBG("Manage_Session - ERR");
				resp =
					(hfcpResp_t *) ((uint8_t *) buf +
							(sizeof(hfcpReq_t) -
							 sizeof(pRxPkt->u)));
				resp->status = ERR_NOT_SUPPORTED;
				(void)host_write((void *)pRxPkt, 4);
			}
			break;
		case DATA_LOG_MODE:
#if AMIT
			if (pRxPkt->u.log_mode == DATA_LOG_START) {
				//IMPORTANT start_and_sync_time_stamp(0);
				DBG("DATA_LOG_MODE, log_mode=DATA_LOG_START");
				Set_DatLog_Event();
				(void)host_write((void *)pRxPkt, 4);
			} else if (pRxPkt->u.log_mode == DATA_LOG_STOP) {
				DBG("DATA_LOG_MODE, log_mode=DATA_LOG_STOP");
				/* Stop Timestamp Timer */
				//IMPORTANT disable_timer(3);
				Clear_DatLog_Event();
				Flush_Datalog();
				(void)host_write((void *)pRxPkt, 4);
			} else {
				DBG("DATA_LOG_MODE, NOT_SUPPORTED");
				resp->status = ERR_NOT_SUPPORTED;
				(void)host_write((void *)pRxPkt, 4);
			}
#endif
			break;
		default:
			DBG("ERR_NOT_SUPPORTED");
			resp =
				(hfcpResp_t *) ((uint8_t *) buf +
						(sizeof(hfcpReq_t) - sizeof(pRxPkt->u)));
			resp->status = ERR_NOT_SUPPORTED;
			(void)host_write((void *)pRxPkt, 4);
	}
	return;
}
/*
   void init_logging_function()
   {

   fp_timing = fopen("/tmp/vci_timing.log", "w");

   if (fp_timing == NULL)
   {
   perror("fopen");
   }
   }
 */

gboolean isotp_rx_callback(GIOChannel *source, GIOCondition condition, gpointer data)
{

	if(condition & G_IO_IN)
	{
		int fd;
		uint8_t rx_buffer[4096];
		ssize_t rx_len;
		uint32_t can_id;
		uint8_t channel;
		uint32_t protoid = 0;
		uint32_t rxFlags = 0, timestamp = 0;
		can_bulk_msg_resp_hdr_t *pRxpkt = NULL;
		uint16_t curr_indx = 0;
		uint32_t remaining;
		uint32_t copy_len;
		uint8_t sequent_num = 0;
		IsoTpSocketInfo *sock_info = NULL;

		pRxpkt = malloc(sizeof(can_bulk_msg_resp_hdr_t));
		if (pRxpkt == NULL)
		{
			ERR("malloc failed in isotp_rx_callback");
			return G_SOURCE_CONTINUE;
		}

		fd = g_io_channel_unix_get_fd(source);

		for (int i = 0; i < MAX_ISOTP_SOCKETS; i++)
		{

			if (isotp_table[i].fd == fd)
			{
				sock_info = &isotp_table[i];
				break;
			}
		}

		if (sock_info == NULL)
		{
			printf("ISO-TP socket not found for fd %d\n", fd);
			free(pRxpkt);
			return G_SOURCE_CONTINUE;
		}

		rx_len = read(fd, rx_buffer, sizeof(rx_buffer));
		//		t_response = get_timing_us();

		/*		if (fp_timing != NULL)
				{
				fprintf(fp_timing,
				"VCI_TIMING: USB=%llu WRITE_START=%llu WRITE_END=%llu RESP=%llu\n",
				(unsigned long long)t_first_usb,
				(unsigned long long)t_write_start,
				(unsigned long long)t_write_end,
				(unsigned long long)t_response);

				fflush(fp_timing);
				}
		 */
		if (rx_len > 0)
		{
			memset(pRxpkt, 0, sizeof(can_bulk_msg_resp_hdr_t));

			pRxpkt->mode = 2;

			can_id = sock_info->rx_id;

			if ((can_id >> 31) == 1) {
				can_id &= CAN_EFF_MASK;
				rxFlags = 0x0000100;
			}
			if( sock_info->channel == 0)
			{
				protoid = ISO15765_PROTO_ID;
			}
			else if( sock_info->channel == 1)
			{
				protoid = ISO15765_CH1_PROTO_ID;
			}
			else
			{
				DBG("INVALID CHANNEL %d\n", sock_info->channel);
				free(pRxpkt);
				return G_SOURCE_CONTINUE;
			}

			pRxpkt->proto   =  protoid;
			pRxpkt->command = CAN_Receive_msg;
			pRxpkt->rxflags = rxFlags;
			pRxpkt->timestamp = timestamp;
			pRxpkt->msgid = can_id;
			pRxpkt->msg_len = rx_len;
			curr_indx = 0;
			sequent_num = 0;
			while (curr_indx < rx_len)
			{
				remaining = rx_len - curr_indx;

				if (remaining > MAX_USB_DATA)
					copy_len = MAX_USB_DATA;
				else
					copy_len = remaining;

				pRxpkt->current_msg_len = copy_len;

				/* Last USB packet? */
				if (curr_indx + copy_len == rx_len)
					pRxpkt->lastPacket = 1;
				else
					pRxpkt->lastPacket = 0;
				pRxpkt->seg_num = sequent_num;
				sequent_num++;
				memcpy(pRxpkt->data,
						&rx_buffer[curr_indx],
						copy_len);

				(void)host_write((void *)pRxpkt, 512);

				curr_indx += copy_len;
			}

			/* rx_buffer contains the complete ISO-TP payload */
			/* rx_len is the payload length */

			// Process / send to USB
		}
		else if (rx_len < 0)
		{
			perror("ISO-TP read");
		}

		/* The success path never freed pRxpkt, so every ISO-TP frame
		 * received leaked sizeof(can_bulk_msg_resp_hdr_t) (~534 bytes).
		 * isotp_canfd_rx_callback() already gets this right.
		 */
		free(pRxpkt);
	}

	/* ...and this function had no return statement at all.  GLib was
	 * reading whatever was in the return register to decide whether to keep
	 * the watch alive, so the CAN ISO-TP receive path could silently
	 * disappear.
	 */
	return G_SOURCE_CONTINUE;
}

void isotp_close_all_sockets(void)
{
	int i;

	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		/* Remove GLib watch */
		if (isotp_table[i].watch_id != 0)
		{
			g_source_remove(isotp_table[i].watch_id);
			isotp_table[i].watch_id = 0;
		}

		/* Close ISO-TP socket */
		if (isotp_table[i].fd >= 0)
		{
			close(isotp_table[i].fd);
			isotp_table[i].fd = -1;
		}

		/* Clear the rest of the entry */
		isotp_table[i].tx_id = 0;
		isotp_table[i].rx_id = 0;
		isotp_table[i].channel = 0;

	}

	/* Do the same for CAN-FD table if required */
	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		if (isotp_CANFD_table[i].watch_id != 0)
		{
			g_source_remove(isotp_CANFD_table[i].watch_id);
			isotp_CANFD_table[i].watch_id = 0;
		}

		if (isotp_CANFD_table[i].fd >= 0)
		{
			close(isotp_CANFD_table[i].fd);
			isotp_CANFD_table[i].fd = -1;
		}

		isotp_CANFD_table[i].tx_id = 0;
		isotp_CANFD_table[i].rx_id = 0;
		isotp_CANFD_table[i].channel = 0;

	}
}

void isotp_socket_table_init(void)
{
	int i;
	//	init_logging_function();
	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		isotp_table[i].fd = -1;
		isotp_CANFD_table[i].fd = -1;
	}
}

int isotp_get_socket(uint8_t channel, uint32_t tx_id, uint32_t rx_id, uint32_t tx_flags)
{
	int i;
	int fd;
	int ifindex;
	struct sockaddr_can addr;
	GIOChannel *gio_channel;
	guint watch_id;
	uint32_t stmin_ns = 0;
	struct can_isotp_options opts = {0};

	DBG("ISO CANTP SOCK FUNCTION\n");
	DBG("SOCK PARAMETER CHannel%d TX ID%ld RX ID%ld TX_FLAG%ld\n",channel,tx_id,rx_id,tx_flags);
	/* Check whether socket already exists */
	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		DBG("TABLE FD %d channel%d TX ID%ld RX ID%ld \n",isotp_table[i].fd ,isotp_table[i].channel,isotp_table[i].tx_id,isotp_table[i].rx_id);

		if (isotp_table[i].fd >= 0 &&
				isotp_table[i].channel == channel &&
				isotp_table[i].tx_id == tx_id &&
				isotp_table[i].rx_id == rx_id )
		{
			return isotp_table[i].fd;
		}
	}
	DBG("New socket\n");
	/* Find empty table entry */
	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		if (isotp_table[i].fd < 0)
			break;
	}

	if (i == MAX_ISOTP_SOCKETS)
	{
		DBG("ERROR: ISO-TP socket table full\n");
		return -1;
	}

	/* Create ISO-TP socket */
	fd = socket(PF_CAN, SOCK_DGRAM, CAN_ISOTP);

	if (fd < 0)
	{
		perror("ISO-TP socket");
		return -1;
	}

	memset(&opts, 0, sizeof(opts));

	if (tx_flags & J2534_ISO15765_FRAME_PAD)
	{
		opts.flags = CAN_ISOTP_TX_PADDING;
		opts.txpad_content = 0x00;

	}
	else
	{
		opts.flags = 0x00;
	}
	opts.frame_txtime  =  0xFFFFFFFF;


	/*
	 * Configure forced STmin
	 *
	 * SET_Force_STMIN:
	 *
	 * 0       -> use ECU FC STmin
	 * 255     -> use ECU FC STmin
	 *
	 * 0x00-0x7F -> force STmin in milliseconds
	 * 0xF1-0xF9 -> force STmin in 100-900 microseconds
	 *
	 * 0x80-0xF0 / 0xFA-0xFE -> invalid
	 */
	if (SET_Force_STMIN != 0 &&
			SET_Force_STMIN != 255)
	{


		if (SET_Force_STMIN <= 0x7F)
		{
			/*
			 * ISO-TP STmin 0x00-0x7F
			 * Unit = milliseconds
			 */
			stmin_ns = (uint32_t)SET_Force_STMIN * 1000000U;
		}
		else if (SET_Force_STMIN >= 0xF1 &&
				SET_Force_STMIN <= 0xF9)
		{
			/*
			 * ISO-TP STmin 0xF1-0xF9
			 * F1 = 100 us
			 * F2 = 200 us
			 * ...
			 * F9 = 900 us
			 *
			 * Convert to nanoseconds.
			 */
			stmin_ns = (uint32_t)(SET_Force_STMIN - 0xF0) * 100000U;
		}
		else
		{
			/*
			 * Invalid ISO-TP STmin value
			 */
			fprintf(stderr,
					"Invalid forced STmin value: 0x%02X\n",
					SET_Force_STMIN);

			close(fd);
			return -1;
		}

		/*
		 * Tell kernel ISO-TP to ignore ECU FC STmin
		 * and use force_tx_stmin instead.
		 */
		opts.flags |= CAN_ISOTP_FORCE_TXSTMIN;

		/*
		 * CAN_ISOTP_TX_STMIN expects nanoseconds.
		 */
		if (setsockopt(fd,
					SOL_CAN_ISOTP,
					CAN_ISOTP_TX_STMIN,
					&stmin_ns,
					sizeof(stmin_ns)) < 0)
		{
			perror("CAN_ISOTP_TX_STMIN");
			close(fd);
			return -1;
		}
	}

	if (setsockopt(fd, SOL_CAN_ISOTP, CAN_ISOTP_OPTS,
				&opts, sizeof(opts)) < 0)
	{
		close(fd);
		return -1;
	}

	memset(&addr, 0, sizeof(addr));

	addr.can_family = AF_CAN;

	if (channel == 0)
		ifindex = if_nametoindex("can0");
	else
		ifindex = if_nametoindex("can1");

	if (ifindex == 0)
	{
		DBG("ERROR: Invalid CAN interface\n");
		close(fd);
		return -1;
	}

	addr.can_ifindex = ifindex;

	addr.can_addr.tp.tx_id = tx_id;
	addr.can_addr.tp.rx_id = rx_id;

	if (bind(fd,
				(struct sockaddr *)&addr,
				sizeof(addr)) < 0)
	{
		perror("ISO-TP bind");
		close(fd);
		return -1;
	}

	/* Add FD to GLib main loop */
	gio_channel = g_io_channel_unix_new(fd);

	watch_id = g_io_add_watch(gio_channel,
			G_IO_IN,
			isotp_rx_callback,
			NULL);

	g_io_channel_unref(gio_channel);

	/* Store socket information */
	isotp_table[i].fd = fd;
	isotp_table[i].watch_id = watch_id;
	isotp_table[i].tx_id = tx_id;
	isotp_table[i].rx_id = rx_id;
	isotp_table[i].channel = channel;


	DBG("Created ISO-TP socket: FD=%d TX=0x%X RX=0x%X CH=%d\n",
			fd, tx_id, rx_id, channel);

	return fd;
}

uint8_t bitrate_config_check(uint32_t can_bitrate, uint32_t protoid)
{
	if (protoid == ISO15765_PROTO_ID)
	{
		if(can_bitrate != current_bitrate[0])
		{
			return true;
		}
		else
			return false;

	}

	else if (protoid == ISO15765_CH1_PROTO_ID)
	{
		if(can_bitrate != current_bitrate[1])
			return true;
		else
			return false;
	}
	else if (protoid == CAN_FD_PROTOCOL_ID)
	{
		if(can_bitrate != current_bitrate[2])
			return true;
		else
			return false;
	}

	else if (protoid == CAN_FD_CH1_PROTO_ID)
	{
		if(can_bitrate != current_bitrate[3])
			return true;
		else
			return false;
	}

	/* An unrecognised protocol id used to fall off the end of this
	 * non-void function, so the caller branched on an undefined value and
	 * could tear down every ISO-TP socket at random.  Treat it as "no
	 * bitrate change needed".
	 */
	ERR("bitrate_config_check: unknown protocol id 0x%X", protoid);
	return false;
}

void Update_bitrate_config_check(uint32_t can_bitrate, uint32_t protoid)
{
	if (protoid == ISO15765_PROTO_ID)
	{

		current_bitrate[0] = can_bitrate;


	}

	else if (protoid == ISO15765_CH1_PROTO_ID)
	{
		current_bitrate[1] = can_bitrate;
	}
	else if (protoid == CAN_FD_PROTOCOL_ID)
	{
		current_bitrate[2] = can_bitrate;
	}

	else if (protoid == CAN_FD_CH1_PROTO_ID)
	{
		current_bitrate[3] = can_bitrate;
	}
	else
	{
		//Do nothing 
	}

}

uint32_t get_bitrate_config( uint32_t protoid)
{
	if (protoid == ISO15765_PROTO_ID)
	{
		return current_bitrate[0];


	}

	else if (protoid == ISO15765_CH1_PROTO_ID)
	{
		return current_bitrate[1];
	}
	else if (protoid == CAN_FD_PROTOCOL_ID)
	{
		return current_bitrate[2];
	}

	else if (protoid == CAN_FD_CH1_PROTO_ID)
	{
		return current_bitrate[3];
	}

	/* Fell off the end of a uint32_t function for any other protocol id.
	 * 0xFFFFFFFF is the sentinel the IOCTL Get_data_rate handler already
	 * tests for and maps to ERR_FAILED.
	 */
	ERR("get_bitrate_config: unknown protocol id 0x%X", protoid);
	return 0xFFFFFFFFu;
}


static uint64_t get_time_us(void)
{
	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);

	return ((uint64_t)ts.tv_sec * 1000000ULL) +
		(ts.tv_nsec / 1000ULL);
}


/*******************************************************************************
 * Function Name  : process_CAN_command
 * Description    :
 * Input          : None.
 * Return         : None.
 *******************************************************************************/
void process_CAN_command(uint8_t * buffer)
{
	uint8_t fl_status_U8 = STATUS_NOERROR;
	struct can_frame frame;
	uint8_t fl_channel_no_U8;
	uint16_t msg_cnt = 0;
	static uint16_t data_len = 0;
	uint32_t fl_baud_rate_U32, fl_Protocol_ID_U8 = 0;
	uint32_t current_time_stamp = 0;
	uint8_t fl_connection_flag_U8;
	uint8_t base_indx = 0, loop_count = 0;
	uint32_t fl_msg_id = 0;

	int fd;

	// @TODO: set but not used variable, and then unused variable
	// uint32_t fl_tx_flags;
	uint8_t ch_id = 0;

	/* J2534 Periodic messages */
	PERIODIC_MSG j2534_periodic_msg;
	uint8_t periodic_msg_cmd = 0;
	J2534_filter_t fl_filter_config;
	uint8_t fl_FilterID;
	J2534_stError_t fl_filt_config_status, fl_filt_stop_status;
	uint8_t fl_Q_Status = 0;
	uint8_t Ack_Required = 0;
	hfcpReq_t *hfcpreq;
	uint32_t proto_id, i;
	lv_t *plv;
	void *pbuf;
	hfcpResp_t *pRsp;
	int hfcp_proto_cmd_len;
	static uint8_t sequenceNum = 0;
	const char *ifname;

	uint32_t CAN_Filter_ID;

	uint8_t iter;

	/* `ret` was a uint8_t holding the result of write(), so a -1 became 255
	 * and `if (ret < 0)` could never fire - every failed ISO-TP write was
	 * reported to the host as a success.
	 */
	ssize_t wret;

	static uint16_t current_len = 0;

	hfcpreq = (hfcpReq_t *) buffer;

	DBG("CAN command 0x%x\n", hfcpreq->command);
	/* calloc, because the old `memset(pbuf, 0, sizeof(USB_PKT_SIZE))`
	 * cleared sizeof(int) == 4 bytes, not USB_PKT_SIZE == 512.  The
	 * remaining 508 bytes of heap garbage were then shipped to the host in
	 * every response.
	 */
	pbuf = calloc(1, USB_PKT_SIZE);
	if (pbuf == NULL) {
		DBG("malloc failed");
		return;
	}
	proto_id = hfcpreq->proto_id;
	hfcp_proto_cmd_len = sizeof(hfcpReq_t) - sizeof(hfcpreq->u);
	((hfcpReq_t *) pbuf)->proto_id = proto_id;
	pRsp = (hfcpResp_t *) ((uint8_t *) pbuf + hfcp_proto_cmd_len);

	switch (hfcpreq->command) {
		case CAN_EnableComm:
			fl_status_U8 = STATUS_NOERROR;
			fl_baud_rate_U32 = hfcpreq->u.can_enable.baudrate;
			/* Handle CAN Channel 1 */
			if ((proto_id == CAN_PROTOCOL_ID) ||
					(proto_id == ISO15765_PROTO_ID)) {
				CAN1_Vehicle_STMinValue = 0;
				fl_channel_no_U8 = CAN_CH1;
				//strcpy(fl_channel_no_U8,CAN_CH1);
				CAN_or_ISO = proto_id;
				CAN_or_ISO15765_J1939 = proto_id;
				CAN_connect_flags = hfcpreq->u.can_enable.conn_flags;
				DBG("CAN 1 Enable Communication Cmd");
				//fl_status_U8 = CAN_Mid_Init(CAN_CHA1, fl_baud_rate_U32);

				ifname = can_get_ifname(proto_id);
				if (ifname == NULL)
				{
					ERR("Invalid protocol ID: 0x%X", proto_id);
					goto out;	/* was `return -1` in a
							 * void function, which
							 * also leaked pbuf */
				}
				DBG("EnableComm: proto_id=0x%X\n", proto_id);
				DBG("EnableComm: baudrate=%u (0x%X)\n",fl_baud_rate_U32, fl_baud_rate_U32);
				DBG("EnableComm: ifname=%s\n", ifname);
				if(bitrate_config_check(fl_baud_rate_U32, proto_id))
				{
					isotp_close_all_sockets();
					fl_status_U8 = can_if_setbitrate((char *)ifname, fl_baud_rate_U32);
				}
				else
				{
					fl_status_U8 = STATUS_NOERROR;
				}

				if (fl_status_U8 == STATUS_NOERROR) {
					Update_bitrate_config_check(fl_baud_rate_U32, proto_id);
					CAN_active = 1;
					SET_Force_STMIN = 0;
					led_set(LED_LINK_LED, LED_ON);

				}
				((hfcpReq_t *) pbuf)->command = CAN_EnableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
			}
			/* Handle CAN Channel 2 */
			else if ((proto_id == CAN_CH1_PROTO_ID) ||
					(proto_id == ISO15765_CH1_PROTO_ID)) {
				CAN2_vehicle_STMinValue = 0;
				fl_channel_no_U8 = CAN_CH2;
				//strcpy(fl_channel_no_U8,CAN_CHA2);
				CAN1_or_ISO1 = proto_id;
				CANCH1_or_ISO15765CH1_J1939CH1 = proto_id;
				CAN_CH1_connect_flags = hfcpreq->u.can_enable.conn_flags;
				DBG("CAN 2 Enable Communication Cmd \r\n");
				//fl_status_U8 = CAN_Mid_Init(CAN_CHA2, fl_baud_rate_U32);

				ifname = can_get_ifname(proto_id);
				if (ifname == NULL)
				{
					ERR("Invalid protocol ID: 0x%X", proto_id);
					goto out;	/* see above */
				}

				if(bitrate_config_check(fl_baud_rate_U32,proto_id))
				{
					isotp_close_all_sockets();
					fl_status_U8 = can_if_setbitrate((char *)ifname, fl_baud_rate_U32);
				}
				else
				{
					fl_status_U8 = STATUS_NOERROR;
				}

				if (fl_status_U8 == STATUS_NOERROR) {
					CAN_CH1_active = 1;
					SET_Force_STMIN = 0;
					led_set(LED_LINK_LED, LED_ON);
					Update_bitrate_config_check(fl_baud_rate_U32, proto_id);

				}
				((hfcpReq_t *) pbuf)->command = CAN_EnableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
			} else {
				/* ERROR: It should never enter here */
				pRsp->status = ERR_INVALID_PROTOCOL_ID;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
			}
			break;
		case CAN_DisableComm:

			if ((proto_id == CAN_PROTOCOL_ID) ||
					(proto_id == ISO15765_PROTO_ID)) {
				fl_channel_no_U8 = CAN_CH1;
				//strcpy(fl_channel_no_U8,CAN_CHA1);
				CAN_or_ISO = 0;
				CAN_or_ISO15765_J1939 = 0;
				//STMinValue =0;
				CAN1_Vehicle_STMinValue = 0;
				/* Clears All the Filters Configured */
				J2534_ClearAllFilter(CAN_PROTOCOL_ID);
				/* Suspend all periodic messages */
				//suspend_pmsg(CAN_PROTOCOL_ID);
				suspend_pmsg(CAN_PROTOCOL_ID);
				//CAN_ClearQ(CAN1_TX_QUEUE);
				if (getCAN1TXStatus()) {
					//xSemaphoreGive(xCAN1StartTx);
				}
				//CAN_ClearQ(CAN1_RX_QUEUE);
#if GARUDA_DEBUG
				DBG("HFCP DEBUG : CAN Disable Communication Cmd");
#endif
				// fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
				if (fl_status_U8 == STATUS_NOERROR) {
					CAN_active = 0;
					isotp_close_all_sockets();
					SET_Force_STMIN = 0;	
					led_set(LED_LINK_LED, LED_OFF);
					if (l_connected_channels) {
						l_connected_channels--;
					}
					l_connected_channel_1 = 0;
				}
				CAN_connect_flags = 0;
				((hfcpReq_t *) pbuf)->command = CAN_DisableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));

				/* Added the Debug Messages in USB Frame for ACK Packet */
#if GARUDA_USB_DEBUG
				// Garuda_Debug.CAN_Tx_Progress = getCAN1TXStatus();
				// memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug, sizeof(Garuda_Debug_Info));
#endif

				/* Garuda_init(); */
				/* Commented to fix the issue of not transmitting Ack for DisableComm
				 * Side effects are yet to be investigated
				 */
			} else if ((proto_id == CAN_CH1_PROTO_ID) ||
					(proto_id == ISO15765_CH1_PROTO_ID)) {
				fl_channel_no_U8 = CAN_CH2;
				//strcpy(fl_channel_no_U8,CAN_CHA2);
				CAN1_or_ISO1 = 0;
				CANCH1_or_ISO15765CH1_J1939CH1 = 0;
				CAN2_vehicle_STMinValue = 0;
				/* Clears All the Filters Configured */
				J2534_ClearAllFilter(CAN_CH1_PROTO_ID);
				/* Suspend all periodic messages */
				// suspend_pmsg(CAN_CH1_PROTO_ID); 
				suspend_pmsg(CAN_CH1_PROTO_ID); 

				//CAN_ClearQ(CAN2_TX_QUEUE);
#if 0
				if (getCAN2TXStatus()) {
					xSemaphoreGive(xCAN2StartTx);
				}
#endif
				//CAN_ClearQ(CAN2_RX_QUEUE);
				//fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
				if (fl_status_U8 == STATUS_NOERROR) {
					CAN_CH1_active = 0;
					SET_Force_STMIN = 0;
					isotp_close_all_sockets();
					led_set(LED_LINK_LED, LED_OFF);
					if (l_connected_channels) {
						l_connected_channels--;
					}
					l_connected_channel_2 = 0;
				}
				CAN_CH1_connect_flags = 0;
				((hfcpReq_t *) pbuf)->command = CAN_DisableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
				/*
				 * #if GARUDA_USB_DEBUG
				 * Garuda_Debug_CAN2.CAN_Tx_Progress = getCAN2TXStatus();
				 * memcpy(&fl_USB_tx_data_U8A[20], &Garuda_Debug_CAN2, sizeof(Garuda_Debug_Info));
				 * #endif
				 */
				/* Garuda_init(); *//* Commented to fix the issue of not transmitting Ack for DisableComm
						       Side effects are yet to be investigated */
			} else {
				/* ERROR: It should never enter here */
				((hfcpReq_t *) pbuf)->command = CAN_DisableComm_ACK;
				pRsp->status = ERR_INVALID_PROTOCOL_ID;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
			}
			break;
		case CAN_IOCTL_COMMAND:
			process_CAN_IOCTL_cmd(buffer);
			break;
		case CAN_Send_msg:
			switch (proto_id) {
				case CAN_PROTOCOL_ID:
				case ISO15765_PROTO_ID:
					ch_id = 1;
					break;
				case CAN_CH1_PROTO_ID:
				case ISO15765_CH1_PROTO_ID:
					ch_id = 2;
					break;
				default:
					/* Error */
			}
			HFCPInitCount++;

			DBG("seg_num =%x",hfcpreq->u.can_sndmsg_Handling.seg_num);
			DBG("last_packtet =%x",hfcpreq->u.can_sndmsg_Handling.last_packtet);
			DBG("Totallen =%x",hfcpreq->u.can_sndmsg_Handling.Totallen);
			DBG("currlen =%x",hfcpreq->u.can_sndmsg_Handling.currlen);
			DBG("hfcpreq->u.can_sndmsg_Handling.tx_flags =%x",hfcpreq->u.can_sndmsg_Handling.tx_flags);
			DBG("hfcpreq->u.can_sndmsg_Handling.canid = %x",hfcpreq->u.can_sndmsg_Handling.canid);

			//			printf("USB received: time=%llu \n", get_time_us());



			if ( (hfcpreq->u.can_sndmsg_Handling.seg_num == 0) && (hfcpreq->u.can_sndmsg_Handling.last_packtet == 1) )   {
				//				t_first_usb = get_timing_us();
				sequenceNum = 0;
				data_idx = 0;
				current_len = 0;	

				data_len = hfcpreq->u.can_sndmsg_Handling.Totallen;
				current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
				tx_flag = hfcpreq->u.can_sndmsg_Handling.tx_flags;

				data_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, data_len);

				data_idx += data_len;

				stored_CANID = CANID_FROM_DATA(& (hfcpreq->u.can_sndmsg_Handling.canid));

				if (CAN_EXT_MSG == (hfcpreq->u.can_sndmsg_Handling.tx_flags & CAN_EXT_MSG)) {
					/* Extended Frame */
					stored_CANID &= CAN_EFF_MASK;
					stored_CANID |= CAN_EFF_FLAG;
				} else {
					/* Standard Frame */
					stored_CANID &= CAN_SFF_MASK;
				}

			}
			else if((hfcpreq->u.can_sndmsg_Handling.seg_num == 0))
			{
				/*				printf("USB SEG0 received: time=%llu us currlen=%d Totallen=%d\n",
								get_time_us(),
								hfcpreq->u.can_sndmsg_Handling.currlen,
								hfcpreq->u.can_sndmsg_Handling.Totallen);
				 */
				//				t_first_usb = get_timing_us();
				sequenceNum = 0;
				data_idx = 0;		
				data_len = hfcpreq->u.can_sndmsg_Handling.Totallen;
				current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
				current_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, current_len);
				tx_flag = hfcpreq->u.can_sndmsg_Handling.tx_flags;
				data_idx += current_len;

				stored_CANID = CANID_FROM_DATA(& (hfcpreq->u.can_sndmsg_Handling.canid));

				if (CAN_EXT_MSG == (hfcpreq->u.can_sndmsg_Handling.tx_flags & CAN_EXT_MSG)) {
					/* Extended Frame */
					stored_CANID &= CAN_EFF_MASK;
					stored_CANID |= CAN_EFF_FLAG;
				} else {
					/* Standard Frame */
					stored_CANID &= CAN_SFF_MASK;
				}

				sequenceNum++;


			}

			else if (hfcpreq->u.can_sndmsg_Handling.last_packtet == 0){


				if( sequenceNum == hfcpreq->u.can_sndmsg_Handling.seg_num) 
				{
					current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
					current_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, current_len);

					data_idx += current_len;
					sequenceNum++;		
				}
				else
				{
					//Error
				}

			}

			else if (hfcpreq->u.can_sndmsg_Handling.last_packtet == 1)
			{
				if(sequenceNum == hfcpreq->u.can_sndmsg_Handling.seg_num)
				{
					if(data_idx + hfcpreq->u.can_sndmsg_Handling.currlen == data_len)
					{
						current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
						current_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, current_len);

						data_idx += current_len;
						/*						printf("USB LAST SEG received: time=%llu us data_idx=%d data_len=%d\n",
												get_time_us(), data_idx, data_len);
						 */
					}
					else
					{
						//Error
					}	
				}
				else
				{
					//Error
				}
			} 

			else
			{
				//Error
			}


			/*Send Block*/
			if( hfcpreq->u.can_sndmsg_Handling.last_packtet == 1 )
			{

				fd = isotp_get_socket(ch_id-1 , stored_CANID, stored_CANID+8, hfcpreq->u.can_sndmsg_Handling.tx_flags);

				if (fd < 0)
				{
					// socket creation/bind failed
					goto out;	/* was `return -1` in a
							 * void function, leaking
							 * pbuf */
				}

				/*				DBG("WRITE DATA LEN %d\n",data_len);
								printf("ISO-TP WRITE START: time=%llu us len=%d\n",
								get_time_us(), data_len);

				 */	
				//				t_write_start =  get_timing_us();
				/* data_idx is how much actually landed in
				 * data_buffer; data_len is only what the host
				 * claimed it would send.
				 */
				wret = write(fd, data_buffer, data_idx);
				//				t_write_end = get_timing_us();
				/*				printf("ISO-TP WRITE END: time=%llu us ret=%zd\n",
								get_time_us(), ret);
				 */

				if (wret < 0)
				{
					perror("ISO-TP write");
					fl_status_U8 = ERR_FAILED;
				}
			}

			((hfcpReq_t *) pbuf)->command = CAN_Send_msg_ACK;
			pRsp->sndmsg_rsp.seg_num = hfcpreq->u.can_sndmsg_Handling.seg_num;       /* Segment number */
			pRsp->sndmsg_rsp.status = fl_status_U8;
			pRsp->sndmsg_rsp.timestamp = current_time_stamp;
			(void)host_write((void *)pbuf, hfcp_proto_cmd_len + sizeof(pRsp->sndmsg_rsp));

			break;
		case Start_msg_filter:
			if ((proto_id == ISO15765_PROTO_ID) ||
					(proto_id == CAN_PROTOCOL_ID)) {
				fl_Protocol_ID_U8 = CAN_PROTOCOL_ID;

			} else if ((proto_id == ISO15765_CH1_PROTO_ID) ||
					(proto_id == CAN_CH1_PROTO_ID)) {
				fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
			}
			/* TODO: fl_Protocol_ID_U8 is used uninitilized */
			fl_filter_config.Protocol_ID = fl_Protocol_ID_U8;
			fl_filter_config.filterType =
				(J2534_filterType_t) (hfcpreq->u.can_msg_filter.filtertype);
			plv = (lv_t *) (hfcpreq->u.can_msg_filter.buf);
			fl_filter_config.MaskLen =
				hfcp_copy_filter_field(fl_filter_config.maskMsg,
					sizeof(fl_filter_config.maskMsg),
					plv, "mask");

			plv =
				(lv_t *) ((hfcpreq->u.can_msg_filter.buf) +
						sizeof(plv->len) + plv->len);
			fl_filter_config.PatternLen =
				hfcp_copy_filter_field(fl_filter_config.patternMsg,
					sizeof(fl_filter_config.patternMsg),
					plv, "pattern");

			fl_filt_config_status =
				J2534_ConfigFilter(&fl_filter_config, &fl_FilterID);

			((hfcpReq_t *) pbuf)->command = Start_msg_filter_ACK;
			pRsp->msg_fil.filterid = fl_FilterID;

			if (fl_filt_config_status != J2534_NO_ERROR) {
				if (fl_filt_config_status == J2534_FLT_NOT_FREE) {
					fl_status_U8 = ERR_EXCEEDED_LIMIT;
				} else {
					fl_status_U8 = ERR_FAILED;
				}
				pRsp->msg_fil.status = fl_status_U8;
			} else {
				pRsp->msg_fil.status = STATUS_NOERROR;
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len + sizeof(pRsp->msg_fil));
			break;
		case Stop_msg_filter:
			switch (proto_id) {
				case ISO15765_PROTO_ID:
				case CAN_PROTOCOL_ID:
					fl_Protocol_ID_U8 = CAN_PROTOCOL_ID;
					break;
				case ISO15765_CH1_PROTO_ID:
				case CAN_CH1_PROTO_ID:
					fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
					break;
				default:
					DBG("Invalid proto_id");
					/* error */
			}
			fl_FilterID = hfcpreq->u.can_stpmsg_filter.filterid;
			fl_filt_stop_status =
				J2534_ClearFilter(fl_FilterID, fl_Protocol_ID_U8);

			((hfcpReq_t *) pbuf)->command = Stop_msg_filter_ACK;
			pRsp->stpmsg_fil.filterid = fl_FilterID;
			if (fl_filt_stop_status != J2534_NO_ERROR) {
				if (fl_filt_stop_status == J2534_INVLD_FLTID) {
					fl_status_U8 = ERR_INVALID_FILTER_ID;
				} else {
					fl_status_U8 = ERR_FAILED;
				}
				((hfcpReq_t *) pbuf)->proto_id = fl_Protocol_ID_U8;
				pRsp->stpmsg_fil.status = fl_status_U8;
			} else {
				pRsp->msg_fil.status = STATUS_NOERROR;
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->stpmsg_fil));
			DBG("HFCP DEBUG : Stop Mesage Filter = %d \r\n", fl_status_U8);
			break;
		case handle_periodic_msg:
			switch (proto_id) {
				case ISO15765_PROTO_ID:
				case CAN_PROTOCOL_ID:
					fl_Protocol_ID_U8 = CAN_PROTOCOL_ID;
					break;
				case ISO15765_CH1_PROTO_ID:
				case CAN_CH1_PROTO_ID:
					fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
					break;
				default:
					DBG("Invalid proto_id");
					/* error */
			}
			periodic_msg_cmd = hfcpreq->u.can_periodic_msg.periodic_command;
			j2534_periodic_msg.protocol_id = fl_Protocol_ID_U8;
			j2534_periodic_msg.periodicity =
				hfcpreq->u.can_periodic_msg.periodicity;
			j2534_periodic_msg.prmsg_id = hfcpreq->u.can_periodic_msg.msgid;
			j2534_periodic_msg.proto_msg.tx_flags =
				hfcpreq->u.can_periodic_msg.tx_flags;
			if ((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN)
					|| (periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID)) {
				j2534_periodic_msg.proto_msg.length =
					hfcpreq->u.can_periodic_msg.msglen;
			} else {
				j2534_periodic_msg.proto_msg.length = 0;
			}
			j2534_periodic_msg.proto_msg.length =
				hfcp_copy_periodic_data(
					j2534_periodic_msg.proto_msg.data,
					sizeof(j2534_periodic_msg.proto_msg.data),
					hfcpreq->u.can_periodic_msg.buf,
					j2534_periodic_msg.proto_msg.length);

			if (PERIODIC_SUCCESS ==
					PERIODIC_msg_cmd(&j2534_periodic_msg, periodic_msg_cmd)) {
				fl_status_U8 = STATUS_NOERROR;
			} else {
				fl_status_U8 = ERR_FAILED;
			}
			((hfcpReq_t *) pbuf)->command = handle_periodic_msg_ACK;
			pRsp->pmsg.status = fl_status_U8;
			pRsp->pmsg.per_msg_id = j2534_periodic_msg.prmsg_id;
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len + sizeof(pRsp->pmsg));
			break;
		default:
			break;
	}

out:
	free(pbuf);
}


gboolean isotp_canfd_rx_callback(GIOChannel *source,
		GIOCondition condition,
		gpointer data)
{
	if (condition & G_IO_IN)
	{
		int fd;
		uint8_t rx_buffer[4096];
		ssize_t rx_len;

		uint32_t can_id;
		uint32_t protoid = 0;
		uint32_t rxFlags = 0;
		uint32_t timestamp = 0;

		can_bulk_msg_resp_hdr_t *pRxpkt = NULL;
		IsoTpSocketInfo *sock_info = NULL;

		uint32_t curr_indx = 0;
		uint32_t copy_len;
		uint32_t remaining;
		uint32_t seg_num = 0;

		pRxpkt = malloc(sizeof(can_bulk_msg_resp_hdr_t));

		if (pRxpkt == NULL)
		{
			DBG("ERROR: malloc failed\n");
			return G_SOURCE_CONTINUE;
		}

		fd = g_io_channel_unix_get_fd(source);

		/* Find socket information using FD */
		for (int i = 0; i < MAX_ISOTP_SOCKETS; i++)
		{
			if (isotp_CANFD_table[i].fd == fd)
			{
				sock_info = &isotp_CANFD_table[i];
				break;
			}
		}

		if (sock_info == NULL)
		{
			DBG("CANFD ISO-TP socket not found for fd %d\n", fd);
			free(pRxpkt);
			return G_SOURCE_CONTINUE;
		}

		rx_len = read(fd, rx_buffer, sizeof(rx_buffer));

		if (rx_len > 0)
		{
			DBG("ISO-TP CANFD RX: channel=%d RX ID=0x%X len=%ld\n",
					sock_info->channel,
					sock_info->rx_id,
					rx_len);

			memset(pRxpkt, 0, sizeof(can_bulk_msg_resp_hdr_t));

			pRxpkt->mode = 2;

			can_id = sock_info->rx_id;

			if ((can_id >> 31) == 1)
			{
				can_id &= CAN_EFF_MASK;
				rxFlags = 0x0000100;
			}

			if (sock_info->channel == 0)
			{
				protoid = CAN_FD_PROTOCOL_ID;
			}
			else if (sock_info->channel == 1)
			{
				protoid = CAN_FD_CH1_PROTO_ID;
			}
			else
			{
				DBG("INVALID CHANNEL %d\n", sock_info->channel);
				free(pRxpkt);
				return G_SOURCE_CONTINUE;
			}

			pRxpkt->proto = protoid;
			pRxpkt->command = CAN_Receive_msg;
			pRxpkt->rxflags = rxFlags;
			pRxpkt->timestamp = timestamp;
			pRxpkt->msgid = can_id;

			seg_num = 0;
			pRxpkt->msg_len = rx_len;

			/* Split complete ISO-TP payload into USB packets */
			while (curr_indx < rx_len)
			{
				remaining = rx_len - curr_indx;

				if (remaining > MAX_USB_DATA)
					copy_len = MAX_USB_DATA;
				else
					copy_len = remaining;

				pRxpkt->seg_num = seg_num;
				pRxpkt->current_msg_len = copy_len;

				if (curr_indx + copy_len == rx_len)
					pRxpkt->lastPacket = 1;
				else
					pRxpkt->lastPacket = 0;

				memcpy(pRxpkt->data,
						&rx_buffer[curr_indx],
						copy_len);

				host_write((void *)pRxpkt, 512);

				curr_indx += copy_len;
				seg_num++;
			}
		}
		else if (rx_len < 0)
		{
			perror("ISO-TP CANFD read");
		}

		free(pRxpkt);
	}

	return G_SOURCE_CONTINUE;
}

int isotp_canfd_get_socket(uint8_t channel,
		uint32_t tx_id,
		uint32_t rx_id,
		uint32_t tx_flags)
{
	int i;
	int fd;
	int ifindex;
	struct sockaddr_can addr;
	GIOChannel *gio_channel;
	guint watch_id;
	uint32_t stmin_ns = 0;
	struct can_isotp_options opts = {0};
	struct can_isotp_ll_options ll_opts = {0};

	DBG("ISO CANFD TP SOCK FUNCTION\n");
	DBG("SOCK PARAMETER CHannel%d TX ID%lX RX ID%lX TX_FLAG%lX\n",
			channel, tx_id, rx_id, tx_flags);

	/* Check whether socket already exists */
	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		DBG("TABLE FD %d channel%d TX ID%lX RX ID%lX\n",
				isotp_CANFD_table[i].fd,
				isotp_CANFD_table[i].channel,
				isotp_CANFD_table[i].tx_id,
				isotp_CANFD_table[i].rx_id);

		if (isotp_CANFD_table[i].fd >= 0 &&
				isotp_CANFD_table[i].channel == channel &&
				isotp_CANFD_table[i].tx_id == tx_id &&
				isotp_CANFD_table[i].rx_id == rx_id)
		{
			return isotp_CANFD_table[i].fd;
		}
	}

	DBG("New CANFD socket\n");

	/* Find empty table entry */
	for (i = 0; i < MAX_ISOTP_SOCKETS; i++)
	{
		if (isotp_CANFD_table[i].fd < 0)
			break;
	}

	if (i == MAX_ISOTP_SOCKETS)
	{
		DBG("ERROR: ISO-TP CANFD socket table full\n");
		return -1;
	}

	/* Create ISO-TP CANFD socket */
	fd = socket(PF_CAN, SOCK_DGRAM, CAN_ISOTP);

	if (fd < 0)
	{
		perror("ISO-TP CANFD socket");
		return -1;
	}
	memset(&opts, 0, sizeof(opts));
	/* ISO-TP padding configuration */
	if (tx_flags & J2534_ISO15765_FRAME_PAD)
	{
		opts.flags = CAN_ISOTP_TX_PADDING;
		opts.txpad_content = 0x00;
	}
	else
	{
		opts.flags = 0;
	}
	opts.frame_txtime  =  0xFFFFFFFF;



	/*
	 * Configure forced STmin
	 *
	 * 0       -> use ECU FC STmin
	 * 255     -> use ECU FC STmin
	 *
	 * 0x00-0x7F -> milliseconds
	 * 0xF1-0xF9 -> 100-900 microseconds
	 */
	if (SET_Force_STMIN != 0 &&
			SET_Force_STMIN != 255)
	{


		if (SET_Force_STMIN <= 0x7F)
		{
			/*
			 * 0x00-0x7F = milliseconds
			 */
			stmin_ns = (uint32_t)SET_Force_STMIN * 1000000U;
		}
		else if (SET_Force_STMIN >= 0xF1 &&
				SET_Force_STMIN <= 0xF9)
		{
			/*
			 * 0xF1-0xF9 = 100-900 microseconds
			 */
			stmin_ns = (uint32_t)(SET_Force_STMIN - 0xF0) * 100000U;
		}
		else
		{
			/*
			 * Invalid ISO-TP STmin value
			 */
			fprintf(stderr,
					"Invalid forced STmin value: 0x%02X\n",
					SET_Force_STMIN);

			close(fd);
			return -1;
		}

		/*
		 * Force application STmin instead of ECU FC STmin.
		 */
		opts.flags |= CAN_ISOTP_FORCE_TXSTMIN;

		/*
		 * CAN_ISOTP_TX_STMIN expects nanoseconds.
		 */
		if (setsockopt(fd,
					SOL_CAN_ISOTP,
					CAN_ISOTP_TX_STMIN,
					&stmin_ns,
					sizeof(stmin_ns)) < 0)
		{
			perror("CAN_ISOTP_TX_STMIN");
			close(fd);
			return -1;
		}
	}



	if (setsockopt(fd,
				SOL_CAN_ISOTP,
				CAN_ISOTP_OPTS,
				&opts,
				sizeof(opts)) < 0)
	{
		perror("ISO-TP CANFD options");
		close(fd);
		return -1;
	}

	/*
	 * CAN-FD link layer configuration
	 */
	memset(&ll_opts, 0, sizeof(ll_opts));


	if (tx_flags & J2534_FD_CAN_FORMAT)
	{
		/*
		 * J2534 FD_CAN_FORMAT
		 * Configure ISO-TP for CAN FD
		 */
		ll_opts.mtu = CANFD_MTU;

		/*
		 * CAN FD TX data length.
		 * 64 = maximum CAN FD payload.
		 */
		ll_opts.tx_dl = 64;

		/*
		 * J2534 FD_CAN_BRS
		 * Enable BRS only when requested by J2534.
		 */

		if (tx_flags & J2534_FD_CAN_BRS)
		{
			ll_opts.tx_flags |= CANFD_BRS;
		}

	}
	else
	{
		/*
		 * Classical CAN ISO-TP
		 */
		ll_opts.mtu = CAN_MTU;
		ll_opts.tx_dl = 8;
		ll_opts.tx_flags = 0;
	}

	if (setsockopt(fd,
				SOL_CAN_ISOTP,
				CAN_ISOTP_LL_OPTS,
				&ll_opts,
				sizeof(ll_opts)) < 0)
	{
		perror("ISO-TP CANFD LL options");
		close(fd);
		return -1;
	}

	memset(&addr, 0, sizeof(addr));

	addr.can_family = AF_CAN;

	if (channel == 0)
		ifindex = if_nametoindex("can0");
	else
		ifindex = if_nametoindex("can1");

	if (ifindex == 0)
	{
		DBG("ERROR: Invalid CAN interface\n");
		close(fd);
		return -1;
	}

	addr.can_ifindex = ifindex;

	addr.can_addr.tp.tx_id = tx_id;
	addr.can_addr.tp.rx_id = rx_id;

	if (bind(fd,
				(struct sockaddr *)&addr,
				sizeof(addr)) < 0)
	{
		perror("ISO-TP CANFD bind");
		close(fd);
		return -1;
	}

	/* Add FD to GLib main loop */
	gio_channel = g_io_channel_unix_new(fd);

	watch_id = g_io_add_watch(gio_channel,
			G_IO_IN,
			isotp_canfd_rx_callback,
			NULL);

	g_io_channel_unref(gio_channel);

	/* Store socket information */
	isotp_CANFD_table[i].fd = fd;
	isotp_CANFD_table[i].watch_id = watch_id;
	isotp_CANFD_table[i].tx_id = tx_id;
	isotp_CANFD_table[i].rx_id = rx_id;
	isotp_CANFD_table[i].channel = channel;

	DBG("Created ISO-TP CANFD socket: FD=%d TX=0x%X RX=0x%X CH=%d\n",
			fd, tx_id, rx_id, channel);

	return fd;
}

void process_CAN_FD_command(uint8_t * buffer)
{
	uint8_t fl_status_U8 = STATUS_NOERROR;

	/* uint8_t fl_USB_tx_data_U8A[64]; */
	uint8_t fl_channel_no_U8;
	uint8_t fl_connection_flag_U8;
	uint32_t fl_baud_rate_U32;
	uint8_t ch_id = 0, fl_Q_Status = 0;
	uint16_t msg_cnt = 0; 
	static uint16_t data_len = 0;
	struct canfd_frame frame;
	uint32_t fl_msg_id = 0;
	uint32_t current_time_stamp = 0;
	uint8_t Ack_Required = 0;
	uint16_t base_indx = 0, loop_count = 0;
	uint8_t fl_FilterID;
	uint32_t fl_Protocol_ID_U8 = 0;
	J2534_stError_t fl_filt_config_status, fl_filt_stop_status;
	J2534_filter_t fl_filter_config;
	uint8_t periodic_msg_cmd = 0;
	PERIODIC_MSG j2534_periodic_msg;
	hfcpReq_t *hfcpreq;
	uint32_t proto_id, i;
	lv_t *plv;
	void *pbuf;
	int hfcp_proto_cmd_len;
	hfcpResp_t *pRsp;
	const char *ifname;

	static uint8_t sequenceNum = 0;

	/* Both of these were uint8_t.  isotp_canfd_get_socket() returns -1 on
	 * failure, which became 255, so `if (fd < 0)` never fired and the code
	 * went on to write() to descriptor 255.  Likewise a failed write()
	 * returned 255 and was reported to the host as success.
	 */
	int fd;
	ssize_t wret;

	static uint16_t current_len = 0;

	hfcpreq = (hfcpReq_t *) buffer;

	DBG("CAN FD command 0x%x\tDATE-02052024\n", hfcpreq->command);
	pbuf = calloc(1, USB_PKT_SIZE);
	if (pbuf == NULL) {
		DBG("PBUF Allocation");
		return;
	}

	/*     memset(pbuf, 0, sizeof(USB_PKT_SIZE));//aready using calloc() */
	proto_id = hfcpreq->proto_id;
	hfcp_proto_cmd_len = sizeof(hfcpReq_t) - sizeof(hfcpreq->u);
	((hfcpReq_t *) pbuf)->proto_id = proto_id;
	pRsp = (hfcpResp_t *) ((uint8_t *) pbuf + hfcp_proto_cmd_len);

	DBG("proto_id=0x%x\n", proto_id);

	switch (hfcpreq->command) {
		case CAN_FD_EnableComm:
			fl_status_U8 = STATUS_NOERROR;
			fl_baud_rate_U32 = hfcpreq->u.can_enable.baudrate;
			/* Handle CAN Channel 1 */
			if ((proto_id == CAN_FD_PROTOCOL_ID) ||
					(proto_id == ISO15765_FD_PROTO_ID)) {
				CAN1_Vehicle_STMinValue = 0;
				fl_channel_no_U8 = CAN_CH1;

				CAN_or_ISO = proto_id;
				CAN_FD_or_ISO15765_FD = proto_id;
				CAN_connect_flags = hfcpreq->u.can_enable.conn_flags;

				ifname = can_get_ifname(proto_id);
				if (ifname == NULL)
				{
					ERR("Invalid protocol ID: 0x%X", proto_id);
					goto out;	/* was `return -1` in a
							 * void function */
				}

				if(bitrate_config_check(fl_baud_rate_U32,proto_id))
				{
					isotp_close_all_sockets();
					fl_status_U8 = can_if_setbitrate((char *)ifname, fl_baud_rate_U32);
				}
				else
				{
					fl_status_U8 = STATUS_NOERROR;
				}

				if (fl_status_U8 == STATUS_NOERROR) {

					CAN_active = 1;
					SET_Force_STMIN = 0;
					led_set(LED_LINK_LED, LED_ON);
					Update_bitrate_config_check(fl_baud_rate_U32, proto_id);
				}
				/*
				   fl_USB_tx_data_U8A[0] = proto_id;
				   fl_USB_tx_data_U8A[1] = CAN_EnableComm_ACK;
				   fl_USB_tx_data_U8A[3] = fl_status_U8;
				   DBG("Before Garuda_Tx_data_on_USB.\t\tfl_USB_tx_data_U8A=%x %x %x %x\n",
				   fl_USB_tx_data_U8A[0], fl_USB_tx_data_U8A[1],
				   fl_USB_tx_data_U8A[2],fl_USB_tx_data_U8A[3]);

				   (void) host_write((void *)fl_USB_tx_data_U8A, 4); */
				((hfcpReq_t *) pbuf)->command = CAN_FD_EnableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));

			}
			/* Handle CAN Channel 2 */
			else if ((proto_id == CAN_FD_CH1_PROTO_ID) ||
					(proto_id == ISO15765_FD_CH1_PROTO_ID)) {
				CAN2_vehicle_STMinValue = 0;
				fl_channel_no_U8 = CAN_CH2;

				CAN1_or_ISO1 = proto_id;
				CAN_FDCH1_or_ISO15765_FDCH1 = proto_id;
				CAN_CH1_connect_flags =
					hfcpreq->u.can_enable.conn_flags;

				ifname = can_get_ifname(proto_id);
				if (ifname == NULL)
				{
					ERR("Invalid protocol ID: 0x%X", proto_id);
					goto out;	/* was `return -1` in a
							 * void function */
				}

				if(bitrate_config_check(fl_baud_rate_U32,proto_id))
				{
					isotp_close_all_sockets();
					fl_status_U8 = can_if_setbitrate((char *)ifname, fl_baud_rate_U32);
				}
				else
				{
					fl_status_U8 = STATUS_NOERROR;
				}

			
				if (fl_status_U8 == STATUS_NOERROR) {
					led_set(LED_LINK_LED, LED_ON);
					CAN_CH1_active = 1;
					SET_Force_STMIN = 0;
					Update_bitrate_config_check(fl_baud_rate_U32, proto_id);
				}
#if 0
				fl_USB_tx_data_U8A[0] = proto_id;
				fl_USB_tx_data_U8A[1] = CAN_EnableComm_ACK;
				fl_USB_tx_data_U8A[3] = fl_status_U8;
				//Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
				(void)host_write((void *)fl_USB_tx_data_U8A, 4);
#endif
				((hfcpReq_t *) pbuf)->command = CAN_FD_EnableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));

			} else if (proto_id == CAN_FD_PS) {
				/* CAN_FD_PS channel select */
				ps_baud_rate = hfcpreq->u.can_enable.baudrate;
				CAN_connect_flags = hfcpreq->u.can_enable.conn_flags;
				CAN_CH1_connect_flags =
					hfcpreq->u.can_enable.conn_flags;

				((hfcpReq_t *) pbuf)->command = CAN_FD_EnableComm_ACK;
				pRsp->status = STATUS_NOERROR;	//channel is being selected in IOCTL
				led_set(LED_LINK_LED, LED_ON);
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
			} else {
#if 0
				/* ERROR: It should never enter here */
				fl_USB_tx_data_U8A[0] = buffer[0];
				fl_USB_tx_data_U8A[1] = CAN_FD_EnableComm_ACK;
				fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
				(void)host_write((void *)fl_USB_tx_data_U8A, 3);
#endif
				((hfcpReq_t *) pbuf)->command = CAN_FD_EnableComm_ACK;
				pRsp->status = ERR_INVALID_PROTOCOL_ID;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));
			}
			break;
		case CAN_FD_DisableComm:
			if ((proto_id == CAN_FD_PROTOCOL_ID) ||
					(proto_id == ISO15765_FD_PROTO_ID)) {
				/* Handle CAN-CH1 */
				fl_channel_no_U8 = CAN_CH1;
				CAN_or_ISO = 0;
				CAN_FD_or_ISO15765_FD = 0;
				CAN1_Vehicle_STMinValue = 0;
				J2534_ClearAllFilter(CAN_FD_PROTOCOL_ID);
				suspend_pmsg(CAN_FD_PROTOCOL_ID);
				DBG("HFCP DEBUG : CAN Disable Communication Cmd\n");
				fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
				if (fl_status_U8 == STATUS_NOERROR) {
					led_set(LED_LINK_LED, LED_OFF);
					isotp_close_all_sockets();
					SET_Force_STMIN = 0;
					CAN_active = 0;
					if (l_connected_channels) {
						l_connected_channels--;
					}
					l_connected_channel_1 = 0;
				}
				CAN_connect_flags = 0;
#if 0
				fl_USB_tx_data_U8A[0] = proto_id;
				fl_USB_tx_data_U8A[1] = CAN_FD_DisableComm_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;

				(void)host_write((void *)fl_USB_tx_data_U8A, 3);
#endif
				((hfcpReq_t *) pbuf)->command = CAN_FD_DisableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));

			} else if ((proto_id == CAN_FD_CH1_PROTO_ID) ||
					(proto_id == ISO15765_FD_CH1_PROTO_ID)) {
				/* Handle CAN-CH2 */
				fl_channel_no_U8 = CAN_CH2;
				CAN1_or_ISO1 = 0;
				CANCH1_or_ISO15765CH1_J1939CH1 = 0;
				CAN2_vehicle_STMinValue = 0;
				J2534_ClearAllFilter(CAN_FD_CH1_PROTO_ID);
				suspend_pmsg(CAN_FD_CH1_PROTO_ID);

				fl_status_U8 = CAN_Mid_Disable(fl_channel_no_U8);
				if (fl_status_U8 == STATUS_NOERROR) {
					CAN_CH1_active = 0;
					SET_Force_STMIN = 0;
					isotp_close_all_sockets();
					led_set(LED_LINK_LED, LED_OFF);
					if (l_connected_channels) {
						l_connected_channels--;
					}
					l_connected_channel_2 = 0;
				}
				CAN_CH1_connect_flags = 0;
#if 0
				fl_USB_tx_data_U8A[0] = proto_id;
				fl_USB_tx_data_U8A[1] = CAN_FD_DisableComm_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				(void)host_write((void *)fl_USB_tx_data_U8A, 3);
#endif
				((hfcpReq_t *) pbuf)->command = CAN_FD_DisableComm_ACK;
				pRsp->status = fl_status_U8;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));

			} else if (proto_id == CAN_FD_PS) {
				/*handle CAN_FD_PS channel select */
				if (CAN_FD_PS_chan == CAN_CH1) {
					CAN_or_ISO = 0;
					CAN_FD_or_ISO15765_FD = 0;
					CAN1_Vehicle_STMinValue = 0;
				} else if (CAN_FD_PS_chan == CAN_CH2) {
					CAN1_or_ISO1 = 0;
					CANCH1_or_ISO15765CH1_J1939CH1 = 0;
					CAN2_vehicle_STMinValue = 0;
				}
				suspend_pmsg(CAN_FD_PS_chan);

				fl_status_U8 = CAN_Mid_Disable(CAN_FD_PS_chan);
				if (fl_status_U8 == STATUS_NOERROR) {

					if (CAN_FD_PS_chan == CAN_CH1) {
						CAN_active = 0;
						led_set(LED_LINK_LED, LED_OFF);
						CAN_connect_flags = 0;
					} else if (CAN_FD_PS_chan == CAN_CH2) {
						CAN_CH1_active = 0;
						led_set(LED_LINK_LED, LED_OFF);
						CAN_CH1_connect_flags = 0;
					}

					if (l_connected_channels) {
						l_connected_channels--;
					}
					l_connected_channel_2 = 0;
				}
			} else {
				/* ERROR: It should never enter here */
#if 0
				fl_USB_tx_data_U8A[0] = buffer[0];
				fl_USB_tx_data_U8A[1] = CAN_FD_DisableComm_ACK;
				fl_USB_tx_data_U8A[2] = ERR_INVALID_PROTOCOL_ID;
				(void)host_write((void *)fl_USB_tx_data_U8A, 3);
#endif
				((hfcpReq_t *) pbuf)->command = CAN_FD_DisableComm_ACK;
				pRsp->status = ERR_INVALID_PROTOCOL_ID;
				(void)host_write((void *)pbuf,
						hfcp_proto_cmd_len +
						sizeof(pRsp->status));

			}
			break;
		case CAN_FD_IOCTL_COMMAND:
			process_CAN_FD_IOCTL_cmd(buffer);
			break;
		case CAN_FD_Send_msg:
			switch (proto_id) {
				case CAN_FD_PROTOCOL_ID:
				case ISO15765_FD_PROTO_ID:
					ch_id = 1;
					break;
				case CAN_FD_CH1_PROTO_ID:
				case ISO15765_FD_CH1_PROTO_ID:
					ch_id = 2;
					break;
				case CAN_FD_PS:
					ch_id = CAN_FD_PS_chan;
					break;
				default:
					/* Error */
			}
			HFCPInitCount++;


			DBG("seg_num =%x",hfcpreq->u.can_sndmsg_Handling.seg_num);
			DBG("last_packtet =%x",hfcpreq->u.can_sndmsg_Handling.last_packtet);
			DBG("Totallen =%x",hfcpreq->u.can_sndmsg_Handling.Totallen);
			DBG("currlen =%x",hfcpreq->u.can_sndmsg_Handling.currlen);
			DBG("hfcpreq->u.can_sndmsg_Handling.tx_flags =%x",hfcpreq->u.can_sndmsg_Handling.tx_flags);
			DBG("hfcpreq->u.can_sndmsg_Handling.canid = %x",hfcpreq->u.can_sndmsg_Handling.canid);

			DBG("local data idx =%d",data_idx);
			data_len = hfcpreq->u.can_sndmsg_Handling.Totallen;
			if ( (hfcpreq->u.can_sndmsg_Handling.seg_num == 0) && (hfcpreq->u.can_sndmsg_Handling.last_packtet == 1) )   {
				sequenceNum = 0;
				data_idx = 0;
				current_len = 0;	

				data_len = hfcpreq->u.can_sndmsg_Handling.Totallen;
				current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
				tx_flag = hfcpreq->u.can_sndmsg_Handling.tx_flags;

				data_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, data_len);

				data_idx += data_len;

				stored_CANID = CANID_FROM_DATA(& (hfcpreq->u.can_sndmsg_Handling.canid));

				if (CAN_EXT_MSG == (hfcpreq->u.can_sndmsg_Handling.tx_flags & CAN_EXT_MSG)) {
					/* Extended Frame */
					stored_CANID &= CAN_EFF_MASK;
					stored_CANID |= CAN_EFF_FLAG;
				} else {
					/* Standard Frame */
					stored_CANID &= CAN_SFF_MASK;
				}

			}
			else if((hfcpreq->u.can_sndmsg_Handling.seg_num == 0))
			{
				sequenceNum = 0;
				data_idx = 0;		
				data_len = hfcpreq->u.can_sndmsg_Handling.Totallen;
				current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
				current_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, current_len);
				tx_flag = hfcpreq->u.can_sndmsg_Handling.tx_flags;
				data_idx += current_len;

				stored_CANID = CANID_FROM_DATA(& (hfcpreq->u.can_sndmsg_Handling.canid));

				if (CAN_EXT_MSG == (hfcpreq->u.can_sndmsg_Handling.tx_flags & CAN_EXT_MSG)) {
					/* Extended Frame */
					stored_CANID &= CAN_EFF_MASK;
					stored_CANID |= CAN_EFF_FLAG;
				} else {
					/* Standard Frame */
					stored_CANID &= CAN_SFF_MASK;
				}

				sequenceNum++;


			}

			else if (hfcpreq->u.can_sndmsg_Handling.last_packtet == 0){


				if( sequenceNum == hfcpreq->u.can_sndmsg_Handling.seg_num) 
				{
					DBG("LOCAL seg_num in 0 =%x",sequenceNum);
					current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
					current_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, current_len);

					data_idx += current_len;
					sequenceNum++;		
				}
				else
				{
					//Error
				}

			}

			else if (hfcpreq->u.can_sndmsg_Handling.last_packtet == 1)
			{
				if(sequenceNum == hfcpreq->u.can_sndmsg_Handling.seg_num)
				{
					DBG("LOCAL seg_num in lst =%x",sequenceNum);

					if(data_idx + hfcpreq->u.can_sndmsg_Handling.currlen == data_len)
					{
						DBG("last data =%d",data_idx + hfcpreq->u.can_sndmsg_Handling.currlen);
						data_len = hfcpreq->u.can_sndmsg_Handling.Totallen;
						current_len = hfcpreq->u.can_sndmsg_Handling.currlen;
						current_len = hfcp_copy_segment(data_idx, hfcpreq->u.can_sndmsg_Handling.data, current_len);

						data_idx += current_len;

					}
					else
					{
						DBG("Error last data =%d",data_idx + hfcpreq->u.can_sndmsg_Handling.currlen);
						//Error
					}	
				}
				else
				{
					//Error
				}
			} 

			else
			{
				//Error
			}


			/*Send Block*/
			if( hfcpreq->u.can_sndmsg_Handling.last_packtet == 1 )
			{

				fd = isotp_canfd_get_socket(ch_id-1 , stored_CANID, stored_CANID+8, hfcpreq->u.can_sndmsg_Handling.tx_flags);

				if (fd < 0)
				{
					// socket creation/bind failed
					goto out;	/* was `return -1` in a
							 * void function, leaking
							 * pbuf */
				}

				DBG("WRITE DATA LEN %d\n", data_idx);
				wret = write(fd, data_buffer, data_idx);

				if (wret < 0)
				{
					perror("ISO-TP write");
					fl_status_U8 = ERR_FAILED;
				}
			}

			((hfcpReq_t *) pbuf)->command = CAN_Send_msg_ACK;
			pRsp->sndmsg_rsp.seg_num = hfcpreq->u.can_sndmsg_Handling.seg_num;       /* Segment number */
			pRsp->sndmsg_rsp.status = fl_status_U8;
			pRsp->sndmsg_rsp.timestamp = current_time_stamp;
			(void)host_write((void *)pbuf, hfcp_proto_cmd_len + sizeof(pRsp->sndmsg_rsp));


			break;
		case Start_FD_msg_filter:
			if ((proto_id == ISO15765_FD_PROTO_ID) ||
					(proto_id == CAN_FD_PROTOCOL_ID)) {
				fl_Protocol_ID_U8 = CAN_FD_PROTOCOL_ID;

			} else if ((proto_id == ISO15765_FD_CH1_PROTO_ID) ||
					(proto_id == CAN_FD_CH1_PROTO_ID)) {
				fl_Protocol_ID_U8 = CAN_FD_CH1_PROTO_ID;
			}
			/* TODO: fl_Protocol_ID_U8 is used uninitilized */
			DBG("Passing to ConfigFilter:Protocol_ID=0x%x\tfl_Protocol_ID=0x%x\n", fl_filter_config.Protocol_ID, fl_Protocol_ID_U8);
			fl_filter_config.Protocol_ID = fl_Protocol_ID_U8;
			fl_filter_config.filterType =
				(J2534_filterType_t) (hfcpreq->u.can_msg_filter.filtertype);
			plv = (lv_t *) (hfcpreq->u.can_msg_filter.buf);
			fl_filter_config.MaskLen =
				hfcp_copy_filter_field(fl_filter_config.maskMsg,
					sizeof(fl_filter_config.maskMsg),
					plv, "mask");

			plv =
				(lv_t *) ((hfcpreq->u.can_msg_filter.buf) +
						sizeof(plv->len) + plv->len);
			fl_filter_config.PatternLen =
				hfcp_copy_filter_field(fl_filter_config.patternMsg,
					sizeof(fl_filter_config.patternMsg),
					plv, "pattern");

			fl_filt_config_status =
				J2534_ConfigFilter(&fl_filter_config, &fl_FilterID);
			((hfcpReq_t *) pbuf)->command = Start_FD_msg_filter_ACK;
			pRsp->msg_fil.filterid = fl_FilterID;

			if (fl_filt_config_status != J2534_NO_ERROR) {
				DBG("FD_msg_filter Error.\n");
				if (fl_filt_config_status == J2534_FLT_NOT_FREE) {
					fl_status_U8 = ERR_EXCEEDED_LIMIT;
				} else {
					fl_status_U8 = ERR_FAILED;
				}
#if 0
				fl_USB_tx_data_U8A[0] = proto_id;
				fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				//Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
				(void)host_write((void *)fl_USB_tx_data_U8A, 5);	/* TODO: write 4 bytes */
#endif
				pRsp->msg_fil.status = fl_status_U8;
			} else {
				DBG("FD_msg_filter NO Error.\n");
#if 0
				fl_USB_tx_data_U8A[0] = proto_id;
				fl_USB_tx_data_U8A[1] = Start_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				fl_USB_tx_data_U8A[3] = fl_FilterID;

				//Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],5,DONT_RELEASE);
				(void)host_write((void *)fl_USB_tx_data_U8A, 5);	/* TODO: Write 4 bytes only */
#endif
				pRsp->msg_fil.status = STATUS_NOERROR;
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len + sizeof(pRsp->msg_fil));
			break;
		case Stop_FD_msg_filter:
			switch (proto_id) {
				case ISO15765_FD_PROTO_ID:
				case CAN_FD_PROTOCOL_ID:
					fl_Protocol_ID_U8 = CAN_FD_PROTOCOL_ID;
					break;
				case ISO15765_FD_CH1_PROTO_ID:
				case CAN_FD_CH1_PROTO_ID:
					fl_Protocol_ID_U8 = CAN_FD_CH1_PROTO_ID;
					break;
				default:
					DBG("Invalid proto_id");
					/* error */
			}
			fl_FilterID = hfcpreq->u.can_stpmsg_filter.filterid;
			DBG("Filter_ID=0x%x\tProtocol_ID=0x%x\n", fl_FilterID,
					fl_Protocol_ID_U8);
			fl_filt_stop_status =
				J2534_ClearFilter(fl_FilterID, fl_Protocol_ID_U8);

			((hfcpReq_t *) pbuf)->command = Stop_FD_msg_filter_ACK;
			pRsp->stpmsg_fil.filterid = fl_FilterID;
			if (fl_filt_stop_status != J2534_NO_ERROR) {
				if (fl_filt_stop_status == J2534_INVLD_FLTID) {
					fl_status_U8 = ERR_INVALID_FILTER_ID;
				} else {
					fl_status_U8 = ERR_FAILED;
				}
#if 0
				fl_USB_tx_data_U8A[0] = fl_Protocol_ID_U8;
				fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = fl_status_U8;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)host_write((void *)fl_USB_tx_data_U8A, 4);
#endif
				((hfcpReq_t *) pbuf)->proto_id = fl_Protocol_ID_U8;
				pRsp->stpmsg_fil.status = fl_status_U8;

			} else {
#if 0
				fl_USB_tx_data_U8A[0] = proto_id;
				fl_USB_tx_data_U8A[1] = Stop_msg_filter_ACK;
				fl_USB_tx_data_U8A[2] = STATUS_NOERROR;
				fl_USB_tx_data_U8A[3] = fl_FilterID;
				(void)host_write((void *)fl_USB_tx_data_U8A, 4);
#endif
				pRsp->msg_fil.status = STATUS_NOERROR;
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->stpmsg_fil));
			DBG("HFCP DEBUG : FD Stop Mesage Filter = %d \r\n",
					fl_status_U8);
			break;
		case handle_FD_periodic_msg:
			switch (proto_id) {
				case ISO15765_FD_PROTO_ID:
				case CAN_FD_PROTOCOL_ID:
					fl_Protocol_ID_U8 = CAN_FD_PROTOCOL_ID;
					break;
				case ISO15765_FD_CH1_PROTO_ID:
				case CAN_FD_CH1_PROTO_ID:
					fl_Protocol_ID_U8 = CAN_FD_CH1_PROTO_ID;
					break;
				default:
					DBG("Invalid proto_id");
					/* error */
			}
			periodic_msg_cmd = hfcpreq->u.can_periodic_msg.periodic_command;
			//(void) host_write((void *)pReq, 9);
			j2534_periodic_msg.protocol_id = fl_Protocol_ID_U8;
			j2534_periodic_msg.periodicity =
				hfcpreq->u.can_periodic_msg.periodicity;
			j2534_periodic_msg.prmsg_id = hfcpreq->u.can_periodic_msg.msgid;
			j2534_periodic_msg.proto_msg.tx_flags =
				hfcpreq->u.can_periodic_msg.tx_flags;
			if ((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN)
					|| (periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID)) {
				j2534_periodic_msg.proto_msg.length =
					hfcpreq->u.can_periodic_msg.msglen;
			} else {
				j2534_periodic_msg.proto_msg.length = 0;
			}
			j2534_periodic_msg.proto_msg.length =
				hfcp_copy_periodic_data(
					j2534_periodic_msg.proto_msg.data,
					sizeof(j2534_periodic_msg.proto_msg.data),
					hfcpreq->u.can_periodic_msg.buf,
					j2534_periodic_msg.proto_msg.length);
#if 1
			//if(PERIODIC_SUCCESS==0)
			if (PERIODIC_SUCCESS ==
					PERIODIC_msg_cmd(&j2534_periodic_msg, periodic_msg_cmd)) {
				fl_status_U8 = STATUS_NOERROR;
			} else {
				fl_status_U8 = ERR_FAILED;
			}
#endif
			/* Send Acknowledgment to J2534 DLL */
#if 0
			fl_USB_tx_data_U8A[0] = proto_id;
			fl_USB_tx_data_U8A[1] = handle_periodic_msg_ACK;
			fl_USB_tx_data_U8A[2] = fl_status_U8;
			fl_USB_tx_data_U8A[3] = j2534_periodic_msg.prmsg_id;
			//Garuda_Tx_data_on_USB(&fl_USB_tx_data_U8A[0],4,DONT_RELEASE);
			(void)host_write((void *)fl_USB_tx_data_U8A, 4);
#endif
			((hfcpReq_t *) pbuf)->command = handle_FD_periodic_msg_ACK;
			pRsp->pmsg.status = fl_status_U8;
			pRsp->pmsg.per_msg_id = j2534_periodic_msg.prmsg_id;
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len + sizeof(pRsp->pmsg));
			break;
		default:
			break;
	}
out:
	free(pbuf);
}

void process_CAN_IOCTL_cmd(uint8_t * buff)
{
	hfcpReq_t *hfcpreq;
	hfcpResp_t *pRsp;
	uint32_t proto_id;
	void *pbuf;
	int hfcp_proto_cmd_len;
	const char *ifname;

	uint8_t ch_id = 0;
	uint32_t fl_current_baudrate_U32 = 0, fl_IOCTL_CMD_U8 = 0;
	uint32_t fl_Protocol_ID_U8 = 0;
	uint8_t fl_loopback_status_U8, fl_SAM_status_U8, fl_SJW_status_U8;
	uint8_t fl_set_BR_ret_status_U8;
	uint8_t fl_filt_stopAll_status, fl_Q_clear_status;

#ifdef DEBUG_MODE
	DBG("***Inside The process_CAN_IOCTL_cmd***");
#endif

	hfcpreq = (hfcpReq_t *) buff;
	/* calloc: `memset(pbuf, 0, sizeof(USB_PKT_SIZE))` only cleared 4 bytes */
	pbuf = calloc(1, USB_PKT_SIZE);
	if (pbuf == NULL) {
		ERR("malloc failed!");
		return;
	}
	proto_id = hfcpreq->proto_id;
	hfcp_proto_cmd_len = sizeof(hfcpReq_t) - sizeof(hfcpreq->u);
	((hfcpReq_t *) pbuf)->proto_id = proto_id;
	pRsp = (hfcpResp_t *) ((uint8_t *) pbuf + hfcp_proto_cmd_len);
	fl_IOCTL_CMD_U8 = hfcpreq->u.ioctl_req.command_ID;	//IOCTL Command

	DBG("***Print protocol ID fl_IOCTL_CMD_U8=0x%x***", fl_IOCTL_CMD_U8);

	if ((proto_id == CAN_PROTOCOL_ID)
			|| (proto_id == ISO15765_PROTO_ID)) {
		ch_id = 1;
	} else if ((proto_id == CAN_CH1_PROTO_ID) ||
			(buff[0] == ISO15765_CH1_PROTO_ID)) {
		ch_id = 2;
	} else {
		//Error it will never reach here.
	}

	switch (fl_IOCTL_CMD_U8) {
#ifdef DEBUG_MODE
		DBG("***Inside IOCTL switch case***");
#endif
		case Get_config:
		DBG("***Inside CAN_IOCTL Get_config***");
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;	//IOCTL CMD ID
		fl_USB_tx_data_U8A[2] = Get_config_ACK;	//ACK for Get_config CMD
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_RESPONSE;
		pRsp->ioctl_resp.com_id = Get_config_ACK;
		if (Get_data_rate == hfcpreq->u.ioctl_req.data) {
			/*Get config parameter ID == Data rate */
			DBG("***Inside CAN_IOCTL Get_config Get_data_rate Get_data_rate=%d hfcpreq->u.ioctl_req.data=%d hfcpreq->u.ioctl_req.data**", Get_data_rate, hfcpreq->u.ioctl_req.data);
			fl_current_baudrate_U32 =
				get_bitrate_config(proto_id);
			if (0xFFFFFFFF == fl_current_baudrate_U32) {
				//fl_USB_tx_data_U8A[3] = ERR_FAILED;
				pRsp->ioctl_resp.status = ERR_FAILED;
			} else {
				//fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
				pRsp->ioctl_resp.status = STATUS_NOERROR;
			}
#if 0
			fl_USB_tx_data_U8A[4] = buff[3];	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[5] = Get_data_rate_ACK;	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[6] =
				(uint8_t) ((fl_current_baudrate_U32) & 0xFF);
			fl_USB_tx_data_U8A[7] =
				(uint8_t) ((fl_current_baudrate_U32 >> 8) & 0xFF);
			fl_USB_tx_data_U8A[8] =
				(uint8_t) ((fl_current_baudrate_U32 >> 16) & 0xFF);
			fl_USB_tx_data_U8A[9] =
				(uint8_t) ((fl_current_baudrate_U32 >> 24) & 0xFF);
#endif
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = Get_data_rate_ACK;
			pRsp->ioctl_resp.u.baudrate = fl_current_baudrate_U32;
		}

		else if (Get_loopback == hfcpreq->u.ioctl_req.data) {
			DBG("***Inside CAN_IOCTL Get_config Get_loopback***");
			DBG("Get_loopback=%d, hfcpreq->u.ioctl_req.data=%d\n",
					Get_loopback, hfcpreq->u.ioctl_req.data);
			fl_loopback_status_U8 =
				LowLevel_CAN_get_loopback_status(ch_id);
			/* Legacy code */
			if (ERR_INVALID_CHANNEL_ID == fl_loopback_status_U8) {
				//fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
				pRsp->ioctl_resp.status =
					ERR_INVALID_CHANNEL_ID;

			} else {
				//fl_USB_tx_data_U8A[3] = fl_loopback_status_U8;
				pRsp->ioctl_resp.status = fl_loopback_status_U8;
			}
#if 0
			fl_USB_tx_data_U8A[3] = STATUS_NOERROR;
			fl_USB_tx_data_U8A[4] = 1;	/* number of bytes */
			fl_USB_tx_data_U8A[5] = Get_loopback_ACK;	/* ACK for loopback status */
			fl_USB_tx_data_U8A[6] = fl_loopback_status_U8;	/* 0 - OFF, 1 - ON */
#endif
			pRsp->ioctl_resp.status = STATUS_NOERROR;
			pRsp->ioctl_resp.length = 1;
			pRsp->ioctl_resp.data_rate = Get_loopback_ACK;

			pRsp->ioctl_resp.u.loopback_status =
				fl_loopback_status_U8;

		} else if (Get_sample_point == hfcpreq->u.ioctl_req.data) {
			DBG("***Inside CAN_IOCTL Get_configi Get_Sample_point***");
			DBG("Get_sample_point=%d, hfcpreq->u.ioctl_req.data=%d\n", Get_sample_point, hfcpreq->u.ioctl_req.data);
			fl_SAM_status_U8 =
				LowLevel_CAN_get_current_sampling_mode(ch_id);

			/* Legacy code */
			if (ERR_INVALID_CHANNEL_ID == fl_SAM_status_U8) {
				//fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
				pRsp->ioctl_resp.status =
					ERR_INVALID_CHANNEL_ID;

			} else {
				//fl_USB_tx_data_U8A[3] = fl_SAM_status_U8;
				pRsp->ioctl_resp.status = fl_SAM_status_U8;
			}

			//fl_USB_tx_data_U8A[4] = buff[3];
			//fl_USB_tx_data_U8A[5] = Get_sample_point_ACK;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = Get_sample_point_ACK;

		} else if (Get_SJW == hfcpreq->u.ioctl_req.data) {
			DBG("***Inside CAN_IOCTL Get_config Get_SJW***");
			DBG("Get_SJW=%d, hfcpreq->u.ioctl_req.data=%d",
					Get_SJW, hfcpreq->u.ioctl_req.data);

			fl_SJW_status_U8 = LowLevel_CAN_get_current_SJW(ch_id);

			/* Legacy code */
			if (ERR_INVALID_CHANNEL_ID == fl_SJW_status_U8) {
				//fl_USB_tx_data_U8A[3] = ERR_INVALID_CHANNEL_ID;
				pRsp->ioctl_resp.status =
					ERR_INVALID_CHANNEL_ID;
			} else {
				//fl_USB_tx_data_U8A[3] = fl_SJW_status_U8;
				pRsp->ioctl_resp.status = fl_SJW_status_U8;
			}

			//fl_USB_tx_data_U8A[4] = buff[3];
			/* fl_USB_tx_data_U8A[5] = Get_SJW_ACK; *//* ACK for data rate parameter */
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = Get_SJW_ACK;

		}

		else {
			DBG("***Inside CAN_IOCTL Get_config INVALID_IOCTL_ID***");
#if 0
			fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
			fl_USB_tx_data_U8A[4] = buff[3];	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;	/* ACK for data rate parameter */
#endif
			pRsp->ioctl_resp.status = ERR_INVALID_IOCTL_ID;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = fl_IOCTL_CMD_U8;
		}

		//(void) host_write((void *)fl_USB_tx_data_U8A,5);
		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));
		break;
		case Set_config:
		DBG("Inside Set_config");
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_RESPONSE;	/* IOCTL CMD ID */
		fl_USB_tx_data_U8A[2] = Set_config_ACK;	/* ACK for Get config CMD */
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_RESPONSE;
		pRsp->ioctl_resp.com_id = Set_config_ACK;
		if (Set_data_rate == hfcpreq->u.ioctl_req.data) {	/*Set config parameter ID == Data rate */
			DBG("Inside CAN_IOCTL Set_config Set_data_rate\n");
#if 0
			fl_current_baudrate_U32 =
				fl_current_baudrate_U32 | (uint32_t)
				buff[5];
			fl_current_baudrate_U32 =
				fl_current_baudrate_U32 | (uint32_t)
				buff[6] << 8;
			fl_current_baudrate_U32 =
				fl_current_baudrate_U32 | (uint32_t)
				buff[7] << 16;
			fl_current_baudrate_U32 =
				fl_current_baudrate_U32 | (uint32_t)
				buff[8] << 24;
#endif

#if 0
			fl_current_baudrate_U32 =
				hfcpreq->u.ioctl_req.un.baudrate;
			/* Added Code for Deinitilization CAN Interface.        */
			/* Initialization of CAN with set config baudrate       */
			/* Update the Baud Rate to Global Structure             */
			CAN_Mid_DeInit((ch_id == 1) ? "can0" : "can1");
			CAN_Mid_Init(((ch_id ==
							1) ? "can0" : "can1"),
					fl_current_baudrate_U32);
			fl_set_BR_ret_status_U8 =
				CAN_Mid_set_baudrate
				(fl_current_baudrate_U32, ch_id);
#endif

			fl_current_baudrate_U32 =
				hfcpreq->u.ioctl_req.un.baudrate;

			ifname = can_get_ifname(proto_id);
			if (ifname == NULL)
			{
				ERR("Invalid protocol ID: 0x%X", proto_id);
				goto out;	/* was `return -1` in a void
						 * function, leaking pbuf */
			}

			DBG("IOCTL: proto_id=0x%X\n", proto_id);
			DBG("IOCTL: ch_id=%d\n", ch_id);
			DBG("IOCTL: data=0x%X\n", hfcpreq->u.ioctl_req.data);
			DBG("IOCTL: baudrate=%u (0x%X)\n", hfcpreq->u.ioctl_req.un.baudrate,hfcpreq->u.ioctl_req.un.baudrate);
			DBG("IOCTL: ifname=%s\n", ifname);

			if(bitrate_config_check(fl_current_baudrate_U32 , proto_id))
			{
				isotp_close_all_sockets();
				fl_set_BR_ret_status_U8 = can_if_setbitrate((char *)ifname, fl_current_baudrate_U32);
			}
			else
			{
				fl_set_BR_ret_status_U8 = STATUS_NOERROR;
			}
			if(fl_set_BR_ret_status_U8 == STATUS_NOERROR)
			{
				Update_bitrate_config_check(fl_current_baudrate_U32, proto_id);
			}


			//			fl_set_BR_ret_status_U8 = STATUS_NOERROR;
#if 0
			fl_USB_tx_data_U8A[3] = fl_set_BR_ret_status_U8;	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[4] = buff[3];
			fl_USB_tx_data_U8A[5] = Set_data_rate_ACK;	/* ACK for data rate parameter */
#endif
			pRsp->ioctl_resp.status = fl_set_BR_ret_status_U8;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = Set_data_rate_ACK;
			pRsp->ioctl_resp.u.baudrate = fl_current_baudrate_U32;
		} else if (Set_loopback == hfcpreq->u.ioctl_req.data) {
			/* Set config parameter ID == loopback */
			DBG("Inside CAN_IOCTL Set_config Set_loopback");
			if (hfcpreq->u.ioctl_req.un.loopback_status == 1) {
				fl_loopback_status_U8 =
					LowLevel_CAN_enable_loopback(ch_id);

			} else if (hfcpreq->u.ioctl_req.un.loopback_status == 0) {
				fl_loopback_status_U8 =
					LowLevel_CAN_disable_loopback(ch_id);
			} else {
				fl_loopback_status_U8 = ERR_INVALID_IOCTL_ID;
			}
#if 0
			fl_USB_tx_data_U8A[3] = fl_loopback_status_U8;	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[4] = buff[3];
			fl_USB_tx_data_U8A[5] = Set_loopback_ACK;
#endif
			pRsp->ioctl_resp.status = fl_loopback_status_U8;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = Set_loopback_ACK;
		} else if ((Set_sample_point == hfcpreq->u.ioctl_req.data)
				|| (Set_SJW == hfcpreq->u.ioctl_req.data)) {
			DBG("Inside CAN_IOCTL Set_config Set_sample_point");
#if 0
			fl_USB_tx_data_U8A[3] = ERR_NOT_SUPPORTED;
			fl_USB_tx_data_U8A[4] = buff[3];
			fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;
#endif
			pRsp->ioctl_resp.status = ERR_NOT_SUPPORTED;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = fl_IOCTL_CMD_U8;
		} else if (Set_STMIN == hfcpreq->u.ioctl_req.data){
			DBG("Set_config - > Set_STMIN - Enter");
			SET_Force_STMIN = hfcpreq->u.ioctl_req.un.STMIN_Value;
			pRsp->ioctl_resp.status = fl_set_BR_ret_status_U8;
                        pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
                        pRsp->ioctl_resp.data_rate = Set_STMIN_ACK;
	
		}
		else {
			DBG("Inside CAN_IOCTL Set_config INVALID_IOCTL_ID");

#if 0
			fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
			fl_USB_tx_data_U8A[4] = buff[3];	/* ACK for data rate parameter */
			fl_USB_tx_data_U8A[5] = fl_IOCTL_CMD_U8;	/* ACK for data rate parameter */
#endif
			pRsp->ioctl_resp.status = ERR_INVALID_IOCTL_ID;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			pRsp->ioctl_resp.data_rate = fl_IOCTL_CMD_U8;
		}

		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));
		break;
		case clear_all_msg_filters:
		DBG("Inside clear_all_msg_filters");
		if ((proto_id == ISO15765_PROTO_ID)
				|| (proto_id == CAN_PROTOCOL_ID)) {
			fl_Protocol_ID_U8 = CAN_PROTOCOL_ID;
		} else if ((proto_id == ISO15765_CH1_PROTO_ID)
				|| (proto_id == CAN_CH1_PROTO_ID)) {
			fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
		}
		fl_filt_stopAll_status = J2534_ClearAllFilter(fl_Protocol_ID_U8);	// declare and define the function before use
		if (fl_filt_stopAll_status == J2534_NO_ERROR) {
			/* fl_USB_tx_data_U8A[3] = STATUS_NOERROR; *//* Staus No_ERROR */
			pRsp->ioctl_resp.status = STATUS_NOERROR;
		} else {
			/* fl_USB_tx_data_U8A[3] = ERR_FAILED; *//* Failed due to Wrong Protocol ID */
			pRsp->ioctl_resp.status = ERR_FAILED;
		}
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_COMMAND;	/* IOCTL CMD ID */
		fl_USB_tx_data_U8A[2] = clear_all_msg_filters_ACK;	/* Command ID */
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_COMMAND;
		pRsp->ioctl_resp.com_id = clear_all_msg_filters_ACK;

		//(void) host_write((void *)fl_USB_tx_data_U8A,5);
		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));
		break;
		case clear_all_periodic_msgs:
		DBG("Inside clear_all_periodic_msgs");
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_COMMAND;	/* IOCTL CMD ID */
		fl_USB_tx_data_U8A[2] = clear_all_periodic_msgs_ACK;
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_COMMAND;
		pRsp->ioctl_resp.com_id = clear_all_periodic_msgs_ACK;
		if ((proto_id == ISO15765_PROTO_ID)
				|| (proto_id == CAN_PROTOCOL_ID)) {
			fl_Protocol_ID_U8 = CAN_PROTOCOL_ID;
		} else if ((proto_id == ISO15765_CH1_PROTO_ID)
				|| (proto_id == CAN_CH1_PROTO_ID)) {
			fl_Protocol_ID_U8 = CAN_CH1_PROTO_ID;
		}
		// uint32_t fl_Protocol_ID_U8 = 0;
		/* @TODO: What is this doing here? */
		suspend_pmsg(fl_Protocol_ID_U8);	// Suspend all periodic messages
		/* declare and define the function before use */
		/* fl_USB_tx_data_U8A[3] = STATUS_NOERROR; *//* Error status */
		pRsp->ioctl_resp.status = STATUS_NOERROR;
		/*((hfcpReq_t *)pbuf)->command = IOCTL_COMMAND;
		  pRsp->ioctl_resp.com_id = clear_all_periodic_msgs_ACK; */

		//(void) host_write((void *)fl_USB_tx_data_U8A,5);
		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));

		break;
		case clear_tx_buffer:
		DBG("Inside clear_tx_buffer\n");

		DBG("Inside clear_tx_buffer\n");
		if ((proto_id == ISO15765_PROTO_ID)
				|| (proto_id == CAN_PROTOCOL_ID)) {
			fl_Q_clear_status = MID_PASS;
		} else if ((proto_id == ISO15765_CH1_PROTO_ID)
				|| (proto_id == CAN_CH1_PROTO_ID)) {
			fl_Q_clear_status = MID_PASS;
		}
		if (fl_Q_clear_status == MID_PASS) {
			pRsp->ioctl_resp.status = STATUS_NOERROR;	/* Staus No_ERROR */
		} else {
			pRsp->ioctl_resp.status = ERR_FAILED;	/* Failed due to Wrong Protocol ID */
		}
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_COMMAND;	/* IOCTL CMD ID */
		fl_USB_tx_data_U8A[2] = clear_tx_buffer_ACK;	/* Command ID */
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_COMMAND;
		pRsp->ioctl_resp.com_id = clear_tx_buffer_ACK;
		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));
		break;
		case clear_rx_buffer:
		DBG("Inside clear_rx_buffer\n");
		if ((proto_id == ISO15765_PROTO_ID)
				|| (proto_id == CAN_PROTOCOL_ID)) {
			fl_Q_clear_status = MID_PASS;
		} else if ((proto_id == ISO15765_CH1_PROTO_ID)
				|| (proto_id == CAN_CH1_PROTO_ID)) {
			fl_Q_clear_status = MID_PASS;
		}
		if (fl_Q_clear_status == MID_PASS) {
			pRsp->ioctl_resp.status = STATUS_NOERROR;	/* Staus No_ERROR */
		} else {
			pRsp->ioctl_resp.status = ERR_FAILED;	/* Failed due to Wrong Protocol ID */
		}
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_COMMAND;	/* IOCTL CMD ID */
		fl_USB_tx_data_U8A[2] = clear_rx_buffer_ACK;	/* Command ID */
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_COMMAND;
		pRsp->ioctl_resp.com_id = clear_rx_buffer_ACK;
		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));
		break;
		default:
#if 0
		fl_USB_tx_data_U8A[0] = buff[0];
		fl_USB_tx_data_U8A[1] = IOCTL_COMMAND;	//IOCTL CMD ID
		fl_USB_tx_data_U8A[2] = fl_IOCTL_CMD_U8;	//ACK for Get_config CMD
		fl_USB_tx_data_U8A[3] = ERR_INVALID_IOCTL_ID;
		fl_USB_tx_data_U8A[4] = buff[3];
#endif
		((hfcpReq_t *) pbuf)->command = IOCTL_COMMAND;
		pRsp->ioctl_resp.com_id = fl_IOCTL_CMD_U8;
		pRsp->ioctl_resp.status = ERR_INVALID_IOCTL_ID;
		pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;

		//(void) host_write((void *)fl_USB_tx_data_U8A,5);
		(void)host_write((void *)pbuf,
				hfcp_proto_cmd_len +
				sizeof(pRsp->ioctl_resp));

	}

out:
	free(pbuf);
}

void process_CAN_FD_IOCTL_cmd(uint8_t * buff)
{
	hfcpReq_t *hfcpreq;
	hfcpResp_t *pRsp;
	uint32_t proto_id;
	void *pbuf;
	int hfcp_proto_cmd_len;

	uint8_t fl_IOCTL_CMD_U8 = 0, ch_id = 0;
	uint32_t fl_current_baudrate_U32 = 0;
	uint32_t fl_Protocol_ID_U8 = 0;
	uint8_t fl_loopback_status_U8, fl_SAM_status_U8, fl_SJW_status_U8;
	uint8_t fl_set_BR_ret_status_U8, fl_filt_stopAll_status;
	uint8_t fl_Q_clear_status;
	uint8_t fl_ps_chan_status = 0;
	uint8_t fl_connection_flag_U8;
	const char *ifname;


	DBG("process_CAN_FD_IOCTL_cmd - Enter\n");

	hfcpreq = (hfcpReq_t *) buff;
	/* calloc: `memset(pbuf, 0, sizeof(USB_PKT_SIZE))` only cleared 4 bytes */
	pbuf = calloc(1, USB_PKT_SIZE);
	if (pbuf == NULL) {
		DBG("malloc failed");
		return;
	}
	proto_id = hfcpreq->proto_id;
	hfcp_proto_cmd_len = sizeof(hfcpReq_t) - sizeof(hfcpreq->u);
	((hfcpReq_t *) pbuf)->proto_id = proto_id;
	((hfcpReq_t *) pbuf)->command = IOCTL_RESPONSE;
	pRsp = (hfcpResp_t *) ((uint8_t *) pbuf + hfcp_proto_cmd_len);
	fl_IOCTL_CMD_U8 = hfcpreq->u.ioctl_req.command_ID;	//IOCTL Command

	DBG("fl_IOCTL_CMD_U8=0x%x", fl_IOCTL_CMD_U8);

	if ((proto_id == CAN_FD_PROTOCOL_ID) ||
			(proto_id == ISO15765_FD_PROTO_ID)) {
		ch_id = 1;
	} else if ((proto_id == CAN_FD_CH1_PROTO_ID) ||
			(proto_id == ISO15765_FD_CH1_PROTO_ID)) {
		ch_id = 2;
	} else if (proto_id == CAN_FD_PS) {
		ch_id = CAN_FD_PS_chan;
	} else {
		//error
	}

	switch (fl_IOCTL_CMD_U8) {
		case Get_config:
			{
				DBG("CAN_FD_IOCTL -> Get_config - Enter");
				pRsp->ioctl_resp.com_id = Get_config_ACK;

				if (Get_data_rate == hfcpreq->u.ioctl_req.data) {
					DBG("Get_config - > Get_data_rate - Enter");
					fl_current_baudrate_U32 =
						CAN_Mid_get_current_baudrate(ch_id);
					if (0xFFFFFFFF == fl_current_baudrate_U32) {
						pRsp->ioctl_resp.status = ERR_FAILED;
					} else {
						pRsp->ioctl_resp.status =
							STATUS_NOERROR;
					}
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Get_data_rate_ACK;
					pRsp->ioctl_resp.u.baudrate =
						fl_current_baudrate_U32;
				} else if (Get_loopback == hfcpreq->u.ioctl_req.data) {
					DBG("Get_config - > Get_loopback - Enter");
					fl_loopback_status_U8 =
						LowLevel_CAN_get_loopback_status(ch_id);
					if (ERR_INVALID_CHANNEL_ID ==
							fl_loopback_status_U8) {
						pRsp->ioctl_resp.status =
							ERR_INVALID_CHANNEL_ID;
					} else {
						pRsp->ioctl_resp.status =
							fl_loopback_status_U8;
					}
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Get_data_rate_ACK;
					pRsp->ioctl_resp.u.loopback_status =
						fl_loopback_status_U8;
				} else if (Get_sample_point ==
						hfcpreq->u.ioctl_req.data) {
					DBG("Get_config - > Get_sample_point - Enter");
					fl_SAM_status_U8 =
						LowLevel_CAN_get_current_sampling_mode
						(ch_id);
					if (ERR_INVALID_CHANNEL_ID == fl_SAM_status_U8) {
						pRsp->ioctl_resp.status =
							ERR_INVALID_CHANNEL_ID;
					} else {
						pRsp->ioctl_resp.status =
							fl_SAM_status_U8;
					}
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate =
						Get_sample_point_ACK;
				} else if (Get_SJW == hfcpreq->u.ioctl_req.data) {
					DBG("Get_config - > Get_SJW - Enter");
					fl_SJW_status_U8 =
						LowLevel_CAN_get_current_SJW(ch_id);
					if (ERR_INVALID_CHANNEL_ID == fl_SJW_status_U8) {
						pRsp->ioctl_resp.status =
							ERR_INVALID_CHANNEL_ID;
					} else {
						pRsp->ioctl_resp.status =
							fl_SJW_status_U8;
					}
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Get_SJW_ACK;
				} else if (Get_ps_chan == hfcpreq->u.ioctl_req.data) {
					//CAN_FD_PS_chan = hfcpreq->u.ioctl_req.un.CAN_FD_PS_chan;

					pRsp->ioctl_resp.status = STATUS_NOERROR;
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Get_ps_chan_ACK;
					pRsp->ioctl_resp.u.CAN_FD_PS_chan =
						CAN_FD_PS_chan;
				} else if (Get_frame_length  == hfcpreq->u.ioctl_req.data) {
					//CAN_FD_PS_chan = hfcpreq->u.ioctl_req.un.CAN_FD_PS_chan;

					pRsp->ioctl_resp.status = STATUS_NOERROR;
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Get_frame_length_ACK;
					pRsp->ioctl_resp.u.CAN_FD_frame_length =
						fd_frame_length;
				} else {
					DBG("Get_config - > Get_INVALID_IOCTL_ID - Enter");
					pRsp->ioctl_resp.status = ERR_INVALID_IOCTL_ID;
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = fl_IOCTL_CMD_U8;
				}
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
			break;
		case Set_config:
			{
				DBG("CAN_FD_IOCTL -> Set_config - Enter");
				pRsp->ioctl_resp.com_id = Set_config_ACK;

				if (Set_data_rate == hfcpreq->u.ioctl_req.data) {
					DBG("Set_config - > Set_data_rate - Enter");


					fl_current_baudrate_U32 =
						hfcpreq->u.ioctl_req.un.baudrate;

					ifname = can_get_ifname(proto_id);
					if (ifname == NULL)
					{
						ERR("Invalid protocol ID: 0x%X", proto_id);
						goto out;	/* was `return -1`
								 * in a void
								 * function */
					}

					DBG("IOCTL: proto_id=0x%X\n", proto_id);
					DBG("IOCTL: ch_id=%d\n", ch_id);
					DBG("IOCTL: data=0x%X\n", hfcpreq->u.ioctl_req.data);
					DBG("IOCTL: baudrate=%u (0x%X)\n", hfcpreq->u.ioctl_req.un.baudrate,hfcpreq->u.ioctl_req.un.baudrate);
					DBG("IOCTL: ifname=%s\n", ifname);

					if(bitrate_config_check(fl_current_baudrate_U32 , proto_id))
					{
						isotp_close_all_sockets();
						fl_set_BR_ret_status_U8 = can_if_setbitrate((char *)ifname, fl_current_baudrate_U32);
					}
					else
					{
						fl_set_BR_ret_status_U8 = STATUS_NOERROR;
					}
					if(fl_set_BR_ret_status_U8 == STATUS_NOERROR)
					{
						Update_bitrate_config_check(fl_current_baudrate_U32, proto_id);
					}

#if 0

					fl_current_baudrate_U32 =
						hfcpreq->u.ioctl_req.un.baudrate;
					CAN_Mid_DeInit((ch_id == 1) ? "can0" : "can1");
					CAN_Mid_Init(((ch_id ==
									1) ? "can0" : "can1"),
							fl_current_baudrate_U32);

					fl_set_BR_ret_status_U8 =
						CAN_Mid_set_baudrate
						(fl_current_baudrate_U32, ch_id);
#endif
					pRsp->ioctl_resp.status =
						fl_set_BR_ret_status_U8;
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Set_data_rate_ACK;
					pRsp->ioctl_resp.u.baudrate =
						fl_current_baudrate_U32;
				} else if (Set_loopback == hfcpreq->u.ioctl_req.data) {
					DBG("Set_config - > Set_loopback - Enter");
					if (hfcpreq->u.ioctl_req.un.loopback_status ==
							1) {
						fl_loopback_status_U8 =
							LowLevel_CAN_enable_loopback(ch_id);
					} else if (hfcpreq->u.ioctl_req.un.
							loopback_status == 0) {
						fl_loopback_status_U8 =
							LowLevel_CAN_disable_loopback
							(ch_id);
					} else {
						fl_loopback_status_U8 =
							ERR_INVALID_IOCTL_ID;
					}
					pRsp->ioctl_resp.status = fl_loopback_status_U8;
					pRsp->ioctl_resp.length =
						hfcpreq->u.ioctl_req.length;
					pRsp->ioctl_resp.data_rate = Set_loopback_ACK;
				} else
					if ((Set_sample_point == hfcpreq->u.ioctl_req.data)
							|| (Set_SJW == hfcpreq->u.ioctl_req.data)) {
						DBG("Set_config - > Set_sample_point_SJW - Enter");
						pRsp->ioctl_resp.status = ERR_NOT_SUPPORTED;
						pRsp->ioctl_resp.length =
							hfcpreq->u.ioctl_req.length;
						pRsp->ioctl_resp.data_rate =
							Set_sample_point_ACK;
					} else if (Set_frame_length ==
							hfcpreq->u.ioctl_req.data) {
						fd_frame_length =
							hfcpreq->u.ioctl_req.un.fd_frame_length;

						pRsp->ioctl_resp.status = STATUS_NOERROR;
						pRsp->ioctl_resp.length =
							hfcpreq->u.ioctl_req.length;
						pRsp->ioctl_resp.data_rate =
							Set_frame_length_ACK;
					} else if (Set_ps_chan == hfcpreq->u.ioctl_req.data) {
						CAN_FD_PS_chan =
							hfcpreq->u.ioctl_req.un.CAN_FD_PS_chan;
						if (CAN_FD_PS_chan == CAN_CH1) {
							CAN_or_ISO = proto_id;
							CAN_FD_or_ISO15765_FD = proto_id;
							CAN1_Vehicle_STMinValue = 0;
							fl_ps_chan_status =
								CAN_Mid_Init(CAN_CHA1,
										ps_baud_rate);
						} else if (CAN_FD_PS_chan == CAN_CH2) {
							CAN1_or_ISO1 = proto_id;
							CANCH1_or_ISO15765CH1_J1939CH1 =
								proto_id;
							CAN2_vehicle_STMinValue = 0;
							fl_ps_chan_status =
								CAN_Mid_Init(CAN_CHA2,
										ps_baud_rate);
						}
#if 1
						if ((ERR_INVALID_BAUDRATE != fl_ps_chan_status)
								&& (ERR_INVALID_CHANNEL_ID !=
									fl_ps_chan_status)) {
							DBG("Check success");
							if ((CAN_connect_flags &
										CAN_ID_BOTH) == CAN_ID_BOTH) {
								fl_connection_flag_U8 =
									RX_BOTH_STD_EXT_MSG;
							} else
								if ((CAN_connect_flags &
											CAN_29BIT_ID) ==
										CAN_29BIT_ID) {
									fl_connection_flag_U8 =
										RX_ONLY_EXT_MSG;
								} else
									if ((CAN_connect_flags &
												CAN_29BIT_ID) == 0) {
										fl_connection_flag_U8 =
											RX_ONLY_STD_MSG;
									} else {
										fl_ps_chan_status =
											ERR_INVALID_FLAGS;
									}
							if (fl_ps_chan_status !=
									ERR_INVALID_FLAGS) {
								fl_ps_chan_status =
									CAN_Mid_Enable
									(CAN_CH1,
									 fl_connection_flag_U8);
								//CAN_Mid_Init (char *can, uint32_t p_baudrate);
								if (fl_ps_chan_status ==
										STATUS_NOERROR) {
									l_connected_channels++;
									if (CAN_FD_PS_chan ==
											CAN_CH1) {
										l_connected_channel_1
											= 1;
									} else
										if (CAN_FD_PS_chan
												== CAN_CH2) {
											l_connected_channel_2
												= 1;
										}
								}
							} else {
								/* Do nothing as fl_ps_chan_status shas been modified */
							}
						} else {
							/* Do nothing as fl_ps_chan_status has been modified */
						}
						if (fl_ps_chan_status == STATUS_NOERROR) {
							CAN_active = 1;
						}
#endif
						pRsp->ioctl_resp.status = fl_ps_chan_status;
						pRsp->ioctl_resp.length =
							hfcpreq->u.ioctl_req.length;
						pRsp->ioctl_resp.data_rate = Set_ps_chan_ACK;
					} else if (Set_fd_datarate == hfcpreq->u.ioctl_req.data) {
						DBG("Set_config - > Set_INVALID_IOCTL_ID - Enter");
					}else if (Set_STMIN == hfcpreq->u.ioctl_req.data){
						 DBG("Set_config - > Set_STMIN - Enter");

			                        SET_Force_STMIN = hfcpreq->u.ioctl_req.un.STMIN_Value;
                			        pRsp->ioctl_resp.status = fl_set_BR_ret_status_U8;
                			        pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
                        			pRsp->ioctl_resp.data_rate = Set_STMIN_ACK;

                			}
					else {
						DBG("Set_config - > Set_INVALID_IOCTL_ID - Enter");
						pRsp->ioctl_resp.status = ERR_INVALID_IOCTL_ID;
						pRsp->ioctl_resp.length =
							hfcpreq->u.ioctl_req.length;
						pRsp->ioctl_resp.data_rate = fl_IOCTL_CMD_U8;
					}
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
			break;
		case clear_all_msg_filters:
			DBG("CAN_FD_IOCTL -> clear_all_msg_filters - Enter");
			pRsp->ioctl_resp.com_id = clear_all_msg_filters_ACK;

			if ((proto_id == ISO15765_FD_PROTO_ID)
					|| (proto_id == CAN_FD_PROTOCOL_ID)) {
				fl_Protocol_ID_U8 = CAN_FD_PROTOCOL_ID;
			} else if ((proto_id == ISO15765_FD_CH1_PROTO_ID)
					|| (proto_id == CAN_FD_CH1_PROTO_ID)) {
				fl_Protocol_ID_U8 = CAN_FD_CH1_PROTO_ID;
			}
			fl_filt_stopAll_status =
				J2534_ClearAllFilter(fl_Protocol_ID_U8);
			if (fl_filt_stopAll_status == J2534_NO_ERROR) {
				pRsp->ioctl_resp.status = STATUS_NOERROR;
			} else {
				pRsp->ioctl_resp.status = ERR_FAILED;
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
			break;
		case clear_all_periodic_msgs:
			DBG("CAN_FD_IOCTL -> clear_all_periodic_msgs - Enter");
			pRsp->ioctl_resp.com_id = clear_all_periodic_msgs_ACK;

			if ((proto_id == ISO15765_FD_PROTO_ID)
					|| (proto_id == CAN_FD_PROTOCOL_ID)) {
				fl_Protocol_ID_U8 = CAN_FD_PROTOCOL_ID;
			} else if ((proto_id == ISO15765_FD_CH1_PROTO_ID)
					|| (proto_id == CAN_FD_CH1_PROTO_ID)) {
				fl_Protocol_ID_U8 = CAN_FD_CH1_PROTO_ID;
			}
			fl_filt_stopAll_status = J2534_NO_ERROR;	//J2534_ClearAllPeriodic(fl_Protocol_ID_U8);
			if (fl_filt_stopAll_status == J2534_NO_ERROR) {
				pRsp->ioctl_resp.status = STATUS_NOERROR;
			} else {
				pRsp->ioctl_resp.status = ERR_FAILED;
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
			break;
		case clear_tx_buffer:
			DBG("CAN_FD_IOCTL -> clear_tx_buffer - Enter");
			pRsp->ioctl_resp.com_id = clear_tx_buffer_ACK;

			if ((proto_id == ISO15765_FD_PROTO_ID)
					|| (proto_id == CAN_FD_PROTOCOL_ID)) {
				fl_Q_clear_status = MID_PASS;
			} else if ((proto_id == ISO15765_FD_CH1_PROTO_ID)
					|| (proto_id == CAN_FD_CH1_PROTO_ID)) {
				fl_Q_clear_status = MID_PASS;
			}
			if (fl_Q_clear_status == MID_PASS) {
				pRsp->ioctl_resp.status = STATUS_NOERROR;	/* Staus No_ERROR */
			} else {
				pRsp->ioctl_resp.status = ERR_FAILED;	/* Failed due to Wrong Protocol ID */
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
			break;
		case clear_rx_buffer:
			DBG("CAN_FD_IOCTL -> clear_rx_buffer - Enter");
			pRsp->ioctl_resp.com_id = clear_rx_buffer_ACK;

			if ((proto_id == ISO15765_FD_PROTO_ID)
					|| (proto_id == CAN_FD_PROTOCOL_ID)) {
				fl_Q_clear_status = MID_PASS;
			} else if ((proto_id == ISO15765_FD_CH1_PROTO_ID)
					|| (proto_id == CAN_FD_CH1_PROTO_ID)) {
				fl_Q_clear_status = MID_PASS;
			}
			if (fl_Q_clear_status == MID_PASS) {
				pRsp->ioctl_resp.status = STATUS_NOERROR;	/* Staus No_ERROR */
			} else {
				pRsp->ioctl_resp.status = ERR_FAILED;	/* Failed due to Wrong Protocol ID */
			}
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
			break;
		default:
			DBG("CAN_FD_IOCTL -> Get_config - Enter");
			pRsp->ioctl_resp.com_id = fl_IOCTL_CMD_U8;
			pRsp->ioctl_resp.status = ERR_INVALID_IOCTL_ID;
			pRsp->ioctl_resp.length = hfcpreq->u.ioctl_req.length;
			(void)host_write((void *)pbuf,
					hfcp_proto_cmd_len +
					sizeof(pRsp->ioctl_resp));
	}

out:
	free(pbuf);
}



void process_KWP_command(uint8_t * buffer)
{
	hfcpReq_t * KWP_buffer = (hfcpReq_t*)buffer;	
	uint8_t fl_status_U8, fl_USB_tx_data_U8A[IN_BUFFER_SIZE], command = 0;
	PERIODIC_MSG j2534_periodic_msg;
	uint8_t periodic_msg_cmd = 0;
	J2534_filter_t 	fl_filter_config;			;
	uint8_t fl_FilterID, fl_Protocol_ID_U8;
	uint32_t loop_count = 0;
	J2534_stError_t fl_filt_config_status, fl_filt_stop_status;
	uint32_t current_time_stamp = 0;
	ISO9141_14230_Init_S fl_App_ISO9141_14230Init_S;
	ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus;
	uint16_t fl_IdxLen;
	lv_t *plv;
	/*hfcpResp_kwp_t hfcpResp_kwp;
	  hfcpResp_kwp_t * hfcpResp_kwp_buf = &hfcpResp_kwp;*/

	hfcpResp_kwp_t * hfcpResp_kwp_buf = (hfcpResp_kwp_t*)malloc(sizeof(hfcpResp_kwp_t));

	if (hfcpResp_kwp_buf == NULL) {
		DBG("malloc failed");
		return;
	}

	/* The Length has to retained with successive Calls */
	static uint16_t fl_KWPTX_LocalLen;

	command = KWP_buffer->command;

	switch (command) {
		case KWP_EnableComm:
			{
				hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
				hfcpResp_kwp_buf->resp_command = KWP_EnableComm_ACK ;

				if ((KWP_buffer->proto_id == KWP_PROTOCOL_ID)  || (KWP_buffer->proto_id == ISO_9141_PROTO_ID)) {

					ISO_9141_OR_14230 = KWP_buffer->proto_id; // changed to uint32_t

					/* Determine the Initialization structure */
					fl_App_ISO9141_14230Init_S.ProtocolId =  KWP_buffer->proto_id ;
					fl_App_ISO9141_14230Init_S.Baudrate   =  KWP_buffer->u.kwp_enable.baudrate;
					fl_App_ISO9141_14230Init_S.Flags      =  KWP_buffer->u.kwp_enable.conn_flags;
					if (((KWP_buffer->u.kwp_enable.conn_flags & ISO9141_K_LINE_ONLY) == ISO9141_K_LINE_ONLY) ||
							((KWP_buffer->u.kwp_enable.conn_flags & ISO9141_NO_CHECKSUM) == ISO9141_NO_CHECKSUM) ||
							(KWP_buffer->u.kwp_enable.conn_flags  == 0x0000000)) {
						/* Call the Driver Init function */
						ISO9141_14230_Init (&fl_App_ISO9141_14230Init_S);
						KWP_active = 1;

						hfcpResp_kwp_buf->un.status = STATUS_NOERROR;

					} else {

						hfcpResp_kwp_buf->un.status = ERR_INVALID_FLAGS;
					}
				} else {
					/* ERROR: It should never enter here */
					hfcpResp_kwp_buf->un.status = ERR_INVALID_PROTOCOL_ID;  // kwp_ch_indx
					(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t)- sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.status))); 
					break;
				}
				l_connected_channels++;
				l_connected_channel_Kline = 1;
				(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t)- sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.status)));        
				break;
			}

		case KWP_DisableComm:
			{

				hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
				hfcpResp_kwp_buf->resp_command = KWP_DisableComm_ACK ;

				J2534_ClearAllFilter(KWP_PROTOCOL_ID);	//buffer[0]);
				suspend_pmsg(KWP_PROTOCOL_ID);	//buffer[0]); /* Suspend all periodic messages */
				ISO9141_14230_Reset();

				if ((KWP_buffer->proto_id == KWP_PROTOCOL_ID) || (KWP_buffer->proto_id == ISO_9141_PROTO_ID)) {
					ISO_9141_OR_14230 = 0;
					if (l_connected_channels) {
						l_connected_channels--;
					}
					l_connected_channel_Kline = 0;
					KWP_active = 0;

				} else {
					/* ERROR: It should never enter here */

					hfcpResp_kwp_buf->un.status = ERR_INVALID_PROTOCOL_ID;

					(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.status)));
					break;
				}
				periodic_suspend_pmsg(KWP_buffer->proto_id);
				hfcpResp_kwp_buf->un.status = STATUS_NOERROR;
				(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.status)));
				break;
			}

		case IOCTL_COMMAND:
			{
				process_KWP_IOCTL_cmd(buffer);
				break;
			}

		case KWP_Send_msg:
			{

				if ((KWP_buffer->proto_id  == KWP_PROTOCOL_ID) || (KWP_buffer->proto_id  == ISO_9141_PROTO_ID)) {

					/* Check the Segment Number if it is 0 or 1 copy the Flag and Length Details */
					if (KWP_buffer->u.kwp_sndmsg.seg_num == SEG_NUM_ZERO) {



						ISO9141_14230_TxMsg_S_Buffer.Length = KWP_buffer->u.kwp_sndmsg.tx_msg_len; 

						/* If Length is 0 then dont copy data and Flags */
						if (ISO9141_14230_TxMsg_S_Buffer.Length != 0) {

							ISO9141_14230_TxMsg_S_Buffer.Flags = KWP_buffer->u.kwp_sndmsg.tx_msg_flags;

							for (fl_IdxLen = 0; fl_IdxLen < ISO9141_14230_TxMsg_S_Buffer.Length;fl_IdxLen++) {
								ISO9141_14230_TxMsg_S_Buffer.Data[fl_IdxLen] = buffer[12 + fl_IdxLen];
							}

						} else {
							/* Do Nothing */
						}

						/* MArk the Flag = NO Segmented Transfer */
						//	l_KWPTX_SegTrnsfr = 0;

						/* Call the Write Message function */
						fl_ISO9141_14230RetStatus = ISO9141_14230_WriteMsg();

						/* Determine the Response */

						hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;	

						hfcpResp_kwp_buf->resp_command = KWP_Send_msg_ACK;
						hfcpResp_kwp_buf->un.kwp_sendmsg_resp.seg_num = KWP_buffer->u.kwp_sndmsg.seg_num;

						/* Update time stamp on USB TX Frame */ // Doubt because timestamp updated by local structure at write msg 
											//current_time_stamp = ISO9141_14230_TxMsg_S_Buffer.Timestamp; //Need to check


						hfcpResp_kwp_buf->un.kwp_sendmsg_resp.timestamp = current_time_stamp;

						/* Update the Error Code based on the return */

						hfcpResp_kwp_buf->un.kwp_sendmsg_resp.status = STATUS_NOERROR;


						(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_sendmsg_resp)));

					}

					else {
						/*Do nothing*/

					}
				} else {
					/* ERROR: It should never enter here */

					hfcpResp_kwp_buf->resp_command = KWP_Send_msg_ACK;
					hfcpResp_kwp_buf->un.kwp_sendmsg_resp.seg_num = KWP_buffer->u.kwp_sndmsg.seg_num;
					hfcpResp_kwp_buf->un.kwp_sendmsg_resp.status = ERR_INVALID_PROTOCOL_ID;



					(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_sendmsg_resp)));

				}
				break;
			}
		case Start_msg_filter:
			if ((KWP_buffer->proto_id == KWP_PROTOCOL_ID) || (KWP_buffer->proto_id == ISO_9141_PROTO_ID)) {
				fl_Protocol_ID_U8 = KWP_PROTOCOL_ID;
			}

			/**< Changed for differentiating 14230 and 9141 protocol */
			fl_filter_config.Protocol_ID = fl_Protocol_ID_U8;	/* buffer[0]; */
			fl_filter_config.filterType = (J2534_filterType_t)KWP_buffer->u.kwp_msg_filter.filtertype;
			plv = (lv_t*) (KWP_buffer->u.kwp_msg_filter.buf);
			fl_filter_config.MaskLen =
				hfcp_copy_filter_field(fl_filter_config.maskMsg,
					sizeof(fl_filter_config.maskMsg),
					plv, "KWP mask");

			/* The cast used to bind to the array only, so the
			 * `+ sizeof(plv->len) + plv->len` was pointer arithmetic
			 * on lv_t * rather than on the byte pointer.  It worked
			 * only because sizeof(lv_t) happens to be 1.
			 */
			plv = (lv_t*) ((KWP_buffer->u.kwp_msg_filter.buf)
					+ sizeof(plv->len) + plv->len);
			fl_filter_config.PatternLen =
				hfcp_copy_filter_field(fl_filter_config.patternMsg,
					sizeof(fl_filter_config.patternMsg),
					plv, "KWP pattern");

			fl_filt_config_status = J2534_ConfigFilter(&fl_filter_config, &fl_FilterID);

			if (fl_filt_config_status != J2534_NO_ERROR) {
				if (fl_filt_config_status == J2534_FLT_NOT_FREE) {
					fl_status_U8 = ERR_EXCEEDED_LIMIT;
				} else {
					fl_status_U8 = ERR_FAILED;
				}

				hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
				hfcpResp_kwp_buf->resp_command = Start_msg_filter_ACK;
				hfcpResp_kwp_buf->un.kwp_msg_filter_resp.status = fl_status_U8;
				hfcpResp_kwp_buf->un.kwp_msg_filter_resp.filterid = fl_FilterID;

				(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_msg_filter_resp)));	


			} else {

				hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
				hfcpResp_kwp_buf->resp_command = Start_msg_filter_ACK;
				hfcpResp_kwp_buf->un.kwp_msg_filter_resp.status = STATUS_NOERROR;
				hfcpResp_kwp_buf->un.kwp_msg_filter_resp.filterid = fl_FilterID;

				(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_msg_filter_resp)));	


			}
			break;


		case Stop_msg_filter:
			if ((KWP_buffer->proto_id == KWP_PROTOCOL_ID) || (KWP_buffer->proto_id == ISO_9141_PROTO_ID)) {
				fl_Protocol_ID_U8 = KWP_PROTOCOL_ID;
			}


			/**< Commented to have a common Id for 9141 and 14230 */
			fl_FilterID = KWP_buffer->u.kwp_stpmsg_filter.filterid;
			fl_filt_stop_status = J2534_ClearFilter(fl_FilterID, fl_Protocol_ID_U8);
			if (fl_filt_stop_status != J2534_NO_ERROR) {
				if (fl_filt_stop_status == J2534_INVLD_FLTID) {
					fl_status_U8 = ERR_INVALID_FILTER_ID;
				} else {
					fl_status_U8 = ERR_FAILED;
				}

				hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
				hfcpResp_kwp_buf->resp_command = Stop_msg_filter_ACK;
				hfcpResp_kwp_buf->un.kwp_stpmsg_filter_resp.status = fl_status_U8;
				hfcpResp_kwp_buf->un.kwp_stpmsg_filter_resp.filterid = fl_FilterID;

				(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_stpmsg_filter_resp)));	


			} else {

				hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
				hfcpResp_kwp_buf->resp_command = Stop_msg_filter_ACK;
				hfcpResp_kwp_buf->un.kwp_stpmsg_filter_resp.status = STATUS_NOERROR;
				hfcpResp_kwp_buf->un.kwp_stpmsg_filter_resp.filterid = fl_FilterID;

				(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_stpmsg_filter_resp)));	

			}
			break;

		case handle_periodic_msg:
			if ((KWP_buffer->proto_id == KWP_PROTOCOL_ID) || (KWP_buffer->proto_id == ISO_9141_PROTO_ID)) {
				fl_Protocol_ID_U8 = KWP_PROTOCOL_ID;
			}


			periodic_msg_cmd = KWP_buffer->u.kwp_periodic_msg.periodic_command;
			j2534_periodic_msg.protocol_id = fl_Protocol_ID_U8;	/* buffer[0]; */

			j2534_periodic_msg.periodicity = KWP_buffer->u.kwp_periodic_msg.periodicity;
			j2534_periodic_msg.prmsg_id = KWP_buffer->u.kwp_periodic_msg.msgid;
			j2534_periodic_msg.proto_msg.tx_flags = KWP_buffer->u.kwp_periodic_msg.tx_flags;

			if ((periodic_msg_cmd == START_NEW_PERIODIC_MSG_TXN) || (periodic_msg_cmd == UPDATE_DATA_TO_MSG_ID)) {
				j2534_periodic_msg.proto_msg.length = KWP_buffer->u.kwp_periodic_msg.msglen;
			} else {
				j2534_periodic_msg.proto_msg.length = 0;
			}

			for (loop_count = 0; loop_count < j2534_periodic_msg.proto_msg.length; loop_count++) {
				j2534_periodic_msg.proto_msg.data[loop_count] = KWP_buffer->u.kwp_periodic_msg.buf[loop_count];
			}

			if (PERIODIC_SUCCESS == PERIODIC_task_msg_cmd(&j2534_periodic_msg, periodic_msg_cmd)) {
				fl_status_U8 = STATUS_NOERROR;
			} else {
				fl_status_U8 = ERR_FAILED;
			}

			hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
			hfcpResp_kwp_buf->resp_command = handle_periodic_msg_ACK;
			hfcpResp_kwp_buf->un.kwp_periodic_msg_resp.status = fl_status_U8;
			hfcpResp_kwp_buf->un.kwp_periodic_msg_resp.per_msg_id = j2534_periodic_msg.prmsg_id;
			(void)host_write((void *) hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_periodic_msg_resp)));	


			break;

		default:
			break;
	}

	free(hfcpResp_kwp_buf);


	return;
}


static void process_KWP_IOCTL_cmd(uint8_t * buffer)
{

	hfcpReq_t *KWP_buffer = (hfcpReq_t*)buffer;  //ch
	uint32_t fl_KWP_par_val_U32;
	uint8_t fl_USB_tx_data_U8A[IN_BUFFER_SIZE];
	J2534_stError_t fl_filt_stopAll_status;
	ISO9141_14230_Cmd_S fl_App_ISO9141_14230Cmd_S;
	ISO9141_14230_Cmd_init_S fl_App_ISO9141_14230Cmd_init_S;

	ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus = NO_ERROR;


	hfcpResp_kwp_t * hfcpResp_kwp_buf = (hfcpResp_kwp_t*)malloc(sizeof(hfcpResp_kwp_t));

	if (hfcpResp_kwp_buf == NULL) {
		DBG("malloc failed");
		return;
	}


	//uint8_t  fl_channel_no_U8;  

	if ((KWP_buffer->proto_id == KWP_PROTOCOL_ID) || (KWP_buffer->proto_id == ISO_9141_PROTO_ID)) {  //ch

		//fl_channel_no_U8 = 1;
	} else {
		//fl_channel_no_U8 = 2;
	}

	hfcpResp_kwp_buf->resp_proto_id = KWP_buffer->proto_id ;
	hfcpResp_kwp_buf->resp_command = IOCTL_COMMAND ;

	/* Determine the Command Structure */
	/* Get the Ioctl ID */
	fl_App_ISO9141_14230Cmd_S.IOCtlId = KWP_buffer->u.kwp_ioctl_req.command_ID;  //ch
	/*Length data ( Only for Fivebaud and Fast Init) */
	fl_App_ISO9141_14230Cmd_S.Length = KWP_buffer->u.kwp_ioctl_req.length;  //ch

	/* Clear All Periodic Messages Command */
	if (clear_all_periodic_msgs == fl_App_ISO9141_14230Cmd_S.IOCtlId) {
		//fl_USB_tx_data_U8A[5] = clear_all_periodic_msgs_ACK; //ch
		hfcpResp_kwp_buf->un.kwp_ioctl_resp.ioctl_ack = clear_all_periodic_msgs_ACK;
		suspend_pmsg(KWP_PROTOCOL_ID);	// buffer[0]);
		/* Suspend all periodic messages */
		hfcpResp_kwp_buf->un.kwp_ioctl_resp.status = STATUS_NOERROR;	/* Error status */   //ch

		(void)host_write((void *)hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_ioctl_resp)));
	}
	/* Clear All Message Filters Command */
	else if (clear_all_msg_filters == fl_App_ISO9141_14230Cmd_S.IOCtlId) {

		hfcpResp_kwp_buf->un.kwp_ioctl_resp.ioctl_ack = clear_all_msg_filters_ACK;	/* ACK for Clear All Filters */  //ch
		fl_filt_stopAll_status = J2534_ClearAllFilter(KWP_PROTOCOL_ID);	//buffer[0]);
		if (fl_filt_stopAll_status == J2534_NO_ERROR) {
			hfcpResp_kwp_buf->un.kwp_ioctl_resp.status = STATUS_NOERROR;	/* Status No_ERROR */    //ch
		} else {
			hfcpResp_kwp_buf->un.kwp_ioctl_resp.status = ERR_FAILED;	/* Failed due to Wrong Protocol ID */  //ch
		}

		(void)host_write((void *)hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_ioctl_resp)));
	} else {
		/* Determine if the IOCtl is GET_CONFIG or SET_CONFIG to check for param id and param val */
		if ((fl_App_ISO9141_14230Cmd_S.IOCtlId == GET_CONFIG)  || (fl_App_ISO9141_14230Cmd_S.IOCtlId == SET_CONFIG) || (fl_App_ISO9141_14230Cmd_S.IOCtlId == CLEAR_RX_BUFFER) || (fl_App_ISO9141_14230Cmd_S.IOCtlId == CLEAR_TX_BUFFER)) {
			/* Parameter ID for Get Config and Setconfig */

			fl_App_ISO9141_14230Cmd_S.ParamId = KWP_buffer->u.kwp_ioctl_req.param_ID; //ch
			/* Copy the Parameter Value */
			if (fl_App_ISO9141_14230Cmd_S.IOCtlId == SET_CONFIG) {

				fl_KWP_par_val_U32 = KWP_buffer->u.kwp_ioctl_req.data;        //ch


			}

			fl_App_ISO9141_14230Cmd_S.pData = &fl_KWP_par_val_U32;

			/* Call the Driver Command function */
			fl_ISO9141_14230RetStatus =  ISO9141_14230_Command(&fl_App_ISO9141_14230Cmd_S);
		}
		/* If IOCtl has no param id and value then assign address of data */
		else {
			//printf("Enter_non_get_set_config\n");
			//fl_App_ISO9141_14230Cmd_S.pData = &buffer[4]; 
			/* Get the Ioctl ID */
			fl_App_ISO9141_14230Cmd_init_S.IOCtlId = KWP_buffer->u.kwp_ioctl_req_init.command_ID;

			/*Length data ( Only for Fivebaud and Fast Init) */
			fl_App_ISO9141_14230Cmd_init_S.Length = KWP_buffer->u.kwp_ioctl_req_init.length; 
			/*get data*/
			fl_App_ISO9141_14230Cmd_init_S.pData  = KWP_buffer->u.kwp_ioctl_req_init.data; 

			fl_ISO9141_14230RetStatus =  ISO9141_14230_Command_init(&fl_App_ISO9141_14230Cmd_init_S);

		}

		/* Determine the response */
		hfcpResp_kwp_buf->un.kwp_ioctl_resp.ioctl_ack = fl_App_ISO9141_14230Cmd_S.IOCtlId;  //ch
		hfcpResp_kwp_buf->un.kwp_ioctl_resp.length = fl_App_ISO9141_14230Cmd_S.Length;   //ch

		/* For Get / Set Config copy the Parameter value and Id to the
		   Response frame */
		if ((fl_App_ISO9141_14230Cmd_S.IOCtlId == GET_CONFIG) || (fl_App_ISO9141_14230Cmd_S.IOCtlId == SET_CONFIG)) {

			hfcpResp_kwp_buf->un.kwp_ioctl_resp.paramId = fl_App_ISO9141_14230Cmd_S.ParamId;                      //ch

			if (fl_App_ISO9141_14230Cmd_S.IOCtlId == GET_CONFIG) {

				hfcpResp_kwp_buf->un.kwp_ioctl_resp.data = fl_KWP_par_val_U32 ;

			}
		}

		/* Update the Error Code based on the return */
		if (fl_ISO9141_14230RetStatus == NO_ERROR) {
			hfcpResp_kwp_buf->un.kwp_ioctl_resp.status = STATUS_NOERROR;                    //ch
		} else if (fl_ISO9141_14230RetStatus == INVALID_COMMAND) {
			hfcpResp_kwp_buf->un.kwp_ioctl_resp.status = ERR_INVALID_IOCTL_ID;              //ch
		} else if (fl_ISO9141_14230RetStatus == INVALID_PARAMETERID) {
			hfcpResp_kwp_buf->un.kwp_ioctl_resp.status = ERR_FAILED;                        //ch
		} else {
			/* Do nothing */
		}

		/* Send the Response only if its not FAST INIT ot FIVE BAUD INIT */
		if ((fl_App_ISO9141_14230Cmd_S.IOCtlId != FAST_INIT) && (fl_App_ISO9141_14230Cmd_S.IOCtlId != FIVE_BAUD_INIT)) {

			(void)host_write((void *)hfcpResp_kwp_buf, ((sizeof(hfcpResp_kwp_t) - sizeof(hfcpResp_kwp_buf->un)) + sizeof(hfcpResp_kwp_buf->un.kwp_ioctl_resp)));
		}
		else
		{

		}
	}
	free(hfcpResp_kwp_buf);
}


void AdressClaimHandler(void)
{
	return;
}

int get_connected_channels(void)
{
	return (l_connected_channel_1 || l_connected_channel_2
			|| l_connected_channel_J1939_1
			|| l_connected_channel_J1939_2 || l_connected_channel_Kline);
}

void clear_connected_channels(void)
{
	return;
}

uint8_t get_CAN_or_ISO(void)
{
	return 0;
}

int get_CAN_or_ISO15756_or_J1939(void)
{
	return CAN_or_ISO15765_J1939;
}

int get_CAN_FD_or_ISO15756_FD(void)
{
	return CAN_FD_or_ISO15765_FD;
}

uint8_t get_CAN1_or_ISO1(void)
{
	return 0;
}

int get_CANCH1_or_ISO15756CH1_or_J1939CH1(void)
{
	return CANCH1_or_ISO15765CH1_J1939CH1;
}

int get_CAN_FDCH1_or_ISO15765_FDCH1(void)
{
	return CAN_FDCH1_or_ISO15765_FDCH1;
}

void hfcp_disable_CAN(void)
{
	return;
}

void HFCP_pauseTask(void)
{
	return;
}

void HFCP_startTask(void)
{
	return;
}

void HFCP_Task_Reset(void)
{
	return;
}

void hfcp_disable_CAN_CH1(void)
{
	return;
}

void suspend_J1939_addressClaim(void)
{
	return;
}

void J1939_AddressClaim_Global_Response(uint8_t * p_pJ2534Msg,
		uint16_t p_MsgLen,
		GARUDA_ChannelNum_t GarudaChannel)
{
	uint8_t loop_cnt;
	struct can_frame frame;
	Mid_API_Status_t fl_Q_Status;

	memset((void *)&frame, 0, sizeof(frame));
	frame.can_id = frame.can_id | 0x18 << 24;
	frame.can_id = frame.can_id | PDU_FORMAT_ADDRESS_CLAIM << 16;
	frame.can_id = frame.can_id | GLOBAL_ADDRESS << 8;
	frame.can_id = frame.can_id | device_claimed_Address << 0;

	frame.can_dlc = p_MsgLen - 4;

	for (loop_cnt = 0; loop_cnt < frame.can_dlc; loop_cnt++) {
		frame.data[loop_cnt] = AdressClaim.nameIdentifier[loop_cnt];
	}

	/* Add To Queue */
	if (GARUDA_J1939_CH1 == GarudaChannel)	//GARUDA_J1939_CH1
	{
		fl_Q_Status = CAN_Mid_Transmit(CAN_CH1, &frame);
	} else if (GARUDA_J1939_CH2 == GarudaChannel) {
		fl_Q_Status = CAN_Mid_Transmit(CAN_CH2, &frame);
	} else {
		/* Do Nothing */
	}
	if (fl_Q_Status == MID_FAIL) {
		/* Queue is Full -- Not Decided the Action next */
	}
}

void process_J1939_command(int *buffer)
{
	return;
}

int get_CAN_CH1_status(void)
{
	return 0;
}

int get_CAN_status(void)
{
	return 0;
}

int get_J1708_status(void)
{
	return 0;
}

int get_ISO9141_or_14230(void)
{
	return 0;
}

void DisconnectAllChanels(void)
{
	return;
}

int get_KWP_status(void)
{
	return 0;
}

/*
 * ------------------------------------------
 * | proto_id | command  | command payload  |
 * | (1 byte) | (1 byte) | (17 bytes)       |
 * ------------------------------------------
 *
 */
int process_doip_command(hfcpReq_t * hfcp)
{
	int ret, len;
	hfcpResp_DOIP_t *resp = (hfcpResp_DOIP_t*)malloc(sizeof(hfcpResp_DOIP_t));


	DBG("Received DoIP cmd %d\n", hfcp->command);
	/*
	   len = sizeof(hfcp->proto_id) + sizeof(hfcp->command);
	   resp = (hfcpResp_t *) ((uint8_t *) hfcp + len);
	 */
	switch (hfcp->command) {
		case DOIP_CLI_CMD_START_SESSION:
			resp->un.status = doip_cli_cmd_start_session(&hfcp->u.start_session);
			break;
		case DOIP_CLI_CMD_ADD_DOIP_SERVER:
			resp->un.status = doip_cli_add_server(&hfcp->u.doip_sadd);
			break;
		case DOIP_CLI_CMD_ADD_NODE:
			resp->un.status = doip_cli_add_node(&hfcp->u.doip_addnode);
			break;
		case DOIP_CLI_CMD_SEND_DIAG_MSG:
			resp->un.status = doip_cli_cmd_send_diag_msg(&hfcp->u.diagmsg);
			break;
		case DOIP_CLI_CMD_SEND_PERIODIC_MSG:
			resp->un.doip_periodic_msg_resp.status = doip_cli_cmd_send_periodic_msg(&hfcp->u.doip_periodic_msg);
			resp->un.doip_periodic_msg_resp.per_msg_id = hfcp->u.doip_periodic_msg.msgid;
			break;
		case DOIP_CLI_CMD_REMOVE_DOIP_SERVER:
			periodic_suspend_pmsg(hfcp->proto_id);	
			resp->un.status = doip_cli_del_server(&hfcp->u.doip_sdel);
			break;
		case DOIP_CLI_CMD_DEL_NODE:
			resp->un.status = doip_cli_del_node(&hfcp->u.doip_delnode);
			break;
		case DOIP_IOCTL_HANDLING:
			resp->un.status = doip_ioctl_handling(&hfcp->u.doipioctl);
			break;
		case DOIP_CLIENT_DETAILS:      
			resp->un.status = doip_client_details(&hfcp->u.doipclient);
			break;
		default:
			DBG("DoIP cmd - unhandled");
			resp->un.status = ERR_NOT_SUPPORTED;
			break;
	}

	resp->resp_proto_id = hfcp->proto_id;
	resp->resp_command = hfcp->command; 
	//	len += sizeof(resp->status);
	ret = host_write((void *)resp, sizeof(hfcpResp_DOIP_t));
	if (ret <= 0) {
		DBG("USB write failed: %s", strerror(errno));
	}
	free(resp);
	return ret;
}

int Firmware_Update_command(uint8_t *buff, int len)
{
	uint8_t segment = 0;
	FirmwareUpgrade_t *Firmware = &buffer_t.f_buffer;
	size_t result;

	FirmwareHost_t *firmwaredetails;
	firmwaredetails = (FirmwareHost_t *)buff;

	const char *dest_path = "/tmp/g3update-M.m.n.tgz";
	static FILE *file = NULL;

	if (file == NULL) {
		file = fopen(dest_path, "ab");
		if (file == NULL) {
			perror("ERROR opening file");
			return EXIT_FAILURE;
		}
	}

	DBG("segment %d\n",firmwaredetails->seg_number);
	DBG("length %d\n", firmwaredetails->length);
	segment = firmwaredetails->seg_number;
	if (segment == 1) {
		buffer_t.pkt_number++;
		Firmware->length = firmwaredetails->length;
		Firmware->pkt_number = firmwaredetails->pkt_number;
		DBG("pkt_number %d\n", Firmware->pkt_number);
		if (Firmware->pkt_number == 1) {
			buffer_t.pkt_number = 1;
			buffer_t.is_ready_to_write = 0;
		}
	}

	static int seg_data_size = 110;
	if (segment == 1 && Firmware->pkt_number == 1) {
		seg_data_size = (Firmware->length > 256) ? 110 : 55;
	}

	/*
	 * Firmware->length is a uint16_t taken straight from the host, while
	 * Firmware->buffer is a fixed 512-byte array.  The two memcpy()s below
	 * are driven entirely by length/index with no bound of their own, so a
	 * host claiming length > 512 walked past the end of buffer_t.
	 */
	if (Firmware->length > sizeof(Firmware->buffer)) {
		ERR("Firmware packet length %u exceeds %zu-byte buffer - aborting",
				Firmware->length, sizeof(Firmware->buffer));
		fclose(file);
		file = NULL;
		Firmware->index = 0;
		buffer_t.is_ready_to_write = 0;
		return -1;
	}

	if (Firmware->index >= Firmware->length) {
		ERR("Firmware index %u past length %u - aborting",
				Firmware->index, Firmware->length);
		fclose(file);
		file = NULL;
		Firmware->index = 0;
		buffer_t.is_ready_to_write = 0;
		return -1;
	}

	if ((Firmware->length - Firmware->index) > seg_data_size) {
		DBG("length %d\n", Firmware->length);
		DBG("index %d\n", Firmware->index);
		DBG("index %d\n", firmwaredetails->index);
		memcpy(&Firmware->buffer[Firmware->index],&firmwaredetails->index[0],seg_data_size);
		Firmware->index += seg_data_size;
		len -= seg_data_size;
		DBG("length %d\n", Firmware->length);
		DBG("index %d\n", Firmware->index);
		DBG("loop %d\n",(Firmware->length - Firmware->index));
	} else {
		memcpy(&Firmware->buffer[Firmware->index], &firmwaredetails->index[0],
				Firmware->length - Firmware->index);
		len -= (Firmware->length - Firmware->index);
		Firmware->index += Firmware->length;
		buffer_t.is_ready_to_write = 1;
	}

	if (buffer_t.is_ready_to_write) {
		buffer_t.is_ready_to_write = 0;
		if (Firmware->pkt_number != buffer_t.pkt_number) {
			fclose(file);
			file = NULL;
			return -1;
		}

		result = fwrite(Firmware->buffer, 1, Firmware->length,file);
		DBG("result %zu\n", result);
		DBG("firmware_length %d\n", Firmware->length);
		/* Dump what was actually written, not a blanket 512 bytes */
		hexdump("buffer", Firmware->buffer, Firmware->length, 1);
		if (result != Firmware->length) {
			perror("error writing to file");	   
			fclose(file);
			file = NULL;
			return EXIT_FAILURE;
		}

		Firmware->index = 0;

		fclose(file);
		file = NULL;
		return 1;
	}

	return 0;	
}
int FileToDelete(void)
{

	const char *fileToDelete = "/tmp/g3update-M.m.n.tgz";

	/* unlink() instead of system("rm ...") - no shell, no fork, no PATH
	 * lookup, and no chance of the path being reinterpreted by sh.
	 */
	if (unlink(fileToDelete) < 0 && errno != ENOENT) {
		ERR("Cannot remove %s: %s", fileToDelete, strerror(errno));
	}

	const char *script_path = "/usr/sbin/candown.sh";

	mode_t mode = S_IRWXU | S_IRWXG | S_IRWXO;

	if (chmod(script_path, mode) == -1) {
		perror("chmod");
		return -1;
	}

	int ret = system(script_path);
	if (ret == -1) {
		perror("system");
		return -1;
	}

	return 0;
}

int Firmware_Update_Script(void)
{
	const char *script_path = "/usr/sbin/fwupdate.sh";

	mode_t mode = S_IRWXU | S_IRWXG | S_IRWXO;

	if (chmod(script_path, mode) == -1) {
		perror("chmod");
		return -1;
	}

	int ret = system(script_path);
	if (ret == -1) {
		perror("system");
		return -1;
	}

	return 0;	
}

int Create_Bridge(void)
{
	const char *script_path = "/usr/sbin/usbbridge.sh";

	mode_t mode = S_IRWXU | S_IRWXG | S_IRWXO;

	if (chmod(script_path, mode) == -1) {
		perror("chmod");
		return -1;
	}

	int ret = system(script_path);
	if (ret == -1) {
		perror("system");
		return -1;
	}

	return 0;	
}

int Disable_Bridge(void)
{
	const char *script_path = "/usr/sbin/Disablebridge.sh";

	mode_t mode = S_IRWXU | S_IRWXG | S_IRWXO;

	if (chmod(script_path, mode) == -1) {
		perror("chmod");
		return -1;
	}

	int ret = system(script_path);
	if (ret == -1) {
		perror("system");
		return -1;
	}

	return 0 ;
}

int ReadBatteryVoltage(uint16_t *BatVg)
{
	const char *adcRawPath = "/sys/bus/iio/devices/iio:device0/in_voltage4_raw";
	const char *adcScalePath = "/sys/bus/iio/devices/iio:device0/in_voltage_scale";

	FILE *fp;
	uint32_t adc_raw;
	uint32_t adc_sum = 0;
	float scale;
	float voltage;

	if (BatVg == NULL)
		return 0;

	/* Read scale value.
	 *
	 * The fscanf() return values used to be ignored, so a short or
	 * malformed sysfs read left `scale` / `adc_raw` holding uninitialised
	 * stack data and the daemon reported a garbage battery voltage to the
	 * diagnostic host.
	 */
	fp = fopen(adcScalePath, "r");
	if (!fp)
		return 0;
	if (fscanf(fp, "%f", &scale) != 1) {
		ERR("Cannot parse %s", adcScalePath);
		fclose(fp);
		return 0;
	}
	fclose(fp);

	/* Read ADC raw samples */
	for (int i = 0; i < ADC_SAMPLE_CNT; i++)
	{
		fp = fopen(adcRawPath, "r");
		if (!fp)
			return 0;

		if (fscanf(fp, "%u", &adc_raw) != 1) {
			ERR("Cannot parse %s", adcRawPath);
			fclose(fp);
			return 0;
		}
		fclose(fp);

		adc_sum += adc_raw;
	}
	adc_raw = adc_sum / ADC_SAMPLE_CNT;
	/* Convert to voltage (Volts) */
	voltage = adc_raw * scale * VOLT_DIVISOR;
	*BatVg =(uint16_t)voltage;
	return 1;
}


ssize_t host_write(const void *buf,size_t count)
{
	if(HFCPComMode == HFCP_COM_MODE_USB) {
		DBG("Garuda in USB HFCPComMode");
		led_set(LED_USB_LED, LED_OFF);//REVC
		led_set(LED_USB_LED, LED_ON);
		led_set(LED_WLANBT_LED, LED_OFF);
		return usbhid_write(buf,count);
	}
	else if(HFCPComMode == HFCP_COM_MODE_WIFI) {
		DBG("Garuda in WiFi HFCPComMode.");
		led_set(LED_USB_LED, LED_OFF);
		led_set(LED_WLANBT_LED, LED_OFF);
		led_set(LED_WLANBT_LED, LED_ON);
		return net_if_write(buf,HFCP_PKT_SIZE);
	}
	else if(HFCPComMode == HFCP_COM_MODE_BT) {
		DBG("Garuda in BT HFCPComMode.");
		led_set(LED_USB_LED, LED_OFF);
		led_set(LED_WLANBT_LED, LED_OFF);
		led_set(LED_WLANBT_LED, LED_ON);
		/* The hexdump() used to sit *after* the return and so never ran */
		hexdump("host_write:", (void *)buf, (int)count, 1);
		return bt_spp_write(buf,count);
	}
	else {
		/* Error Condition.*/
		DBG("Garuda in ERROR HFCPComMode");
		led_set(LED_USB_LED, LED_OFF);
		led_set(LED_USB_LED, LED_ON);
		led_set(LED_WLANBT_LED, LED_OFF);
		return 0;
	}
}

int handle_hfcp_rx(uint8_t * buf, int length)
{
	hfcpReq_t *hfcp = (hfcpReq_t *) buf;
	hfcpResp_t *pAck = NULL;
	int ret;
	DBG("proto_id %d\n", hfcp->proto_id);
	switch (hfcp->proto_id) {
		case SESSION_MANAGEMENT:
			DBG("SESSION_MANAGEMENT");
			process_session_mgmt_command((uint8_t *) hfcp);
			break;
		case CAN_PROTOCOL_ID:
		case CAN_CH1_PROTO_ID:
		case ISO15765_PROTO_ID:
		case ISO15765_CH1_PROTO_ID:
			DBG("CAN_PROTOCOL_ID");
			process_CAN_command(buf);
			break;
		case CAN_FD_PROTOCOL_ID:
		case ISO15765_FD_PROTO_ID:
		case CAN_FD_CH1_PROTO_ID:
		case ISO15765_FD_CH1_PROTO_ID:
		case CAN_FD_PS:
			DBG("CAN_FD_PROTOCOL_ID");
			process_CAN_FD_command(buf);
			break;
		case KWP_PROTOCOL_ID:
		case ISO_9141_PROTO_ID:
			//	process_KWP_command(&data_read[0]);
			process_KWP_command(buf);
			break;
		case J1708_PROTOCOL_ID:
			break;
		case SETUP_CMD_ID:
			DBG("SETUP_CMD_ID");
			process_Setup_command((uint8_t *) hfcp);
			break;
		case FIRMWARE_UPGRADE_MODE:
			DBG("Firmware_Upgrade");
			ret = Firmware_Update_command(buf, USB_PKT_SIZE);

			if (ret < 0) {
				FileToDelete();
				pAck = (hfcpResp_t *) (&(hfcp->u));
				pAck->status = ERR_NOT_SUPPORTED;
				if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0) {
					DBG("write failed: %s", strerror(errno));
				}
			} else if (ret == 1) {
				pAck = (hfcpResp_t *) (&(hfcp->u));
				pAck->status = STATUS_NOERROR;
				if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0) {
					DBG("write failed: %s", strerror(errno));
				}
			}
			break;
		case FIRMWARE_SCRIPT:
			ret = Firmware_Update_Script();                		
			pAck = (hfcpResp_t *) (&(hfcp->u));
			if (ret < 0 ){
				pAck->status = ERR_NOT_SUPPORTED;
			} else {
				pAck->status = STATUS_NOERROR;
			}
			if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0){
				DBG("write faile: %s", strerror(errno));
			}		    
			break;
		case TMP_FILE_DELETE:
			ret = FileToDelete();
			pAck = (hfcpResp_t *) (&(hfcp->u));
			if (ret < 0 ){
				pAck->status = ERR_NOT_SUPPORTED;
			} else {
				pAck->status = STATUS_NOERROR;
			}
			if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0){
				DBG("write faile: %s", strerror(errno));
			}		    
			break;
		case Enable_RNDIS:
			ret = Create_Bridge();
			pAck = (hfcpResp_t *) (&(hfcp->u));
			if (ret < 0 ){
				pAck->status = ERR_NOT_SUPPORTED;
			} else {
				pAck->status = STATUS_NOERROR;
			}
			if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0){
				DBG("write faile: %s", strerror(errno));
			}		    
			break;
		case Disable_RNDIS:
			ret = Disable_Bridge();
			pAck = (hfcpResp_t *) (&(hfcp->u));
			if (ret < 0 ){
				pAck->status = ERR_NOT_SUPPORTED;
			} else {
				pAck->status = STATUS_NOERROR;
			}
			if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0){
				DBG("write faile: %s", strerror(errno));
			}		    
			break;	        	
		case J1939_PROTOCOL_ID:
		case J1939_CH1_PROTOCOL_ID:
			//process_J1939_command(&data_read[0]);
			break;
		case DOIP_PROTOCOL_ID:
			process_doip_command(hfcp);
			break;
		default:
			DBG("NOT_SUPPORTED");
			pAck = (hfcpResp_t *) (&(hfcp->u));
			pAck->status = ERR_NOT_SUPPORTED;
			if (host_write((void *)hfcp, USB_PKT_SIZE) <= 0) {
				DBG("Write failed: %s", strerror(errno));
			}
	}

	return 0;
}
